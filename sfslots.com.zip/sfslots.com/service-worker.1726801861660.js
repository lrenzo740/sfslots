if (!self.define) {
    let e, i = {};
    const n = (n, o) => (n = new URL(n + ".js", o).href, i[n] || new Promise((i => {
        if ("document" in self) {
            const e = document.createElement("script");
            e.src = n, e.onload = i, document.head.appendChild(e)
        } else e = n, importScripts(n), i()
    })).then((() => {
        let e = i[n];
        if (!e) throw new Error(`Module ${n} didn’t register its module`);
        return e
    })));
    self.define = (o, r) => {
        const s = e || ("document" in self ? document.currentScript.src : "") || location.href;
        if (i[s]) return;
        let t = {};
        const c = e => n(e, s),
            f = {
                module: {
                    uri: s
                },
                exports: t,
                require: c
            };
        i[s] = Promise.all(o.map((e => f[e] || c(e)))).then((e => (r(...e), t)))
    }
}
define(["./workbox-1ab968a5"], (function(e) {
    "use strict";
    self.skipWaiting(), e.clientsClaim(), e.precacheAndRoute([{
        url: "img/common/default_mini_2.svg",
        revision: "4f4aac520ba0bd570b802de483739c20"
    }, {
        url: "img/favicon.ico",
        revision: "35c895b6eddd3f9be1b5a703391a5fbd"
    }, {
        url: "svg/loading.9e67d630.svg",
        revision: "a1e86f038e7db48ad3c6dc0dc17e8720"
    }, {
        url: "img/icon_512.png",
        revision: "7e12ff75739c75a852504e415beb88f9"
    }, {
        url: "manifest.webmanifest",
        revision: "1bf30fa3270c2414a54f20c3aa5366e2"
    }], {}), e.cleanupOutdatedCaches()
}));