import {
    a as w
} from "./clipboard.f53621db.js";

function y(f, r) {
    for (var d = 0; d < r.length; d++) {
        const a = r[d];
        if (typeof a != "string" && !Array.isArray(a)) {
            for (const s in a)
                if (s !== "default" && !(s in f)) {
                    const p = Object.getOwnPropertyDescriptor(a, s);
                    p && Object.defineProperty(f, s, p.get ? p : {
                        enumerable: !0,
                        get: () => a[s]
                    })
                }
        }
    }
    return Object.freeze(Object.defineProperty(f, Symbol.toStringTag, {
        value: "Module"
    }))
}
var k = {
    exports: {}
};
(function(f) {
    (function() {
        /**
         * @preserve FastClick: polyfill to remove click delays on browsers with touch UIs.
         *
         * @codingstandard ftlabs-jsv2
         * @copyright The Financial Times Limited [All Rights Reserved]
         * @license MIT License (see LICENSE.txt)
         */
        function r(t, e) {
            var n;
            if (e = e || {}, this.trackingClick = !1, this.trackingClickStart = 0, this.targetElement = null, this.touchStartX = 0, this.touchStartY = 0, this.lastTouchIdentifier = 0, this.touchBoundary = e.touchBoundary || 10, this.layer = t, this.tapDelay = e.tapDelay || 200, this.tapTimeout = e.tapTimeout || 700, r.notNeeded(t)) return;

            function i(u, l) {
                return function() {
                    return u.apply(l, arguments)
                }
            }
            for (var c = ["onMouse", "onClick", "onTouchStart", "onTouchMove", "onTouchEnd", "onTouchCancel"], h = this, o = 0, S = c.length; o < S; o++) h[c[o]] = i(h[c[o]], h);
            a && (t.addEventListener("mouseover", this.onMouse, !0), t.addEventListener("mousedown", this.onMouse, !0), t.addEventListener("mouseup", this.onMouse, !0)), t.addEventListener("click", this.onClick, !0), t.addEventListener("touchstart", this.onTouchStart, !1), t.addEventListener("touchmove", this.onTouchMove, !1), t.addEventListener("touchend", this.onTouchEnd, !1), t.addEventListener("touchcancel", this.onTouchCancel, !1), Event.prototype.stopImmediatePropagation || (t.removeEventListener = function(u, l, m) {
                var g = Node.prototype.removeEventListener;
                u === "click" ? g.call(t, u, l.hijacked || l, m) : g.call(t, u, l, m)
            }, t.addEventListener = function(u, l, m) {
                var g = Node.prototype.addEventListener;
                u === "click" ? g.call(t, u, l.hijacked || (l.hijacked = function(v) {
                    v.propagationStopped || l(v)
                }), m) : g.call(t, u, l, m)
            }), typeof t.onclick == "function" && (n = t.onclick, t.addEventListener("click", function(u) {
                n(u)
            }, !1), t.onclick = null)
        }
        var d = navigator.userAgent.indexOf("Windows Phone") >= 0,
            a = navigator.userAgent.indexOf("Android") > 0 && !d,
            s = /iP(ad|hone|od)/.test(navigator.userAgent) && !d,
            p = s && /OS 4_\d(_\d)?/.test(navigator.userAgent),
            E = s && /OS [6-7]_\d/.test(navigator.userAgent),
            T = navigator.userAgent.indexOf("BB10") > 0;
        r.prototype.needsClick = function(t) {
            switch (t.nodeName.toLowerCase()) {
                case "button":
                case "select":
                case "textarea":
                    if (t.disabled) return !0;
                    break;
                case "input":
                    if (s && t.type === "file" || t.disabled) return !0;
                    break;
                case "label":
                case "iframe":
                case "video":
                    return !0
            }
            return /\bneedsclick\b/.test(t.className)
        }, r.prototype.needsFocus = function(t) {
            switch (t.nodeName.toLowerCase()) {
                case "textarea":
                    return !0;
                case "select":
                    return !a;
                case "input":
                    switch (t.type) {
                        case "button":
                        case "checkbox":
                        case "file":
                        case "image":
                        case "radio":
                        case "submit":
                            return !1
                    }
                    return !t.disabled && !t.readOnly;
                default:
                    return /\bneedsfocus\b/.test(t.className)
            }
        }, r.prototype.sendClick = function(t, e) {
            var n, i;
            document.activeElement && document.activeElement !== t && document.activeElement.blur(), i = e.changedTouches[0], n = document.createEvent("MouseEvents"), n.initMouseEvent(this.determineEventType(t), !0, !0, window, 1, i.screenX, i.screenY, i.clientX, i.clientY, !1, !1, !1, !1, 0, null), n.forwardedTouchEvent = !0, t.dispatchEvent(n)
        }, r.prototype.determineEventType = function(t) {
            return a && t.tagName.toLowerCase() === "select" ? "mousedown" : "click"
        }, r.prototype.focus = function(t) {
            var e;
            s && t.setSelectionRange && t.type.indexOf("date") !== 0 && t.type !== "time" && t.type !== "month" ? (e = t.value.length, t.setSelectionRange(e, e)) : t.focus()
        }, r.prototype.updateScrollParent = function(t) {
            var e, n;
            if (e = t.fastClickScrollParent, !e || !e.contains(t)) {
                n = t;
                do {
                    if (n.scrollHeight > n.offsetHeight) {
                        e = n, t.fastClickScrollParent = n;
                        break
                    }
                    n = n.parentElement
                } while (n)
            }
            e && (e.fastClickLastScrollTop = e.scrollTop)
        }, r.prototype.getTargetElementFromEventTarget = function(t) {
            return t.nodeType === Node.TEXT_NODE ? t.parentNode : t
        }, r.prototype.onTouchStart = function(t) {
            var e, n, i;
            if (t.targetTouches.length > 1) return !0;
            if (e = this.getTargetElementFromEventTarget(t.target), n = t.targetTouches[0], s) {
                if (i = window.getSelection(), i.rangeCount && !i.isCollapsed) return !0;
                if (!p) {
                    if (n.identifier && n.identifier === this.lastTouchIdentifier) return t.preventDefault(), !1;
                    this.lastTouchIdentifier = n.identifier, this.updateScrollParent(e)
                }
            }
            return this.trackingClick = !0, this.trackingClickStart = t.timeStamp, this.targetElement = e, this.touchStartX = n.pageX, this.touchStartY = n.pageY, t.timeStamp - this.lastClickTime < this.tapDelay && t.preventDefault(), !0
        }, r.prototype.touchHasMoved = function(t) {
            var e = t.changedTouches[0],
                n = this.touchBoundary;
            return Math.abs(e.pageX - this.touchStartX) > n || Math.abs(e.pageY - this.touchStartY) > n
        }, r.prototype.onTouchMove = function(t) {
            return this.trackingClick && (this.targetElement !== this.getTargetElementFromEventTarget(t.target) || this.touchHasMoved(t)) && (this.trackingClick = !1, this.targetElement = null), !0
        }, r.prototype.findControl = function(t) {
            return t.control !== void 0 ? t.control : t.htmlFor ? document.getElementById(t.htmlFor) : t.querySelector("button, input:not([type=hidden]), keygen, meter, output, progress, select, textarea")
        }, r.prototype.onTouchEnd = function(t) {
            var e, n, i, c, h, o = this.targetElement;
            if (!this.trackingClick) return !0;
            if (t.timeStamp - this.lastClickTime < this.tapDelay) return this.cancelNextClick = !0, !0;
            if (t.timeStamp - this.trackingClickStart > this.tapTimeout) return !0;
            if (this.cancelNextClick = !1, this.lastClickTime = t.timeStamp, n = this.trackingClickStart, this.trackingClick = !1, this.trackingClickStart = 0, E && (h = t.changedTouches[0], o = document.elementFromPoint(h.pageX - window.pageXOffset, h.pageY - window.pageYOffset) || o, o.fastClickScrollParent = this.targetElement.fastClickScrollParent), i = o.tagName.toLowerCase(), i === "label") {
                if (e = this.findControl(o), e) {
                    if (this.focus(o), a) return !1;
                    o = e
                }
            } else if (this.needsFocus(o)) return t.timeStamp - n > 100 || s && window.top !== window && i === "input" ? (this.targetElement = null, !1) : (this.focus(o), this.sendClick(o, t), (!s || i !== "select") && (this.targetElement = null, t.preventDefault()), !1);
            return s && !p && (c = o.fastClickScrollParent, c && c.fastClickLastScrollTop !== c.scrollTop) ? !0 : (this.needsClick(o) || (t.preventDefault(), this.sendClick(o, t)), !1)
        }, r.prototype.onTouchCancel = function() {
            this.trackingClick = !1, this.targetElement = null
        }, r.prototype.onMouse = function(t) {
            return !this.targetElement || t.forwardedTouchEvent || !t.cancelable ? !0 : !this.needsClick(this.targetElement) || this.cancelNextClick ? (t.stopImmediatePropagation ? t.stopImmediatePropagation() : t.propagationStopped = !0, t.stopPropagation(), t.preventDefault(), !1) : !0
        }, r.prototype.onClick = function(t) {
            var e;
            return this.trackingClick ? (this.targetElement = null, this.trackingClick = !1, !0) : t.target.type === "submit" && t.detail === 0 ? !0 : (e = this.onMouse(t), e || (this.targetElement = null), e)
        }, r.prototype.destroy = function() {
            var t = this.layer;
            a && (t.removeEventListener("mouseover", this.onMouse, !0), t.removeEventListener("mousedown", this.onMouse, !0), t.removeEventListener("mouseup", this.onMouse, !0)), t.removeEventListener("click", this.onClick, !0), t.removeEventListener("touchstart", this.onTouchStart, !1), t.removeEventListener("touchmove", this.onTouchMove, !1), t.removeEventListener("touchend", this.onTouchEnd, !1), t.removeEventListener("touchcancel", this.onTouchCancel, !1)
        }, r.notNeeded = function(t) {
            var e, n, i, c;
            if (typeof window.ontouchstart > "u") return !0;
            if (n = +(/Chrome\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1], n)
                if (a) {
                    if (e = document.querySelector("meta[name=viewport]"), e && (e.content.indexOf("user-scalable=no") !== -1 || n > 31 && document.documentElement.scrollWidth <= window.outerWidth)) return !0
                } else return !0;
            return !!(T && (i = navigator.userAgent.match(/Version\/([0-9]*)\.([0-9]*)/), i[1] >= 10 && i[2] >= 3 && (e = document.querySelector("meta[name=viewport]"), e && (e.content.indexOf("user-scalable=no") !== -1 || document.documentElement.scrollWidth <= window.outerWidth))) || t.style.msTouchAction === "none" || t.style.touchAction === "manipulation" || (c = +(/Firefox\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1], c >= 27 && (e = document.querySelector("meta[name=viewport]"), e && (e.content.indexOf("user-scalable=no") !== -1 || document.documentElement.scrollWidth <= window.outerWidth))) || t.style.touchAction === "none" || t.style.touchAction === "manipulation")
        }, r.attach = function(t, e) {
            return new r(t, e)
        }, f.exports ? (f.exports = r.attach, f.exports.FastClick = r) : window.FastClick = r
    })()
})(k);
var C = k.exports;
const x = w(C),
    b = y({
        __proto__: null,
        default: x
    }, [C]);
export {
    b as f
};