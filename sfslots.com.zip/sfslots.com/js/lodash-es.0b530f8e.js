var Wt = typeof global == "object" && global && global.Object === Object && global;
const jt = Wt;
var Xt = typeof self == "object" && self && self.Object === Object && self,
    qt = jt || Xt || Function("return this")();
const $ = qt;
var Yt = $.Symbol;
const m = Yt;
var It = Object.prototype,
    Zt = It.hasOwnProperty,
    Jt = It.toString,
    F = m ? m.toStringTag : void 0;

function Qt(t) {
    var e = Zt.call(t, F),
        r = t[F];
    try {
        t[F] = void 0;
        var n = !0
    } catch {}
    var i = Jt.call(t);
    return n && (e ? t[F] = r : delete t[F]), i
}
var Vt = Object.prototype,
    kt = Vt.toString;

function te(t) {
    return kt.call(t)
}
var ee = "[object Null]",
    re = "[object Undefined]",
    it = m ? m.toStringTag : void 0;

function L(t) {
    return t == null ? t === void 0 ? re : ee : it && it in Object(t) ? Qt(t) : te(t)
}

function M(t) {
    return t != null && typeof t == "object"
}
var ne = "[object Symbol]";

function W(t) {
    return typeof t == "symbol" || M(t) && L(t) == ne
}

function ae(t, e) {
    for (var r = -1, n = t == null ? 0 : t.length, i = Array(n); ++r < n;) i[r] = e(t[r], r, t);
    return i
}
var ie = Array.isArray;
const E = ie;
var oe = 1 / 0,
    ot = m ? m.prototype : void 0,
    st = ot ? ot.toString : void 0;

function Ct(t) {
    if (typeof t == "string") return t;
    if (E(t)) return ae(t, Ct) + "";
    if (W(t)) return st ? st.call(t) : "";
    var e = t + "";
    return e == "0" && 1 / t == -oe ? "-0" : e
}
var se = /\s/;

function fe(t) {
    for (var e = t.length; e-- && se.test(t.charAt(e)););
    return e
}
var ue = /^\s+/;

function ce(t) {
    return t && t.slice(0, fe(t) + 1).replace(ue, "")
}

function R(t) {
    var e = typeof t;
    return t != null && (e == "object" || e == "function")
}
var ft = 0 / 0,
    le = /^[-+]0x[0-9a-f]+$/i,
    pe = /^0b[01]+$/i,
    ge = /^0o[0-7]+$/i,
    de = parseInt;

function ut(t) {
    if (typeof t == "number") return t;
    if (W(t)) return ft;
    if (R(t)) {
        var e = typeof t.valueOf == "function" ? t.valueOf() : t;
        t = R(e) ? e + "" : e
    }
    if (typeof t != "string") return t === 0 ? t : +t;
    t = ce(t);
    var r = pe.test(t);
    return r || ge.test(t) ? de(t.slice(2), r ? 2 : 8) : le.test(t) ? ft : +t
}
var he = "[object AsyncFunction]",
    ye = "[object Function]",
    _e = "[object GeneratorFunction]",
    be = "[object Proxy]";

function Mt(t) {
    if (!R(t)) return !1;
    var e = L(t);
    return e == ye || e == _e || e == he || e == be
}
var ve = $["__core-js_shared__"];
const Y = ve;
var ct = function() {
    var t = /[^.]+$/.exec(Y && Y.keys && Y.keys.IE_PROTO || "");
    return t ? "Symbol(src)_1." + t : ""
}();

function Te(t) {
    return !!ct && ct in t
}
var me = Function.prototype,
    $e = me.toString;

function I(t) {
    if (t != null) {
        try {
            return $e.call(t)
        } catch {}
        try {
            return t + ""
        } catch {}
    }
    return ""
}
var Ae = /[\\^$.*+?()[\]{}|]/g,
    Oe = /^\[object .+?Constructor\]$/,
    we = Function.prototype,
    Se = Object.prototype,
    Pe = we.toString,
    Ee = Se.hasOwnProperty,
    xe = RegExp("^" + Pe.call(Ee).replace(Ae, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");

function je(t) {
    if (!R(t) || Te(t)) return !1;
    var e = Mt(t) ? xe : Oe;
    return e.test(I(t))
}

function Ie(t, e) {
    return t ? .[e]
}

function D(t, e) {
    var r = Ie(t, e);
    return je(r) ? r : void 0
}
var Ce = D($, "WeakMap");
const V = Ce;
var Me = 9007199254740991,
    Re = /^(?:0|[1-9]\d*)$/;

function Le(t, e) {
    var r = typeof t;
    return e = e ? ? Me, !!e && (r == "number" || r != "symbol" && Re.test(t)) && t > -1 && t % 1 == 0 && t < e
}

function Rt(t, e) {
    return t === e || t !== t && e !== e
}
var De = 9007199254740991;

function Lt(t) {
    return typeof t == "number" && t > -1 && t % 1 == 0 && t <= De
}

function Ne(t) {
    return t != null && Lt(t.length) && !Mt(t)
}
var Fe = Object.prototype;

function Ue(t) {
    var e = t && t.constructor,
        r = typeof e == "function" && e.prototype || Fe;
    return t === r
}

function Ge(t, e) {
    for (var r = -1, n = Array(t); ++r < t;) n[r] = e(r);
    return n
}
var ze = "[object Arguments]";

function lt(t) {
    return M(t) && L(t) == ze
}
var Dt = Object.prototype,
    Be = Dt.hasOwnProperty,
    He = Dt.propertyIsEnumerable,
    Ke = lt(function() {
        return arguments
    }()) ? lt : function(t) {
        return M(t) && Be.call(t, "callee") && !He.call(t, "callee")
    };
const Nt = Ke;

function We() {
    return !1
}
var Ft = typeof exports == "object" && exports && !exports.nodeType && exports,
    pt = Ft && typeof module == "object" && module && !module.nodeType && module,
    Xe = pt && pt.exports === Ft,
    gt = Xe ? $.Buffer : void 0,
    qe = gt ? gt.isBuffer : void 0,
    Ye = qe || We;
const k = Ye;
var Ze = "[object Arguments]",
    Je = "[object Array]",
    Qe = "[object Boolean]",
    Ve = "[object Date]",
    ke = "[object Error]",
    tr = "[object Function]",
    er = "[object Map]",
    rr = "[object Number]",
    nr = "[object Object]",
    ar = "[object RegExp]",
    ir = "[object Set]",
    or = "[object String]",
    sr = "[object WeakMap]",
    fr = "[object ArrayBuffer]",
    ur = "[object DataView]",
    cr = "[object Float32Array]",
    lr = "[object Float64Array]",
    pr = "[object Int8Array]",
    gr = "[object Int16Array]",
    dr = "[object Int32Array]",
    hr = "[object Uint8Array]",
    yr = "[object Uint8ClampedArray]",
    _r = "[object Uint16Array]",
    br = "[object Uint32Array]",
    c = {};
c[cr] = c[lr] = c[pr] = c[gr] = c[dr] = c[hr] = c[yr] = c[_r] = c[br] = !0;
c[Ze] = c[Je] = c[fr] = c[Qe] = c[ur] = c[Ve] = c[ke] = c[tr] = c[er] = c[rr] = c[nr] = c[ar] = c[ir] = c[or] = c[sr] = !1;

function vr(t) {
    return M(t) && Lt(t.length) && !!c[L(t)]
}

function Tr(t) {
    return function(e) {
        return t(e)
    }
}
var Ut = typeof exports == "object" && exports && !exports.nodeType && exports,
    U = Ut && typeof module == "object" && module && !module.nodeType && module,
    mr = U && U.exports === Ut,
    Z = mr && jt.process,
    $r = function() {
        try {
            var t = U && U.require && U.require("util").types;
            return t || Z && Z.binding && Z.binding("util")
        } catch {}
    }();
const dt = $r;
var ht = dt && dt.isTypedArray,
    Ar = ht ? Tr(ht) : vr;
const Gt = Ar;
var Or = Object.prototype,
    wr = Or.hasOwnProperty;

function Sr(t, e) {
    var r = E(t),
        n = !r && Nt(t),
        i = !r && !n && k(t),
        a = !r && !n && !i && Gt(t),
        s = r || n || i || a,
        o = s ? Ge(t.length, String) : [],
        u = o.length;
    for (var f in t)(e || wr.call(t, f)) && !(s && (f == "length" || i && (f == "offset" || f == "parent") || a && (f == "buffer" || f == "byteLength" || f == "byteOffset") || Le(f, u))) && o.push(f);
    return o
}

function Pr(t, e) {
    return function(r) {
        return t(e(r))
    }
}
var Er = Pr(Object.keys, Object);
const xr = Er;
var jr = Object.prototype,
    Ir = jr.hasOwnProperty;

function Cr(t) {
    if (!Ue(t)) return xr(t);
    var e = [];
    for (var r in Object(t)) Ir.call(t, r) && r != "constructor" && e.push(r);
    return e
}

function Mr(t) {
    return Ne(t) ? Sr(t) : Cr(t)
}
var Rr = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    Lr = /^\w*$/;

function Dr(t, e) {
    if (E(t)) return !1;
    var r = typeof t;
    return r == "number" || r == "symbol" || r == "boolean" || t == null || W(t) ? !0 : Lr.test(t) || !Rr.test(t) || e != null && t in Object(e)
}
var Nr = D(Object, "create");
const G = Nr;

function Fr() {
    this.__data__ = G ? G(null) : {}, this.size = 0
}

function Ur(t) {
    var e = this.has(t) && delete this.__data__[t];
    return this.size -= e ? 1 : 0, e
}
var Gr = "__lodash_hash_undefined__",
    zr = Object.prototype,
    Br = zr.hasOwnProperty;

function Hr(t) {
    var e = this.__data__;
    if (G) {
        var r = e[t];
        return r === Gr ? void 0 : r
    }
    return Br.call(e, t) ? e[t] : void 0
}
var Kr = Object.prototype,
    Wr = Kr.hasOwnProperty;

function Xr(t) {
    var e = this.__data__;
    return G ? e[t] !== void 0 : Wr.call(e, t)
}
var qr = "__lodash_hash_undefined__";

function Yr(t, e) {
    var r = this.__data__;
    return this.size += this.has(t) ? 0 : 1, r[t] = G && e === void 0 ? qr : e, this
}

function j(t) {
    var e = -1,
        r = t == null ? 0 : t.length;
    for (this.clear(); ++e < r;) {
        var n = t[e];
        this.set(n[0], n[1])
    }
}
j.prototype.clear = Fr;
j.prototype.delete = Ur;
j.prototype.get = Hr;
j.prototype.has = Xr;
j.prototype.set = Yr;

function Zr() {
    this.__data__ = [], this.size = 0
}

function X(t, e) {
    for (var r = t.length; r--;)
        if (Rt(t[r][0], e)) return r;
    return -1
}
var Jr = Array.prototype,
    Qr = Jr.splice;

function Vr(t) {
    var e = this.__data__,
        r = X(e, t);
    if (r < 0) return !1;
    var n = e.length - 1;
    return r == n ? e.pop() : Qr.call(e, r, 1), --this.size, !0
}

function kr(t) {
    var e = this.__data__,
        r = X(e, t);
    return r < 0 ? void 0 : e[r][1]
}

function tn(t) {
    return X(this.__data__, t) > -1
}

function en(t, e) {
    var r = this.__data__,
        n = X(r, t);
    return n < 0 ? (++this.size, r.push([t, e])) : r[n][1] = e, this
}

function A(t) {
    var e = -1,
        r = t == null ? 0 : t.length;
    for (this.clear(); ++e < r;) {
        var n = t[e];
        this.set(n[0], n[1])
    }
}
A.prototype.clear = Zr;
A.prototype.delete = Vr;
A.prototype.get = kr;
A.prototype.has = tn;
A.prototype.set = en;
var rn = D($, "Map");
const z = rn;

function nn() {
    this.size = 0, this.__data__ = {
        hash: new j,
        map: new(z || A),
        string: new j
    }
}

function an(t) {
    var e = typeof t;
    return e == "string" || e == "number" || e == "symbol" || e == "boolean" ? t !== "__proto__" : t === null
}

function q(t, e) {
    var r = t.__data__;
    return an(e) ? r[typeof e == "string" ? "string" : "hash"] : r.map
}

function on(t) {
    var e = q(this, t).delete(t);
    return this.size -= e ? 1 : 0, e
}

function sn(t) {
    return q(this, t).get(t)
}

function fn(t) {
    return q(this, t).has(t)
}

function un(t, e) {
    var r = q(this, t),
        n = r.size;
    return r.set(t, e), this.size += r.size == n ? 0 : 1, this
}

function O(t) {
    var e = -1,
        r = t == null ? 0 : t.length;
    for (this.clear(); ++e < r;) {
        var n = t[e];
        this.set(n[0], n[1])
    }
}
O.prototype.clear = nn;
O.prototype.delete = on;
O.prototype.get = sn;
O.prototype.has = fn;
O.prototype.set = un;
var cn = "Expected a function";

function nt(t, e) {
    if (typeof t != "function" || e != null && typeof e != "function") throw new TypeError(cn);
    var r = function() {
        var n = arguments,
            i = e ? e.apply(this, n) : n[0],
            a = r.cache;
        if (a.has(i)) return a.get(i);
        var s = t.apply(this, n);
        return r.cache = a.set(i, s) || a, s
    };
    return r.cache = new(nt.Cache || O), r
}
nt.Cache = O;
var ln = 500;

function pn(t) {
    var e = nt(t, function(n) {
            return r.size === ln && r.clear(), n
        }),
        r = e.cache;
    return e
}
var gn = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
    dn = /\\(\\)?/g,
    hn = pn(function(t) {
        var e = [];
        return t.charCodeAt(0) === 46 && e.push(""), t.replace(gn, function(r, n, i, a) {
            e.push(i ? a.replace(dn, "$1") : n || r)
        }), e
    });
const yn = hn;

function _n(t) {
    return t == null ? "" : Ct(t)
}

function bn(t, e) {
    return E(t) ? t : Dr(t, e) ? [t] : yn(_n(t))
}
var vn = 1 / 0;

function Tn(t) {
    if (typeof t == "string" || W(t)) return t;
    var e = t + "";
    return e == "0" && 1 / t == -vn ? "-0" : e
}

function mn(t, e) {
    e = bn(e, t);
    for (var r = 0, n = e.length; t != null && r < n;) t = t[Tn(e[r++])];
    return r && r == n ? t : void 0
}

function Ea(t, e, r) {
    var n = t == null ? void 0 : mn(t, e);
    return n === void 0 ? r : n
}

function zt(t, e) {
    for (var r = -1, n = e.length, i = t.length; ++r < n;) t[i + r] = e[r];
    return t
}
var yt = m ? m.isConcatSpreadable : void 0;

function $n(t) {
    return E(t) || Nt(t) || !!(yt && t && t[yt])
}

function Bt(t, e, r, n, i) {
    var a = -1,
        s = t.length;
    for (r || (r = $n), i || (i = []); ++a < s;) {
        var o = t[a];
        e > 0 && r(o) ? e > 1 ? Bt(o, e - 1, r, n, i) : zt(i, o) : n || (i[i.length] = o)
    }
    return i
}

function xa(t) {
    var e = t == null ? 0 : t.length;
    return e ? Bt(t, 1) : []
}

function An() {
    this.__data__ = new A, this.size = 0
}

function On(t) {
    var e = this.__data__,
        r = e.delete(t);
    return this.size = e.size, r
}

function wn(t) {
    return this.__data__.get(t)
}

function Sn(t) {
    return this.__data__.has(t)
}
var Pn = 200;

function En(t, e) {
    var r = this.__data__;
    if (r instanceof A) {
        var n = r.__data__;
        if (!z || n.length < Pn - 1) return n.push([t, e]), this.size = ++r.size, this;
        r = this.__data__ = new O(n)
    }
    return r.set(t, e), this.size = r.size, this
}

function P(t) {
    var e = this.__data__ = new A(t);
    this.size = e.size
}
P.prototype.clear = An;
P.prototype.delete = On;
P.prototype.get = wn;
P.prototype.has = Sn;
P.prototype.set = En;

function xn(t, e) {
    for (var r = -1, n = t == null ? 0 : t.length, i = 0, a = []; ++r < n;) {
        var s = t[r];
        e(s, r, t) && (a[i++] = s)
    }
    return a
}

function jn() {
    return []
}
var In = Object.prototype,
    Cn = In.propertyIsEnumerable,
    _t = Object.getOwnPropertySymbols,
    Mn = _t ? function(t) {
        return t == null ? [] : (t = Object(t), xn(_t(t), function(e) {
            return Cn.call(t, e)
        }))
    } : jn;
const Rn = Mn;

function Ln(t, e, r) {
    var n = e(t);
    return E(t) ? n : zt(n, r(t))
}

function bt(t) {
    return Ln(t, Mr, Rn)
}
var Dn = D($, "DataView");
const tt = Dn;
var Nn = D($, "Promise");
const et = Nn;
var Fn = D($, "Set");
const rt = Fn;
var vt = "[object Map]",
    Un = "[object Object]",
    Tt = "[object Promise]",
    mt = "[object Set]",
    $t = "[object WeakMap]",
    At = "[object DataView]",
    Gn = I(tt),
    zn = I(z),
    Bn = I(et),
    Hn = I(rt),
    Kn = I(V),
    x = L;
(tt && x(new tt(new ArrayBuffer(1))) != At || z && x(new z) != vt || et && x(et.resolve()) != Tt || rt && x(new rt) != mt || V && x(new V) != $t) && (x = function(t) {
    var e = L(t),
        r = e == Un ? t.constructor : void 0,
        n = r ? I(r) : "";
    if (n) switch (n) {
        case Gn:
            return At;
        case zn:
            return vt;
        case Bn:
            return Tt;
        case Hn:
            return mt;
        case Kn:
            return $t
    }
    return e
});
const Ot = x;
var Wn = $.Uint8Array;
const wt = Wn;
var Xn = "__lodash_hash_undefined__";

function qn(t) {
    return this.__data__.set(t, Xn), this
}

function Yn(t) {
    return this.__data__.has(t)
}

function K(t) {
    var e = -1,
        r = t == null ? 0 : t.length;
    for (this.__data__ = new O; ++e < r;) this.add(t[e])
}
K.prototype.add = K.prototype.push = qn;
K.prototype.has = Yn;

function Zn(t, e) {
    for (var r = -1, n = t == null ? 0 : t.length; ++r < n;)
        if (e(t[r], r, t)) return !0;
    return !1
}

function Jn(t, e) {
    return t.has(e)
}
var Qn = 1,
    Vn = 2;

function Ht(t, e, r, n, i, a) {
    var s = r & Qn,
        o = t.length,
        u = e.length;
    if (o != u && !(s && u > o)) return !1;
    var f = a.get(t),
        h = a.get(e);
    if (f && h) return f == e && h == t;
    var g = -1,
        l = !0,
        y = r & Vn ? new K : void 0;
    for (a.set(t, e), a.set(e, t); ++g < o;) {
        var d = t[g],
            _ = e[g];
        if (n) var v = s ? n(_, d, g, e, t, a) : n(d, _, g, t, e, a);
        if (v !== void 0) {
            if (v) continue;
            l = !1;
            break
        }
        if (y) {
            if (!Zn(e, function(b, T) {
                    if (!Jn(y, T) && (d === b || i(d, b, r, n, a))) return y.push(T)
                })) {
                l = !1;
                break
            }
        } else if (!(d === _ || i(d, _, r, n, a))) {
            l = !1;
            break
        }
    }
    return a.delete(t), a.delete(e), l
}

function kn(t) {
    var e = -1,
        r = Array(t.size);
    return t.forEach(function(n, i) {
        r[++e] = [i, n]
    }), r
}

function ta(t) {
    var e = -1,
        r = Array(t.size);
    return t.forEach(function(n) {
        r[++e] = n
    }), r
}
var ea = 1,
    ra = 2,
    na = "[object Boolean]",
    aa = "[object Date]",
    ia = "[object Error]",
    oa = "[object Map]",
    sa = "[object Number]",
    fa = "[object RegExp]",
    ua = "[object Set]",
    ca = "[object String]",
    la = "[object Symbol]",
    pa = "[object ArrayBuffer]",
    ga = "[object DataView]",
    St = m ? m.prototype : void 0,
    J = St ? St.valueOf : void 0;

function da(t, e, r, n, i, a, s) {
    switch (r) {
        case ga:
            if (t.byteLength != e.byteLength || t.byteOffset != e.byteOffset) return !1;
            t = t.buffer, e = e.buffer;
        case pa:
            return !(t.byteLength != e.byteLength || !a(new wt(t), new wt(e)));
        case na:
        case aa:
        case sa:
            return Rt(+t, +e);
        case ia:
            return t.name == e.name && t.message == e.message;
        case fa:
        case ca:
            return t == e + "";
        case oa:
            var o = kn;
        case ua:
            var u = n & ea;
            if (o || (o = ta), t.size != e.size && !u) return !1;
            var f = s.get(t);
            if (f) return f == e;
            n |= ra, s.set(t, e);
            var h = Ht(o(t), o(e), n, i, a, s);
            return s.delete(t), h;
        case la:
            if (J) return J.call(t) == J.call(e)
    }
    return !1
}
var ha = 1,
    ya = Object.prototype,
    _a = ya.hasOwnProperty;

function ba(t, e, r, n, i, a) {
    var s = r & ha,
        o = bt(t),
        u = o.length,
        f = bt(e),
        h = f.length;
    if (u != h && !s) return !1;
    for (var g = u; g--;) {
        var l = o[g];
        if (!(s ? l in e : _a.call(e, l))) return !1
    }
    var y = a.get(t),
        d = a.get(e);
    if (y && d) return y == e && d == t;
    var _ = !0;
    a.set(t, e), a.set(e, t);
    for (var v = s; ++g < u;) {
        l = o[g];
        var b = t[l],
            T = e[l];
        if (n) var B = s ? n(T, b, l, e, t, a) : n(b, T, l, t, e, a);
        if (!(B === void 0 ? b === T || i(b, T, r, n, a) : B)) {
            _ = !1;
            break
        }
        v || (v = l == "constructor")
    }
    if (_ && !v) {
        var C = t.constructor,
            w = e.constructor;
        C != w && "constructor" in t && "constructor" in e && !(typeof C == "function" && C instanceof C && typeof w == "function" && w instanceof w) && (_ = !1)
    }
    return a.delete(t), a.delete(e), _
}
var va = 1,
    Pt = "[object Arguments]",
    Et = "[object Array]",
    H = "[object Object]",
    Ta = Object.prototype,
    xt = Ta.hasOwnProperty;

function ma(t, e, r, n, i, a) {
    var s = E(t),
        o = E(e),
        u = s ? Et : Ot(t),
        f = o ? Et : Ot(e);
    u = u == Pt ? H : u, f = f == Pt ? H : f;
    var h = u == H,
        g = f == H,
        l = u == f;
    if (l && k(t)) {
        if (!k(e)) return !1;
        s = !0, h = !1
    }
    if (l && !h) return a || (a = new P), s || Gt(t) ? Ht(t, e, r, n, i, a) : da(t, e, u, r, n, i, a);
    if (!(r & va)) {
        var y = h && xt.call(t, "__wrapped__"),
            d = g && xt.call(e, "__wrapped__");
        if (y || d) {
            var _ = y ? t.value() : t,
                v = d ? e.value() : e;
            return a || (a = new P), i(_, v, r, n, a)
        }
    }
    return l ? (a || (a = new P), ba(t, e, r, n, i, a)) : !1
}

function Kt(t, e, r, n, i) {
    return t === e ? !0 : t == null || e == null || !M(t) && !M(e) ? t !== t && e !== e : ma(t, e, r, n, Kt, i)
}
var $a = function() {
    return $.Date.now()
};
const Q = $a;
var Aa = "Expected a function",
    Oa = Math.max,
    wa = Math.min;

function Sa(t, e, r) {
    var n, i, a, s, o, u, f = 0,
        h = !1,
        g = !1,
        l = !0;
    if (typeof t != "function") throw new TypeError(Aa);
    e = ut(e) || 0, R(r) && (h = !!r.leading, g = "maxWait" in r, a = g ? Oa(ut(r.maxWait) || 0, e) : a, l = "trailing" in r ? !!r.trailing : l);

    function y(p) {
        var S = n,
            N = i;
        return n = i = void 0, f = p, s = t.apply(N, S), s
    }

    function d(p) {
        return f = p, o = setTimeout(b, e), h ? y(p) : s
    }

    function _(p) {
        var S = p - u,
            N = p - f,
            at = e - S;
        return g ? wa(at, a - N) : at
    }

    function v(p) {
        var S = p - u,
            N = p - f;
        return u === void 0 || S >= e || S < 0 || g && N >= a
    }

    function b() {
        var p = Q();
        if (v(p)) return T(p);
        o = setTimeout(b, _(p))
    }

    function T(p) {
        return o = void 0, l && n ? y(p) : (n = i = void 0, s)
    }

    function B() {
        o !== void 0 && clearTimeout(o), f = 0, n = u = i = o = void 0
    }

    function C() {
        return o === void 0 ? s : T(Q())
    }

    function w() {
        var p = Q(),
            S = v(p);
        if (n = arguments, i = this, u = p, S) {
            if (o === void 0) return d(u);
            if (g) return clearTimeout(o), o = setTimeout(b, e), y(u)
        }
        return o === void 0 && (o = setTimeout(b, e)), s
    }
    return w.cancel = B, w.flush = C, w
}

function ja(t) {
    for (var e = -1, r = t == null ? 0 : t.length, n = {}; ++e < r;) {
        var i = t[e];
        n[i[0]] = i[1]
    }
    return n
}

function Ia(t, e) {
    return Kt(t, e)
}

function Ca(t) {
    return t == null
}

function Ma(t) {
    return t === void 0
}
var Pa = "Expected a function";

function Ra(t, e, r) {
    var n = !0,
        i = !0;
    if (typeof t != "function") throw new TypeError(Pa);
    return R(r) && (n = "leading" in r ? !!r.leading : n, i = "trailing" in r ? !!r.trailing : i), Sa(t, e, {
        leading: n,
        maxWait: e,
        trailing: i
    })
}
export {
    Ma as a, Ia as b, xa as c, Sa as d, ja as f, Ea as g, Ca as i, Ra as t
};