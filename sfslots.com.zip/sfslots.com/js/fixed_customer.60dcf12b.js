import {
    r as a,
    j as r,
    o as l,
    c,
    a as e,
    Q as u,
    L as d,
    M as f,
    d as _
} from "./@vue.16908cbf.js";
import {
    u as p
} from "./vuex.7fead168.js";
const v = {
        class: "fixed-customer"
    },
    h = ["href"],
    m = e("svg", {
        x: "0px",
        y: "0px",
        width: "32px",
        height: "32px",
        viewBox: "0 0 32 32",
        enableBackground: "new 0 0 32 32",
        focusable: "false",
        "aria-hidden": "true",
        class: "outIcon"
    }, [e("g", null, [e("defs", null, [e("linearGradient", {
        id: "linear"
    }, [e("stop", {
        offset: "0%",
        "stop-color": "#329fd9"
    }), e("stop", {
        offset: "100%",
        "stop-color": "rgb(25,134,192)"
    })])]), e("path", {
        fill: "#fff",
        d: "M16.007 0c-8.299 0-14.023 6.836-14.023 14.024 0 5.88 2.982 8.636 4.107 9.916 0 0 4.093 4.585 12.068 8.060v-4.121c4.783-0.563 11.858-5.289 11.858-13.855-0.001-8.271-6.794-14.024-14.010-14.024z",
        class: "chatButton__svg-chat-path"
    }), e("path", {
        fill: "url(#linear)",
        d: "M18.035 22.372v3.657c-0.014 0-2.729-1.364-4.276-2.574-2.926-2.236-6.498-4.416-6.498-9.438 0-4.993 4.149-8.622 8.622-8.622 0.005 0 0.011-0 0.017-0 4.744 0 8.591 3.838 8.605 8.579v0.043c0 5.162-4.164 7.779-6.47 8.355z",
        class: "innerIcon"
    })])], -1),
    x = {
        class: "innerDotContainer"
    },
    g = {
        viewBox: "0 0 32 32",
        width: "32px",
        fill: "#329fd9",
        "aria-hidden": "true"
    },
    B = e("circle", {
        r: "2",
        cy: "15",
        cx: "10",
        class: "innerDot"
    }, null, -1),
    b = e("circle", {
        r: "2",
        cy: "15",
        cx: "16",
        class: "innerDot"
    }, null, -1),
    w = e("circle", {
        r: "2",
        cy: "15",
        cx: "22",
        class: "innerDot"
    }, null, -1),
    C = [B, b, w],
    y = _({
        name: "true"
    }),
    z = Object.assign(y, {
        setup(M) {
            const t = p(),
                s = a(!1),
                n = a();
            return r(() => {
                t.state.customerConfig.el && (n.value = t.state.customerConfig.el.indexOf("http") > -1 ? t.state.customerConfig.el : "https://" + t.state.customerConfig.el)
            }), (D, o) => (l(), c("div", v, [e("a", {
                href: n.value,
                "aria-label": "Botão de bate-papo, agente on-line",
                role: "button",
                "aria-expanded": "false",
                class: "chatButton--ripple chatButton",
                onMousemove: o[0] || (o[0] = i => s.value = !0),
                onMouseout: o[1] || (o[1] = i => s.value = !1),
                target: "_blank"
            }, [e("div", {
                class: u(["svg-container", s.value ? "moveIn" : "moveOut"])
            }, [m, e("div", x, [d((l(), c("svg", g, C, 512)), [
                [f, s.value]
            ])])], 2)], 40, h)]))
        }
    });
export {
    z as
    default
};