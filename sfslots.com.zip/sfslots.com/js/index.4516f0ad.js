import {
    S as ae,
    d as ne
} from "./vant.be74fb7c.js";
import {
    j as le,
    k as ie
} from "./element-plus.c133b52b.js";
import {
    $ as re,
    o as O,
    g as te,
    d as Ae,
    __tla as me
} from "./index.0a674315.js";
import {
    b as ce
} from "./vue-router.d17f0860.js";
import {
    u as pe
} from "./vuex.7fead168.js";
import {
    X as d
} from "./xe-utils.0e898ace.js";
import {
    r as c,
    j as ue,
    b as de,
    aa as ge,
    ab as ve,
    o as s,
    c as i,
    a as e,
    R as g,
    S as p,
    P as V,
    a3 as I,
    u as T,
    L as X,
    O as t,
    U as M,
    W as Z
} from "./@vue.16908cbf.js";
import "./@vant.359a3f91.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./axios.4a70c6fc.js";
import "./vue-i18n.d9454f26.js";
import "./@intlify.7347860c.js";
import "./nprogress.1adef0ba.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
let q, ke = Promise.all([(() => {
    try {
        return me
    } catch {}
})()]).then(async () => {
    const v = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAYCAYAAADtaU2/AAAAAXNSR0IArs4c6QAAAsNJREFUSEu1lstLVGEYxn/v8VJQ1j/Qwk0JmZkRLlpEEd1vFEg6Xgj8DyIoMNN01GpdeIkoiGBCcCPUKoh2LYRoEc3CsAtkYiIkXZwz88Z3zpzm4rkM4ZzlzPed3/c+7/O83xHK+SgCsb3AFWAr6ATYz5DJVSknF23bDTIAHAOqgDeg16HmRfnA2tUEqUGQE4CVV+AMaLw8YG1vAL0FGKgfY2b9wdpWD9YgcA40v9K8ouXH+oK1oxHSfSBngQp//xikJtcPrK1NYMWB40U9za/UQOeAoh7rwUqorYQ5G3lpl+R4JzJtDSAGeiZiz2eQXlhK5CrWlmqougC6H6xXsDSNPP8TCdfYHiArb2BPzWs+QfombHmMTKRcsF7aCKluUBP0WtBZ1yBLiVC4CzVGOhkh70egF5IJZCZlkOJCV7vcP9jmVugY4APoAGx4ijz6XVC5I29nPdhDWSOFCfMFpA+ePDQ0b6GgsW7gKsh2cr978PdgDcD3qYLKncjQD5ZpTVBkzOG/upNr0wMjb/7pDPg1SHMhtGBJEjI3oG4K6bfRjjpIm0rPB8trzpIx0CFYvW9mc7EkgrYnQFsievTOlSs9C3IZpD1gInnvX3B7nxz3euoDbt0HVg9wGqj0b5apIP0WZBFoBjaHDIcF0DuwfDfMmFlXm1uEYZBTwS7xkvfPH0VLHXmz0JVRZPpnmOPycuwM9uHwaAS9yrwmM+8efnmilPwXjkzt3AXpkezYC5DdDy7zoEOwY8wxYAnP2lntDgVzpR0JNlwujaDGSMNQPb4m7yEH8L8kcvCjwe51thp540GRKa3Hxav0YiNUeLL7HFAWIBOHmrHi4VCC0r5fB7l9zlUnt0EO52R3xuki6AjYo8jkr1JAa3MctUudnJvKD4FUgH5zP2vs8f+FerdBFBo0dgDkGuhOYBRS95DJleiNwSv+AsCa49jMftZSAAAAAElFTkSuQmCC",
        k = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAkCAYAAACTz/ouAAAAAXNSR0IArs4c6QAAAYNJREFUSEvFl7lKBEEURU+DCy7ggqAGZgaioCYuYDIG7ploIBqYuIHgiviNfoTIJH7GlSfVWJY9M91tlVbSSfc71fctdSsj8pLUDSwDu8BbFjO+pEEX+A6YB16jASRNAlfAGTDhNv4eBSBpDngG9oF+T5XmrwCSLNg2YJKsAKa/v+oDJI07Oc6BqRa5rAeQNAs8AQfAQJtCqQaQ1AdsALfAGtDToQrLAySNAafABTBdsrzLAZwkj65KhkoGt9faAyT1Ag3gwT3DKunEag2QNAocA5eAJbXOKgY4SSyRh8Bwncjum+8ASV1Oihtgq6BxqrK+AJIseUdOkoWqkdo2mqQZ4NoBTPtYq5lJ2nRTcC+CJOHGPgEvwFKsLf8Ydn8BSCuR/VLSJOeaJS1TD5Ku0fzsJxsVAWQEOEky7DzJ8nF9D6zXaMR/PnACydIdmZ5k6Q79giqLb1sCSDrj5UmWzjoGf5PG/AYQs+xm382rxrXvnmT5BcRMw2LUC0gwMFeBHbtCfQBQNq5TTVnrNAAAAABJRU5ErkJggg==";
    let C, f, B, S, w, D, Y, z, E, J, R, G, y, h, P, Q, j, U;
    C = {
        key: 0,
        class: "anno-dialog"
    }, f = {
        class: "anno-banner"
    }, B = {
        class: "banner-icon"
    }, S = {
        class: "not-remind-inner"
    }, w = {
        class: "not-remind-icon"
    }, D = {
        key: 0,
        src: v
    }, Y = {
        class: "not-remind-text"
    }, z = {
        class: "anno-banner-mini"
    }, E = e("img", {
        src: Ae,
        class: "close"
    }, null, -1), J = [E], R = e("img", {
        src: k,
        alt: ""
    }, null, -1), G = [R], y = e("img", {
        src: k,
        alt: ""
    }, null, -1), h = [y], P = {
        class: "not-remind-inner"
    }, Q = {
        class: "not-remind-icon"
    }, j = {
        key: 0,
        src: v
    }, U = {
        class: "not-remind-text"
    }, q = {
        __name: "index",
        emits: ["close"],
        setup(Ce, {
            emit: r
        }) {
            pe(), ce();
            const n = c([]),
                F = c(3e3),
                A = c(null),
                m = c(!1),
                _ = c(!0),
                K = o => ({
                    loading: new URL("/img/colors/" + te() + "/default_anno.png",
                        import.meta.url).href,
                    src: o.image
                }),
                b = () => {
                    r("close")
                },
                x = o => {
                    o === "pre" ? A.value.prev() : A.value.next()
                },
                N = () => {
                    m.value = !m.value, m ? d.cookie("notRemind", "1", {
                        expires: "1d"
                    }) : d.cookie("notRemind", null, {
                        expires: -1
                    })
                },
                H = () => {
                    A.value && A.value.resize()
                };
            return ue(() => {
                if (d.cookie("notRemind")) return r("close");
                re.get("/user/site/banners", {
                    type: 3
                }).then(o => {
                    if (o && o.code === 0) {
                        const {
                            list: l,
                            time: u
                        } = o.data;
                        l && l.length ? (n.value = l, F.value = u * 1e3) : r("close")
                    } else r("close")
                }).catch(() => {
                    r("close")
                }), window.addEventListener("resize", H)
            }), de(() => {
                window.removeEventListener("resize", H)
            }), (o, l) => {
                const u = le,
                    W = ie,
                    $ = ge("svg-icon"),
                    ee = ae,
                    oe = ne,
                    L = ve("lazy");
                return _.value && n.value.length ? (s(), i("div", C, [e("div", f, [n.value.length ? (s(), g(W, {
                    key: 0,
                    auto: !0,
                    arrow: n.value.length > 1 ? "always" : "never",
                    "indicator-position": "none"
                }, {
                    default: p(() => [(s(!0), i(V, null, I(n.value, a => (s(), g(u, {
                        key: a,
                        onClick: se => T(O)(a)
                    }, {
                        default: p(() => [X(e("img", B, null, 512), [
                            [L, K(a)]
                        ])]),
                        _: 2
                    }, 1032, ["onClick"]))), 128))]),
                    _: 1
                }, 8, ["arrow"])) : t("", !0), e("div", {
                    class: "close-icon",
                    onClick: b
                }, [M($, {
                    iconClass: "close",
                    class: "close"
                })]), e("div", {
                    class: "not-remind",
                    onClick: N
                }, [e("div", S, [e("div", w, [m.value ? (s(), i("img", D)) : t("", !0)]), e("span", Y, Z(o.$t("common.no_remind")), 1)])])]), e("div", z, [M(oe, {
                    class: "my-swipe",
                    autoplay: F.value,
                    "show-indicators": !0,
                    "stop-propagation": !1,
                    ref_key: "swipe",
                    ref: A
                }, {
                    default: p(() => [(s(!0), i(V, null, I(n.value, a => (s(), g(ee, {
                        key: a,
                        onClick: se => {
                            T(O)(a), r("close")
                        }
                    }, {
                        default: p(() => [X(e("img", null, null, 512), [
                            [L, K(a)]
                        ])]),
                        _: 2
                    }, 1032, ["onClick"]))), 128))]),
                    _: 1
                }, 8, ["autoplay"]), e("div", {
                    class: "close-icon",
                    onClick: b
                }, J), n.value.length > 1 ? (s(), i("div", {
                    key: 0,
                    class: "slider-pre slider",
                    onClick: l[0] || (l[0] = a => x("pre"))
                }, G)) : t("", !0), n.value.length > 1 ? (s(), i("div", {
                    key: 1,
                    class: "slider-next slider",
                    onClick: l[1] || (l[1] = a => x("next"))
                }, h)) : t("", !0), e("div", {
                    class: "not-remind",
                    onClick: N
                }, [e("div", P, [e("div", Q, [m.value ? (s(), i("img", j)) : t("", !0)]), e("span", U, Z(o.$t("common.no_remind")), 1)])])])])) : t("", !0)
            }
        }
    }
});
export {
    ke as __tla, q as
    default
};