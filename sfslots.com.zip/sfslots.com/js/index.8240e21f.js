import {
    V as u,
    c as B,
    __tla as _
} from "./index.0a674315.js";
import {
    u as h
} from "./vuex.7fead168.js";
import {
    u as o,
    o as p,
    c as e,
    a,
    O as n,
    X as f
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./vue-router.d17f0860.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./vue-i18n.d9454f26.js";
import "./@intlify.7347860c.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
let c, k = Promise.all([(() => {
    try {
        return _
    } catch {}
})()]).then(async () => {
    let r, l, i, s, m;
    r = {
        class: "download-app-left"
    }, l = ["src"], i = ["src"], s = ["src"], m = ["src"], c = {
        __name: "index",
        emits: ["close"],
        setup(y, {
            emit: d
        }) {
            const t = h(),
                w = () => {
                    d("close"), globalVBus.$emit("closeDownLoad")
                },
                g = () => {
                    B()
                };
            return (v, x) => o(t).state.downloadBar.length ? (p(), e("div", {
                key: 0,
                class: "download-app",
                style: f(`height:${o(u)};background-color:${o(t).state.downloadBar.length&&o(t).state.downloadBar[4].color}`)
            }, [a("div", r, [a("div", {
                class: "close-icon",
                onClick: w
            }, [a("img", {
                src: o(t).state.downloadBar[0].icon,
                alt: ""
            }, null, 8, l)]), a("img", {
                src: o(t).state.downloadBar[1].icon,
                class: "logo"
            }, null, 8, i), a("img", {
                src: o(t).state.downloadBar[2].icon,
                class: "download-txt"
            }, null, 8, s)]), o(t).state.downloadBar.length ? (p(), e("div", {
                key: 0,
                class: "download-app-right",
                onClick: g
            }, [a("img", {
                src: o(t).state.downloadBar[3].icon,
                alt: ""
            }, null, 8, m)])) : n("", !0)], 4)) : n("", !0)
        }
    }
});
export {
    k as __tla, c as
    default
};