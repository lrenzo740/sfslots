/*!
 * shared v9.2.2
 * (c) 2022 kazuya kawaguchi
 * Released under the MIT License.
 */
const on = typeof window < "u",
    ze = typeof Symbol == "function" && typeof Symbol.toStringTag == "symbol",
    un = e => ze ? Symbol(e) : e,
    et = (e, t, s) => tt({
        l: e,
        k: t,
        s
    }),
    tt = e => JSON.stringify(e).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029").replace(/\u0027/g, "\\u0027"),
    v = e => typeof e == "number" && isFinite(e),
    nt = e => ue(e) === "[object Date]",
    Ne = e => ue(e) === "[object RegExp]",
    ie = e => M(e) && Object.keys(e).length === 0;

function rt(e, t) {
    typeof console < "u" && (console.warn("[intlify] " + e), t && console.warn(t.stack))
}
const q = Object.assign;
let ge;
const st = () => ge || (ge = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});

function Te(e) {
    return e.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
}
const at = Object.prototype.hasOwnProperty;

function fn(e, t) {
    return at.call(e, t)
}
const G = Array.isArray,
    U = e => typeof e == "function",
    b = e => typeof e == "string",
    W = e => typeof e == "boolean",
    w = e => e !== null && typeof e == "object",
    Pe = Object.prototype.toString,
    ue = e => Pe.call(e),
    M = e => ue(e) === "[object Object]",
    lt = e => e == null ? "" : G(e) || M(e) && e.toString === Pe ? JSON.stringify(e, null, 2) : String(e);
/*!
 * message-compiler v9.2.2
 * (c) 2022 kazuya kawaguchi
 * Released under the MIT License.
 */
const D = {
    EXPECTED_TOKEN: 1,
    INVALID_TOKEN_IN_PLACEHOLDER: 2,
    UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER: 3,
    UNKNOWN_ESCAPE_SEQUENCE: 4,
    INVALID_UNICODE_ESCAPE_SEQUENCE: 5,
    UNBALANCED_CLOSING_BRACE: 6,
    UNTERMINATED_CLOSING_BRACE: 7,
    EMPTY_PLACEHOLDER: 8,
    NOT_ALLOW_NEST_PLACEHOLDER: 9,
    INVALID_LINKED_FORMAT: 10,
    MUST_HAVE_MESSAGES_IN_PLURAL: 11,
    UNEXPECTED_EMPTY_LINKED_MODIFIER: 12,
    UNEXPECTED_EMPTY_LINKED_KEY: 13,
    UNEXPECTED_LEXICAL_ANALYSIS: 14,
    __EXTEND_POINT__: 15
};

function fe(e, t, s = {}) {
    const {
        domain: a,
        messages: o,
        args: c
    } = s, m = e, g = new SyntaxError(String(m));
    return g.code = e, t && (g.location = t), g.domain = a, g
}

function ct(e) {
    throw e
}

function ot(e, t, s) {
    return {
        line: e,
        column: t,
        offset: s
    }
}

function oe(e, t, s) {
    const a = {
        start: e,
        end: t
    };
    return s != null && (a.source = s), a
}
const Y = " ",
    it = "\r",
    F = `
`,
    ut = String.fromCharCode(8232),
    ft = String.fromCharCode(8233);

function dt(e) {
    const t = e;
    let s = 0,
        a = 1,
        o = 1,
        c = 0;
    const m = C => t[C] === it && t[C + 1] === F,
        g = C => t[C] === F,
        f = C => t[C] === ft,
        _ = C => t[C] === ut,
        S = C => m(C) || g(C) || f(C) || _(C),
        T = () => s,
        N = () => a,
        y = () => o,
        O = () => c,
        A = C => m(C) || f(C) || _(C) ? F : t[C],
        I = () => A(s),
        l = () => A(s + c);

    function d() {
        return c = 0, S(s) && (a++, o = 0), m(s) && s++, s++, o++, t[s]
    }

    function E() {
        return m(s + c) && c++, c++, t[s + c]
    }

    function u() {
        s = 0, a = 1, o = 1, c = 0
    }

    function h(C = 0) {
        c = C
    }

    function p() {
        const C = s + c;
        for (; C !== s;) d();
        c = 0
    }
    return {
        index: T,
        line: N,
        column: y,
        peekOffset: O,
        charAt: A,
        currentChar: I,
        currentPeek: l,
        next: d,
        peek: E,
        reset: u,
        resetPeek: h,
        skipToPeek: p
    }
}
const B = void 0,
    Ce = "'",
    mt = "tokenizer";

function _t(e, t = {}) {
    const s = t.location !== !1,
        a = dt(e),
        o = () => a.index(),
        c = () => ot(a.line(), a.column(), a.index()),
        m = c(),
        g = o(),
        f = {
            currentType: 14,
            offset: g,
            startLoc: m,
            endLoc: m,
            lastType: 14,
            lastOffset: g,
            lastStartLoc: m,
            lastEndLoc: m,
            braceNest: 0,
            inLinked: !1,
            text: ""
        },
        _ = () => f,
        {
            onError: S
        } = t;

    function T(n, r, i, ...L) {
        const k = _();
        if (r.column += i, r.offset += i, S) {
            const P = oe(k.startLoc, r),
                j = fe(n, P, {
                    domain: mt,
                    args: L
                });
            S(j)
        }
    }

    function N(n, r, i) {
        n.endLoc = c(), n.currentType = r;
        const L = {
            type: r
        };
        return s && (L.loc = oe(n.startLoc, n.endLoc)), i != null && (L.value = i), L
    }
    const y = n => N(n, 14);

    function O(n, r) {
        return n.currentChar() === r ? (n.next(), r) : (T(D.EXPECTED_TOKEN, c(), 0, r), "")
    }

    function A(n) {
        let r = "";
        for (; n.currentPeek() === Y || n.currentPeek() === F;) r += n.currentPeek(), n.peek();
        return r
    }

    function I(n) {
        const r = A(n);
        return n.skipToPeek(), r
    }

    function l(n) {
        if (n === B) return !1;
        const r = n.charCodeAt(0);
        return r >= 97 && r <= 122 || r >= 65 && r <= 90 || r === 95
    }

    function d(n) {
        if (n === B) return !1;
        const r = n.charCodeAt(0);
        return r >= 48 && r <= 57
    }

    function E(n, r) {
        const {
            currentType: i
        } = r;
        if (i !== 2) return !1;
        A(n);
        const L = l(n.currentPeek());
        return n.resetPeek(), L
    }

    function u(n, r) {
        const {
            currentType: i
        } = r;
        if (i !== 2) return !1;
        A(n);
        const L = n.currentPeek() === "-" ? n.peek() : n.currentPeek(),
            k = d(L);
        return n.resetPeek(), k
    }

    function h(n, r) {
        const {
            currentType: i
        } = r;
        if (i !== 2) return !1;
        A(n);
        const L = n.currentPeek() === Ce;
        return n.resetPeek(), L
    }

    function p(n, r) {
        const {
            currentType: i
        } = r;
        if (i !== 8) return !1;
        A(n);
        const L = n.currentPeek() === ".";
        return n.resetPeek(), L
    }

    function C(n, r) {
        const {
            currentType: i
        } = r;
        if (i !== 9) return !1;
        A(n);
        const L = l(n.currentPeek());
        return n.resetPeek(), L
    }

    function x(n, r) {
        const {
            currentType: i
        } = r;
        if (!(i === 8 || i === 12)) return !1;
        A(n);
        const L = n.currentPeek() === ":";
        return n.resetPeek(), L
    }

    function R(n, r) {
        const {
            currentType: i
        } = r;
        if (i !== 10) return !1;
        const L = () => {
                const P = n.currentPeek();
                return P === "{" ? l(n.peek()) : P === "@" || P === "%" || P === "|" || P === ":" || P === "." || P === Y || !P ? !1 : P === F ? (n.peek(), L()) : l(P)
            },
            k = L();
        return n.resetPeek(), k
    }

    function $(n) {
        A(n);
        const r = n.currentPeek() === "|";
        return n.resetPeek(), r
    }

    function V(n) {
        const r = A(n),
            i = n.currentPeek() === "%" && n.peek() === "{";
        return n.resetPeek(), {
            isModulo: i,
            hasSpace: r.length > 0
        }
    }

    function Z(n, r = !0) {
        const i = (k = !1, P = "", j = !1) => {
                const Q = n.currentPeek();
                return Q === "{" ? P === "%" ? !1 : k : Q === "@" || !Q ? P === "%" ? !0 : k : Q === "%" ? (n.peek(), i(k, "%", !0)) : Q === "|" ? P === "%" || j ? !0 : !(P === Y || P === F) : Q === Y ? (n.peek(), i(!0, Y, j)) : Q === F ? (n.peek(), i(!0, F, j)) : !0
            },
            L = i();
        return r && n.resetPeek(), L
    }

    function H(n, r) {
        const i = n.currentChar();
        return i === B ? B : r(i) ? (n.next(), i) : null
    }

    function Ee(n) {
        return H(n, i => {
            const L = i.charCodeAt(0);
            return L >= 97 && L <= 122 || L >= 65 && L <= 90 || L >= 48 && L <= 57 || L === 95 || L === 36
        })
    }

    function Xe(n) {
        return H(n, i => {
            const L = i.charCodeAt(0);
            return L >= 48 && L <= 57
        })
    }

    function Ke(n) {
        return H(n, i => {
            const L = i.charCodeAt(0);
            return L >= 48 && L <= 57 || L >= 65 && L <= 70 || L >= 97 && L <= 102
        })
    }

    function Le(n) {
        let r = "",
            i = "";
        for (; r = Xe(n);) i += r;
        return i
    }

    function Ge(n) {
        I(n);
        const r = n.currentChar();
        return r !== "%" && T(D.EXPECTED_TOKEN, c(), 0, r), n.next(), "%"
    }

    function he(n) {
        let r = "";
        for (;;) {
            const i = n.currentChar();
            if (i === "{" || i === "}" || i === "@" || i === "|" || !i) break;
            if (i === "%")
                if (Z(n)) r += i, n.next();
                else break;
            else if (i === Y || i === F)
                if (Z(n)) r += i, n.next();
                else {
                    if ($(n)) break;
                    r += i, n.next()
                }
            else r += i, n.next()
        }
        return r
    }

    function Ye(n) {
        I(n);
        let r = "",
            i = "";
        for (; r = Ee(n);) i += r;
        return n.currentChar() === B && T(D.UNTERMINATED_CLOSING_BRACE, c(), 0), i
    }

    function He(n) {
        I(n);
        let r = "";
        return n.currentChar() === "-" ? (n.next(), r += `-${Le(n)}`) : r += Le(n), n.currentChar() === B && T(D.UNTERMINATED_CLOSING_BRACE, c(), 0), r
    }

    function je(n) {
        I(n), O(n, "'");
        let r = "",
            i = "";
        const L = P => P !== Ce && P !== F;
        for (; r = H(n, L);) r === "\\" ? i += Be(n) : i += r;
        const k = n.currentChar();
        return k === F || k === B ? (T(D.UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER, c(), 0), k === F && (n.next(), O(n, "'")), i) : (O(n, "'"), i)
    }

    function Be(n) {
        const r = n.currentChar();
        switch (r) {
            case "\\":
            case "'":
                return n.next(), `\\${r}`;
            case "u":
                return pe(n, r, 4);
            case "U":
                return pe(n, r, 6);
            default:
                return T(D.UNKNOWN_ESCAPE_SEQUENCE, c(), 0, r), ""
        }
    }

    function pe(n, r, i) {
        O(n, r);
        let L = "";
        for (let k = 0; k < i; k++) {
            const P = Ke(n);
            if (!P) {
                T(D.INVALID_UNICODE_ESCAPE_SEQUENCE, c(), 0, `\\${r}${L}${n.currentChar()}`);
                break
            }
            L += P
        }
        return `\\${r}${L}`
    }

    function Je(n) {
        I(n);
        let r = "",
            i = "";
        const L = k => k !== "{" && k !== "}" && k !== Y && k !== F;
        for (; r = H(n, L);) i += r;
        return i
    }

    function Qe(n) {
        let r = "",
            i = "";
        for (; r = Ee(n);) i += r;
        return i
    }

    function qe(n) {
        const r = (i = !1, L) => {
            const k = n.currentChar();
            return k === "{" || k === "%" || k === "@" || k === "|" || !k || k === Y ? L : k === F ? (L += k, n.next(), r(i, L)) : (L += k, n.next(), r(!0, L))
        };
        return r(!1, "")
    }

    function se(n) {
        I(n);
        const r = O(n, "|");
        return I(n), r
    }

    function ae(n, r) {
        let i = null;
        switch (n.currentChar()) {
            case "{":
                return r.braceNest >= 1 && T(D.NOT_ALLOW_NEST_PLACEHOLDER, c(), 0), n.next(), i = N(r, 2, "{"), I(n), r.braceNest++, i;
            case "}":
                return r.braceNest > 0 && r.currentType === 2 && T(D.EMPTY_PLACEHOLDER, c(), 0), n.next(), i = N(r, 3, "}"), r.braceNest--, r.braceNest > 0 && I(n), r.inLinked && r.braceNest === 0 && (r.inLinked = !1), i;
            case "@":
                return r.braceNest > 0 && T(D.UNTERMINATED_CLOSING_BRACE, c(), 0), i = re(n, r) || y(r), r.braceNest = 0, i;
            default:
                let k = !0,
                    P = !0,
                    j = !0;
                if ($(n)) return r.braceNest > 0 && T(D.UNTERMINATED_CLOSING_BRACE, c(), 0), i = N(r, 1, se(n)), r.braceNest = 0, r.inLinked = !1, i;
                if (r.braceNest > 0 && (r.currentType === 5 || r.currentType === 6 || r.currentType === 7)) return T(D.UNTERMINATED_CLOSING_BRACE, c(), 0), r.braceNest = 0, le(n, r);
                if (k = E(n, r)) return i = N(r, 5, Ye(n)), I(n), i;
                if (P = u(n, r)) return i = N(r, 6, He(n)), I(n), i;
                if (j = h(n, r)) return i = N(r, 7, je(n)), I(n), i;
                if (!k && !P && !j) return i = N(r, 13, Je(n)), T(D.INVALID_TOKEN_IN_PLACEHOLDER, c(), 0, i.value), I(n), i;
                break
        }
        return i
    }

    function re(n, r) {
        const {
            currentType: i
        } = r;
        let L = null;
        const k = n.currentChar();
        switch ((i === 8 || i === 9 || i === 12 || i === 10) && (k === F || k === Y) && T(D.INVALID_LINKED_FORMAT, c(), 0), k) {
            case "@":
                return n.next(), L = N(r, 8, "@"), r.inLinked = !0, L;
            case ".":
                return I(n), n.next(), N(r, 9, ".");
            case ":":
                return I(n), n.next(), N(r, 10, ":");
            default:
                return $(n) ? (L = N(r, 1, se(n)), r.braceNest = 0, r.inLinked = !1, L) : p(n, r) || x(n, r) ? (I(n), re(n, r)) : C(n, r) ? (I(n), N(r, 12, Qe(n))) : R(n, r) ? (I(n), k === "{" ? ae(n, r) || L : N(r, 11, qe(n))) : (i === 8 && T(D.INVALID_LINKED_FORMAT, c(), 0), r.braceNest = 0, r.inLinked = !1, le(n, r))
        }
    }

    function le(n, r) {
        let i = {
            type: 14
        };
        if (r.braceNest > 0) return ae(n, r) || y(r);
        if (r.inLinked) return re(n, r) || y(r);
        switch (n.currentChar()) {
            case "{":
                return ae(n, r) || y(r);
            case "}":
                return T(D.UNBALANCED_CLOSING_BRACE, c(), 0), n.next(), N(r, 3, "}");
            case "@":
                return re(n, r) || y(r);
            default:
                if ($(n)) return i = N(r, 1, se(n)), r.braceNest = 0, r.inLinked = !1, i;
                const {
                    isModulo: k,
                    hasSpace: P
                } = V(n);
                if (k) return P ? N(r, 0, he(n)) : N(r, 4, Ge(n));
                if (Z(n)) return N(r, 0, he(n));
                break
        }
        return i
    }

    function Ze() {
        const {
            currentType: n,
            offset: r,
            startLoc: i,
            endLoc: L
        } = f;
        return f.lastType = n, f.lastOffset = r, f.lastStartLoc = i, f.lastEndLoc = L, f.offset = o(), f.startLoc = c(), a.currentChar() === B ? N(f, 14) : le(a, f)
    }
    return {
        nextToken: Ze,
        currentOffset: o,
        currentPosition: c,
        context: _
    }
}
const Et = "parser",
    Lt = /(?:\\\\|\\'|\\u([0-9a-fA-F]{4})|\\U([0-9a-fA-F]{6}))/g;

function ht(e, t, s) {
    switch (e) {
        case "\\\\":
            return "\\";
        case "\\'":
            return "'";
        default:
            {
                const a = parseInt(t || s, 16);
                return a <= 55295 || a >= 57344 ? String.fromCodePoint(a) : "�"
            }
    }
}

function pt(e = {}) {
    const t = e.location !== !1,
        {
            onError: s
        } = e;

    function a(l, d, E, u, ...h) {
        const p = l.currentPosition();
        if (p.offset += u, p.column += u, s) {
            const C = oe(E, p),
                x = fe(d, C, {
                    domain: Et,
                    args: h
                });
            s(x)
        }
    }

    function o(l, d, E) {
        const u = {
            type: l,
            start: d,
            end: d
        };
        return t && (u.loc = {
            start: E,
            end: E
        }), u
    }

    function c(l, d, E, u) {
        l.end = d, u && (l.type = u), t && l.loc && (l.loc.end = E)
    }

    function m(l, d) {
        const E = l.context(),
            u = o(3, E.offset, E.startLoc);
        return u.value = d, c(u, l.currentOffset(), l.currentPosition()), u
    }

    function g(l, d) {
        const E = l.context(),
            {
                lastOffset: u,
                lastStartLoc: h
            } = E,
            p = o(5, u, h);
        return p.index = parseInt(d, 10), l.nextToken(), c(p, l.currentOffset(), l.currentPosition()), p
    }

    function f(l, d) {
        const E = l.context(),
            {
                lastOffset: u,
                lastStartLoc: h
            } = E,
            p = o(4, u, h);
        return p.key = d, l.nextToken(), c(p, l.currentOffset(), l.currentPosition()), p
    }

    function _(l, d) {
        const E = l.context(),
            {
                lastOffset: u,
                lastStartLoc: h
            } = E,
            p = o(9, u, h);
        return p.value = d.replace(Lt, ht), l.nextToken(), c(p, l.currentOffset(), l.currentPosition()), p
    }

    function S(l) {
        const d = l.nextToken(),
            E = l.context(),
            {
                lastOffset: u,
                lastStartLoc: h
            } = E,
            p = o(8, u, h);
        return d.type !== 12 ? (a(l, D.UNEXPECTED_EMPTY_LINKED_MODIFIER, E.lastStartLoc, 0), p.value = "", c(p, u, h), {
            nextConsumeToken: d,
            node: p
        }) : (d.value == null && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, E.lastStartLoc, 0, X(d)), p.value = d.value || "", c(p, l.currentOffset(), l.currentPosition()), {
            node: p
        })
    }

    function T(l, d) {
        const E = l.context(),
            u = o(7, E.offset, E.startLoc);
        return u.value = d, c(u, l.currentOffset(), l.currentPosition()), u
    }

    function N(l) {
        const d = l.context(),
            E = o(6, d.offset, d.startLoc);
        let u = l.nextToken();
        if (u.type === 9) {
            const h = S(l);
            E.modifier = h.node, u = h.nextConsumeToken || l.nextToken()
        }
        switch (u.type !== 10 && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, d.lastStartLoc, 0, X(u)), u = l.nextToken(), u.type === 2 && (u = l.nextToken()), u.type) {
            case 11:
                u.value == null && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, d.lastStartLoc, 0, X(u)), E.key = T(l, u.value || "");
                break;
            case 5:
                u.value == null && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, d.lastStartLoc, 0, X(u)), E.key = f(l, u.value || "");
                break;
            case 6:
                u.value == null && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, d.lastStartLoc, 0, X(u)), E.key = g(l, u.value || "");
                break;
            case 7:
                u.value == null && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, d.lastStartLoc, 0, X(u)), E.key = _(l, u.value || "");
                break;
            default:
                a(l, D.UNEXPECTED_EMPTY_LINKED_KEY, d.lastStartLoc, 0);
                const h = l.context(),
                    p = o(7, h.offset, h.startLoc);
                return p.value = "", c(p, h.offset, h.startLoc), E.key = p, c(E, h.offset, h.startLoc), {
                    nextConsumeToken: u,
                    node: E
                }
        }
        return c(E, l.currentOffset(), l.currentPosition()), {
            node: E
        }
    }

    function y(l) {
        const d = l.context(),
            E = d.currentType === 1 ? l.currentOffset() : d.offset,
            u = d.currentType === 1 ? d.endLoc : d.startLoc,
            h = o(2, E, u);
        h.items = [];
        let p = null;
        do {
            const R = p || l.nextToken();
            switch (p = null, R.type) {
                case 0:
                    R.value == null && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, d.lastStartLoc, 0, X(R)), h.items.push(m(l, R.value || ""));
                    break;
                case 6:
                    R.value == null && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, d.lastStartLoc, 0, X(R)), h.items.push(g(l, R.value || ""));
                    break;
                case 5:
                    R.value == null && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, d.lastStartLoc, 0, X(R)), h.items.push(f(l, R.value || ""));
                    break;
                case 7:
                    R.value == null && a(l, D.UNEXPECTED_LEXICAL_ANALYSIS, d.lastStartLoc, 0, X(R)), h.items.push(_(l, R.value || ""));
                    break;
                case 8:
                    const $ = N(l);
                    h.items.push($.node), p = $.nextConsumeToken || null;
                    break
            }
        } while (d.currentType !== 14 && d.currentType !== 1);
        const C = d.currentType === 1 ? d.lastOffset : l.currentOffset(),
            x = d.currentType === 1 ? d.lastEndLoc : l.currentPosition();
        return c(h, C, x), h
    }

    function O(l, d, E, u) {
        const h = l.context();
        let p = u.items.length === 0;
        const C = o(1, d, E);
        C.cases = [], C.cases.push(u);
        do {
            const x = y(l);
            p || (p = x.items.length === 0), C.cases.push(x)
        } while (h.currentType !== 14);
        return p && a(l, D.MUST_HAVE_MESSAGES_IN_PLURAL, E, 0), c(C, l.currentOffset(), l.currentPosition()), C
    }

    function A(l) {
        const d = l.context(),
            {
                offset: E,
                startLoc: u
            } = d,
            h = y(l);
        return d.currentType === 14 ? h : O(l, E, u, h)
    }

    function I(l) {
        const d = _t(l, q({}, e)),
            E = d.context(),
            u = o(0, E.offset, E.startLoc);
        return t && u.loc && (u.loc.source = l), u.body = A(d), E.currentType !== 14 && a(d, D.UNEXPECTED_LEXICAL_ANALYSIS, E.lastStartLoc, 0, l[E.offset] || ""), c(u, d.currentOffset(), d.currentPosition()), u
    }
    return {
        parse: I
    }
}

function X(e) {
    if (e.type === 14) return "EOF";
    const t = (e.value || "").replace(/\r?\n/gu, "\\n");
    return t.length > 10 ? t.slice(0, 9) + "…" : t
}

function Nt(e, t = {}) {
    const s = {
        ast: e,
        helpers: new Set
    };
    return {
        context: () => s,
        helper: c => (s.helpers.add(c), c)
    }
}

function Ie(e, t) {
    for (let s = 0; s < e.length; s++) de(e[s], t)
}

function de(e, t) {
    switch (e.type) {
        case 1:
            Ie(e.cases, t), t.helper("plural");
            break;
        case 2:
            Ie(e.items, t);
            break;
        case 6:
            de(e.key, t), t.helper("linked"), t.helper("type");
            break;
        case 5:
            t.helper("interpolate"), t.helper("list");
            break;
        case 4:
            t.helper("interpolate"), t.helper("named");
            break
    }
}

function gt(e, t = {}) {
    const s = Nt(e);
    s.helper("normalize"), e.body && de(e.body, s);
    const a = s.context();
    e.helpers = Array.from(a.helpers)
}

function Tt(e, t) {
    const {
        sourceMap: s,
        filename: a,
        breakLineCode: o,
        needIndent: c
    } = t, m = {
        source: e.loc.source,
        filename: a,
        code: "",
        column: 1,
        line: 1,
        offset: 0,
        map: void 0,
        breakLineCode: o,
        needIndent: c,
        indentLevel: 0
    }, g = () => m;

    function f(A, I) {
        m.code += A
    }

    function _(A, I = !0) {
        const l = I ? o : "";
        f(c ? l + "  ".repeat(A) : l)
    }

    function S(A = !0) {
        const I = ++m.indentLevel;
        A && _(I)
    }

    function T(A = !0) {
        const I = --m.indentLevel;
        A && _(I)
    }

    function N() {
        _(m.indentLevel)
    }
    return {
        context: g,
        push: f,
        indent: S,
        deindent: T,
        newline: N,
        helper: A => `_${A}`,
        needIndent: () => m.needIndent
    }
}

function Ct(e, t) {
    const {
        helper: s
    } = e;
    e.push(`${s("linked")}(`), te(e, t.key), t.modifier ? (e.push(", "), te(e, t.modifier), e.push(", _type")) : e.push(", undefined, _type"), e.push(")")
}

function It(e, t) {
    const {
        helper: s,
        needIndent: a
    } = e;
    e.push(`${s("normalize")}([`), e.indent(a());
    const o = t.items.length;
    for (let c = 0; c < o && (te(e, t.items[c]), c !== o - 1); c++) e.push(", ");
    e.deindent(a()), e.push("])")
}

function St(e, t) {
    const {
        helper: s,
        needIndent: a
    } = e;
    if (t.cases.length > 1) {
        e.push(`${s("plural")}([`), e.indent(a());
        const o = t.cases.length;
        for (let c = 0; c < o && (te(e, t.cases[c]), c !== o - 1); c++) e.push(", ");
        e.deindent(a()), e.push("])")
    }
}

function At(e, t) {
    t.body ? te(e, t.body) : e.push("null")
}

function te(e, t) {
    const {
        helper: s
    } = e;
    switch (t.type) {
        case 0:
            At(e, t);
            break;
        case 1:
            St(e, t);
            break;
        case 2:
            It(e, t);
            break;
        case 6:
            Ct(e, t);
            break;
        case 8:
            e.push(JSON.stringify(t.value), t);
            break;
        case 7:
            e.push(JSON.stringify(t.value), t);
            break;
        case 5:
            e.push(`${s("interpolate")}(${s("list")}(${t.index}))`, t);
            break;
        case 4:
            e.push(`${s("interpolate")}(${s("named")}(${JSON.stringify(t.key)}))`, t);
            break;
        case 9:
            e.push(JSON.stringify(t.value), t);
            break;
        case 3:
            e.push(JSON.stringify(t.value), t);
            break
    }
}
const bt = (e, t = {}) => {
    const s = b(t.mode) ? t.mode : "normal",
        a = b(t.filename) ? t.filename : "message.intl",
        o = !!t.sourceMap,
        c = t.breakLineCode != null ? t.breakLineCode : s === "arrow" ? ";" : `
`,
        m = t.needIndent ? t.needIndent : s !== "arrow",
        g = e.helpers || [],
        f = Tt(e, {
            mode: s,
            filename: a,
            sourceMap: o,
            breakLineCode: c,
            needIndent: m
        });
    f.push(s === "normal" ? "function __msg__ (ctx) {" : "(ctx) => {"), f.indent(m), g.length > 0 && (f.push(`const { ${g.map(T=>`${T}: _${T}`).join(", ")} } = ctx`), f.newline()), f.push("return "), te(f, e), f.deindent(m), f.push("}");
    const {
        code: _,
        map: S
    } = f.context();
    return {
        ast: e,
        code: _,
        map: S ? S.toJSON() : void 0
    }
};

function kt(e, t = {}) {
    const s = q({}, t),
        o = pt(s).parse(e);
    return gt(o, s), bt(o, s)
}
/*!
 * devtools-if v9.2.2
 * (c) 2022 kazuya kawaguchi
 * Released under the MIT License.
 */
const Me = {
    I18nInit: "i18n:init",
    FunctionTranslate: "function:translate"
};
/*!
 * core-base v9.2.2
 * (c) 2022 kazuya kawaguchi
 * Released under the MIT License.
 */
const J = [];
J[0] = {
    w: [0],
    i: [3, 0],
    ["["]: [4],
    o: [7]
};
J[1] = {
    w: [1],
    ["."]: [2],
    ["["]: [4],
    o: [7]
};
J[2] = {
    w: [2],
    i: [3, 0],
    [0]: [3, 0]
};
J[3] = {
    i: [3, 0],
    [0]: [3, 0],
    w: [1, 1],
    ["."]: [2, 1],
    ["["]: [4, 1],
    o: [7, 1]
};
J[4] = {
    ["'"]: [5, 0],
    ['"']: [6, 0],
    ["["]: [4, 2],
    ["]"]: [1, 3],
    o: 8,
    l: [4, 0]
};
J[5] = {
    ["'"]: [4, 0],
    o: 8,
    l: [5, 0]
};
J[6] = {
    ['"']: [4, 0],
    o: 8,
    l: [6, 0]
};
const yt = /^\s?(?:true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;

function Ot(e) {
    return yt.test(e)
}

function Dt(e) {
    const t = e.charCodeAt(0),
        s = e.charCodeAt(e.length - 1);
    return t === s && (t === 34 || t === 39) ? e.slice(1, -1) : e
}

function Pt(e) {
    if (e == null) return "o";
    switch (e.charCodeAt(0)) {
        case 91:
        case 93:
        case 46:
        case 34:
        case 39:
            return e;
        case 95:
        case 36:
        case 45:
            return "i";
        case 9:
        case 10:
        case 13:
        case 160:
        case 65279:
        case 8232:
        case 8233:
            return "w"
    }
    return "i"
}

function Mt(e) {
    const t = e.trim();
    return e.charAt(0) === "0" && isNaN(parseInt(e)) ? !1 : Ot(t) ? Dt(t) : "*" + t
}

function Rt(e) {
    const t = [];
    let s = -1,
        a = 0,
        o = 0,
        c, m, g, f, _, S, T;
    const N = [];
    N[0] = () => {
        m === void 0 ? m = g : m += g
    }, N[1] = () => {
        m !== void 0 && (t.push(m), m = void 0)
    }, N[2] = () => {
        N[0](), o++
    }, N[3] = () => {
        if (o > 0) o--, a = 4, N[0]();
        else {
            if (o = 0, m === void 0 || (m = Mt(m), m === !1)) return !1;
            N[1]()
        }
    };

    function y() {
        const O = e[s + 1];
        if (a === 5 && O === "'" || a === 6 && O === '"') return s++, g = "\\" + O, N[0](), !0
    }
    for (; a !== null;)
        if (s++, c = e[s], !(c === "\\" && y())) {
            if (f = Pt(c), T = J[a], _ = T[f] || T.l || 8, _ === 8 || (a = _[0], _[1] !== void 0 && (S = N[_[1]], S && (g = c, S() === !1)))) return;
            if (a === 7) return t
        }
}
const Se = new Map;

function Ft(e, t) {
    return w(e) ? e[t] : null
}

function dn(e, t) {
    if (!w(e)) return null;
    let s = Se.get(t);
    if (s || (s = Rt(t), s && Se.set(t, s)), !s) return null;
    const a = s.length;
    let o = e,
        c = 0;
    for (; c < a;) {
        const m = o[s[c]];
        if (m === void 0) return null;
        o = m, c++
    }
    return o
}
const wt = e => e,
    Ut = e => "",
    vt = "text",
    Wt = e => e.length === 0 ? "" : e.join(""),
    xt = lt;

function Ae(e, t) {
    return e = Math.abs(e), t === 2 ? e ? e > 1 ? 1 : 0 : 1 : e ? Math.min(e, 2) : 0
}

function $t(e) {
    const t = v(e.pluralIndex) ? e.pluralIndex : -1;
    return e.named && (v(e.named.count) || v(e.named.n)) ? v(e.named.count) ? e.named.count : v(e.named.n) ? e.named.n : t : t
}

function Vt(e, t) {
    t.count || (t.count = e), t.n || (t.n = e)
}

function Xt(e = {}) {
    const t = e.locale,
        s = $t(e),
        a = w(e.pluralRules) && b(t) && U(e.pluralRules[t]) ? e.pluralRules[t] : Ae,
        o = w(e.pluralRules) && b(t) && U(e.pluralRules[t]) ? Ae : void 0,
        c = l => l[a(s, l.length, o)],
        m = e.list || [],
        g = l => m[l],
        f = e.named || {};
    v(e.pluralIndex) && Vt(s, f);
    const _ = l => f[l];

    function S(l) {
        const d = U(e.messages) ? e.messages(l) : w(e.messages) ? e.messages[l] : !1;
        return d || (e.parent ? e.parent.message(l) : Ut)
    }
    const T = l => e.modifiers ? e.modifiers[l] : wt,
        N = M(e.processor) && U(e.processor.normalize) ? e.processor.normalize : Wt,
        y = M(e.processor) && U(e.processor.interpolate) ? e.processor.interpolate : xt,
        O = M(e.processor) && b(e.processor.type) ? e.processor.type : vt,
        I = {
            list: g,
            named: _,
            plural: c,
            linked: (l, ...d) => {
                const [E, u] = d;
                let h = "text",
                    p = "";
                d.length === 1 ? w(E) ? (p = E.modifier || p, h = E.type || h) : b(E) && (p = E || p) : d.length === 2 && (b(E) && (p = E || p), b(u) && (h = u || h));
                let C = S(l)(I);
                return h === "vnode" && G(C) && p && (C = C[0]), p ? T(p)(C, h) : C
            },
            message: S,
            type: O,
            interpolate: y,
            normalize: N
        };
    return I
}
let ne = null;

function mn(e) {
    ne = e
}

function Kt(e, t, s) {
    ne && ne.emit(Me.I18nInit, {
        timestamp: Date.now(),
        i18n: e,
        version: t,
        meta: s
    })
}
const Gt = Yt(Me.FunctionTranslate);

function Yt(e) {
    return t => ne && ne.emit(e, t)
}

function Ht(e, t, s) {
    return [...new Set([s, ...G(t) ? t : w(t) ? Object.keys(t) : b(t) ? [t] : [s]])]
}

function _n(e, t, s) {
    const a = b(s) ? s : Re,
        o = e;
    o.__localeChainCache || (o.__localeChainCache = new Map);
    let c = o.__localeChainCache.get(a);
    if (!c) {
        c = [];
        let m = [s];
        for (; G(m);) m = be(c, m, t);
        const g = G(t) || !M(t) ? t : t.default ? t.default : null;
        m = b(g) ? [g] : g, G(m) && be(c, m, !1), o.__localeChainCache.set(a, c)
    }
    return c
}

function be(e, t, s) {
    let a = !0;
    for (let o = 0; o < t.length && W(a); o++) {
        const c = t[o];
        b(c) && (a = jt(e, t[o], s))
    }
    return a
}

function jt(e, t, s) {
    let a;
    const o = t.split("-");
    do {
        const c = o.join("-");
        a = Bt(e, c, s), o.splice(-1, 1)
    } while (o.length && a === !0);
    return a
}

function Bt(e, t, s) {
    let a = !1;
    if (!e.includes(t) && (a = !0, t)) {
        a = t[t.length - 1] !== "!";
        const o = t.replace(/!/g, "");
        e.push(o), (G(s) || M(s)) && s[o] && (a = s[o])
    }
    return a
}
const Jt = "9.2.2",
    me = -1,
    Re = "en-US",
    En = "",
    ke = e => `${e.charAt(0).toLocaleUpperCase()}${e.substr(1)}`;

function Qt() {
    return {
        upper: (e, t) => t === "text" && b(e) ? e.toUpperCase() : t === "vnode" && w(e) && "__v_isVNode" in e ? e.children.toUpperCase() : e,
        lower: (e, t) => t === "text" && b(e) ? e.toLowerCase() : t === "vnode" && w(e) && "__v_isVNode" in e ? e.children.toLowerCase() : e,
        capitalize: (e, t) => t === "text" && b(e) ? ke(e) : t === "vnode" && w(e) && "__v_isVNode" in e ? ke(e.children) : e
    }
}
let Fe;

function Ln(e) {
    Fe = e
}
let we;

function hn(e) {
    we = e
}
let Ue;

function pn(e) {
    Ue = e
}
let ve = null;
const Nn = e => {
        ve = e
    },
    qt = () => ve;
let We = null;
const gn = e => {
        We = e
    },
    Tn = () => We;
let ye = 0;

function Cn(e = {}) {
    const t = b(e.version) ? e.version : Jt,
        s = b(e.locale) ? e.locale : Re,
        a = G(e.fallbackLocale) || M(e.fallbackLocale) || b(e.fallbackLocale) || e.fallbackLocale === !1 ? e.fallbackLocale : s,
        o = M(e.messages) ? e.messages : {
            [s]: {}
        },
        c = M(e.datetimeFormats) ? e.datetimeFormats : {
            [s]: {}
        },
        m = M(e.numberFormats) ? e.numberFormats : {
            [s]: {}
        },
        g = q({}, e.modifiers || {}, Qt()),
        f = e.pluralRules || {},
        _ = U(e.missing) ? e.missing : null,
        S = W(e.missingWarn) || Ne(e.missingWarn) ? e.missingWarn : !0,
        T = W(e.fallbackWarn) || Ne(e.fallbackWarn) ? e.fallbackWarn : !0,
        N = !!e.fallbackFormat,
        y = !!e.unresolving,
        O = U(e.postTranslation) ? e.postTranslation : null,
        A = M(e.processor) ? e.processor : null,
        I = W(e.warnHtmlMessage) ? e.warnHtmlMessage : !0,
        l = !!e.escapeParameter,
        d = U(e.messageCompiler) ? e.messageCompiler : Fe,
        E = U(e.messageResolver) ? e.messageResolver : we || Ft,
        u = U(e.localeFallbacker) ? e.localeFallbacker : Ue || Ht,
        h = w(e.fallbackContext) ? e.fallbackContext : void 0,
        p = U(e.onWarn) ? e.onWarn : rt,
        C = e,
        x = w(C.__datetimeFormatters) ? C.__datetimeFormatters : new Map,
        R = w(C.__numberFormatters) ? C.__numberFormatters : new Map,
        $ = w(C.__meta) ? C.__meta : {};
    ye++;
    const V = {
        version: t,
        cid: ye,
        locale: s,
        fallbackLocale: a,
        messages: o,
        modifiers: g,
        pluralRules: f,
        missing: _,
        missingWarn: S,
        fallbackWarn: T,
        fallbackFormat: N,
        unresolving: y,
        postTranslation: O,
        processor: A,
        warnHtmlMessage: I,
        escapeParameter: l,
        messageCompiler: d,
        messageResolver: E,
        localeFallbacker: u,
        fallbackContext: h,
        onWarn: p,
        __meta: $
    };
    return V.datetimeFormats = c, V.numberFormats = m, V.__datetimeFormatters = x, V.__numberFormatters = R, __INTLIFY_PROD_DEVTOOLS__ && Kt(V, t, $), V
}

function _e(e, t, s, a, o) {
    const {
        missing: c,
        onWarn: m
    } = e;
    if (c !== null) {
        const g = c(e, s, t, o);
        return b(g) ? g : t
    } else return t
}

function In(e, t, s) {
    const a = e;
    a.__localeChainCache = new Map, e.localeFallbacker(e, s, t)
}
const Zt = e => e;
let Oe = Object.create(null);

function Sn(e, t = {}) {
    {
        const a = (t.onCacheKey || Zt)(e),
            o = Oe[a];
        if (o) return o;
        let c = !1;
        const m = t.onError || ct;
        t.onError = _ => {
            c = !0, m(_)
        };
        const {
            code: g
        } = kt(e, t), f = new Function(`return ${g}`)();
        return c ? f : Oe[a] = f
    }
}
let xe = D.__EXTEND_POINT__;
const ce = () => ++xe,
    z = {
        INVALID_ARGUMENT: xe,
        INVALID_DATE_ARGUMENT: ce(),
        INVALID_ISO_DATE_ARGUMENT: ce(),
        __EXTEND_POINT__: ce()
    };

function ee(e) {
    return fe(e, null, void 0)
}
const De = () => "",
    K = e => U(e);

function An(e, ...t) {
    const {
        fallbackFormat: s,
        postTranslation: a,
        unresolving: o,
        messageCompiler: c,
        fallbackLocale: m,
        messages: g
    } = e, [f, _] = tn(...t), S = W(_.missingWarn) ? _.missingWarn : e.missingWarn, T = W(_.fallbackWarn) ? _.fallbackWarn : e.fallbackWarn, N = W(_.escapeParameter) ? _.escapeParameter : e.escapeParameter, y = !!_.resolvedMessage, O = b(_.default) || W(_.default) ? W(_.default) ? c ? f : () => f : _.default : s ? c ? f : () => f : "", A = s || O !== "", I = b(_.locale) ? _.locale : e.locale;
    N && zt(_);
    let [l, d, E] = y ? [f, I, g[I] || {}] : $e(e, f, I, m, T, S), u = l, h = f;
    if (!y && !(b(u) || K(u)) && A && (u = O, h = u), !y && (!(b(u) || K(u)) || !b(d))) return o ? me : f;
    let p = !1;
    const C = () => {
            p = !0
        },
        x = K(u) ? u : Ve(e, f, d, u, h, C);
    if (p) return u;
    const R = rn(e, d, E, _),
        $ = Xt(R),
        V = en(e, x, $),
        Z = a ? a(V, f) : V;
    if (__INTLIFY_PROD_DEVTOOLS__) {
        const H = {
            timestamp: Date.now(),
            key: b(f) ? f : K(u) ? u.key : "",
            locale: d || (K(u) ? u.locale : ""),
            format: b(u) ? u : K(u) ? u.source : "",
            message: Z
        };
        H.meta = q({}, e.__meta, qt() || {}), Gt(H)
    }
    return Z
}

function zt(e) {
    G(e.list) ? e.list = e.list.map(t => b(t) ? Te(t) : t) : w(e.named) && Object.keys(e.named).forEach(t => {
        b(e.named[t]) && (e.named[t] = Te(e.named[t]))
    })
}

function $e(e, t, s, a, o, c) {
    const {
        messages: m,
        onWarn: g,
        messageResolver: f,
        localeFallbacker: _
    } = e, S = _(e, a, s);
    let T = {},
        N, y = null;
    const O = "translate";
    for (let A = 0; A < S.length && (N = S[A], T = m[N] || {}, (y = f(T, t)) === null && (y = T[t]), !(b(y) || U(y))); A++) {
        const I = _e(e, t, N, c, O);
        I !== t && (y = I)
    }
    return [y, N, T]
}

function Ve(e, t, s, a, o, c) {
    const {
        messageCompiler: m,
        warnHtmlMessage: g
    } = e;
    if (K(a)) {
        const _ = a;
        return _.locale = _.locale || s, _.key = _.key || t, _
    }
    if (m == null) {
        const _ = () => a;
        return _.locale = s, _.key = t, _
    }
    const f = m(a, nn(e, s, o, a, g, c));
    return f.locale = s, f.key = t, f.source = a, f
}

function en(e, t, s) {
    return t(s)
}

function tn(...e) {
    const [t, s, a] = e, o = {};
    if (!b(t) && !v(t) && !K(t)) throw ee(z.INVALID_ARGUMENT);
    const c = v(t) ? String(t) : (K(t), t);
    return v(s) ? o.plural = s : b(s) ? o.default = s : M(s) && !ie(s) ? o.named = s : G(s) && (o.list = s), v(a) ? o.plural = a : b(a) ? o.default = a : M(a) && q(o, a), [c, o]
}

function nn(e, t, s, a, o, c) {
    return {
        warnHtmlMessage: o,
        onError: m => {
            throw c && c(m), m
        },
        onCacheKey: m => et(t, s, m)
    }
}

function rn(e, t, s, a) {
    const {
        modifiers: o,
        pluralRules: c,
        messageResolver: m,
        fallbackLocale: g,
        fallbackWarn: f,
        missingWarn: _,
        fallbackContext: S
    } = e, N = {
        locale: t,
        modifiers: o,
        pluralRules: c,
        messages: y => {
            let O = m(s, y);
            if (O == null && S) {
                const [, , A] = $e(S, y, t, g, f, _);
                O = m(A, y)
            }
            if (b(O)) {
                let A = !1;
                const l = Ve(e, y, t, O, y, () => {
                    A = !0
                });
                return A ? De : l
            } else return K(O) ? O : De
        }
    };
    return e.processor && (N.processor = e.processor), a.list && (N.list = a.list), a.named && (N.named = a.named), v(a.plural) && (N.pluralIndex = a.plural), N
}

function bn(e, ...t) {
    const {
        datetimeFormats: s,
        unresolving: a,
        fallbackLocale: o,
        onWarn: c,
        localeFallbacker: m
    } = e, {
        __datetimeFormatters: g
    } = e, [f, _, S, T] = an(...t), N = W(S.missingWarn) ? S.missingWarn : e.missingWarn;
    W(S.fallbackWarn) ? S.fallbackWarn : e.fallbackWarn;
    const y = !!S.part,
        O = b(S.locale) ? S.locale : e.locale,
        A = m(e, o, O);
    if (!b(f) || f === "") return new Intl.DateTimeFormat(O, T).format(_);
    let I = {},
        l, d = null;
    const E = "datetime format";
    for (let p = 0; p < A.length && (l = A[p], I = s[l] || {}, d = I[f], !M(d)); p++) _e(e, f, l, N, E);
    if (!M(d) || !b(l)) return a ? me : f;
    let u = `${l}__${f}`;
    ie(T) || (u = `${u}__${JSON.stringify(T)}`);
    let h = g.get(u);
    return h || (h = new Intl.DateTimeFormat(l, q({}, d, T)), g.set(u, h)), y ? h.formatToParts(_) : h.format(_)
}
const sn = ["localeMatcher", "weekday", "era", "year", "month", "day", "hour", "minute", "second", "timeZoneName", "formatMatcher", "hour12", "timeZone", "dateStyle", "timeStyle", "calendar", "dayPeriod", "numberingSystem", "hourCycle", "fractionalSecondDigits"];

function an(...e) {
    const [t, s, a, o] = e, c = {};
    let m = {},
        g;
    if (b(t)) {
        const f = t.match(/(\d{4}-\d{2}-\d{2})(T|\s)?(.*)/);
        if (!f) throw ee(z.INVALID_ISO_DATE_ARGUMENT);
        const _ = f[3] ? f[3].trim().startsWith("T") ? `${f[1].trim()}${f[3].trim()}` : `${f[1].trim()}T${f[3].trim()}` : f[1].trim();
        g = new Date(_);
        try {
            g.toISOString()
        } catch {
            throw ee(z.INVALID_ISO_DATE_ARGUMENT)
        }
    } else if (nt(t)) {
        if (isNaN(t.getTime())) throw ee(z.INVALID_DATE_ARGUMENT);
        g = t
    } else if (v(t)) g = t;
    else throw ee(z.INVALID_ARGUMENT);
    return b(s) ? c.key = s : M(s) && Object.keys(s).forEach(f => {
        sn.includes(f) ? m[f] = s[f] : c[f] = s[f]
    }), b(a) ? c.locale = a : M(a) && (m = a), M(o) && (m = o), [c.key || "", g, c, m]
}

function kn(e, t, s) {
    const a = e;
    for (const o in s) {
        const c = `${t}__${o}`;
        a.__datetimeFormatters.has(c) && a.__datetimeFormatters.delete(c)
    }
}

function yn(e, ...t) {
    const {
        numberFormats: s,
        unresolving: a,
        fallbackLocale: o,
        onWarn: c,
        localeFallbacker: m
    } = e, {
        __numberFormatters: g
    } = e, [f, _, S, T] = cn(...t), N = W(S.missingWarn) ? S.missingWarn : e.missingWarn;
    W(S.fallbackWarn) ? S.fallbackWarn : e.fallbackWarn;
    const y = !!S.part,
        O = b(S.locale) ? S.locale : e.locale,
        A = m(e, o, O);
    if (!b(f) || f === "") return new Intl.NumberFormat(O, T).format(_);
    let I = {},
        l, d = null;
    const E = "number format";
    for (let p = 0; p < A.length && (l = A[p], I = s[l] || {}, d = I[f], !M(d)); p++) _e(e, f, l, N, E);
    if (!M(d) || !b(l)) return a ? me : f;
    let u = `${l}__${f}`;
    ie(T) || (u = `${u}__${JSON.stringify(T)}`);
    let h = g.get(u);
    return h || (h = new Intl.NumberFormat(l, q({}, d, T)), g.set(u, h)), y ? h.formatToParts(_) : h.format(_)
}
const ln = ["localeMatcher", "style", "currency", "currencyDisplay", "currencySign", "useGrouping", "minimumIntegerDigits", "minimumFractionDigits", "maximumFractionDigits", "minimumSignificantDigits", "maximumSignificantDigits", "compactDisplay", "notation", "signDisplay", "unit", "unitDisplay", "roundingMode", "roundingPriority", "roundingIncrement", "trailingZeroDisplay"];

function cn(...e) {
    const [t, s, a, o] = e, c = {};
    let m = {};
    if (!v(t)) throw ee(z.INVALID_ARGUMENT);
    const g = t;
    return b(s) ? c.key = s : M(s) && Object.keys(s).forEach(f => {
        ln.includes(f) ? m[f] = s[f] : c[f] = s[f]
    }), b(a) ? c.locale = a : M(a) && (m = a), M(o) && (m = o), [c.key || "", g, c, m]
}

function On(e, t, s) {
    const a = e;
    for (const o in s) {
        const c = `${t}__${o}`;
        a.__numberFormatters.has(c) && a.__numberFormatters.delete(c)
    }
}
typeof __INTLIFY_PROD_DEVTOOLS__ != "boolean" && (st().__INTLIFY_PROD_DEVTOOLS__ = !1);
export {
    On as A, Nn as B, D as C, Re as D, Tn as E, me as F, tn as G, An as H, an as I, bn as J, cn as K, yn as L, En as M, ln as N, gn as O, q as a, b, w as c, W as d, ie as e, G as f, M as g, Ne as h, v as i, U as j, hn as k, pn as l, un as m, st as n, fe as o, fn as p, on as q, Ln as r, mn as s, sn as t, In as u, Sn as v, dn as w, _n as x, Cn as y, kn as z
};