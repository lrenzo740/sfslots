import {
    _ as H,
    $ as V,
    g as v,
    __tla as X
} from "./index.0a674315.js";
import {
    an as q,
    r as u,
    k as z,
    l as J,
    j as Q,
    ab as F,
    o,
    c as g,
    L as G,
    a as d,
    R as y,
    S,
    P as K,
    a3 as Y,
    u as a,
    O as $,
    V as B,
    Q as Z
} from "./@vue.16908cbf.js";
import {
    b as tt,
    u as at
} from "./vue-router.d17f0860.js";
import {
    u as et
} from "./vuex.7fead168.js";
import {
    S as st,
    A as rt,
    P as ot,
    a as lt
} from "./swiper.137b1af3.js";
import "./axios.4a70c6fc.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./vue-i18n.d9454f26.js";
import "./@intlify.7347860c.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
let N, nt = Promise.all([(() => {
    try {
        return X
    } catch {}
})()]).then(async () => {
    let h, _, k, b, x, C, I;
    h = {
        class: "notice"
    }, _ = {
        class: "noticeIcon"
    }, k = {
        class: "notice-content"
    }, b = {
        class: "text-content"
    }, x = ["innerHTML"], C = ["src", "onClick"], I = ["src", "onClick"], N = {
        __name: "notice",
        setup(it) {
            const P = q(() => H(() =>
                    import ("./index.68114189.js"), ["js/index.68114189.js", "js/@vue.16908cbf.js", "css/index.b337ae19.css"])),
                f = u(null),
                R = tt(),
                O = at(),
                W = u(0),
                s = et(),
                m = u([]),
                p = u(0),
                M = u(null),
                T = (t, l) => {
                    let n = t.slides[0].getElementsByTagName("div")[0],
                        e = t.slides[1].getElementsByTagName("div")[0];
                    if (l == "start") {
                        var r = t.slides[0].getElementsByTagName("p")[0],
                            i = r.offsetWidth - e.offsetWidth,
                            c = i / 60;
                        p.value = parseInt(c + 2)
                    } else {
                        var r = t.slides[1].getElementsByTagName("p")[0],
                            i = r.offsetWidth - e.offsetWidth,
                            c = i / 60;
                        p.value = parseInt(c + 2)
                    }
                    i > 0 ? l == "start" ? (e.style = "transform: none; transition: none;", n.style = `transform: translateX(-${i}px); transition: ${c}s linear 0.5s;`) : (n.style = "transform: none; transition: none;", e.style = `transform: translateX(-${i}px); transition: ${c}s linear 0.5s;`) : p.value = 10
                },
                U = t => {
                    T(t, "start")
                },
                j = () => new URL("/img/colors/" + v() + "/unread.png",
                    import.meta.url).href,
                A = () => new URL("/img/colors/" + v() + "/read.png",
                    import.meta.url).href,
                D = () => new URL("/img/colors/" + v() + "/notice_gif.png",
                    import.meta.url).href,
                E = () => {
                    R.push("/message-center?type=message")
                };
            z(() => {
                setTimeout(() => {
                    O.path === "/index" && w()
                })
            }), J(() => {
                f.value && clearInterval(f.value), m.value = []
            }), Q(() => {
                w()
            });
            const w = () => {
                    L(), f.value = setInterval(() => {
                        m.value = [], L()
                    }, 3e5)
                },
                L = () => {
                    V.get("/user/msg/marquee", {
                        version: W.value || ""
                    }).then(t => {
                        t.code === 0 && t.data && t.data.length && (t.data.length == 1 && (t.data = [...t.data, ...t.data]), p.value = 0, t.data = [...t.data.slice(-1), ...t.data.slice(0, -1)], t.data.forEach(l => {
                            try {
                                let n = JSON.parse(l.content),
                                    e = "";
                                n.forEach(r => {
                                    e += `<span style='color:${r.color}'>${r.text}</span>`
                                }), l.html = e
                            } catch {}
                        }), m.value = t.data)
                    })
                };
            return (t, l) => {
                const n = F("lazy");
                return o(), g("div", h, [G(d("img", _, null, 512), [
                    [n, D()]
                ]), d("div", k, [m.value.length ? (o(), y(a(lt), {
                    key: 0,
                    onSwiper: U,
                    allowTouchMove: !1,
                    preventClicksPropagation: "",
                    autoplay: {
                        delay: p.value * 1e3,
                        disableOnInteraction: !1
                    },
                    modules: [a(rt), a(ot)],
                    loop: !0,
                    ref_key: "mySwiper",
                    ref: M,
                    direction: "vertical",
                    onSlideChange: T,
                    class: "mySwiper"
                }, {
                    default: S(() => [(o(!0), g(K, null, Y(m.value, e => (o(), y(a(st), {
                        key: e,
                        onClick: r => t.jumpCarouse(e)
                    }, {
                        default: S(() => [d("div", b, [d("p", {
                            innerHTML: e.html
                        }, null, 8, x)])]),
                        _: 2
                    }, 1032, ["onClick"]))), 128))]),
                    _: 1
                }, 8, ["autoplay", "modules"])) : $("", !0)]), d("div", {
                    class: Z(["emailBox", {
                        opened: !(a(s).state.badge && a(s).state.badge.message > 0)
                    }])
                }, [a(s).state.badge && a(s).state.badge.message > 0 ? (o(), g("img", {
                    key: 0,
                    src: j(),
                    class: "emailIcon",
                    onClick: B(E, ["stop"])
                }, null, 8, C)) : (o(), g("img", {
                    key: 1,
                    src: A(),
                    class: "emailIcon",
                    onClick: B(E, ["stop"])
                }, null, 8, I)), a(s).state.badge && a(s).state.badge.message > 0 ? (o(), y(a(P), {
                    key: 2,
                    text: a(s).state.badge.message,
                    top: "-.1rem"
                }, null, 8, ["text"])) : $("", !0)], 2)])
            }
        }
    }
});
export {
    nt as __tla, N as
    default
};