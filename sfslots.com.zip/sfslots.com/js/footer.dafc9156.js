import {
    u as ot
} from "./vuex.7fead168.js";
import {
    b as st,
    u as at
} from "./vue-router.d17f0860.js";
import {
    e as v,
    f as lt,
    h as rt,
    j as it,
    F as mt,
    S as K,
    T as nt,
    __tla as ct
} from "./index.0a674315.js";
import {
    u as pt
} from "./vue-i18n.d9454f26.js";
import {
    ab as ut,
    o as s,
    c as a,
    u as t,
    O as i,
    a as r,
    W as m,
    P as p,
    a3 as u,
    L as b
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@intlify.7347860c.js";
let N, dt = Promise.all([(() => {
    try {
        return ct
    } catch {}
})()]).then(async () => {
    const Q = "/png/img_footer_jr.d565e155.png",
        U = "/png/img_footer_jr2.1dcec9da.png";
    let g, y, w, F, h, k, x, I, _, C, T, B, $, S, j, L, O, P, q, z, A, M, R, V, W, D, E, G;
    g = {
        class: "home-footer"
    }, y = {
        key: 0,
        class: "home-footer-festivalBox"
    }, w = r("img", {
        src: Q,
        class: "home-footer-festivalBox-leftImg"
    }, null, -1), F = r("img", {
        src: U,
        class: "home-footer-festivalBox-rightImg"
    }, null, -1), h = [w, F], k = {
        class: "innerBox"
    }, x = {
        class: "mixBox"
    }, I = {
        class: "home-footer-top"
    }, _ = {
        key: 0,
        class: "home-footer-top-box"
    }, C = {
        key: 0,
        class: "cassino footer-item"
    }, T = {
        class: "title"
    }, B = ["onClick"], $ = {
        key: 1,
        class: "games footer-item"
    }, S = {
        class: "title"
    }, j = ["onClick"], L = {
        key: 2,
        class: "support footer-item"
    }, O = {
        class: "title"
    }, P = ["onClick"], q = {
        class: "home-footer-middle"
    }, z = {
        class: "home-footer-middle-box"
    }, A = {
        key: 1,
        class: "icons-box"
    }, M = ["onClick"], R = {
        key: 2,
        class: "text"
    }, V = {
        class: "home-footer-bottom"
    }, W = {
        class: "mixIcons"
    }, D = {
        key: 0,
        class: "bigIcons"
    }, E = {
        key: 1,
        class: "smallIcons"
    }, G = {
        key: 0,
        class: "copyRight"
    }, N = {
        __name: "footer",
        setup(ft) {
            const e = ot(),
                d = st(),
                H = at(),
                {
                    t: X
                } = pt(),
                Y = l => {
                    d.push(mt[l])
                },
                Z = l => {
                    if (H.name === "index") {
                        let c = e.state.tableList.find(o => o.type == l.value),
                            f = e.state.tableList.findIndex(o => o.type == l.value);
                        H.query.gameType != l.value && d.replace("/index?gameType=" + l.value), globalVBus.$emit("changeActiveTab", f, c)
                    } else d.push("/index?gameType=" + l.value)
                },
                tt = l => {
                    if (!K[l]) return nt(X("footer.none"));
                    d.push(K[l])
                },
                J = l => {
                    l && window.open(l, "new")
                };
            return (l, c) => {
                const f = ut("lazy");
                return s(), a("div", g, [t(e).state.festivalStyle && !t(e).state.isMobile ? (s(), a("div", y, h)) : i("", !0), r("div", k, [r("div", x, [r("div", I, [t(e).state.webFooter.modules && t(e).state.webFooter.modules.status ? (s(), a("div", _, [t(e).state.webFooter.modules.funcs && t(e).state.webFooter.modules.funcs.length ? (s(), a("div", C, [r("div", T, m(l.$t("footer.cassino")), 1), r("ul", null, [(s(!0), a(p, null, u(t(e).state.webFooter.modules.funcs, o => (s(), a("li", {
                    key: o.value,
                    onClick: n => Y(o.value)
                }, m(t(v)(t(lt)(o.value))), 9, B))), 128))])])) : i("", !0), t(e).state.webFooter.modules.gameTypes && t(e).state.webFooter.modules.gameTypes.length ? (s(), a("div", $, [r("div", S, m(l.$t("footer.games")), 1), r("ul", null, [(s(!0), a(p, null, u(t(e).state.webFooter.modules.gameTypes, (o, n) => (s(), a("li", {
                    key: o.value,
                    onClick: et => Z(o)
                }, m(t(v)(t(rt)(o.value))), 9, j))), 128))])])) : i("", !0), t(e).state.webFooter.modules.supps && t(e).state.webFooter.modules.supps.length ? (s(), a("div", L, [r("div", O, m(l.$t("footer.support")), 1), r("ul", null, [(s(!0), a(p, null, u(t(e).state.webFooter.modules.supps, o => (s(), a("li", {
                    key: o.value,
                    onClick: n => tt(o.value)
                }, m(t(v)(t(it)(o.value))), 9, P))), 128))])])) : i("", !0)])) : i("", !0)]), r("div", q, [r("div", z, [t(e).state.techSupport ? (s(), a("div", {
                    key: 0,
                    class: "home-footer-middle-support",
                    onClick: c[0] || (c[0] = o => J(t(e).state.techSupport))
                }, m(l.$t("footer.technicalSupport")), 1)) : i("", !0), t(e).state.webFooter.customConfig && t(e).state.webFooter.customConfig.status ? (s(), a("div", A, [(s(!0), a(p, null, u(t(e).state.webFooter.customConfig.customs, (o, n) => b((s(), a("img", {
                    key: n,
                    onClick: et => J(o.url)
                }, null, 8, M)), [
                    [f, o.image]
                ])), 128))])) : i("", !0), t(e).state.webFooter.companyInfo && t(e).state.webFooter.companyInfo.status ? (s(), a("div", R, m(t(e).state.webFooter.companyInfo.desc), 1)) : i("", !0)])])]), r("div", V, [r("div", W, [t(e).state.webFooter.partners && t(e).state.webFooter.partners.status ? (s(), a("div", D, [(s(!0), a(p, null, u(t(e).state.webFooter.partners.images, (o, n) => b((s(), a("img", {
                    key: n
                })), [
                    [f, o]
                ])), 128))])) : i("", !0), t(e).state.webFooter.licenses && t(e).state.webFooter.licenses.status ? (s(), a("div", E, [(s(!0), a(p, null, u(t(e).state.webFooter.licenses.images, (o, n) => b((s(), a("img", {
                    key: n
                })), [
                    [f, o]
                ])), 128))])) : i("", !0)]), t(e).state.webFooter.contactInfo && t(e).state.webFooter.contactInfo.status ? (s(), a("div", G, m(t(e).state.webFooter.contactInfo.contact) + " " + m(t(e).state.webFooter.contactInfo.copyright) + " ", 1)) : i("", !0), r("div", {
                    class: "complaintBtn",
                    onClick: c[1] || (c[1] = o => t(d).push("/complaint"))
                }, m(l.$t("complaint.title")), 1)])])])
            }
        }
    }
});
export {
    dt as __tla, N as
    default
};