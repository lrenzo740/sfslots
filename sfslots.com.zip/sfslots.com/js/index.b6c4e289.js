import {
    _ as T,
    g as L,
    t as u,
    a as U,
    $ as V,
    __tla as q
} from "./index.0a674315.js";
import {
    b as B,
    u as K
} from "./vue-router.d17f0860.js";
import {
    u as Q
} from "./vuex.7fead168.js";
import {
    u as S
} from "./vue-i18n.d9454f26.js";
import {
    an as W,
    r as g,
    w as z,
    j as F,
    u as c,
    o as r,
    c as s,
    O as v,
    P as G,
    a3 as H,
    Q as J,
    a as l,
    R as N,
    W as X
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@intlify.7347860c.js";
let $, Y = Promise.all([(() => {
    try {
        return q
    } catch {}
})()]).then(async () => {
    const E = "/png/icon_btm_jr.b38f3c3d.png",
        M = "/png/icon_btm_jr2.17e667c7.png";
    let d, h, b, _, k, f, I, w, x;
    d = {
        key: 0,
        class: "bottomMenu"
    }, h = {
        key: 0,
        class: "festival"
    }, b = l("img", {
        src: E,
        class: "leftImg"
    }, null, -1), _ = l("img", {
        src: M,
        class: "rightImg"
    }, null, -1), k = [b, _], f = ["onClick"], I = {
        class: "imgIcon"
    }, w = ["src"], x = ["src"], $ = {
        __name: "index",
        setup(Z) {
            const P = W(() => T(() =>
                    import ("./index.68114189.js"), ["js/index.68114189.js", "js/@vue.16908cbf.js", "css/index.b337ae19.css"])),
                t = Q(),
                n = g(""),
                j = B(),
                o = K(),
                p = g(null),
                m = g();
            S();
            const y = a => {
                    let e;
                    switch (a) {
                        case "index":
                            e = {
                                icon: "index_active",
                                noIcon: "index"
                            };
                            break;
                        case "promotion":
                            e = {
                                icon: "promotion_active",
                                noIcon: "promotion"
                            };
                            break;
                        case "exchange":
                            e = {
                                icon: "withdraw_active",
                                noIcon: "withdraw"
                            };
                            break;
                        case "recharge":
                            e = {
                                icon: "recharge",
                                noIcon: "recharge"
                            };
                            break;
                        case "me":
                            e = {
                                icon: "me_active",
                                noIcon: "me"
                            };
                            break;
                        case "vip":
                            e = {
                                icon: "vip_active",
                                noIcon: "vip"
                            };
                            break;
                        case "rebate":
                            e = {
                                icon: "promotion_active",
                                noIcon: "promotion"
                            };
                            break;
                        case "task":
                            e = {
                                icon: "task_active",
                                noIcon: "task"
                            };
                            break;
                        case "agent":
                            e = {
                                icon: "agent",
                                noIcon: "agent"
                            };
                            break
                    }
                    return e
                },
                R = (a, e) => e ? new URL("/img/colors/" + L() + "/" + y(a).icon + ".png",
                    import.meta.url).href : new URL("/img/colors/" + L() + "/" + y(a).noIcon + ".png",
                    import.meta.url).href,
                A = a => {
                    if (a.badge !== 1) return !1;
                    if (a.alias === "recharge" && m.value && m.value.rechargeMaxRate || a.alias === "vip" && t.state.badge.vip && t.state.badge.vip > 0 || a.alias === "promotion" && t.state.badge.event && t.state.badge.event > 0) return !0
                },
                O = a => {
                    let e = "";
                    switch (a.alias) {
                        case "recharge":
                            e = m.value ? m.value.rechargeMaxRate + "%" : "";
                            break;
                        case "vip":
                            e = t.state.badge.vip;
                            break;
                        case "promotion":
                            e = t.state.badge.event;
                            break
                    }
                    return e
                };
            z(o, () => {
                if (o.name) {
                    if (t.state.moduleList.find(a => a.alias === o.name)) return n.value = o.name;
                    o.name === "fees" || o.name === "event" || o.name === "rebate" || o.name === "vip" || o.name === "claim" ? n.value = "promotion" : n.value = o.name
                }
            }, {
                deep: !0,
                immediate: !0
            });
            const C = a => {
                    if (u() && a === "recharge") return t.state.showRechargeDialog = !0;
                    (u() || !u() && (a === "index" || a === "promotion" || a === "vip" || a === "agent")) && (n.value = a), a === "promotion" && (a = "promotion/event"), a === "vip" && (a = "promotion/vip"), a === "rebate" && (a = "promotion/rebate"), a === "task" && (a = "promotion/task"), a === "exchange" && !t.state.accountInfo.hasExchangePwd && (a = "set-password"), j.push({
                        path: `/${a}`,
                        query: U()
                    })
                },
                D = () => {
                    V.post("/trade/order/topTip").then(a => {
                        a && a.status === "OK" && (m.value = a.data, t.state.agentAd = !!a.data.agentAd)
                    })
                };
            return F(() => {
                globalVBus.$on("changeMenu", a => {
                    n.value = a
                }), p.value && p.value.forEach(a => {
                    a.style.width = 100 / t.state.moduleList.length + "%"
                }), D()
            }), (a, e) => c(t).state.moduleList.length ? (r(), s("div", d, [c(t).state.festivalStyle ? (r(), s("div", h, k)) : v("", !0), (r(!0), s(G, null, H(c(t).state.moduleList, i => (r(), s("div", {
                class: J(["menu-item", {
                    active: n.value === i.alias && i.alias != "recharge"
                }]),
                key: i.alias,
                onClick: aa => C(i.alias),
                ref_for: !0,
                ref_key: "menuItem",
                ref: p
            }, [l("div", I, [n.value === i.alias ? (r(), s("img", {
                key: 0,
                src: R(i.alias, !0)
            }, null, 8, w)) : (r(), s("img", {
                key: 1,
                src: R(i.alias, !1)
            }, null, 8, x)), A(i) ? (r(), N(c(P), {
                key: 2,
                text: O(i)
            }, null, 8, ["text"])) : v("", !0)]), l("span", null, X(a.$t(`bottom_menu.${i.alias}`)), 1)], 10, f))), 128))])) : v("", !0)
        }
    }
});
export {
    Y as __tla, $ as
    default
};