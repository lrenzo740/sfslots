import {
    _ as u,
    __tla as n
} from "./index.0a674315.js";
import {
    P as c
} from "./vant.be74fb7c.js";
import {
    u as h
} from "./vuex.7fead168.js";
import {
    an as f,
    r as w,
    e as d,
    w as v,
    o as p,
    R as i,
    S as g,
    u as x,
    O as y
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./vue-router.d17f0860.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vue-i18n.d9454f26.js";
import "./@intlify.7347860c.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@vant.359a3f91.js";
let m, P = Promise.all([(() => {
    try {
        return n
    } catch {}
})()]).then(async () => {
    m = {
        __name: "index_popup",
        setup(R) {
            const e = f(() => u(() =>
                    import ("./index.10f4a4d2.js").then(async t => (await t.__tla, t)), ["js/index.10f4a4d2.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/index.384d5d5f.css"])),
                s = h(),
                o = w(!1),
                r = d(() => s.state.showRechargeDialog);
            return v(r, (t, a) => {
                t ? o.value = t : setTimeout(() => {
                    o.value = t
                }, 300)
            }), (t, a) => {
                const l = c;
                return p(), i(l, {
                    show: r.value,
                    "onUpdate:show": a[0] || (a[0] = _ => r.value = _),
                    position: "bottom",
                    closeable: !1,
                    class: "recharge"
                }, {
                    default: g(() => [o.value ? (p(), i(x(e), {
                        key: 0,
                        class: "index-popup"
                    })) : y("", !0)]),
                    _: 1
                }, 8, ["show"])
            }
        }
    }
});
export {
    P as __tla, m as
    default
};