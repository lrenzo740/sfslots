import {
    t as P,
    $ as I,
    d as $,
    C as H,
    __tla as L
} from "./index.0a674315.js";
import {
    u as V
} from "./vuex.7fead168.js";
import {
    u as j
} from "./vue-i18n.d9454f26.js";
import {
    u as w
} from "./vue-router.d17f0860.js";
import {
    r as n,
    e as R,
    j as D,
    k as J,
    o as c,
    c as d,
    a,
    W as i,
    O as K
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@intlify.7347860c.js";
let y, W = Promise.all([(() => {
    try {
        return L
    } catch {}
})()]).then(async () => {
    let u, v, x, g, _, f, S, k;
    u = {
        key: 0,
        class: "pop-red-envelopes"
    }, v = {
        key: 0,
        class: "redEnvelopes-box"
    }, x = {
        class: "text"
    }, g = {
        class: "btnBox-text"
    }, _ = {
        key: 1,
        class: "redEnvelopes-open"
    }, f = {
        class: "redEnvelopes-open-title"
    }, S = {
        class: "redEnvelopes-open-amount"
    }, k = {
        class: "redEnvelopes-open-text"
    }, y = {
        __name: "index",
        props: ["value"],
        emits: ["update:value", "checkNextRedEnvelopes"],
        setup(B, {
            emit: T
        }) {
            const C = B,
                s = V(),
                p = n(!1),
                h = n(),
                {
                    t: r
                } = j();
            w();
            const e = n(),
                m = n(!1),
                l = R({
                    get() {
                        return C.value
                    },
                    set(t) {
                        setTimeout(() => {
                            T("update:value", t)
                        })
                    }
                }),
                E = () => {
                    H(r("pop_red_envelopes.tips2"), r("pop_red_envelopes.tips1"), () => {
                        l.value = !1, localStorage.setItem("redPocketHandleClose", JSON.stringify(Object.assign(e.value, {
                            userId: s.state.accountInfo.id
                        })))
                    }, () => {}, {
                        confirmText: r("common.confirm"),
                        cancelText: r("common.cancel")
                    })
                },
                M = () => {
                    e.value.count === 0 && (l.value = !1), p.value = !1
                },
                N = () => {
                    globalVBus.$emit("globalLoading", !0), I.post("/user/promotion/claim", {
                        type: 6,
                        promotionId: e.value.id
                    }).then(t => {
                        globalVBus.$emit("globalLoading", !1), t.code === 0 && (e.value.count--, p.value = !0, h.value = t.data.reward, s.dispatch("getBadge"), s.dispatch("refreshBalance"))
                    }).catch(() => {
                        globalVBus.$emit("globalLoading", !1)
                    })
                };
            D(() => {
                O()
            });
            const O = () => {
                if (!P()) return l.value = !1;
                I.get("/user/promotion/vfx").then(t => {
                    if (t.status == "OK" && t.data && t.data[6]) {
                        let b = t.data[6];
                        if (e.value = b[0], s.state.endMs = e.value.endMs || 0, e.value.endMs && e.value.count > 0) {
                            if (localStorage.getItem("redPocketHandleClose")) {
                                let o = JSON.parse(localStorage.getItem("redPocketHandleClose"));
                                o.userId === s.state.accountInfo.id && o.id === e.value.id && (o.nextStartTime && e.value.nextStartTime && o.nextStartTime === e.value.nextStartTime || !o.nextStartTime && !e.value.nextStartTime) && (l.value = !1)
                            }
                        } else l.value = !1;
                        if (e.value.nextStartTime) {
                            let o = e.value.nextStartTime - new Date().getTime() + 3e3;
                            o > 0 && T("checkNextRedEnvelopes", Math.ceil(o / 1e3) * 1e3)
                        }
                        m.value = !0
                    }
                })
            };
            return J(() => {
                m.value = !1
            }), (t, b) => l.value && m.value ? (c(), d("div", u, [p.value ? (c(), d("div", _, [a("div", f, i(t.$t("pop_red_envelopes.text3")), 1), a("div", S, i(h.value), 1), a("div", k, [a("span", null, i(t.$t("pop_red_envelopes.text4")), 1)]), a("div", {
                class: "closeIcon"
            }, [a("img", {
                src: $,
                alt: "",
                onClick: M
            })])])) : (c(), d("div", v, [a("div", x, i(t.$t("pop_red_envelopes.text1")), 1), a("div", {
                class: "btnBox",
                onClick: N
            }, [a("div", g, [a("span", null, i(t.$t("pop_red_envelopes.text2")), 1)])]), a("div", {
                class: "closeIcon"
            }, [a("img", {
                src: $,
                alt: "",
                onClick: E
            })])]))])) : K("", !0)
        }
    }
});
export {
    W as __tla, y as
    default
};