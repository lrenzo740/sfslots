import {
    _ as ze,
    $ as Ce,
    b as je,
    i as Ge,
    T as Je,
    t as Qe,
    c as Ue,
    __tla as Xe
} from "./index.0a674315.js";
import {
    an as Fe,
    r as C,
    w as Ke,
    j as Ye,
    n as _e,
    aa as Ze,
    ab as et,
    o as i,
    c as r,
    a as s,
    u as t,
    P as xe,
    a3 as Be,
    Q as w,
    R as g,
    W as d,
    O as c,
    U as f,
    V as I,
    L as b
} from "./@vue.16908cbf.js";
import {
    u as tt
} from "./vuex.7fead168.js";
import {
    b as at,
    u as st
} from "./vue-router.d17f0860.js";
import {
    u as lt
} from "./vue-i18n.d9454f26.js";
import {
    X as it
} from "./xe-utils.0e898ace.js";
import "./axios.4a70c6fc.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./nprogress.1adef0ba.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@intlify.7347860c.js";
let we, ot = Promise.all([(() => {
    try {
        return Xe
    } catch {}
})()]).then(async () => {
    let N, L, T, V, M, q, R, H, D, A, E, P, O, W, z, j, G, J, Q, U, X, F, K, Y, Z, ee, te, ae, se, le, ie, oe, ne, ce, re, de, ue, me, ge, pe, ve, fe, ye, be;
    N = {
        key: 0,
        class: "side-bar-table"
    }, L = ["onClick"], T = {
        class: "iconBox"
    }, V = ["src"], M = {
        key: 0,
        class: "festival"
    }, q = s("div", {
        class: "festival-leftImg"
    }, null, -1), R = s("div", {
        class: "festival-rightImg"
    }, null, -1), H = [q, R], D = {
        key: 1,
        class: "side-bar-music"
    }, A = {
        class: "music-left"
    }, E = {
        class: "widthBox"
    }, P = {
        class: "music-left-pre"
    }, O = {
        class: "music-left-play"
    }, W = {
        class: "music-left-next"
    }, z = {
        class: "music-right"
    }, j = {
        class: "music-right-type"
    }, G = {
        key: 0,
        class: "badge"
    }, J = {
        key: 0,
        class: "music-name"
    }, Q = {
        class: "side-bar-btns"
    }, U = {
        class: "event-title"
    }, X = {
        alt: ""
    }, F = {
        alt: ""
    }, K = {
        alt: ""
    }, Y = {
        alt: ""
    }, Z = {
        alt: ""
    }, ee = {
        alt: ""
    }, te = {
        alt: ""
    }, ae = s("span", null, "VIP", -1), se = {
        alt: ""
    }, le = {
        class: "language-left"
    }, ie = {
        class: "language-right"
    }, oe = {
        class: "item-left"
    }, ne = {
        class: "custom-icon"
    }, ce = {
        class: "item-right"
    }, re = {
        class: "item-left"
    }, de = {
        class: "custom-icon"
    }, ue = {
        class: "item-right"
    }, me = {
        class: "item-left"
    }, ge = {
        class: "custom-icon"
    }, pe = {
        class: "item-right"
    }, ve = {
        class: "item-left"
    }, fe = {
        class: "custom-icon"
    }, ye = {
        class: "item-right"
    }, be = ["onClick"], we = {
        __name: "index",
        setup(nt) {
            const k = Fe(() => ze(() =>
                    import ("./index.68114189.js"), ["js/index.68114189.js", "js/@vue.16908cbf.js", "css/index.b337ae19.css"])),
                {
                    locale: Se,
                    t: $e
                } = lt(),
                e = tt(),
                _ = C(null),
                Ie = C(null),
                h = at(),
                x = st(),
                y = C(!1),
                S = C(null),
                ke = C(null);
            C(null), Ke(e.state, a => {
                a.showSideBar || (y.value = !1)
            }, {
                deep: !0
            }), Ye(() => {
                e.state.isMobile && (globalVBus.$on("openSideBar", B), B()), globalVBus.$on("toggleSideBar", Le), globalVBus.$on("closeDownLoad", B), Te(), window.addEventListener("resize", () => {
                    e.state.isMobile && globalVBus.$on("openSideBar", B), !e.state.isMobile && _.value && (_.value.style.top = 0)
                }), document.querySelector(".side-bar").addEventListener("scroll", () => {
                    y.value = !1
                })
            });
            const Ne = () => {
                    if (e.state.customerConfig.csc && e.state.customerConfig.el) {
                        let a = e.state.customerConfig.el.indexOf("http") > -1 ? e.state.customerConfig.el : "https://" + e.state.customerConfig.el;
                        window.open(a, "__blank")
                    } else p("/message-center?type=customer-service")
                },
                Le = () => {
                    let a = document.querySelector(".app-side-bar");
                    a.clientWidth ? a.classList.add("hideSide") : a.classList.remove("hideSide")
                },
                Te = () => {
                    e.state.tableList.length || Ve()
                },
                Ve = async () => {
                    let a = [];
                    await Ce.get("/game/game/typedVendors").then(async l => {
                        if (l.code === 0) {
                            a.push(...l.data.filter(m => !!m.vendors.length || m.type === 0 || m.type === 98 || m.type === 99));
                            let n = a.find(m => m.type === 0),
                                u = a.findIndex(m => m.type === 0);
                            u !== -1 && a.splice(u, 1);
                            let o = a.find(m => m.type === 98),
                                v = a.findIndex(m => m.type === 98);
                            v !== -1 && a.splice(v, 1);
                            let $ = a.find(m => m.type === 99),
                                he = a.findIndex(m => m.type === 99);
                            he !== -1 && a.splice(he, 1), n && a.unshift(n), o && a.push(o), $ && a.push($), e.state.tableList = a
                        }
                    })
                },
                B = () => {
                    _e(() => {
                        let a = document.querySelector(".download-app"),
                            l = document.querySelector(".dark-headerMenu");
                        if (!l || !_.value) return;
                        let n = a ? a.clientHeight + l.clientHeight : l.clientHeight;
                        _.value.style.top = n + "px"
                    })
                },
                p = a => {
                    if (!a) return Je($e("side_bar.closed"));
                    e.state.showSideBar = !1, h.push(a)
                },
                Me = (a, l) => {
                    e.state.showSideBar = !1, x.name === "index" ? (x.query.gameType == l.type || h.replace("/index?gameType=" + l.type), globalVBus.$emit("changeActiveTab", a, l)) : h.push("/index?gameType=" + l.type)
                },
                qe = () => {
                    if (y.value = !y.value, !y.value) return;
                    let a = document.querySelector(".download-app"),
                        l = document.querySelector(".app-side-bar .side-bar"),
                        n = l.scrollTop,
                        u, o, v = document.querySelector("html");
                    e.state.isMobile ? (u = document.querySelector(".dark-headerMenu"), o = a ? a.clientHeight + u.clientHeight - n : u.clientHeight - n) : (u = document.querySelector(".dark-headerMenu-pc"), o = u.clientHeight - n), y.value = !0, _e(() => {
                        S.value.style.top = ke.value.offsetTop + o + "px", S.value.style.left = v.offsetLeft + l.clientWidth - 1 + "px"
                    })
                },
                Re = a => {
                    Se.value = a, e.state.language = a, y.value = !1, localStorage.setItem("language", a), e.dispatch("getMetas"), globalVBus.$emit("refreshGameTypeVendorList"), h.replace("/index")
                },
                He = () => {
                    globalVBus.$emit("startMusic")
                },
                De = () => {
                    globalVBus.$emit("pauseMusic")
                },
                Ae = () => {
                    globalVBus.$emit("preMusic")
                },
                Ee = () => {
                    globalVBus.$emit("nextMusic")
                },
                Pe = () => {
                    if (!Qe()) return e.state.showLoginDialog = !0;
                    Oe()
                },
                Oe = it.throttle(function() {
                    let a = {};
                    if (localStorage.getItem("dealerCode")) {
                        let l = localStorage.getItem("dealerCode").split("_")[0];
                        a.dealerCode = l
                    }
                    globalVBus.$emit("globalLoading", !0), Ce.get("/game/dealer/info", a).then(l => {
                        if (globalVBus.$emit("globalLoading", !1), l && l.code === 0) {
                            const {
                                data: n
                            } = l;
                            e.state.dealerApplyData = n, n.isDealer ? (h.push("/dealer"), e.state.showSideBar = !1) : (e.state.showDealerJoinDialog = !0, e.state.showSideBar = !1)
                        }
                    })
                }, 3e3, {
                    leading: !0,
                    trailing: !1
                }),
                We = () => {
                    Ue()
                };
            return (a, l) => {
                const n = Ze("svg-icon"),
                    u = et("lazy");
                return i(), r("div", {
                    class: "app-side-bar",
                    ref_key: "appSideBarRef",
                    ref: Ie
                }, [s("div", {
                    class: w([{
                        show: t(e).state.showSideBar
                    }, "side-bar", {
                        skin0: t(e).state.skinBg === 0
                    }]),
                    ref_key: "sideBarRef",
                    ref: _
                }, [t(e).state.sections.game && t(e).state.tableList.length ? (i(), r("ul", N, [(i(!0), r(xe, null, Be(t(e).state.tableList, (o, v) => (i(), r("li", {
                    key: v,
                    class: w({
                        active: t(e).state.activeTab === v && t(x).name === "index"
                    }),
                    onClick: $ => Me(v, o)
                }, [s("div", T, [t(e).state.activeTab === v && t(x).name === "index" ? (i(), r("img", {
                    key: 0,
                    src: o.icon
                }, null, 8, V)) : (i(), g(n, {
                    key: 1,
                    iconClass: t(je)(o.type).icon
                }, null, 8, ["iconClass"]))]), s("span", null, d(o.name), 1), t(e).state.festivalStyle && t(e).state.activeTab === v ? (i(), r("div", M, H)) : c("", !0)], 10, L))), 128))])) : c("", !0), t(e).state.musicInfo.open ? (i(), r("div", D, [s("div", A, [s("div", E, [s("div", P, [f(n, {
                    iconClass: "music_pre",
                    onClick: Ae
                })]), s("div", O, [t(e).state.musicInfo.playStatus ? (i(), g(n, {
                    key: 0,
                    iconClass: "music_pause",
                    onClick: De
                })) : (i(), g(n, {
                    key: 1,
                    iconClass: "music_start",
                    onClick: He
                }))]), s("div", W, [f(n, {
                    iconClass: "music_next",
                    onClick: Ee
                })])])]), s("div", z, [s("div", j, [t(e).state.musicInfo.cycleType === "cycle" ? (i(), g(n, {
                    key: 0,
                    iconClass: "music_cycle",
                    onClick: l[0] || (l[0] = o => t(e).state.musicInfo.cycleType = "random")
                })) : t(e).state.musicInfo.cycleType === "random" ? (i(), g(n, {
                    key: 1,
                    iconClass: "music_random",
                    onClick: l[1] || (l[1] = o => t(e).state.musicInfo.cycleType = "single")
                })) : t(e).state.musicInfo.cycleType === "single" ? (i(), g(n, {
                    key: 2,
                    iconClass: "music_single",
                    onClick: l[2] || (l[2] = o => t(e).state.musicInfo.cycleType = "cycle")
                })) : c("", !0)]), s("div", {
                    class: "music-right-list",
                    onClick: l[3] || (l[3] = o => t(e).state.showMusicList = !0)
                }, [f(n, {
                    iconClass: "music_list"
                }), t(e).state.musicInfo.downloadList.length > 0 ? (i(), r("div", G, d(t(e).state.musicInfo.downloadList.length), 1)) : c("", !0)])]), t(e).state.musicInfo.currentMusic.name ? (i(), r("div", J, d(t(e).state.musicInfo.currentMusic.name), 1)) : c("", !0)])) : c("", !0), t(e).state.leftNavigations.playRecord ? (i(), r("div", {
                    key: 2,
                    class: "side-bar-betting-records",
                    onClick: l[4] || (l[4] = I(o => {
                        t(h).push("/account?tabId=2"), t(e).state.showSideBar = !1
                    }, ["stop"]))
                }, [f(n, {
                    iconClass: "nav_record"
                }), s("span", null, d(a.$t("side_bar.bet_record")), 1)])) : c("", !0), t(e).state.leftNavigations.inviteShare ? (i(), r("div", {
                    key: 3,
                    class: "side-bar-betting-records side-bar-betting-records-top",
                    onClick: l[5] || (l[5] = I(o => p("/agent"), ["stop"]))
                }, [f(n, {
                    iconClass: "agente"
                }), s("span", null, d(a.$t("side_bar.agency")), 1)])) : c("", !0), s("ul", Q, [s("div", U, [s("span", null, d(a.$t("side_bar.event_title")), 1)]), t(e).state.leftNavigations.promotion ? (i(), r("li", {
                    key: 0,
                    class: "small",
                    onClick: l[6] || (l[6] = o => p("/promotion/event"))
                }, [b(s("img", X, null, 512), [
                    [u, t(e).state.leftNavigations.promotion]
                ]), s("span", null, d(a.$t("side_bar.event")), 1), t(e).state.badge && t(e).state.badge.event > 0 ? (i(), g(t(k), {
                    key: 0,
                    text: t(e).state.badge.event
                }, null, 8, ["text"])) : c("", !0)])) : c("", !0), t(e).state.leftNavigations.task ? (i(), r("li", {
                    key: 1,
                    class: "small",
                    onClick: l[7] || (l[7] = o => p("/promotion/task"))
                }, [b(s("img", F, null, 512), [
                    [u, t(e).state.leftNavigations.task]
                ]), s("span", null, d(a.$t("side_bar.task")), 1), t(e).state.badge && t(e).state.badge.task > 0 ? (i(), g(t(k), {
                    key: 0,
                    text: t(e).state.badge.task
                }, null, 8, ["text"])) : c("", !0)])) : c("", !0), t(e).state.leftNavigations.rebate ? (i(), r("li", {
                    key: 2,
                    class: "small",
                    onClick: l[8] || (l[8] = o => p("/promotion/rebate"))
                }, [b(s("img", K, null, 512), [
                    [u, t(e).state.leftNavigations.rebate]
                ]), s("span", null, d(a.$t("side_bar.rebate")), 1)])) : c("", !0), t(e).state.leftNavigations.pending ? (i(), r("li", {
                    key: 3,
                    class: "small",
                    onClick: l[9] || (l[9] = o => p("/promotion/claim"))
                }, [b(s("img", Y, null, 512), [
                    [u, t(e).state.leftNavigations.pending]
                ]), s("span", null, d(a.$t("side_bar.reward")), 1), t(e).state.badge && t(e).state.badge.unclaimed > 0 ? (i(), g(t(k), {
                    key: 0,
                    text: t(e).state.badge.unclaimed
                }, null, 8, ["text"])) : c("", !0)])) : c("", !0), t(e).state.leftNavigations.collectRecord ? (i(), r("li", {
                    key: 4,
                    class: "small",
                    onClick: l[10] || (l[10] = o => p("/promotion/records"))
                }, [b(s("img", Z, null, 512), [
                    [u, t(e).state.leftNavigations.collectRecord]
                ]), s("span", null, d(a.$t("side_bar.history")), 1)])) : c("", !0), t(e).state.leftNavigations.incomeBox ? (i(), r("li", {
                    key: 5,
                    class: "small",
                    onClick: l[11] || (l[11] = o => p("/promotion/fees"))
                }, [b(s("img", ee, null, 512), [
                    [u, t(e).state.leftNavigations.incomeBox]
                ]), s("span", null, d(a.$t("side_bar.fees")), 1), t(e).state.badge && t(e).state.badge.fees > 0 ? (i(), g(t(k), {
                    key: 0,
                    text: t(e).state.badge.fees
                }, null, 8, ["text"])) : c("", !0)])) : c("", !0), t(e).state.leftNavigations.vip ? (i(), r("li", {
                    key: 6,
                    class: "small",
                    onClick: l[12] || (l[12] = o => p("/promotion/vip"))
                }, [b(s("img", te, null, 512), [
                    [u, t(e).state.leftNavigations.vip]
                ]), ae, t(e).state.badge && t(e).state.badge.vip > 0 ? (i(), g(t(k), {
                    key: 0,
                    text: t(e).state.badge.vip
                }, null, 8, ["text"])) : c("", !0)])) : c("", !0), t(e).state.leftNavigations.dealer ? (i(), r("li", {
                    key: 7,
                    class: "small",
                    onClick: Pe
                }, [b(s("img", se, null, 512), [
                    [u, t(e).state.leftNavigations.dealer]
                ]), s("span", null, d(a.$t("side_bar.dealer")), 1), t(e).state.badge && t(e).state.badge.dealer > 0 ? (i(), g(t(k), {
                    key: 0,
                    text: t(e).state.badge.dealer
                }, null, 8, ["text"])) : c("", !0)])) : c("", !0)]), t(e).state.leftNavigations.language ? (i(), r("div", {
                    key: 4,
                    class: w(["side-bar-language", {
                        active: y.value
                    }]),
                    onClick: qe,
                    ref_key: "languageRef",
                    ref: ke
                }, [s("div", le, [f(n, {
                    iconClass: "nav_language"
                })]), s("div", ie, [s("span", null, d(t(e).state.metaConfig.language.find(o => o.value === t(e).state.language).label), 1)]), f(n, {
                    iconClass: "select_down",
                    class: "arrowIcon"
                })], 2)) : c("", !0), t(e).state.leftNavigations.download && !t(Ge)() && !t(e).state.isApp ? (i(), r("div", {
                    key: 5,
                    class: "side-bar-item",
                    onClick: We
                }, [s("div", oe, [s("div", ne, [f(n, {
                    iconClass: "nav_download"
                })])]), s("div", ce, [s("span", null, d(a.$t("side_bar.download")), 1)])])) : c("", !0), t(e).state.leftNavigations.customerService ? (i(), r("div", {
                    key: 6,
                    class: "side-bar-item",
                    onClick: Ne
                }, [s("div", re, [s("div", de, [f(n, {
                    iconClass: "nav_customer"
                })])]), s("div", ue, [s("span", null, d(a.$t("side_bar.customer_service")), 1)])])) : c("", !0), t(e).state.leftNavigations.faqHelp ? (i(), r("div", {
                    key: 7,
                    class: "side-bar-item",
                    onClick: l[13] || (l[13] = o => p("/message-center?type=customer-service"))
                }, [s("div", me, [s("div", ge, [f(n, {
                    iconClass: "nav_faq"
                })])]), s("div", pe, [s("span", null, d(a.$t("side_bar.faq")), 1)])])) : c("", !0), t(e).state.leftNavigations.about ? (i(), r("div", {
                    key: 8,
                    class: "side-bar-item",
                    onClick: l[14] || (l[14] = o => p("/about-us"))
                }, [s("div", ve, [s("div", fe, [f(n, {
                    iconClass: "nav_about"
                })])]), s("div", ye, [s("span", null, d(a.$t("side_bar.about_us")), 1)])])) : c("", !0)], 2), y.value ? (i(), r("div", {
                    key: 0,
                    class: "selectBox",
                    ref_key: "selectBoxRef",
                    ref: S
                }, [(i(!0), r(xe, null, Be(t(e).state.metaConfig.language, o => (i(), r("div", {
                    key: o.value,
                    class: w(["item", {
                        active: t(e).state.language === o.value
                    }]),
                    onClick: I(v => Re(o.value), ["stop"])
                }, [s("span", null, d(o.label), 1)], 10, be))), 128))], 512)) : c("", !0), t(e).state.showSideBar && t(e).state.isMobile ? (i(), r("div", {
                    key: 1,
                    class: "side-overlay",
                    onClick: l[15] || (l[15] = o => t(e).state.showSideBar = !1)
                })) : c("", !0)], 512)
            }
        }
    }
});
export {
    ot as __tla, we as
    default
};