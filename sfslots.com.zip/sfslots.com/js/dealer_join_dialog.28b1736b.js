import {
    _ as va,
    m as ma,
    T as b,
    $ as _a,
    __tla as ya
} from "./index.0a674315.js";
import {
    d as ba
} from "./element-plus.c133b52b.js";
import {
    R as ga,
    c as fa
} from "./vant.be74fb7c.js";
import {
    an as ja,
    r as y,
    e as D,
    aa as Da,
    ab as ka,
    o as i,
    R as q,
    S as g,
    c as p,
    u as r,
    a,
    W as l,
    O as G,
    P as J,
    a3 as Q,
    U as k,
    a4 as f,
    L as X,
    ac as Aa
} from "./@vue.16908cbf.js";
import {
    C as La
} from "./clipboard.f53621db.js";
import {
    u as $a
} from "./vuex.7fead168.js";
import {
    u as ha
} from "./vue-i18n.d9454f26.js";
import "./axios.4a70c6fc.js";
import "./vue-router.d17f0860.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@vant.359a3f91.js";
import "./dayjs.42829e09.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./@intlify.7347860c.js";
let aa, xa = Promise.all([(() => {
    try {
        return ya
    } catch {}
})()]).then(async () => {
    let A, L, $, h, x, C, I, T, V, w, H, M, U, R, B, E, S, Y, F, N, O, P, z;
    A = {
        key: 0,
        class: "dealer-join-box"
    }, L = {
        key: 0,
        class: "applyDetail"
    }, $ = {
        class: "table-header"
    }, h = {
        class: "table-item"
    }, x = {
        class: "detail"
    }, C = {
        class: "content"
    }, I = {
        key: 0
    }, T = {
        key: 1
    }, V = {
        class: "contact-list"
    }, w = {
        class: "contact-list-item"
    }, H = ["innerHTML"], M = {
        key: 1,
        class: "apply-box"
    }, U = {
        class: "chooseList"
    }, R = {
        class: "chooseList-label"
    }, B = a("b", null, "*", -1), E = {
        class: "contactInput"
    }, S = a("b", null, "*", -1), Y = {
        class: "remarkInput"
    }, F = {
        class: "btns"
    }, N = {
        class: "submitBtn btn"
    }, O = {
        key: 2,
        class: "view-box"
    }, P = ["innerHTML"], z = {
        class: "btns"
    }, aa = {
        __name: "dealer_join_dialog",
        props: ["value"],
        emits: ["update:value"],
        setup(ea, {
            emit: la
        }) {
            const ta = ea,
                oa = ja(() => va(() =>
                    import ("./index.0a674315.js").then(async e => (await e.__tla, e)).then(e => e.a6), ["js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css"])),
                o = $a(),
                d = y(null),
                s = y(1),
                u = y(),
                c = y(),
                v = y(),
                {
                    t: K
                } = ha(),
                na = D(() => {
                    let e = [];
                    return o.state.dealerApplyData.contact && o.state.dealerApplyData.contact.contact.forEach(t => {
                        let m = o.state.metaConfig.imType.find(_ => _.value == t.k).label;
                        e.push({
                            name: m,
                            url: t.v
                        })
                    }), e
                }),
                sa = D(() => {
                    let e = [];
                    return o.state.dealerApplyData.contact && o.state.dealerApplyData.contact.service.forEach(t => {
                        let m = o.state.metaConfig.imType.find(_ => _.value == t);
                        e.push(m)
                    }), e
                }),
                j = D({
                    get() {
                        return ta.value
                    },
                    set(e) {
                        W(), la("update:value", e)
                    }
                }),
                W = () => {
                    u.value = "", c.value = "", v.value = "", s.value = 1
                },
                ia = () => {
                    d.value && d.value.destroy(), d.value = new La(".clipboardUserId"), d.value.on("success", () => {
                        b("Success", "success", ""), d.value.destroy()
                    }), d.value.on("error", () => {
                        b("Failed", "error"), d.value.destroy()
                    })
                },
                ra = async () => {
                    if (!u.value) return b(K("dealer_join_dialog.tips1"));
                    if (!c.value) return b(K("dealer_join_dialog.tips2"));
                    let e = {
                        contact: u.value,
                        contactNum: c.value,
                        content: v.value
                    };
                    o.state.dealerApplyData.dealerId && (e.dealerId = o.state.dealerApplyData.dealerId), await _a.post("/game/dealer/apply", e).then(t => {
                        t && t.status === "OK" && (j.value = !1)
                    })
                },
                pa = () => {
                    s.value === 1 ? j.value = !1 : (W(), s.value = 1)
                },
                Z = () => {
                    s.value = 2, c.value = o.state.dealerApplyData.applyLog.contactNum, v.value = o.state.dealerApplyData.applyLog.content, u.value = o.state.dealerApplyData.applyLog.contact
                };
            return (e, t) => {
                const m = Da("svg-icon"),
                    _ = ga,
                    da = fa,
                    ua = ba,
                    ca = ka("throttle");
                return i(), q(r(oa), {
                    class: "dealer-join-dialog",
                    value: j.value,
                    onInput: pa,
                    modalClose: !1,
                    title: s.value === 1 ? e.$t("dealer_join_dialog.title1") : s.value === 2 ? e.$t("dealer_join_dialog.title2") : " "
                }, {
                    footer: g(() => []),
                    default: g(() => [s.value === 1 ? (i(), p("div", A, [r(o).state.dealerApplyData.applyLog ? (i(), p("div", L, [a("div", $, [a("div", null, [a("span", null, l(e.$t("dealer_join_dialog.table1")), 1)]), a("div", null, [a("span", null, l(e.$t("dealer_join_dialog.table2")), 1)]), a("div", null, [a("span", null, l(e.$t("dealer_join_dialog.table3")), 1)]), a("div", null, [a("span", null, l(e.$t("dealer_join_dialog.table4")), 1)]), a("div", null, [a("span", null, l(e.$t("dealer_join_dialog.table5")), 1)])]), a("div", h, [a("span", x, [a("span", null, l(r(o).state.dealerApplyData.applyLog.contact), 1), a("span", null, l(r(o).state.dealerApplyData.applyLog.contactNum), 1)]), a("span", C, [a("span", null, l(r(o).state.dealerApplyData.applyLog.verifyFrontRemark), 1)]), a("span", null, l(r(ma)(r(o).state.dealerApplyData.applyLog.addTime, "YYYY-MM-DD HH:II:SS")), 1), a("span", null, l(r(o).state.dealerApplyData.applyLog.status_), 1), r(o).state.dealerApplyData.applyLog.status === 0 ? (i(), p("span", I, [a("b", {
                        onClick: Z
                    }, l(e.$t("dealer_join_dialog.btn1")), 1)])) : (i(), p("span", T, [a("b", {
                        onClick: t[0] || (t[0] = n => s.value = 3)
                    }, l(e.$t("dealer_join_dialog.btn2")), 1)]))])])) : G("", !0), a("div", V, [(i(!0), p(J, null, Q(na.value, n => (i(), p("div", w, [a("label", null, l(n.name) + ":", 1), a("span", null, l(n.url), 1), k(m, {
                        iconClass: "mine_copy",
                        class: "clipboardUserId",
                        "data-clipboard-text": n.url,
                        onClick: ia
                    }, null, 8, ["data-clipboard-text"])]))), 256))]), a("div", {
                        class: "desc",
                        innerHTML: r(o).state.dealerApplyData.content
                    }, null, 8, H), a("div", {
                        class: "btn",
                        onClick: t[1] || (t[1] = n => s.value = 2)
                    }, [a("span", null, l(e.$t("dealer_join_dialog.title2")), 1)])])) : s.value === 2 ? (i(), p("div", M, [a("div", U, [a("div", R, [B, f(l(e.$t("dealer_join_dialog.text1")), 1)]), k(da, {
                        modelValue: u.value,
                        "onUpdate:modelValue": t[2] || (t[2] = n => u.value = n),
                        shape: "dot",
                        direction: "horizontal"
                    }, {
                        default: g(() => [(i(!0), p(J, null, Q(sa.value, n => (i(), q(_, {
                            name: n.label
                        }, {
                            default: g(() => [f(l(n.label), 1)]),
                            _: 2
                        }, 1032, ["name"]))), 256))]),
                        _: 1
                    }, 8, ["modelValue"])]), a("div", E, [a("label", null, [S, f(l(e.$t("dealer_join_dialog.text2")), 1)]), X(a("input", {
                        type: "text",
                        "onUpdate:modelValue": t[3] || (t[3] = n => c.value = n)
                    }, null, 512), [
                        [Aa, c.value]
                    ])]), a("div", Y, [a("label", null, l(e.$t("dealer_join_dialog.text3")), 1), k(ua, {
                        type: "textarea",
                        modelValue: v.value,
                        "onUpdate:modelValue": t[4] || (t[4] = n => v.value = n),
                        "show-word-limit": "",
                        resize: "none",
                        maxlength: "1000"
                    }, null, 8, ["modelValue"])]), a("div", F, [a("div", {
                        class: "cancelBtn btn",
                        onClick: t[5] || (t[5] = n => s.value = 1)
                    }, l(e.$t("dealer_join_dialog.btn3")), 1), X((i(), p("div", N, [f(l(e.$t("dealer_join_dialog.btn4")), 1)])), [
                        [ca, ra, "loading"]
                    ])])])) : s.value === 3 ? (i(), p("div", O, [a("div", {
                        class: "remarkBox",
                        innerHTML: r(o).state.dealerApplyData.applyLog.verifyFrontRemark
                    }, null, 8, P), a("div", z, [a("div", {
                        class: "cancelBtn",
                        onClick: t[6] || (t[6] = n => s.value = 1)
                    }, l(e.$t("dealer_join_dialog.btn5")), 1), a("div", {
                        class: "reSubmitBtn",
                        onClick: Z
                    }, l(e.$t("dealer_join_dialog.btn6")), 1)])])) : G("", !0)]),
                    _: 1
                }, 8, ["value", "title"])
            }
        }
    }
});
export {
    xa as __tla, aa as
    default
};