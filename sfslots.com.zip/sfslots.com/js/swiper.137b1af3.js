import {
    r as D,
    Z as Se,
    p as ye,
    w as $e,
    n as Ne,
    j as be,
    E as Te,
    h as V,
    ah as Ve,
    e as Fe
} from "./@vue.16908cbf.js";

function pe(t) {
    return t !== null && typeof t == "object" && "constructor" in t && t.constructor === Object
}

function ce(t, e) {
    t === void 0 && (t = {}), e === void 0 && (e = {}), Object.keys(e).forEach(i => {
        typeof t[i] > "u" ? t[i] = e[i] : pe(e[i]) && pe(t[i]) && Object.keys(e[i]).length > 0 && ce(t[i], e[i])
    })
}
const xe = {
    body: {},
    addEventListener() {},
    removeEventListener() {},
    activeElement: {
        blur() {},
        nodeName: ""
    },
    querySelector() {
        return null
    },
    querySelectorAll() {
        return []
    },
    getElementById() {
        return null
    },
    createEvent() {
        return {
            initEvent() {}
        }
    },
    createElement() {
        return {
            children: [],
            childNodes: [],
            style: {},
            setAttribute() {},
            getElementsByTagName() {
                return []
            }
        }
    },
    createElementNS() {
        return {}
    },
    importNode() {
        return null
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    }
};

function R() {
    const t = typeof document < "u" ? document : {};
    return ce(t, xe), t
}
const Re = {
    document: xe,
    navigator: {
        userAgent: ""
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    },
    history: {
        replaceState() {},
        pushState() {},
        go() {},
        back() {}
    },
    CustomEvent: function() {
        return this
    },
    addEventListener() {},
    removeEventListener() {},
    getComputedStyle() {
        return {
            getPropertyValue() {
                return ""
            }
        }
    },
    Image() {},
    Date() {},
    screen: {},
    setTimeout() {},
    clearTimeout() {},
    matchMedia() {
        return {}
    },
    requestAnimationFrame(t) {
        return typeof setTimeout > "u" ? (t(), null) : setTimeout(t, 0)
    },
    cancelAnimationFrame(t) {
        typeof setTimeout > "u" || clearTimeout(t)
    }
};

function G() {
    const t = typeof window < "u" ? window : {};
    return ce(t, Re), t
}

function He(t) {
    const e = t;
    Object.keys(e).forEach(i => {
        try {
            e[i] = null
        } catch {}
        try {
            delete e[i]
        } catch {}
    })
}

function de(t, e) {
    return e === void 0 && (e = 0), setTimeout(t, e)
}

function q() {
    return Date.now()
}

function ke(t) {
    const e = G();
    let i;
    return e.getComputedStyle && (i = e.getComputedStyle(t, null)), !i && t.currentStyle && (i = t.currentStyle), i || (i = t.style), i
}

function je(t, e) {
    e === void 0 && (e = "x");
    const i = G();
    let n, r, s;
    const o = ke(t);
    return i.WebKitCSSMatrix ? (r = o.transform || o.webkitTransform, r.split(",").length > 6 && (r = r.split(", ").map(l => l.replace(",", ".")).join(", ")), s = new i.WebKitCSSMatrix(r === "none" ? "" : r)) : (s = o.MozTransform || o.OTransform || o.MsTransform || o.msTransform || o.transform || o.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), n = s.toString().split(",")), e === "x" && (i.WebKitCSSMatrix ? r = s.m41 : n.length === 16 ? r = parseFloat(n[12]) : r = parseFloat(n[4])), e === "y" && (i.WebKitCSSMatrix ? r = s.m42 : n.length === 16 ? r = parseFloat(n[13]) : r = parseFloat(n[5])), r || 0
}

function Z(t) {
    return typeof t == "object" && t !== null && t.constructor && Object.prototype.toString.call(t).slice(8, -1) === "Object"
}

function We(t) {
    return typeof window < "u" && typeof window.HTMLElement < "u" ? t instanceof HTMLElement : t && (t.nodeType === 1 || t.nodeType === 11)
}

function _() {
    const t = Object(arguments.length <= 0 ? void 0 : arguments[0]),
        e = ["__proto__", "constructor", "prototype"];
    for (let i = 1; i < arguments.length; i += 1) {
        const n = i < 0 || arguments.length <= i ? void 0 : arguments[i];
        if (n != null && !We(n)) {
            const r = Object.keys(Object(n)).filter(s => e.indexOf(s) < 0);
            for (let s = 0, o = r.length; s < o; s += 1) {
                const l = r[s],
                    a = Object.getOwnPropertyDescriptor(n, l);
                a !== void 0 && a.enumerable && (Z(t[l]) && Z(n[l]) ? n[l].__swiper__ ? t[l] = n[l] : _(t[l], n[l]) : !Z(t[l]) && Z(n[l]) ? (t[l] = {}, n[l].__swiper__ ? t[l] = n[l] : _(t[l], n[l])) : t[l] = n[l])
            }
        }
    }
    return t
}

function J(t, e, i) {
    t.style.setProperty(e, i)
}

function Ee(t) {
    let {
        swiper: e,
        targetPosition: i,
        side: n
    } = t;
    const r = G(),
        s = -e.translate;
    let o = null,
        l;
    const a = e.params.speed;
    e.wrapperEl.style.scrollSnapType = "none", r.cancelAnimationFrame(e.cssModeFrameID);
    const c = i > s ? "next" : "prev",
        d = (v, m) => c === "next" && v >= m || c === "prev" && v <= m,
        p = () => {
            l = new Date().getTime(), o === null && (o = l);
            const v = Math.max(Math.min((l - o) / a, 1), 0),
                m = .5 - Math.cos(v * Math.PI) / 2;
            let w = s + m * (i - s);
            if (d(w, i) && (w = i), e.wrapperEl.scrollTo({
                    [n]: w
                }), d(w, i)) {
                e.wrapperEl.style.overflow = "hidden", e.wrapperEl.style.scrollSnapType = "", setTimeout(() => {
                    e.wrapperEl.style.overflow = "", e.wrapperEl.scrollTo({
                        [n]: w
                    })
                }), r.cancelAnimationFrame(e.cssModeFrameID);
                return
            }
            e.cssModeFrameID = r.requestAnimationFrame(p)
        };
    p()
}

function F(t, e) {
    return e === void 0 && (e = ""), [...t.children].filter(i => i.matches(e))
}

function Ce(t, e) {
    e === void 0 && (e = []);
    const i = document.createElement(t);
    return i.classList.add(...Array.isArray(e) ? e : [e]), i
}

function qe(t, e) {
    const i = [];
    for (; t.previousElementSibling;) {
        const n = t.previousElementSibling;
        e ? n.matches(e) && i.push(n) : i.push(n), t = n
    }
    return i
}

function Xe(t, e) {
    const i = [];
    for (; t.nextElementSibling;) {
        const n = t.nextElementSibling;
        e ? n.matches(e) && i.push(n) : i.push(n), t = n
    }
    return i
}

function j(t, e) {
    return G().getComputedStyle(t, null).getPropertyValue(e)
}

function ee(t) {
    let e = t,
        i;
    if (e) {
        for (i = 0;
            (e = e.previousSibling) !== null;) e.nodeType === 1 && (i += 1);
        return i
    }
}

function Me(t, e) {
    const i = [];
    let n = t.parentElement;
    for (; n;) e ? n.matches(e) && i.push(n) : i.push(n), n = n.parentElement;
    return i
}

function te(t, e) {
    function i(n) {
        n.target === t && (e.call(t, n), t.removeEventListener("transitionend", i))
    }
    e && t.addEventListener("transitionend", i)
}

function ue(t, e, i) {
    const n = G();
    return i ? t[e === "width" ? "offsetWidth" : "offsetHeight"] + parseFloat(n.getComputedStyle(t, null).getPropertyValue(e === "width" ? "margin-right" : "margin-top")) + parseFloat(n.getComputedStyle(t, null).getPropertyValue(e === "width" ? "margin-left" : "margin-bottom")) : t.offsetWidth
}
let ie;

function Ye() {
    const t = G(),
        e = R();
    return {
        smoothScroll: e.documentElement && e.documentElement.style && "scrollBehavior" in e.documentElement.style,
        touch: !!("ontouchstart" in t || t.DocumentTouch && e instanceof t.DocumentTouch)
    }
}

function Pe() {
    return ie || (ie = Ye()), ie
}
let ne;

function Ue(t) {
    let {
        userAgent: e
    } = t === void 0 ? {} : t;
    const i = Pe(),
        n = G(),
        r = n.navigator.platform,
        s = e || n.navigator.userAgent,
        o = {
            ios: !1,
            android: !1
        },
        l = n.screen.width,
        a = n.screen.height,
        c = s.match(/(Android);?[\s\/]+([\d.]+)?/);
    let d = s.match(/(iPad).*OS\s([\d_]+)/);
    const p = s.match(/(iPod)(.*OS\s([\d_]+))?/),
        v = !d && s.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
        m = r === "Win32";
    let w = r === "MacIntel";
    const S = ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"];
    return !d && w && i.touch && S.indexOf(`${l}x${a}`) >= 0 && (d = s.match(/(Version)\/([\d.]+)/), d || (d = [0, 1, "13_0_0"]), w = !1), c && !m && (o.os = "android", o.android = !0), (d || v || p) && (o.os = "ios", o.ios = !0), o
}

function Ke(t) {
    return t === void 0 && (t = {}), ne || (ne = Ue(t)), ne
}
let se;

function Ze() {
    const t = G();
    let e = !1;

    function i() {
        const n = t.navigator.userAgent.toLowerCase();
        return n.indexOf("safari") >= 0 && n.indexOf("chrome") < 0 && n.indexOf("android") < 0
    }
    if (i()) {
        const n = String(t.navigator.userAgent);
        if (n.includes("Version/")) {
            const [r, s] = n.split("Version/")[1].split(" ")[0].split(".").map(o => Number(o));
            e = r < 16 || r === 16 && s < 2
        }
    }
    return {
        isSafari: e || i(),
        needPerspectiveFix: e,
        isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(t.navigator.userAgent)
    }
}

function Je() {
    return se || (se = Ze()), se
}

function Qe(t) {
    let {
        swiper: e,
        on: i,
        emit: n
    } = t;
    const r = G();
    let s = null,
        o = null;
    const l = () => {
            !e || e.destroyed || !e.initialized || (n("beforeResize"), n("resize"))
        },
        a = () => {
            !e || e.destroyed || !e.initialized || (s = new ResizeObserver(p => {
                o = r.requestAnimationFrame(() => {
                    const {
                        width: v,
                        height: m
                    } = e;
                    let w = v,
                        S = m;
                    p.forEach(x => {
                        let {
                            contentBoxSize: y,
                            contentRect: f,
                            target: u
                        } = x;
                        u && u !== e.el || (w = f ? f.width : (y[0] || y).inlineSize, S = f ? f.height : (y[0] || y).blockSize)
                    }), (w !== v || S !== m) && l()
                })
            }), s.observe(e.el))
        },
        c = () => {
            o && r.cancelAnimationFrame(o), s && s.unobserve && e.el && (s.unobserve(e.el), s = null)
        },
        d = () => {
            !e || e.destroyed || !e.initialized || n("orientationchange")
        };
    i("init", () => {
        if (e.params.resizeObserver && typeof r.ResizeObserver < "u") {
            a();
            return
        }
        r.addEventListener("resize", l), r.addEventListener("orientationchange", d)
    }), i("destroy", () => {
        c(), r.removeEventListener("resize", l), r.removeEventListener("orientationchange", d)
    })
}

function et(t) {
    let {
        swiper: e,
        extendParams: i,
        on: n,
        emit: r
    } = t;
    const s = [],
        o = G(),
        l = function(d, p) {
            p === void 0 && (p = {});
            const v = o.MutationObserver || o.WebkitMutationObserver,
                m = new v(w => {
                    if (e.__preventObserver__) return;
                    if (w.length === 1) {
                        r("observerUpdate", w[0]);
                        return
                    }
                    const S = function() {
                        r("observerUpdate", w[0])
                    };
                    o.requestAnimationFrame ? o.requestAnimationFrame(S) : o.setTimeout(S, 0)
                });
            m.observe(d, {
                attributes: typeof p.attributes > "u" ? !0 : p.attributes,
                childList: typeof p.childList > "u" ? !0 : p.childList,
                characterData: typeof p.characterData > "u" ? !0 : p.characterData
            }), s.push(m)
        },
        a = () => {
            if (e.params.observer) {
                if (e.params.observeParents) {
                    const d = Me(e.el);
                    for (let p = 0; p < d.length; p += 1) l(d[p])
                }
                l(e.el, {
                    childList: e.params.observeSlideChildren
                }), l(e.wrapperEl, {
                    attributes: !1
                })
            }
        },
        c = () => {
            s.forEach(d => {
                d.disconnect()
            }), s.splice(0, s.length)
        };
    i({
        observer: !1,
        observeParents: !1,
        observeSlideChildren: !1
    }), n("init", a), n("destroy", c)
}
var tt = {
    on(t, e, i) {
        const n = this;
        if (!n.eventsListeners || n.destroyed || typeof e != "function") return n;
        const r = i ? "unshift" : "push";
        return t.split(" ").forEach(s => {
            n.eventsListeners[s] || (n.eventsListeners[s] = []), n.eventsListeners[s][r](e)
        }), n
    },
    once(t, e, i) {
        const n = this;
        if (!n.eventsListeners || n.destroyed || typeof e != "function") return n;

        function r() {
            n.off(t, r), r.__emitterProxy && delete r.__emitterProxy;
            for (var s = arguments.length, o = new Array(s), l = 0; l < s; l++) o[l] = arguments[l];
            e.apply(n, o)
        }
        return r.__emitterProxy = e, n.on(t, r, i)
    },
    onAny(t, e) {
        const i = this;
        if (!i.eventsListeners || i.destroyed || typeof t != "function") return i;
        const n = e ? "unshift" : "push";
        return i.eventsAnyListeners.indexOf(t) < 0 && i.eventsAnyListeners[n](t), i
    },
    offAny(t) {
        const e = this;
        if (!e.eventsListeners || e.destroyed || !e.eventsAnyListeners) return e;
        const i = e.eventsAnyListeners.indexOf(t);
        return i >= 0 && e.eventsAnyListeners.splice(i, 1), e
    },
    off(t, e) {
        const i = this;
        return !i.eventsListeners || i.destroyed || !i.eventsListeners || t.split(" ").forEach(n => {
            typeof e > "u" ? i.eventsListeners[n] = [] : i.eventsListeners[n] && i.eventsListeners[n].forEach((r, s) => {
                (r === e || r.__emitterProxy && r.__emitterProxy === e) && i.eventsListeners[n].splice(s, 1)
            })
        }), i
    },
    emit() {
        const t = this;
        if (!t.eventsListeners || t.destroyed || !t.eventsListeners) return t;
        let e, i, n;
        for (var r = arguments.length, s = new Array(r), o = 0; o < r; o++) s[o] = arguments[o];
        return typeof s[0] == "string" || Array.isArray(s[0]) ? (e = s[0], i = s.slice(1, s.length), n = t) : (e = s[0].events, i = s[0].data, n = s[0].context || t), i.unshift(n), (Array.isArray(e) ? e : e.split(" ")).forEach(a => {
            t.eventsAnyListeners && t.eventsAnyListeners.length && t.eventsAnyListeners.forEach(c => {
                c.apply(n, [a, ...i])
            }), t.eventsListeners && t.eventsListeners[a] && t.eventsListeners[a].forEach(c => {
                c.apply(n, i)
            })
        }), t
    }
};

function it() {
    const t = this;
    let e, i;
    const n = t.el;
    typeof t.params.width < "u" && t.params.width !== null ? e = t.params.width : e = n.clientWidth, typeof t.params.height < "u" && t.params.height !== null ? i = t.params.height : i = n.clientHeight, !(e === 0 && t.isHorizontal() || i === 0 && t.isVertical()) && (e = e - parseInt(j(n, "padding-left") || 0, 10) - parseInt(j(n, "padding-right") || 0, 10), i = i - parseInt(j(n, "padding-top") || 0, 10) - parseInt(j(n, "padding-bottom") || 0, 10), Number.isNaN(e) && (e = 0), Number.isNaN(i) && (i = 0), Object.assign(t, {
        width: e,
        height: i,
        size: t.isHorizontal() ? e : i
    }))
}

function nt() {
    const t = this;

    function e(T) {
        return t.isHorizontal() ? T : {
            width: "height",
            "margin-top": "margin-left",
            "margin-bottom ": "margin-right",
            "margin-left": "margin-top",
            "margin-right": "margin-bottom",
            "padding-left": "padding-top",
            "padding-right": "padding-bottom",
            marginRight: "marginBottom"
        }[T]
    }

    function i(T, P) {
        return parseFloat(T.getPropertyValue(e(P)) || 0)
    }
    const n = t.params,
        {
            wrapperEl: r,
            slidesEl: s,
            size: o,
            rtlTranslate: l,
            wrongRTL: a
        } = t,
        c = t.virtual && n.virtual.enabled,
        d = c ? t.virtual.slides.length : t.slides.length,
        p = F(s, `.${t.params.slideClass}, swiper-slide`),
        v = c ? t.virtual.slides.length : p.length;
    let m = [];
    const w = [],
        S = [];
    let x = n.slidesOffsetBefore;
    typeof x == "function" && (x = n.slidesOffsetBefore.call(t));
    let y = n.slidesOffsetAfter;
    typeof y == "function" && (y = n.slidesOffsetAfter.call(t));
    const f = t.snapGrid.length,
        u = t.slidesGrid.length;
    let g = n.spaceBetween,
        b = -x,
        M = 0,
        E = 0;
    if (typeof o > "u") return;
    typeof g == "string" && g.indexOf("%") >= 0 ? g = parseFloat(g.replace("%", "")) / 100 * o : typeof g == "string" && (g = parseFloat(g)), t.virtualSize = -g, p.forEach(T => {
        l ? T.style.marginLeft = "" : T.style.marginRight = "", T.style.marginBottom = "", T.style.marginTop = ""
    }), n.centeredSlides && n.cssMode && (J(r, "--swiper-centered-offset-before", ""), J(r, "--swiper-centered-offset-after", ""));
    const C = n.grid && n.grid.rows > 1 && t.grid;
    C && t.grid.initSlides(v);
    let h;
    const O = n.slidesPerView === "auto" && n.breakpoints && Object.keys(n.breakpoints).filter(T => typeof n.breakpoints[T].slidesPerView < "u").length > 0;
    for (let T = 0; T < v; T += 1) {
        h = 0;
        let P;
        if (p[T] && (P = p[T]), C && t.grid.updateSlide(T, P, v, e), !(p[T] && j(P, "display") === "none")) {
            if (n.slidesPerView === "auto") {
                O && (p[T].style[e("width")] = "");
                const L = getComputedStyle(P),
                    I = P.style.transform,
                    B = P.style.webkitTransform;
                if (I && (P.style.transform = "none"), B && (P.style.webkitTransform = "none"), n.roundLengths) h = t.isHorizontal() ? ue(P, "width", !0) : ue(P, "height", !0);
                else {
                    const $ = i(L, "width"),
                        z = i(L, "padding-left"),
                        N = i(L, "padding-right"),
                        A = i(L, "margin-left"),
                        k = i(L, "margin-right"),
                        Y = L.getPropertyValue("box-sizing");
                    if (Y && Y === "border-box") h = $ + A + k;
                    else {
                        const {
                            clientWidth: _e,
                            offsetWidth: Ge
                        } = P;
                        h = $ + z + N + A + k + (Ge - _e)
                    }
                }
                I && (P.style.transform = I), B && (P.style.webkitTransform = B), n.roundLengths && (h = Math.floor(h))
            } else h = (o - (n.slidesPerView - 1) * g) / n.slidesPerView, n.roundLengths && (h = Math.floor(h)), p[T] && (p[T].style[e("width")] = `${h}px`);
            p[T] && (p[T].swiperSlideSize = h), S.push(h), n.centeredSlides ? (b = b + h / 2 + M / 2 + g, M === 0 && T !== 0 && (b = b - o / 2 - g), T === 0 && (b = b - o / 2 - g), Math.abs(b) < 1 / 1e3 && (b = 0), n.roundLengths && (b = Math.floor(b)), E % n.slidesPerGroup === 0 && m.push(b), w.push(b)) : (n.roundLengths && (b = Math.floor(b)), (E - Math.min(t.params.slidesPerGroupSkip, E)) % t.params.slidesPerGroup === 0 && m.push(b), w.push(b), b = b + h + g), t.virtualSize += h + g, M = h, E += 1
        }
    }
    if (t.virtualSize = Math.max(t.virtualSize, o) + y, l && a && (n.effect === "slide" || n.effect === "coverflow") && (r.style.width = `${t.virtualSize+g}px`), n.setWrapperSize && (r.style[e("width")] = `${t.virtualSize+g}px`), C && t.grid.updateWrapperSize(h, m, e), !n.centeredSlides) {
        const T = [];
        for (let P = 0; P < m.length; P += 1) {
            let L = m[P];
            n.roundLengths && (L = Math.floor(L)), m[P] <= t.virtualSize - o && T.push(L)
        }
        m = T, Math.floor(t.virtualSize - o) - Math.floor(m[m.length - 1]) > 1 && m.push(t.virtualSize - o)
    }
    if (c && n.loop) {
        const T = S[0] + g;
        if (n.slidesPerGroup > 1) {
            const P = Math.ceil((t.virtual.slidesBefore + t.virtual.slidesAfter) / n.slidesPerGroup),
                L = T * n.slidesPerGroup;
            for (let I = 0; I < P; I += 1) m.push(m[m.length - 1] + L)
        }
        for (let P = 0; P < t.virtual.slidesBefore + t.virtual.slidesAfter; P += 1) n.slidesPerGroup === 1 && m.push(m[m.length - 1] + T), w.push(w[w.length - 1] + T), t.virtualSize += T
    }
    if (m.length === 0 && (m = [0]), g !== 0) {
        const T = t.isHorizontal() && l ? "marginLeft" : e("marginRight");
        p.filter((P, L) => !n.cssMode || n.loop ? !0 : L !== p.length - 1).forEach(P => {
            P.style[T] = `${g}px`
        })
    }
    if (n.centeredSlides && n.centeredSlidesBounds) {
        let T = 0;
        S.forEach(L => {
            T += L + (g || 0)
        }), T -= g;
        const P = T - o;
        m = m.map(L => L <= 0 ? -x : L > P ? P + y : L)
    }
    if (n.centerInsufficientSlides) {
        let T = 0;
        if (S.forEach(P => {
                T += P + (g || 0)
            }), T -= g, T < o) {
            const P = (o - T) / 2;
            m.forEach((L, I) => {
                m[I] = L - P
            }), w.forEach((L, I) => {
                w[I] = L + P
            })
        }
    }
    if (Object.assign(t, {
            slides: p,
            snapGrid: m,
            slidesGrid: w,
            slidesSizesGrid: S
        }), n.centeredSlides && n.cssMode && !n.centeredSlidesBounds) {
        J(r, "--swiper-centered-offset-before", `${-m[0]}px`), J(r, "--swiper-centered-offset-after", `${t.size/2-S[S.length-1]/2}px`);
        const T = -t.snapGrid[0],
            P = -t.slidesGrid[0];
        t.snapGrid = t.snapGrid.map(L => L + T), t.slidesGrid = t.slidesGrid.map(L => L + P)
    }
    if (v !== d && t.emit("slidesLengthChange"), m.length !== f && (t.params.watchOverflow && t.checkOverflow(), t.emit("snapGridLengthChange")), w.length !== u && t.emit("slidesGridLengthChange"), n.watchSlidesProgress && t.updateSlidesOffset(), !c && !n.cssMode && (n.effect === "slide" || n.effect === "fade")) {
        const T = `${n.containerModifierClass}backface-hidden`,
            P = t.el.classList.contains(T);
        v <= n.maxBackfaceHiddenSlides ? P || t.el.classList.add(T) : P && t.el.classList.remove(T)
    }
}

function st(t) {
    const e = this,
        i = [],
        n = e.virtual && e.params.virtual.enabled;
    let r = 0,
        s;
    typeof t == "number" ? e.setTransition(t) : t === !0 && e.setTransition(e.params.speed);
    const o = l => n ? e.slides[e.getSlideIndexByData(l)] : e.slides[l];
    if (e.params.slidesPerView !== "auto" && e.params.slidesPerView > 1)
        if (e.params.centeredSlides)(e.visibleSlides || []).forEach(l => {
            i.push(l)
        });
        else
            for (s = 0; s < Math.ceil(e.params.slidesPerView); s += 1) {
                const l = e.activeIndex + s;
                if (l > e.slides.length && !n) break;
                i.push(o(l))
            } else i.push(o(e.activeIndex));
    for (s = 0; s < i.length; s += 1)
        if (typeof i[s] < "u") {
            const l = i[s].offsetHeight;
            r = l > r ? l : r
        }(r || r === 0) && (e.wrapperEl.style.height = `${r}px`)
}

function rt() {
    const t = this,
        e = t.slides,
        i = t.isElement ? t.isHorizontal() ? t.wrapperEl.offsetLeft : t.wrapperEl.offsetTop : 0;
    for (let n = 0; n < e.length; n += 1) e[n].swiperSlideOffset = (t.isHorizontal() ? e[n].offsetLeft : e[n].offsetTop) - i - t.cssOverflowAdjustment()
}

function at(t) {
    t === void 0 && (t = this && this.translate || 0);
    const e = this,
        i = e.params,
        {
            slides: n,
            rtlTranslate: r,
            snapGrid: s
        } = e;
    if (n.length === 0) return;
    typeof n[0].swiperSlideOffset > "u" && e.updateSlidesOffset();
    let o = -t;
    r && (o = t), n.forEach(a => {
        a.classList.remove(i.slideVisibleClass)
    }), e.visibleSlidesIndexes = [], e.visibleSlides = [];
    let l = i.spaceBetween;
    typeof l == "string" && l.indexOf("%") >= 0 ? l = parseFloat(l.replace("%", "")) / 100 * e.size : typeof l == "string" && (l = parseFloat(l));
    for (let a = 0; a < n.length; a += 1) {
        const c = n[a];
        let d = c.swiperSlideOffset;
        i.cssMode && i.centeredSlides && (d -= n[0].swiperSlideOffset);
        const p = (o + (i.centeredSlides ? e.minTranslate() : 0) - d) / (c.swiperSlideSize + l),
            v = (o - s[0] + (i.centeredSlides ? e.minTranslate() : 0) - d) / (c.swiperSlideSize + l),
            m = -(o - d),
            w = m + e.slidesSizesGrid[a];
        (m >= 0 && m < e.size - 1 || w > 1 && w <= e.size || m <= 0 && w >= e.size) && (e.visibleSlides.push(c), e.visibleSlidesIndexes.push(a), n[a].classList.add(i.slideVisibleClass)), c.progress = r ? -p : p, c.originalProgress = r ? -v : v
    }
}

function lt(t) {
    const e = this;
    if (typeof t > "u") {
        const d = e.rtlTranslate ? -1 : 1;
        t = e && e.translate && e.translate * d || 0
    }
    const i = e.params,
        n = e.maxTranslate() - e.minTranslate();
    let {
        progress: r,
        isBeginning: s,
        isEnd: o,
        progressLoop: l
    } = e;
    const a = s,
        c = o;
    if (n === 0) r = 0, s = !0, o = !0;
    else {
        r = (t - e.minTranslate()) / n;
        const d = Math.abs(t - e.minTranslate()) < 1,
            p = Math.abs(t - e.maxTranslate()) < 1;
        s = d || r <= 0, o = p || r >= 1, d && (r = 0), p && (r = 1)
    }
    if (i.loop) {
        const d = e.getSlideIndexByData(0),
            p = e.getSlideIndexByData(e.slides.length - 1),
            v = e.slidesGrid[d],
            m = e.slidesGrid[p],
            w = e.slidesGrid[e.slidesGrid.length - 1],
            S = Math.abs(t);
        S >= v ? l = (S - v) / w : l = (S + w - m) / w, l > 1 && (l -= 1)
    }
    Object.assign(e, {
        progress: r,
        progressLoop: l,
        isBeginning: s,
        isEnd: o
    }), (i.watchSlidesProgress || i.centeredSlides && i.autoHeight) && e.updateSlidesProgress(t), s && !a && e.emit("reachBeginning toEdge"), o && !c && e.emit("reachEnd toEdge"), (a && !s || c && !o) && e.emit("fromEdge"), e.emit("progress", r)
}

function ot() {
    const t = this,
        {
            slides: e,
            params: i,
            slidesEl: n,
            activeIndex: r
        } = t,
        s = t.virtual && i.virtual.enabled,
        o = a => F(n, `.${i.slideClass}${a}, swiper-slide${a}`)[0];
    e.forEach(a => {
        a.classList.remove(i.slideActiveClass, i.slideNextClass, i.slidePrevClass)
    });
    let l;
    if (s)
        if (i.loop) {
            let a = r - t.virtual.slidesBefore;
            a < 0 && (a = t.virtual.slides.length + a), a >= t.virtual.slides.length && (a -= t.virtual.slides.length), l = o(`[data-swiper-slide-index="${a}"]`)
        } else l = o(`[data-swiper-slide-index="${r}"]`);
    else l = e[r];
    if (l) {
        l.classList.add(i.slideActiveClass);
        let a = Xe(l, `.${i.slideClass}, swiper-slide`)[0];
        i.loop && !a && (a = e[0]), a && a.classList.add(i.slideNextClass);
        let c = qe(l, `.${i.slideClass}, swiper-slide`)[0];
        i.loop && !c === 0 && (c = e[e.length - 1]), c && c.classList.add(i.slidePrevClass)
    }
    t.emitSlidesClasses()
}
const Q = (t, e) => {
        if (!t || t.destroyed || !t.params) return;
        const i = () => t.isElement ? "swiper-slide" : `.${t.params.slideClass}`,
            n = e.closest(i());
        if (n) {
            const r = n.querySelector(`.${t.params.lazyPreloaderClass}`);
            r && r.remove()
        }
    },
    re = (t, e) => {
        if (!t.slides[e]) return;
        const i = t.slides[e].querySelector('[loading="lazy"]');
        i && i.removeAttribute("loading")
    },
    fe = t => {
        if (!t || t.destroyed || !t.params) return;
        let e = t.params.lazyPreloadPrevNext;
        const i = t.slides.length;
        if (!i || !e || e < 0) return;
        e = Math.min(e, i);
        const n = t.params.slidesPerView === "auto" ? t.slidesPerViewDynamic() : Math.ceil(t.params.slidesPerView),
            r = t.activeIndex;
        if (t.params.grid && t.params.grid.rows > 1) {
            const o = r,
                l = [o - e];
            l.push(...Array.from({
                length: e
            }).map((a, c) => o + n + c)), t.slides.forEach((a, c) => {
                l.includes(a.column) && re(t, c)
            });
            return
        }
        const s = r + n - 1;
        if (t.params.rewind || t.params.loop)
            for (let o = r - e; o <= s + e; o += 1) {
                const l = (o % i + i) % i;
                (l < r || l > s) && re(t, l)
            } else
                for (let o = Math.max(r - e, 0); o <= Math.min(s + e, i - 1); o += 1) o !== r && (o > s || o < r) && re(t, o)
    };

function dt(t) {
    const {
        slidesGrid: e,
        params: i
    } = t, n = t.rtlTranslate ? t.translate : -t.translate;
    let r;
    for (let s = 0; s < e.length; s += 1) typeof e[s + 1] < "u" ? n >= e[s] && n < e[s + 1] - (e[s + 1] - e[s]) / 2 ? r = s : n >= e[s] && n < e[s + 1] && (r = s + 1) : n >= e[s] && (r = s);
    return i.normalizeSlideIndex && (r < 0 || typeof r > "u") && (r = 0), r
}

function ut(t) {
    const e = this,
        i = e.rtlTranslate ? e.translate : -e.translate,
        {
            snapGrid: n,
            params: r,
            activeIndex: s,
            realIndex: o,
            snapIndex: l
        } = e;
    let a = t,
        c;
    const d = v => {
        let m = v - e.virtual.slidesBefore;
        return m < 0 && (m = e.virtual.slides.length + m), m >= e.virtual.slides.length && (m -= e.virtual.slides.length), m
    };
    if (typeof a > "u" && (a = dt(e)), n.indexOf(i) >= 0) c = n.indexOf(i);
    else {
        const v = Math.min(r.slidesPerGroupSkip, a);
        c = v + Math.floor((a - v) / r.slidesPerGroup)
    }
    if (c >= n.length && (c = n.length - 1), a === s) {
        c !== l && (e.snapIndex = c, e.emit("snapIndexChange")), e.params.loop && e.virtual && e.params.virtual.enabled && (e.realIndex = d(a));
        return
    }
    let p;
    e.virtual && r.virtual.enabled && r.loop ? p = d(a) : e.slides[a] ? p = parseInt(e.slides[a].getAttribute("data-swiper-slide-index") || a, 10) : p = a, Object.assign(e, {
        previousSnapIndex: l,
        snapIndex: c,
        previousRealIndex: o,
        realIndex: p,
        previousIndex: s,
        activeIndex: a
    }), e.initialized && fe(e), e.emit("activeIndexChange"), e.emit("snapIndexChange"), o !== p && e.emit("realIndexChange"), (e.initialized || e.params.runCallbacksOnInit) && e.emit("slideChange")
}

function ft(t) {
    const e = this,
        i = e.params,
        n = t.closest(`.${i.slideClass}, swiper-slide`);
    let r = !1,
        s;
    if (n) {
        for (let o = 0; o < e.slides.length; o += 1)
            if (e.slides[o] === n) {
                r = !0, s = o;
                break
            }
    }
    if (n && r) e.clickedSlide = n, e.virtual && e.params.virtual.enabled ? e.clickedIndex = parseInt(n.getAttribute("data-swiper-slide-index"), 10) : e.clickedIndex = s;
    else {
        e.clickedSlide = void 0, e.clickedIndex = void 0;
        return
    }
    i.slideToClickedSlide && e.clickedIndex !== void 0 && e.clickedIndex !== e.activeIndex && e.slideToClickedSlide()
}
var ct = {
    updateSize: it,
    updateSlides: nt,
    updateAutoHeight: st,
    updateSlidesOffset: rt,
    updateSlidesProgress: at,
    updateProgress: lt,
    updateSlidesClasses: ot,
    updateActiveIndex: ut,
    updateClickedSlide: ft
};

function pt(t) {
    t === void 0 && (t = this.isHorizontal() ? "x" : "y");
    const e = this,
        {
            params: i,
            rtlTranslate: n,
            translate: r,
            wrapperEl: s
        } = e;
    if (i.virtualTranslate) return n ? -r : r;
    if (i.cssMode) return r;
    let o = je(s, t);
    return o += e.cssOverflowAdjustment(), n && (o = -o), o || 0
}

function mt(t, e) {
    const i = this,
        {
            rtlTranslate: n,
            params: r,
            wrapperEl: s,
            progress: o
        } = i;
    let l = 0,
        a = 0;
    const c = 0;
    i.isHorizontal() ? l = n ? -t : t : a = t, r.roundLengths && (l = Math.floor(l), a = Math.floor(a)), i.previousTranslate = i.translate, i.translate = i.isHorizontal() ? l : a, r.cssMode ? s[i.isHorizontal() ? "scrollLeft" : "scrollTop"] = i.isHorizontal() ? -l : -a : r.virtualTranslate || (i.isHorizontal() ? l -= i.cssOverflowAdjustment() : a -= i.cssOverflowAdjustment(), s.style.transform = `translate3d(${l}px, ${a}px, ${c}px)`);
    let d;
    const p = i.maxTranslate() - i.minTranslate();
    p === 0 ? d = 0 : d = (t - i.minTranslate()) / p, d !== o && i.updateProgress(t), i.emit("setTranslate", i.translate, e)
}

function ht() {
    return -this.snapGrid[0]
}

function gt() {
    return -this.snapGrid[this.snapGrid.length - 1]
}

function vt(t, e, i, n, r) {
    t === void 0 && (t = 0), e === void 0 && (e = this.params.speed), i === void 0 && (i = !0), n === void 0 && (n = !0);
    const s = this,
        {
            params: o,
            wrapperEl: l
        } = s;
    if (s.animating && o.preventInteractionOnTransition) return !1;
    const a = s.minTranslate(),
        c = s.maxTranslate();
    let d;
    if (n && t > a ? d = a : n && t < c ? d = c : d = t, s.updateProgress(d), o.cssMode) {
        const p = s.isHorizontal();
        if (e === 0) l[p ? "scrollLeft" : "scrollTop"] = -d;
        else {
            if (!s.support.smoothScroll) return Ee({
                swiper: s,
                targetPosition: -d,
                side: p ? "left" : "top"
            }), !0;
            l.scrollTo({
                [p ? "left" : "top"]: -d,
                behavior: "smooth"
            })
        }
        return !0
    }
    return e === 0 ? (s.setTransition(0), s.setTranslate(d), i && (s.emit("beforeTransitionStart", e, r), s.emit("transitionEnd"))) : (s.setTransition(e), s.setTranslate(d), i && (s.emit("beforeTransitionStart", e, r), s.emit("transitionStart")), s.animating || (s.animating = !0, s.onTranslateToWrapperTransitionEnd || (s.onTranslateToWrapperTransitionEnd = function(v) {
        !s || s.destroyed || v.target === this && (s.wrapperEl.removeEventListener("transitionend", s.onTranslateToWrapperTransitionEnd), s.onTranslateToWrapperTransitionEnd = null, delete s.onTranslateToWrapperTransitionEnd, i && s.emit("transitionEnd"))
    }), s.wrapperEl.addEventListener("transitionend", s.onTranslateToWrapperTransitionEnd))), !0
}
var wt = {
    getTranslate: pt,
    setTranslate: mt,
    minTranslate: ht,
    maxTranslate: gt,
    translateTo: vt
};

function St(t, e) {
    const i = this;
    i.params.cssMode || (i.wrapperEl.style.transitionDuration = `${t}ms`), i.emit("setTransition", t, e)
}

function Le(t) {
    let {
        swiper: e,
        runCallbacks: i,
        direction: n,
        step: r
    } = t;
    const {
        activeIndex: s,
        previousIndex: o
    } = e;
    let l = n;
    if (l || (s > o ? l = "next" : s < o ? l = "prev" : l = "reset"), e.emit(`transition${r}`), i && s !== o) {
        if (l === "reset") {
            e.emit(`slideResetTransition${r}`);
            return
        }
        e.emit(`slideChangeTransition${r}`), l === "next" ? e.emit(`slideNextTransition${r}`) : e.emit(`slidePrevTransition${r}`)
    }
}

function yt(t, e) {
    t === void 0 && (t = !0);
    const i = this,
        {
            params: n
        } = i;
    n.cssMode || (n.autoHeight && i.updateAutoHeight(), Le({
        swiper: i,
        runCallbacks: t,
        direction: e,
        step: "Start"
    }))
}

function bt(t, e) {
    t === void 0 && (t = !0);
    const i = this,
        {
            params: n
        } = i;
    i.animating = !1, !n.cssMode && (i.setTransition(0), Le({
        swiper: i,
        runCallbacks: t,
        direction: e,
        step: "End"
    }))
}
var Tt = {
    setTransition: St,
    transitionStart: yt,
    transitionEnd: bt
};

function xt(t, e, i, n, r) {
    t === void 0 && (t = 0), e === void 0 && (e = this.params.speed), i === void 0 && (i = !0), typeof t == "string" && (t = parseInt(t, 10));
    const s = this;
    let o = t;
    o < 0 && (o = 0);
    const {
        params: l,
        snapGrid: a,
        slidesGrid: c,
        previousIndex: d,
        activeIndex: p,
        rtlTranslate: v,
        wrapperEl: m,
        enabled: w
    } = s;
    if (s.animating && l.preventInteractionOnTransition || !w && !n && !r) return !1;
    const S = Math.min(s.params.slidesPerGroupSkip, o);
    let x = S + Math.floor((o - S) / s.params.slidesPerGroup);
    x >= a.length && (x = a.length - 1);
    const y = -a[x];
    if (l.normalizeSlideIndex)
        for (let u = 0; u < c.length; u += 1) {
            const g = -Math.floor(y * 100),
                b = Math.floor(c[u] * 100),
                M = Math.floor(c[u + 1] * 100);
            typeof c[u + 1] < "u" ? g >= b && g < M - (M - b) / 2 ? o = u : g >= b && g < M && (o = u + 1) : g >= b && (o = u)
        }
    if (s.initialized && o !== p && (!s.allowSlideNext && (v ? y > s.translate && y > s.minTranslate() : y < s.translate && y < s.minTranslate()) || !s.allowSlidePrev && y > s.translate && y > s.maxTranslate() && (p || 0) !== o)) return !1;
    o !== (d || 0) && i && s.emit("beforeSlideChangeStart"), s.updateProgress(y);
    let f;
    if (o > p ? f = "next" : o < p ? f = "prev" : f = "reset", v && -y === s.translate || !v && y === s.translate) return s.updateActiveIndex(o), l.autoHeight && s.updateAutoHeight(), s.updateSlidesClasses(), l.effect !== "slide" && s.setTranslate(y), f !== "reset" && (s.transitionStart(i, f), s.transitionEnd(i, f)), !1;
    if (l.cssMode) {
        const u = s.isHorizontal(),
            g = v ? y : -y;
        if (e === 0) {
            const b = s.virtual && s.params.virtual.enabled;
            b && (s.wrapperEl.style.scrollSnapType = "none", s._immediateVirtual = !0), b && !s._cssModeVirtualInitialSet && s.params.initialSlide > 0 ? (s._cssModeVirtualInitialSet = !0, requestAnimationFrame(() => {
                m[u ? "scrollLeft" : "scrollTop"] = g
            })) : m[u ? "scrollLeft" : "scrollTop"] = g, b && requestAnimationFrame(() => {
                s.wrapperEl.style.scrollSnapType = "", s._immediateVirtual = !1
            })
        } else {
            if (!s.support.smoothScroll) return Ee({
                swiper: s,
                targetPosition: g,
                side: u ? "left" : "top"
            }), !0;
            m.scrollTo({
                [u ? "left" : "top"]: g,
                behavior: "smooth"
            })
        }
        return !0
    }
    return s.setTransition(e), s.setTranslate(y), s.updateActiveIndex(o), s.updateSlidesClasses(), s.emit("beforeTransitionStart", e, n), s.transitionStart(i, f), e === 0 ? s.transitionEnd(i, f) : s.animating || (s.animating = !0, s.onSlideToWrapperTransitionEnd || (s.onSlideToWrapperTransitionEnd = function(g) {
        !s || s.destroyed || g.target === this && (s.wrapperEl.removeEventListener("transitionend", s.onSlideToWrapperTransitionEnd), s.onSlideToWrapperTransitionEnd = null, delete s.onSlideToWrapperTransitionEnd, s.transitionEnd(i, f))
    }), s.wrapperEl.addEventListener("transitionend", s.onSlideToWrapperTransitionEnd)), !0
}

function Et(t, e, i, n) {
    t === void 0 && (t = 0), e === void 0 && (e = this.params.speed), i === void 0 && (i = !0), typeof t == "string" && (t = parseInt(t, 10));
    const r = this;
    let s = t;
    return r.params.loop && (r.virtual && r.params.virtual.enabled ? s = s + r.virtual.slidesBefore : s = r.getSlideIndexByData(s)), r.slideTo(s, e, i, n)
}

function Ct(t, e, i) {
    t === void 0 && (t = this.params.speed), e === void 0 && (e = !0);
    const n = this,
        {
            enabled: r,
            params: s,
            animating: o
        } = n;
    if (!r) return n;
    let l = s.slidesPerGroup;
    s.slidesPerView === "auto" && s.slidesPerGroup === 1 && s.slidesPerGroupAuto && (l = Math.max(n.slidesPerViewDynamic("current", !0), 1));
    const a = n.activeIndex < s.slidesPerGroupSkip ? 1 : l,
        c = n.virtual && s.virtual.enabled;
    if (s.loop) {
        if (o && !c && s.loopPreventsSliding) return !1;
        n.loopFix({
            direction: "next"
        }), n._clientLeft = n.wrapperEl.clientLeft
    }
    return s.rewind && n.isEnd ? n.slideTo(0, t, e, i) : n.slideTo(n.activeIndex + a, t, e, i)
}

function Mt(t, e, i) {
    t === void 0 && (t = this.params.speed), e === void 0 && (e = !0);
    const n = this,
        {
            params: r,
            snapGrid: s,
            slidesGrid: o,
            rtlTranslate: l,
            enabled: a,
            animating: c
        } = n;
    if (!a) return n;
    const d = n.virtual && r.virtual.enabled;
    if (r.loop) {
        if (c && !d && r.loopPreventsSliding) return !1;
        n.loopFix({
            direction: "prev"
        }), n._clientLeft = n.wrapperEl.clientLeft
    }
    const p = l ? n.translate : -n.translate;

    function v(y) {
        return y < 0 ? -Math.floor(Math.abs(y)) : Math.floor(y)
    }
    const m = v(p),
        w = s.map(y => v(y));
    let S = s[w.indexOf(m) - 1];
    if (typeof S > "u" && r.cssMode) {
        let y;
        s.forEach((f, u) => {
            m >= f && (y = u)
        }), typeof y < "u" && (S = s[y > 0 ? y - 1 : y])
    }
    let x = 0;
    if (typeof S < "u" && (x = o.indexOf(S), x < 0 && (x = n.activeIndex - 1), r.slidesPerView === "auto" && r.slidesPerGroup === 1 && r.slidesPerGroupAuto && (x = x - n.slidesPerViewDynamic("previous", !0) + 1, x = Math.max(x, 0))), r.rewind && n.isBeginning) {
        const y = n.params.virtual && n.params.virtual.enabled && n.virtual ? n.virtual.slides.length - 1 : n.slides.length - 1;
        return n.slideTo(y, t, e, i)
    }
    return n.slideTo(x, t, e, i)
}

function Pt(t, e, i) {
    t === void 0 && (t = this.params.speed), e === void 0 && (e = !0);
    const n = this;
    return n.slideTo(n.activeIndex, t, e, i)
}

function Lt(t, e, i, n) {
    t === void 0 && (t = this.params.speed), e === void 0 && (e = !0), n === void 0 && (n = .5);
    const r = this;
    let s = r.activeIndex;
    const o = Math.min(r.params.slidesPerGroupSkip, s),
        l = o + Math.floor((s - o) / r.params.slidesPerGroup),
        a = r.rtlTranslate ? r.translate : -r.translate;
    if (a >= r.snapGrid[l]) {
        const c = r.snapGrid[l],
            d = r.snapGrid[l + 1];
        a - c > (d - c) * n && (s += r.params.slidesPerGroup)
    } else {
        const c = r.snapGrid[l - 1],
            d = r.snapGrid[l];
        a - c <= (d - c) * n && (s -= r.params.slidesPerGroup)
    }
    return s = Math.max(s, 0), s = Math.min(s, r.slidesGrid.length - 1), r.slideTo(s, t, e, i)
}

function Ot() {
    const t = this,
        {
            params: e,
            slidesEl: i
        } = t,
        n = e.slidesPerView === "auto" ? t.slidesPerViewDynamic() : e.slidesPerView;
    let r = t.clickedIndex,
        s;
    const o = t.isElement ? "swiper-slide" : `.${e.slideClass}`;
    if (e.loop) {
        if (t.animating) return;
        s = parseInt(t.clickedSlide.getAttribute("data-swiper-slide-index"), 10), e.centeredSlides ? r < t.loopedSlides - n / 2 || r > t.slides.length - t.loopedSlides + n / 2 ? (t.loopFix(), r = t.getSlideIndex(F(i, `${o}[data-swiper-slide-index="${s}"]`)[0]), de(() => {
            t.slideTo(r)
        })) : t.slideTo(r) : r > t.slides.length - n ? (t.loopFix(), r = t.getSlideIndex(F(i, `${o}[data-swiper-slide-index="${s}"]`)[0]), de(() => {
            t.slideTo(r)
        })) : t.slideTo(r)
    } else t.slideTo(r)
}
var It = {
    slideTo: xt,
    slideToLoop: Et,
    slideNext: Ct,
    slidePrev: Mt,
    slideReset: Pt,
    slideToClosest: Lt,
    slideToClickedSlide: Ot
};

function zt(t) {
    const e = this,
        {
            params: i,
            slidesEl: n
        } = e;
    if (!i.loop || e.virtual && e.params.virtual.enabled) return;
    F(n, `.${i.slideClass}, swiper-slide`).forEach((s, o) => {
        s.setAttribute("data-swiper-slide-index", o)
    }), e.loopFix({
        slideRealIndex: t,
        direction: i.centeredSlides ? void 0 : "next"
    })
}

function Bt(t) {
    let {
        slideRealIndex: e,
        slideTo: i = !0,
        direction: n,
        setTranslate: r,
        activeSlideIndex: s,
        byController: o,
        byMousewheel: l
    } = t === void 0 ? {} : t;
    const a = this;
    if (!a.params.loop) return;
    a.emit("beforeLoopFix");
    const {
        slides: c,
        allowSlidePrev: d,
        allowSlideNext: p,
        slidesEl: v,
        params: m
    } = a;
    if (a.allowSlidePrev = !0, a.allowSlideNext = !0, a.virtual && m.virtual.enabled) {
        i && (!m.centeredSlides && a.snapIndex === 0 ? a.slideTo(a.virtual.slides.length, 0, !1, !0) : m.centeredSlides && a.snapIndex < m.slidesPerView ? a.slideTo(a.virtual.slides.length + a.snapIndex, 0, !1, !0) : a.snapIndex === a.snapGrid.length - 1 && a.slideTo(a.virtual.slidesBefore, 0, !1, !0)), a.allowSlidePrev = d, a.allowSlideNext = p, a.emit("loopFix");
        return
    }
    const w = m.slidesPerView === "auto" ? a.slidesPerViewDynamic() : Math.ceil(parseFloat(m.slidesPerView, 10));
    let S = m.loopedSlides || w;
    S % m.slidesPerGroup !== 0 && (S += m.slidesPerGroup - S % m.slidesPerGroup), a.loopedSlides = S;
    const x = [],
        y = [];
    let f = a.activeIndex;
    typeof s > "u" ? s = a.getSlideIndex(a.slides.filter(E => E.classList.contains(m.slideActiveClass))[0]) : f = s;
    const u = n === "next" || !n,
        g = n === "prev" || !n;
    let b = 0,
        M = 0;
    if (s < S) {
        b = Math.max(S - s, m.slidesPerGroup);
        for (let E = 0; E < S - s; E += 1) {
            const C = E - Math.floor(E / c.length) * c.length;
            x.push(c.length - C - 1)
        }
    } else if (s > a.slides.length - S * 2) {
        M = Math.max(s - (a.slides.length - S * 2), m.slidesPerGroup);
        for (let E = 0; E < M; E += 1) {
            const C = E - Math.floor(E / c.length) * c.length;
            y.push(C)
        }
    }
    if (g && x.forEach(E => {
            a.slides[E].swiperLoopMoveDOM = !0, v.prepend(a.slides[E]), a.slides[E].swiperLoopMoveDOM = !1
        }), u && y.forEach(E => {
            a.slides[E].swiperLoopMoveDOM = !0, v.append(a.slides[E]), a.slides[E].swiperLoopMoveDOM = !1
        }), a.recalcSlides(), m.slidesPerView === "auto" && a.updateSlides(), m.watchSlidesProgress && a.updateSlidesOffset(), i) {
        if (x.length > 0 && g)
            if (typeof e > "u") {
                const E = a.slidesGrid[f],
                    h = a.slidesGrid[f + b] - E;
                l ? a.setTranslate(a.translate - h) : (a.slideTo(f + b, 0, !1, !0), r && (a.touches[a.isHorizontal() ? "startX" : "startY"] += h))
            } else r && a.slideToLoop(e, 0, !1, !0);
        else if (y.length > 0 && u)
            if (typeof e > "u") {
                const E = a.slidesGrid[f],
                    h = a.slidesGrid[f - M] - E;
                l ? a.setTranslate(a.translate - h) : (a.slideTo(f - M, 0, !1, !0), r && (a.touches[a.isHorizontal() ? "startX" : "startY"] += h))
            } else a.slideToLoop(e, 0, !1, !0)
    }
    if (a.allowSlidePrev = d, a.allowSlideNext = p, a.controller && a.controller.control && !o) {
        const E = {
            slideRealIndex: e,
            slideTo: !1,
            direction: n,
            setTranslate: r,
            activeSlideIndex: s,
            byController: !0
        };
        Array.isArray(a.controller.control) ? a.controller.control.forEach(C => {
            !C.destroyed && C.params.loop && C.loopFix(E)
        }) : a.controller.control instanceof a.constructor && a.controller.control.params.loop && a.controller.control.loopFix(E)
    }
    a.emit("loopFix")
}

function At() {
    const t = this,
        {
            params: e,
            slidesEl: i
        } = t;
    if (!e.loop || t.virtual && t.params.virtual.enabled) return;
    t.recalcSlides();
    const n = [];
    t.slides.forEach(r => {
        const s = typeof r.swiperSlideIndex > "u" ? r.getAttribute("data-swiper-slide-index") * 1 : r.swiperSlideIndex;
        n[s] = r
    }), t.slides.forEach(r => {
        r.removeAttribute("data-swiper-slide-index")
    }), n.forEach(r => {
        i.append(r)
    }), t.recalcSlides(), t.slideTo(t.realIndex, 0)
}
var Dt = {
    loopCreate: zt,
    loopFix: Bt,
    loopDestroy: At
};

function _t(t) {
    const e = this;
    if (!e.params.simulateTouch || e.params.watchOverflow && e.isLocked || e.params.cssMode) return;
    const i = e.params.touchEventsTarget === "container" ? e.el : e.wrapperEl;
    e.isElement && (e.__preventObserver__ = !0), i.style.cursor = "move", i.style.cursor = t ? "grabbing" : "grab", e.isElement && requestAnimationFrame(() => {
        e.__preventObserver__ = !1
    })
}

function Gt() {
    const t = this;
    t.params.watchOverflow && t.isLocked || t.params.cssMode || (t.isElement && (t.__preventObserver__ = !0), t[t.params.touchEventsTarget === "container" ? "el" : "wrapperEl"].style.cursor = "", t.isElement && requestAnimationFrame(() => {
        t.__preventObserver__ = !1
    }))
}
var $t = {
    setGrabCursor: _t,
    unsetGrabCursor: Gt
};

function Nt(t, e) {
    e === void 0 && (e = this);

    function i(n) {
        if (!n || n === R() || n === G()) return null;
        n.assignedSlot && (n = n.assignedSlot);
        const r = n.closest(t);
        return !r && !n.getRootNode ? null : r || i(n.getRootNode().host)
    }
    return i(e)
}

function Vt(t) {
    const e = this,
        i = R(),
        n = G(),
        r = e.touchEventsData;
    r.evCache.push(t);
    const {
        params: s,
        touches: o,
        enabled: l
    } = e;
    if (!l || !s.simulateTouch && t.pointerType === "mouse" || e.animating && s.preventInteractionOnTransition) return;
    !e.animating && s.cssMode && s.loop && e.loopFix();
    let a = t;
    a.originalEvent && (a = a.originalEvent);
    let c = a.target;
    if (s.touchEventsTarget === "wrapper" && !e.wrapperEl.contains(c) || "which" in a && a.which === 3 || "button" in a && a.button > 0 || r.isTouched && r.isMoved) return;
    const d = !!s.noSwipingClass && s.noSwipingClass !== "",
        p = t.composedPath ? t.composedPath() : t.path;
    d && a.target && a.target.shadowRoot && p && (c = p[0]);
    const v = s.noSwipingSelector ? s.noSwipingSelector : `.${s.noSwipingClass}`,
        m = !!(a.target && a.target.shadowRoot);
    if (s.noSwiping && (m ? Nt(v, c) : c.closest(v))) {
        e.allowClick = !0;
        return
    }
    if (s.swipeHandler && !c.closest(s.swipeHandler)) return;
    o.currentX = a.pageX, o.currentY = a.pageY;
    const w = o.currentX,
        S = o.currentY,
        x = s.edgeSwipeDetection || s.iOSEdgeSwipeDetection,
        y = s.edgeSwipeThreshold || s.iOSEdgeSwipeThreshold;
    if (x && (w <= y || w >= n.innerWidth - y))
        if (x === "prevent") t.preventDefault();
        else return;
    Object.assign(r, {
        isTouched: !0,
        isMoved: !1,
        allowTouchCallbacks: !0,
        isScrolling: void 0,
        startMoving: void 0
    }), o.startX = w, o.startY = S, r.touchStartTime = q(), e.allowClick = !0, e.updateSize(), e.swipeDirection = void 0, s.threshold > 0 && (r.allowThresholdMove = !1);
    let f = !0;
    c.matches(r.focusableElements) && (f = !1, c.nodeName === "SELECT" && (r.isTouched = !1)), i.activeElement && i.activeElement.matches(r.focusableElements) && i.activeElement !== c && i.activeElement.blur();
    const u = f && e.allowTouchMove && s.touchStartPreventDefault;
    (s.touchStartForcePreventDefault || u) && !c.isContentEditable && a.preventDefault(), s.freeMode && s.freeMode.enabled && e.freeMode && e.animating && !s.cssMode && e.freeMode.onTouchStart(), e.emit("touchStart", a)
}

function Ft(t) {
    const e = R(),
        i = this,
        n = i.touchEventsData,
        {
            params: r,
            touches: s,
            rtlTranslate: o,
            enabled: l
        } = i;
    if (!l || !r.simulateTouch && t.pointerType === "mouse") return;
    let a = t;
    if (a.originalEvent && (a = a.originalEvent), !n.isTouched) {
        n.startMoving && n.isScrolling && i.emit("touchMoveOpposite", a);
        return
    }
    const c = n.evCache.findIndex(M => M.pointerId === a.pointerId);
    c >= 0 && (n.evCache[c] = a);
    const d = n.evCache.length > 1 ? n.evCache[0] : a,
        p = d.pageX,
        v = d.pageY;
    if (a.preventedByNestedSwiper) {
        s.startX = p, s.startY = v;
        return
    }
    if (!i.allowTouchMove) {
        a.target.matches(n.focusableElements) || (i.allowClick = !1), n.isTouched && (Object.assign(s, {
            startX: p,
            startY: v,
            prevX: i.touches.currentX,
            prevY: i.touches.currentY,
            currentX: p,
            currentY: v
        }), n.touchStartTime = q());
        return
    }
    if (r.touchReleaseOnEdges && !r.loop) {
        if (i.isVertical()) {
            if (v < s.startY && i.translate <= i.maxTranslate() || v > s.startY && i.translate >= i.minTranslate()) {
                n.isTouched = !1, n.isMoved = !1;
                return
            }
        } else if (p < s.startX && i.translate <= i.maxTranslate() || p > s.startX && i.translate >= i.minTranslate()) return
    }
    if (e.activeElement && a.target === e.activeElement && a.target.matches(n.focusableElements)) {
        n.isMoved = !0, i.allowClick = !1;
        return
    }
    if (n.allowTouchCallbacks && i.emit("touchMove", a), a.targetTouches && a.targetTouches.length > 1) return;
    s.currentX = p, s.currentY = v;
    const m = s.currentX - s.startX,
        w = s.currentY - s.startY;
    if (i.params.threshold && Math.sqrt(m ** 2 + w ** 2) < i.params.threshold) return;
    if (typeof n.isScrolling > "u") {
        let M;
        i.isHorizontal() && s.currentY === s.startY || i.isVertical() && s.currentX === s.startX ? n.isScrolling = !1 : m * m + w * w >= 25 && (M = Math.atan2(Math.abs(w), Math.abs(m)) * 180 / Math.PI, n.isScrolling = i.isHorizontal() ? M > r.touchAngle : 90 - M > r.touchAngle)
    }
    if (n.isScrolling && i.emit("touchMoveOpposite", a), typeof n.startMoving > "u" && (s.currentX !== s.startX || s.currentY !== s.startY) && (n.startMoving = !0), n.isScrolling || i.zoom && i.params.zoom && i.params.zoom.enabled && n.evCache.length > 1) {
        n.isTouched = !1;
        return
    }
    if (!n.startMoving) return;
    i.allowClick = !1, !r.cssMode && a.cancelable && a.preventDefault(), r.touchMoveStopPropagation && !r.nested && a.stopPropagation();
    let S = i.isHorizontal() ? m : w,
        x = i.isHorizontal() ? s.currentX - s.previousX : s.currentY - s.previousY;
    r.oneWayMovement && (S = Math.abs(S) * (o ? 1 : -1), x = Math.abs(x) * (o ? 1 : -1)), s.diff = S, S *= r.touchRatio, o && (S = -S, x = -x);
    const y = i.touchesDirection;
    i.swipeDirection = S > 0 ? "prev" : "next", i.touchesDirection = x > 0 ? "prev" : "next";
    const f = i.params.loop && !r.cssMode;
    if (!n.isMoved) {
        if (f && i.loopFix({
                direction: i.swipeDirection
            }), n.startTranslate = i.getTranslate(), i.setTransition(0), i.animating) {
            const M = new window.CustomEvent("transitionend", {
                bubbles: !0,
                cancelable: !0
            });
            i.wrapperEl.dispatchEvent(M)
        }
        n.allowMomentumBounce = !1, r.grabCursor && (i.allowSlideNext === !0 || i.allowSlidePrev === !0) && i.setGrabCursor(!0), i.emit("sliderFirstMove", a)
    }
    let u;
    n.isMoved && y !== i.touchesDirection && f && Math.abs(S) >= 1 && (i.loopFix({
        direction: i.swipeDirection,
        setTranslate: !0
    }), u = !0), i.emit("sliderMove", a), n.isMoved = !0, n.currentTranslate = S + n.startTranslate;
    let g = !0,
        b = r.resistanceRatio;
    if (r.touchReleaseOnEdges && (b = 0), S > 0 ? (f && !u && n.currentTranslate > (r.centeredSlides ? i.minTranslate() - i.size / 2 : i.minTranslate()) && i.loopFix({
            direction: "prev",
            setTranslate: !0,
            activeSlideIndex: 0
        }), n.currentTranslate > i.minTranslate() && (g = !1, r.resistance && (n.currentTranslate = i.minTranslate() - 1 + (-i.minTranslate() + n.startTranslate + S) ** b))) : S < 0 && (f && !u && n.currentTranslate < (r.centeredSlides ? i.maxTranslate() + i.size / 2 : i.maxTranslate()) && i.loopFix({
            direction: "next",
            setTranslate: !0,
            activeSlideIndex: i.slides.length - (r.slidesPerView === "auto" ? i.slidesPerViewDynamic() : Math.ceil(parseFloat(r.slidesPerView, 10)))
        }), n.currentTranslate < i.maxTranslate() && (g = !1, r.resistance && (n.currentTranslate = i.maxTranslate() + 1 - (i.maxTranslate() - n.startTranslate - S) ** b))), g && (a.preventedByNestedSwiper = !0), !i.allowSlideNext && i.swipeDirection === "next" && n.currentTranslate < n.startTranslate && (n.currentTranslate = n.startTranslate), !i.allowSlidePrev && i.swipeDirection === "prev" && n.currentTranslate > n.startTranslate && (n.currentTranslate = n.startTranslate), !i.allowSlidePrev && !i.allowSlideNext && (n.currentTranslate = n.startTranslate), r.threshold > 0)
        if (Math.abs(S) > r.threshold || n.allowThresholdMove) {
            if (!n.allowThresholdMove) {
                n.allowThresholdMove = !0, s.startX = s.currentX, s.startY = s.currentY, n.currentTranslate = n.startTranslate, s.diff = i.isHorizontal() ? s.currentX - s.startX : s.currentY - s.startY;
                return
            }
        } else {
            n.currentTranslate = n.startTranslate;
            return
        }!r.followFinger || r.cssMode || ((r.freeMode && r.freeMode.enabled && i.freeMode || r.watchSlidesProgress) && (i.updateActiveIndex(), i.updateSlidesClasses()), r.freeMode && r.freeMode.enabled && i.freeMode && i.freeMode.onTouchMove(), i.updateProgress(n.currentTranslate), i.setTranslate(n.currentTranslate))
}

function Rt(t) {
    const e = this,
        i = e.touchEventsData,
        n = i.evCache.findIndex(u => u.pointerId === t.pointerId);
    if (n >= 0 && i.evCache.splice(n, 1), ["pointercancel", "pointerout", "pointerleave"].includes(t.type) && !(t.type === "pointercancel" && (e.browser.isSafari || e.browser.isWebView))) return;
    const {
        params: r,
        touches: s,
        rtlTranslate: o,
        slidesGrid: l,
        enabled: a
    } = e;
    if (!a || !r.simulateTouch && t.pointerType === "mouse") return;
    let c = t;
    if (c.originalEvent && (c = c.originalEvent), i.allowTouchCallbacks && e.emit("touchEnd", c), i.allowTouchCallbacks = !1, !i.isTouched) {
        i.isMoved && r.grabCursor && e.setGrabCursor(!1), i.isMoved = !1, i.startMoving = !1;
        return
    }
    r.grabCursor && i.isMoved && i.isTouched && (e.allowSlideNext === !0 || e.allowSlidePrev === !0) && e.setGrabCursor(!1);
    const d = q(),
        p = d - i.touchStartTime;
    if (e.allowClick) {
        const u = c.path || c.composedPath && c.composedPath();
        e.updateClickedSlide(u && u[0] || c.target), e.emit("tap click", c), p < 300 && d - i.lastClickTime < 300 && e.emit("doubleTap doubleClick", c)
    }
    if (i.lastClickTime = q(), de(() => {
            e.destroyed || (e.allowClick = !0)
        }), !i.isTouched || !i.isMoved || !e.swipeDirection || s.diff === 0 || i.currentTranslate === i.startTranslate) {
        i.isTouched = !1, i.isMoved = !1, i.startMoving = !1;
        return
    }
    i.isTouched = !1, i.isMoved = !1, i.startMoving = !1;
    let v;
    if (r.followFinger ? v = o ? e.translate : -e.translate : v = -i.currentTranslate, r.cssMode) return;
    if (r.freeMode && r.freeMode.enabled) {
        e.freeMode.onTouchEnd({
            currentPos: v
        });
        return
    }
    let m = 0,
        w = e.slidesSizesGrid[0];
    for (let u = 0; u < l.length; u += u < r.slidesPerGroupSkip ? 1 : r.slidesPerGroup) {
        const g = u < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
        typeof l[u + g] < "u" ? v >= l[u] && v < l[u + g] && (m = u, w = l[u + g] - l[u]) : v >= l[u] && (m = u, w = l[l.length - 1] - l[l.length - 2])
    }
    let S = null,
        x = null;
    r.rewind && (e.isBeginning ? x = r.virtual && r.virtual.enabled && e.virtual ? e.virtual.slides.length - 1 : e.slides.length - 1 : e.isEnd && (S = 0));
    const y = (v - l[m]) / w,
        f = m < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
    if (p > r.longSwipesMs) {
        if (!r.longSwipes) {
            e.slideTo(e.activeIndex);
            return
        }
        e.swipeDirection === "next" && (y >= r.longSwipesRatio ? e.slideTo(r.rewind && e.isEnd ? S : m + f) : e.slideTo(m)), e.swipeDirection === "prev" && (y > 1 - r.longSwipesRatio ? e.slideTo(m + f) : x !== null && y < 0 && Math.abs(y) > r.longSwipesRatio ? e.slideTo(x) : e.slideTo(m))
    } else {
        if (!r.shortSwipes) {
            e.slideTo(e.activeIndex);
            return
        }
        e.navigation && (c.target === e.navigation.nextEl || c.target === e.navigation.prevEl) ? c.target === e.navigation.nextEl ? e.slideTo(m + f) : e.slideTo(m) : (e.swipeDirection === "next" && e.slideTo(S !== null ? S : m + f), e.swipeDirection === "prev" && e.slideTo(x !== null ? x : m))
    }
}

function me() {
    const t = this,
        {
            params: e,
            el: i
        } = t;
    if (i && i.offsetWidth === 0) return;
    e.breakpoints && t.setBreakpoint();
    const {
        allowSlideNext: n,
        allowSlidePrev: r,
        snapGrid: s
    } = t, o = t.virtual && t.params.virtual.enabled;
    t.allowSlideNext = !0, t.allowSlidePrev = !0, t.updateSize(), t.updateSlides(), t.updateSlidesClasses();
    const l = o && e.loop;
    (e.slidesPerView === "auto" || e.slidesPerView > 1) && t.isEnd && !t.isBeginning && !t.params.centeredSlides && !l ? t.slideTo(t.slides.length - 1, 0, !1, !0) : t.params.loop && !o ? t.slideToLoop(t.realIndex, 0, !1, !0) : t.slideTo(t.activeIndex, 0, !1, !0), t.autoplay && t.autoplay.running && t.autoplay.paused && (clearTimeout(t.autoplay.resizeTimeout), t.autoplay.resizeTimeout = setTimeout(() => {
        t.autoplay && t.autoplay.running && t.autoplay.paused && t.autoplay.resume()
    }, 500)), t.allowSlidePrev = r, t.allowSlideNext = n, t.params.watchOverflow && s !== t.snapGrid && t.checkOverflow()
}

function Ht(t) {
    const e = this;
    e.enabled && (e.allowClick || (e.params.preventClicks && t.preventDefault(), e.params.preventClicksPropagation && e.animating && (t.stopPropagation(), t.stopImmediatePropagation())))
}

function kt() {
    const t = this,
        {
            wrapperEl: e,
            rtlTranslate: i,
            enabled: n
        } = t;
    if (!n) return;
    t.previousTranslate = t.translate, t.isHorizontal() ? t.translate = -e.scrollLeft : t.translate = -e.scrollTop, t.translate === 0 && (t.translate = 0), t.updateActiveIndex(), t.updateSlidesClasses();
    let r;
    const s = t.maxTranslate() - t.minTranslate();
    s === 0 ? r = 0 : r = (t.translate - t.minTranslate()) / s, r !== t.progress && t.updateProgress(i ? -t.translate : t.translate), t.emit("setTranslate", t.translate, !1)
}

function jt(t) {
    const e = this;
    Q(e, t.target), !(e.params.cssMode || e.params.slidesPerView !== "auto" && !e.params.autoHeight) && e.update()
}
let he = !1;

function Wt() {}
const Oe = (t, e) => {
    const i = R(),
        {
            params: n,
            el: r,
            wrapperEl: s,
            device: o
        } = t,
        l = !!n.nested,
        a = e === "on" ? "addEventListener" : "removeEventListener",
        c = e;
    r[a]("pointerdown", t.onTouchStart, {
        passive: !1
    }), i[a]("pointermove", t.onTouchMove, {
        passive: !1,
        capture: l
    }), i[a]("pointerup", t.onTouchEnd, {
        passive: !0
    }), i[a]("pointercancel", t.onTouchEnd, {
        passive: !0
    }), i[a]("pointerout", t.onTouchEnd, {
        passive: !0
    }), i[a]("pointerleave", t.onTouchEnd, {
        passive: !0
    }), (n.preventClicks || n.preventClicksPropagation) && r[a]("click", t.onClick, !0), n.cssMode && s[a]("scroll", t.onScroll), n.updateOnWindowResize ? t[c](o.ios || o.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", me, !0) : t[c]("observerUpdate", me, !0), r[a]("load", t.onLoad, {
        capture: !0
    })
};

function qt() {
    const t = this,
        e = R(),
        {
            params: i
        } = t;
    t.onTouchStart = Vt.bind(t), t.onTouchMove = Ft.bind(t), t.onTouchEnd = Rt.bind(t), i.cssMode && (t.onScroll = kt.bind(t)), t.onClick = Ht.bind(t), t.onLoad = jt.bind(t), he || (e.addEventListener("touchstart", Wt), he = !0), Oe(t, "on")
}

function Xt() {
    Oe(this, "off")
}
var Yt = {
    attachEvents: qt,
    detachEvents: Xt
};
const ge = (t, e) => t.grid && e.grid && e.grid.rows > 1;

function Ut() {
    const t = this,
        {
            realIndex: e,
            initialized: i,
            params: n,
            el: r
        } = t,
        s = n.breakpoints;
    if (!s || s && Object.keys(s).length === 0) return;
    const o = t.getBreakpoint(s, t.params.breakpointsBase, t.el);
    if (!o || t.currentBreakpoint === o) return;
    const a = (o in s ? s[o] : void 0) || t.originalParams,
        c = ge(t, n),
        d = ge(t, a),
        p = n.enabled;
    c && !d ? (r.classList.remove(`${n.containerModifierClass}grid`, `${n.containerModifierClass}grid-column`), t.emitContainerClasses()) : !c && d && (r.classList.add(`${n.containerModifierClass}grid`), (a.grid.fill && a.grid.fill === "column" || !a.grid.fill && n.grid.fill === "column") && r.classList.add(`${n.containerModifierClass}grid-column`), t.emitContainerClasses()), ["navigation", "pagination", "scrollbar"].forEach(S => {
        if (typeof a[S] > "u") return;
        const x = n[S] && n[S].enabled,
            y = a[S] && a[S].enabled;
        x && !y && t[S].disable(), !x && y && t[S].enable()
    });
    const v = a.direction && a.direction !== n.direction,
        m = n.loop && (a.slidesPerView !== n.slidesPerView || v);
    v && i && t.changeDirection(), _(t.params, a);
    const w = t.params.enabled;
    Object.assign(t, {
        allowTouchMove: t.params.allowTouchMove,
        allowSlideNext: t.params.allowSlideNext,
        allowSlidePrev: t.params.allowSlidePrev
    }), p && !w ? t.disable() : !p && w && t.enable(), t.currentBreakpoint = o, t.emit("_beforeBreakpoint", a), m && i && (t.loopDestroy(), t.loopCreate(e), t.updateSlides()), t.emit("breakpoint", a)
}

function Kt(t, e, i) {
    if (e === void 0 && (e = "window"), !t || e === "container" && !i) return;
    let n = !1;
    const r = G(),
        s = e === "window" ? r.innerHeight : i.clientHeight,
        o = Object.keys(t).map(l => {
            if (typeof l == "string" && l.indexOf("@") === 0) {
                const a = parseFloat(l.substr(1));
                return {
                    value: s * a,
                    point: l
                }
            }
            return {
                value: l,
                point: l
            }
        });
    o.sort((l, a) => parseInt(l.value, 10) - parseInt(a.value, 10));
    for (let l = 0; l < o.length; l += 1) {
        const {
            point: a,
            value: c
        } = o[l];
        e === "window" ? r.matchMedia(`(min-width: ${c}px)`).matches && (n = a) : c <= i.clientWidth && (n = a)
    }
    return n || "max"
}
var Zt = {
    setBreakpoint: Ut,
    getBreakpoint: Kt
};

function Jt(t, e) {
    const i = [];
    return t.forEach(n => {
        typeof n == "object" ? Object.keys(n).forEach(r => {
            n[r] && i.push(e + r)
        }) : typeof n == "string" && i.push(e + n)
    }), i
}

function Qt() {
    const t = this,
        {
            classNames: e,
            params: i,
            rtl: n,
            el: r,
            device: s
        } = t,
        o = Jt(["initialized", i.direction, {
            "free-mode": t.params.freeMode && i.freeMode.enabled
        }, {
            autoheight: i.autoHeight
        }, {
            rtl: n
        }, {
            grid: i.grid && i.grid.rows > 1
        }, {
            "grid-column": i.grid && i.grid.rows > 1 && i.grid.fill === "column"
        }, {
            android: s.android
        }, {
            ios: s.ios
        }, {
            "css-mode": i.cssMode
        }, {
            centered: i.cssMode && i.centeredSlides
        }, {
            "watch-progress": i.watchSlidesProgress
        }], i.containerModifierClass);
    e.push(...o), r.classList.add(...e), t.emitContainerClasses()
}

function ei() {
    const t = this,
        {
            el: e,
            classNames: i
        } = t;
    e.classList.remove(...i), t.emitContainerClasses()
}
var ti = {
    addClasses: Qt,
    removeClasses: ei
};

function ii() {
    const t = this,
        {
            isLocked: e,
            params: i
        } = t,
        {
            slidesOffsetBefore: n
        } = i;
    if (n) {
        const r = t.slides.length - 1,
            s = t.slidesGrid[r] + t.slidesSizesGrid[r] + n * 2;
        t.isLocked = t.size > s
    } else t.isLocked = t.snapGrid.length === 1;
    i.allowSlideNext === !0 && (t.allowSlideNext = !t.isLocked), i.allowSlidePrev === !0 && (t.allowSlidePrev = !t.isLocked), e && e !== t.isLocked && (t.isEnd = !1), e !== t.isLocked && t.emit(t.isLocked ? "lock" : "unlock")
}
var ni = {
        checkOverflow: ii
    },
    ve = {
        init: !0,
        direction: "horizontal",
        oneWayMovement: !1,
        touchEventsTarget: "wrapper",
        initialSlide: 0,
        speed: 300,
        cssMode: !1,
        updateOnWindowResize: !0,
        resizeObserver: !0,
        nested: !1,
        createElements: !1,
        enabled: !0,
        focusableElements: "input, select, option, textarea, button, video, label",
        width: null,
        height: null,
        preventInteractionOnTransition: !1,
        userAgent: null,
        url: null,
        edgeSwipeDetection: !1,
        edgeSwipeThreshold: 20,
        autoHeight: !1,
        setWrapperSize: !1,
        virtualTranslate: !1,
        effect: "slide",
        breakpoints: void 0,
        breakpointsBase: "window",
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerGroup: 1,
        slidesPerGroupSkip: 0,
        slidesPerGroupAuto: !1,
        centeredSlides: !1,
        centeredSlidesBounds: !1,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        normalizeSlideIndex: !0,
        centerInsufficientSlides: !1,
        watchOverflow: !0,
        roundLengths: !1,
        touchRatio: 1,
        touchAngle: 45,
        simulateTouch: !0,
        shortSwipes: !0,
        longSwipes: !0,
        longSwipesRatio: .5,
        longSwipesMs: 300,
        followFinger: !0,
        allowTouchMove: !0,
        threshold: 5,
        touchMoveStopPropagation: !1,
        touchStartPreventDefault: !0,
        touchStartForcePreventDefault: !1,
        touchReleaseOnEdges: !1,
        uniqueNavElements: !0,
        resistance: !0,
        resistanceRatio: .85,
        watchSlidesProgress: !1,
        grabCursor: !1,
        preventClicks: !0,
        preventClicksPropagation: !0,
        slideToClickedSlide: !1,
        loop: !1,
        loopedSlides: null,
        loopPreventsSliding: !0,
        rewind: !1,
        allowSlidePrev: !0,
        allowSlideNext: !0,
        swipeHandler: null,
        noSwiping: !0,
        noSwipingClass: "swiper-no-swiping",
        noSwipingSelector: null,
        passiveListeners: !0,
        maxBackfaceHiddenSlides: 10,
        containerModifierClass: "swiper-",
        slideClass: "swiper-slide",
        slideActiveClass: "swiper-slide-active",
        slideVisibleClass: "swiper-slide-visible",
        slideNextClass: "swiper-slide-next",
        slidePrevClass: "swiper-slide-prev",
        wrapperClass: "swiper-wrapper",
        lazyPreloaderClass: "swiper-lazy-preloader",
        lazyPreloadPrevNext: 0,
        runCallbacksOnInit: !0,
        _emitClasses: !1
    };

function si(t, e) {
    return function(n) {
        n === void 0 && (n = {});
        const r = Object.keys(n)[0],
            s = n[r];
        if (typeof s != "object" || s === null) {
            _(e, n);
            return
        }
        if (["navigation", "pagination", "scrollbar"].indexOf(r) >= 0 && t[r] === !0 && (t[r] = {
                auto: !0
            }), !(r in t && "enabled" in s)) {
            _(e, n);
            return
        }
        t[r] === !0 && (t[r] = {
            enabled: !0
        }), typeof t[r] == "object" && !("enabled" in t[r]) && (t[r].enabled = !0), t[r] || (t[r] = {
            enabled: !1
        }), _(e, n)
    }
}
const ae = {
        eventsEmitter: tt,
        update: ct,
        translate: wt,
        transition: Tt,
        slide: It,
        loop: Dt,
        grabCursor: $t,
        events: Yt,
        breakpoints: Zt,
        checkOverflow: ni,
        classes: ti
    },
    le = {};
let K = class H {
    constructor() {
        let e, i;
        for (var n = arguments.length, r = new Array(n), s = 0; s < n; s++) r[s] = arguments[s];
        r.length === 1 && r[0].constructor && Object.prototype.toString.call(r[0]).slice(8, -1) === "Object" ? i = r[0] : [e, i] = r, i || (i = {}), i = _({}, i), e && !i.el && (i.el = e);
        const o = R();
        if (i.el && typeof i.el == "string" && o.querySelectorAll(i.el).length > 1) {
            const d = [];
            return o.querySelectorAll(i.el).forEach(p => {
                const v = _({}, i, {
                    el: p
                });
                d.push(new H(v))
            }), d
        }
        const l = this;
        l.__swiper__ = !0, l.support = Pe(), l.device = Ke({
            userAgent: i.userAgent
        }), l.browser = Je(), l.eventsListeners = {}, l.eventsAnyListeners = [], l.modules = [...l.__modules__], i.modules && Array.isArray(i.modules) && l.modules.push(...i.modules);
        const a = {};
        l.modules.forEach(d => {
            d({
                params: i,
                swiper: l,
                extendParams: si(i, a),
                on: l.on.bind(l),
                once: l.once.bind(l),
                off: l.off.bind(l),
                emit: l.emit.bind(l)
            })
        });
        const c = _({}, ve, a);
        return l.params = _({}, c, le, i), l.originalParams = _({}, l.params), l.passedParams = _({}, i), l.params && l.params.on && Object.keys(l.params.on).forEach(d => {
            l.on(d, l.params.on[d])
        }), l.params && l.params.onAny && l.onAny(l.params.onAny), Object.assign(l, {
            enabled: l.params.enabled,
            el: e,
            classNames: [],
            slides: [],
            slidesGrid: [],
            snapGrid: [],
            slidesSizesGrid: [],
            isHorizontal() {
                return l.params.direction === "horizontal"
            },
            isVertical() {
                return l.params.direction === "vertical"
            },
            activeIndex: 0,
            realIndex: 0,
            isBeginning: !0,
            isEnd: !1,
            translate: 0,
            previousTranslate: 0,
            progress: 0,
            velocity: 0,
            animating: !1,
            cssOverflowAdjustment() {
                return Math.trunc(this.translate / 2 ** 23) * 2 ** 23
            },
            allowSlideNext: l.params.allowSlideNext,
            allowSlidePrev: l.params.allowSlidePrev,
            touchEventsData: {
                isTouched: void 0,
                isMoved: void 0,
                allowTouchCallbacks: void 0,
                touchStartTime: void 0,
                isScrolling: void 0,
                currentTranslate: void 0,
                startTranslate: void 0,
                allowThresholdMove: void 0,
                focusableElements: l.params.focusableElements,
                lastClickTime: 0,
                clickTimeout: void 0,
                velocities: [],
                allowMomentumBounce: void 0,
                startMoving: void 0,
                evCache: []
            },
            allowClick: !0,
            allowTouchMove: l.params.allowTouchMove,
            touches: {
                startX: 0,
                startY: 0,
                currentX: 0,
                currentY: 0,
                diff: 0
            },
            imagesToLoad: [],
            imagesLoaded: 0
        }), l.emit("_swiper"), l.params.init && l.init(), l
    }
    getSlideIndex(e) {
        const {
            slidesEl: i,
            params: n
        } = this, r = F(i, `.${n.slideClass}, swiper-slide`), s = ee(r[0]);
        return ee(e) - s
    }
    getSlideIndexByData(e) {
        return this.getSlideIndex(this.slides.filter(i => i.getAttribute("data-swiper-slide-index") * 1 === e)[0])
    }
    recalcSlides() {
        const e = this,
            {
                slidesEl: i,
                params: n
            } = e;
        e.slides = F(i, `.${n.slideClass}, swiper-slide`)
    }
    enable() {
        const e = this;
        e.enabled || (e.enabled = !0, e.params.grabCursor && e.setGrabCursor(), e.emit("enable"))
    }
    disable() {
        const e = this;
        e.enabled && (e.enabled = !1, e.params.grabCursor && e.unsetGrabCursor(), e.emit("disable"))
    }
    setProgress(e, i) {
        const n = this;
        e = Math.min(Math.max(e, 0), 1);
        const r = n.minTranslate(),
            o = (n.maxTranslate() - r) * e + r;
        n.translateTo(o, typeof i > "u" ? 0 : i), n.updateActiveIndex(), n.updateSlidesClasses()
    }
    emitContainerClasses() {
        const e = this;
        if (!e.params._emitClasses || !e.el) return;
        const i = e.el.className.split(" ").filter(n => n.indexOf("swiper") === 0 || n.indexOf(e.params.containerModifierClass) === 0);
        e.emit("_containerClasses", i.join(" "))
    }
    getSlideClasses(e) {
        const i = this;
        return i.destroyed ? "" : e.className.split(" ").filter(n => n.indexOf("swiper-slide") === 0 || n.indexOf(i.params.slideClass) === 0).join(" ")
    }
    emitSlidesClasses() {
        const e = this;
        if (!e.params._emitClasses || !e.el) return;
        const i = [];
        e.slides.forEach(n => {
            const r = e.getSlideClasses(n);
            i.push({
                slideEl: n,
                classNames: r
            }), e.emit("_slideClass", n, r)
        }), e.emit("_slideClasses", i)
    }
    slidesPerViewDynamic(e, i) {
        e === void 0 && (e = "current"), i === void 0 && (i = !1);
        const n = this,
            {
                params: r,
                slides: s,
                slidesGrid: o,
                slidesSizesGrid: l,
                size: a,
                activeIndex: c
            } = n;
        let d = 1;
        if (r.centeredSlides) {
            let p = s[c] ? s[c].swiperSlideSize : 0,
                v;
            for (let m = c + 1; m < s.length; m += 1) s[m] && !v && (p += s[m].swiperSlideSize, d += 1, p > a && (v = !0));
            for (let m = c - 1; m >= 0; m -= 1) s[m] && !v && (p += s[m].swiperSlideSize, d += 1, p > a && (v = !0))
        } else if (e === "current")
            for (let p = c + 1; p < s.length; p += 1)(i ? o[p] + l[p] - o[c] < a : o[p] - o[c] < a) && (d += 1);
        else
            for (let p = c - 1; p >= 0; p -= 1) o[c] - o[p] < a && (d += 1);
        return d
    }
    update() {
        const e = this;
        if (!e || e.destroyed) return;
        const {
            snapGrid: i,
            params: n
        } = e;
        n.breakpoints && e.setBreakpoint(), [...e.el.querySelectorAll('[loading="lazy"]')].forEach(o => {
            o.complete && Q(e, o)
        }), e.updateSize(), e.updateSlides(), e.updateProgress(), e.updateSlidesClasses();

        function r() {
            const o = e.rtlTranslate ? e.translate * -1 : e.translate,
                l = Math.min(Math.max(o, e.maxTranslate()), e.minTranslate());
            e.setTranslate(l), e.updateActiveIndex(), e.updateSlidesClasses()
        }
        let s;
        if (n.freeMode && n.freeMode.enabled && !n.cssMode) r(), n.autoHeight && e.updateAutoHeight();
        else {
            if ((n.slidesPerView === "auto" || n.slidesPerView > 1) && e.isEnd && !n.centeredSlides) {
                const o = e.virtual && n.virtual.enabled ? e.virtual.slides : e.slides;
                s = e.slideTo(o.length - 1, 0, !1, !0)
            } else s = e.slideTo(e.activeIndex, 0, !1, !0);
            s || r()
        }
        n.watchOverflow && i !== e.snapGrid && e.checkOverflow(), e.emit("update")
    }
    changeDirection(e, i) {
        i === void 0 && (i = !0);
        const n = this,
            r = n.params.direction;
        return e || (e = r === "horizontal" ? "vertical" : "horizontal"), e === r || e !== "horizontal" && e !== "vertical" || (n.el.classList.remove(`${n.params.containerModifierClass}${r}`), n.el.classList.add(`${n.params.containerModifierClass}${e}`), n.emitContainerClasses(), n.params.direction = e, n.slides.forEach(s => {
            e === "vertical" ? s.style.width = "" : s.style.height = ""
        }), n.emit("changeDirection"), i && n.update()), n
    }
    changeLanguageDirection(e) {
        const i = this;
        i.rtl && e === "rtl" || !i.rtl && e === "ltr" || (i.rtl = e === "rtl", i.rtlTranslate = i.params.direction === "horizontal" && i.rtl, i.rtl ? (i.el.classList.add(`${i.params.containerModifierClass}rtl`), i.el.dir = "rtl") : (i.el.classList.remove(`${i.params.containerModifierClass}rtl`), i.el.dir = "ltr"), i.update())
    }
    mount(e) {
        const i = this;
        if (i.mounted) return !0;
        let n = e || i.params.el;
        if (typeof n == "string" && (n = document.querySelector(n)), !n) return !1;
        n.swiper = i, n.parentNode && n.parentNode.host && (i.isElement = !0);
        const r = () => `.${(i.params.wrapperClass||"").trim().split(" ").join(".")}`;
        let o = (() => n && n.shadowRoot && n.shadowRoot.querySelector ? n.shadowRoot.querySelector(r()) : F(n, r())[0])();
        return !o && i.params.createElements && (o = Ce("div", i.params.wrapperClass), n.append(o), F(n, `.${i.params.slideClass}`).forEach(l => {
            o.append(l)
        })), Object.assign(i, {
            el: n,
            wrapperEl: o,
            slidesEl: i.isElement ? n.parentNode.host : o,
            hostEl: i.isElement ? n.parentNode.host : n,
            mounted: !0,
            rtl: n.dir.toLowerCase() === "rtl" || j(n, "direction") === "rtl",
            rtlTranslate: i.params.direction === "horizontal" && (n.dir.toLowerCase() === "rtl" || j(n, "direction") === "rtl"),
            wrongRTL: j(o, "display") === "-webkit-box"
        }), !0
    }
    init(e) {
        const i = this;
        return i.initialized || i.mount(e) === !1 || (i.emit("beforeInit"), i.params.breakpoints && i.setBreakpoint(), i.addClasses(), i.updateSize(), i.updateSlides(), i.params.watchOverflow && i.checkOverflow(), i.params.grabCursor && i.enabled && i.setGrabCursor(), i.params.loop && i.virtual && i.params.virtual.enabled ? i.slideTo(i.params.initialSlide + i.virtual.slidesBefore, 0, i.params.runCallbacksOnInit, !1, !0) : i.slideTo(i.params.initialSlide, 0, i.params.runCallbacksOnInit, !1, !0), i.params.loop && i.loopCreate(), i.attachEvents(), [...i.el.querySelectorAll('[loading="lazy"]')].forEach(r => {
            r.complete ? Q(i, r) : r.addEventListener("load", s => {
                Q(i, s.target)
            })
        }), fe(i), i.initialized = !0, fe(i), i.emit("init"), i.emit("afterInit")), i
    }
    destroy(e, i) {
        e === void 0 && (e = !0), i === void 0 && (i = !0);
        const n = this,
            {
                params: r,
                el: s,
                wrapperEl: o,
                slides: l
            } = n;
        return typeof n.params > "u" || n.destroyed || (n.emit("beforeDestroy"), n.initialized = !1, n.detachEvents(), r.loop && n.loopDestroy(), i && (n.removeClasses(), s.removeAttribute("style"), o.removeAttribute("style"), l && l.length && l.forEach(a => {
            a.classList.remove(r.slideVisibleClass, r.slideActiveClass, r.slideNextClass, r.slidePrevClass), a.removeAttribute("style"), a.removeAttribute("data-swiper-slide-index")
        })), n.emit("destroy"), Object.keys(n.eventsListeners).forEach(a => {
            n.off(a)
        }), e !== !1 && (n.el.swiper = null, He(n)), n.destroyed = !0), null
    }
    static extendDefaults(e) {
        _(le, e)
    }
    static get extendedDefaults() {
        return le
    }
    static get defaults() {
        return ve
    }
    static installModule(e) {
        H.prototype.__modules__ || (H.prototype.__modules__ = []);
        const i = H.prototype.__modules__;
        typeof e == "function" && i.indexOf(e) < 0 && i.push(e)
    }
    static use(e) {
        return Array.isArray(e) ? (e.forEach(i => H.installModule(i)), H) : (H.installModule(e), H)
    }
};
Object.keys(ae).forEach(t => {
    Object.keys(ae[t]).forEach(e => {
        K.prototype[e] = ae[t][e]
    })
});
K.use([Qe, et]);
const Ie = ["eventsPrefix", "injectStyles", "injectStylesUrls", "modules", "init", "_direction", "oneWayMovement", "touchEventsTarget", "initialSlide", "_speed", "cssMode", "updateOnWindowResize", "resizeObserver", "nested", "focusableElements", "_enabled", "_width", "_height", "preventInteractionOnTransition", "userAgent", "url", "_edgeSwipeDetection", "_edgeSwipeThreshold", "_freeMode", "_autoHeight", "setWrapperSize", "virtualTranslate", "_effect", "breakpoints", "_spaceBetween", "_slidesPerView", "maxBackfaceHiddenSlides", "_grid", "_slidesPerGroup", "_slidesPerGroupSkip", "_slidesPerGroupAuto", "_centeredSlides", "_centeredSlidesBounds", "_slidesOffsetBefore", "_slidesOffsetAfter", "normalizeSlideIndex", "_centerInsufficientSlides", "_watchOverflow", "roundLengths", "touchRatio", "touchAngle", "simulateTouch", "_shortSwipes", "_longSwipes", "longSwipesRatio", "longSwipesMs", "_followFinger", "allowTouchMove", "_threshold", "touchMoveStopPropagation", "touchStartPreventDefault", "touchStartForcePreventDefault", "touchReleaseOnEdges", "uniqueNavElements", "_resistance", "_resistanceRatio", "_watchSlidesProgress", "_grabCursor", "preventClicks", "preventClicksPropagation", "_slideToClickedSlide", "_loop", "loopedSlides", "loopPreventsSliding", "_rewind", "_allowSlidePrev", "_allowSlideNext", "_swipeHandler", "_noSwiping", "noSwipingClass", "noSwipingSelector", "passiveListeners", "containerModifierClass", "slideClass", "slideActiveClass", "slideVisibleClass", "slideNextClass", "slidePrevClass", "wrapperClass", "lazyPreloaderClass", "lazyPreloadPrevNext", "runCallbacksOnInit", "observer", "observeParents", "observeSlideChildren", "a11y", "_autoplay", "_controller", "coverflowEffect", "cubeEffect", "fadeEffect", "flipEffect", "creativeEffect", "cardsEffect", "hashNavigation", "history", "keyboard", "mousewheel", "_navigation", "_pagination", "parallax", "_scrollbar", "_thumbs", "virtual", "zoom", "control"];

function X(t) {
    return typeof t == "object" && t !== null && t.constructor && Object.prototype.toString.call(t).slice(8, -1) === "Object"
}

function W(t, e) {
    const i = ["__proto__", "constructor", "prototype"];
    Object.keys(e).filter(n => i.indexOf(n) < 0).forEach(n => {
        typeof t[n] > "u" ? t[n] = e[n] : X(e[n]) && X(t[n]) && Object.keys(e[n]).length > 0 ? e[n].__swiper__ ? t[n] = e[n] : W(t[n], e[n]) : t[n] = e[n]
    })
}

function ze(t) {
    return t === void 0 && (t = {}), t.navigation && typeof t.navigation.nextEl > "u" && typeof t.navigation.prevEl > "u"
}

function Be(t) {
    return t === void 0 && (t = {}), t.pagination && typeof t.pagination.el > "u"
}

function Ae(t) {
    return t === void 0 && (t = {}), t.scrollbar && typeof t.scrollbar.el > "u"
}

function De(t) {
    t === void 0 && (t = "");
    const e = t.split(" ").map(n => n.trim()).filter(n => !!n),
        i = [];
    return e.forEach(n => {
        i.indexOf(n) < 0 && i.push(n)
    }), i.join(" ")
}

function ri(t) {
    return t === void 0 && (t = ""), t ? t.includes("swiper-wrapper") ? t : `swiper-wrapper ${t}` : "swiper-wrapper"
}

function ai(t) {
    let {
        swiper: e,
        slides: i,
        passedParams: n,
        changedParams: r,
        nextEl: s,
        prevEl: o,
        scrollbarEl: l,
        paginationEl: a
    } = t;
    const c = r.filter(h => h !== "children" && h !== "direction" && h !== "wrapperClass"),
        {
            params: d,
            pagination: p,
            navigation: v,
            scrollbar: m,
            virtual: w,
            thumbs: S
        } = e;
    let x, y, f, u, g, b, M, E;
    r.includes("thumbs") && n.thumbs && n.thumbs.swiper && d.thumbs && !d.thumbs.swiper && (x = !0), r.includes("controller") && n.controller && n.controller.control && d.controller && !d.controller.control && (y = !0), r.includes("pagination") && n.pagination && (n.pagination.el || a) && (d.pagination || d.pagination === !1) && p && !p.el && (f = !0), r.includes("scrollbar") && n.scrollbar && (n.scrollbar.el || l) && (d.scrollbar || d.scrollbar === !1) && m && !m.el && (u = !0), r.includes("navigation") && n.navigation && (n.navigation.prevEl || o) && (n.navigation.nextEl || s) && (d.navigation || d.navigation === !1) && v && !v.prevEl && !v.nextEl && (g = !0);
    const C = h => {
        e[h] && (e[h].destroy(), h === "navigation" ? (e.isElement && (e[h].prevEl.remove(), e[h].nextEl.remove()), d[h].prevEl = void 0, d[h].nextEl = void 0, e[h].prevEl = void 0, e[h].nextEl = void 0) : (e.isElement && e[h].el.remove(), d[h].el = void 0, e[h].el = void 0))
    };
    r.includes("loop") && e.isElement && (d.loop && !n.loop ? b = !0 : !d.loop && n.loop ? M = !0 : E = !0), c.forEach(h => {
        if (X(d[h]) && X(n[h])) W(d[h], n[h]), (h === "navigation" || h === "pagination" || h === "scrollbar") && "enabled" in n[h] && !n[h].enabled && C(h);
        else {
            const O = n[h];
            (O === !0 || O === !1) && (h === "navigation" || h === "pagination" || h === "scrollbar") ? O === !1 && C(h): d[h] = n[h]
        }
    }), c.includes("controller") && !y && e.controller && e.controller.control && d.controller && d.controller.control && (e.controller.control = d.controller.control), r.includes("children") && i && w && d.virtual.enabled && (w.slides = i, w.update(!0)), r.includes("children") && i && d.loop && (E = !0), x && S.init() && S.update(!0), y && (e.controller.control = d.controller.control), f && (e.isElement && (!a || typeof a == "string") && (a = document.createElement("div"), a.classList.add("swiper-pagination"), e.el.appendChild(a)), a && (d.pagination.el = a), p.init(), p.render(), p.update()), u && (e.isElement && (!l || typeof l == "string") && (l = document.createElement("div"), l.classList.add("swiper-scrollbar"), e.el.appendChild(l)), l && (d.scrollbar.el = l), m.init(), m.updateSize(), m.setTranslate()), g && (e.isElement && ((!s || typeof s == "string") && (s = document.createElement("div"), s.classList.add("swiper-button-next"), s.innerHTML = e.hostEl.nextButtonSvg, e.el.appendChild(s)), (!o || typeof o == "string") && (o = document.createElement("div"), o.classList.add("swiper-button-prev"), s.innerHTML = e.hostEl.prevButtonSvg, e.el.appendChild(o))), s && (d.navigation.nextEl = s), o && (d.navigation.prevEl = o), v.init(), v.update()), r.includes("allowSlideNext") && (e.allowSlideNext = n.allowSlideNext), r.includes("allowSlidePrev") && (e.allowSlidePrev = n.allowSlidePrev), r.includes("direction") && e.changeDirection(n.direction, !1), (b || E) && e.loopDestroy(), (M || E) && e.loopCreate(), e.update()
}

function we(t, e) {
    t === void 0 && (t = {}), e === void 0 && (e = !0);
    const i = {
            on: {}
        },
        n = {},
        r = {};
    W(i, K.defaults), W(i, K.extendedDefaults), i._emitClasses = !0, i.init = !1;
    const s = {},
        o = Ie.map(a => a.replace(/_/, "")),
        l = Object.assign({}, t);
    return Object.keys(l).forEach(a => {
        typeof t[a] > "u" || (o.indexOf(a) >= 0 ? X(t[a]) ? (i[a] = {}, r[a] = {}, W(i[a], t[a]), W(r[a], t[a])) : (i[a] = t[a], r[a] = t[a]) : a.search(/on[A-Z]/) === 0 && typeof t[a] == "function" ? e ? n[`${a[2].toLowerCase()}${a.substr(3)}`] = t[a] : i.on[`${a[2].toLowerCase()}${a.substr(3)}`] = t[a] : s[a] = t[a])
    }), ["navigation", "pagination", "scrollbar"].forEach(a => {
        i[a] === !0 && (i[a] = {}), i[a] === !1 && delete i[a]
    }), {
        params: i,
        passedParams: r,
        rest: s,
        events: n
    }
}

function li(t, e) {
    let {
        el: i,
        nextEl: n,
        prevEl: r,
        paginationEl: s,
        scrollbarEl: o,
        swiper: l
    } = t;
    ze(e) && n && r && (l.params.navigation.nextEl = n, l.originalParams.navigation.nextEl = n, l.params.navigation.prevEl = r, l.originalParams.navigation.prevEl = r), Be(e) && s && (l.params.pagination.el = s, l.originalParams.pagination.el = s), Ae(e) && o && (l.params.scrollbar.el = o, l.originalParams.scrollbar.el = o), l.init(i)
}

function oi(t, e, i, n, r) {
    const s = [];
    if (!e) return s;
    const o = a => {
        s.indexOf(a) < 0 && s.push(a)
    };
    if (i && n) {
        const a = n.map(r),
            c = i.map(r);
        a.join("") !== c.join("") && o("children"), n.length !== i.length && o("children")
    }
    return Ie.filter(a => a[0] === "_").map(a => a.replace(/_/, "")).forEach(a => {
        if (a in t && a in e)
            if (X(t[a]) && X(e[a])) {
                const c = Object.keys(t[a]),
                    d = Object.keys(e[a]);
                c.length !== d.length ? o(a) : (c.forEach(p => {
                    t[a][p] !== e[a][p] && o(a)
                }), d.forEach(p => {
                    t[a][p] !== e[a][p] && o(a)
                }))
            } else t[a] !== e[a] && o(a)
    }), s
}
const di = t => {
    !t || t.destroyed || !t.params.virtual || t.params.virtual && !t.params.virtual.enabled || (t.updateSlides(), t.updateProgress(), t.updateSlidesClasses(), t.parallax && t.params.parallax && t.params.parallax.enabled && t.parallax.setTranslate())
};

function oe(t, e, i) {
    t === void 0 && (t = {});
    const n = [],
        r = {
            "container-start": [],
            "container-end": [],
            "wrapper-start": [],
            "wrapper-end": []
        },
        s = (o, l) => {
            Array.isArray(o) && o.forEach(a => {
                const c = typeof a.type == "symbol";
                l === "default" && (l = "container-end"), c && a.children ? s(a.children, l) : a.type && (a.type.name === "SwiperSlide" || a.type.name === "AsyncComponentWrapper") ? n.push(a) : r[l] && r[l].push(a)
            })
        };
    return Object.keys(t).forEach(o => {
        if (typeof t[o] != "function") return;
        const l = t[o]();
        s(l, o)
    }), i.value = e.value, e.value = n, {
        slides: n,
        slots: r
    }
}

function ui(t, e, i) {
    if (!i) return null;
    const n = d => {
            let p = d;
            return d < 0 ? p = e.length + d : p >= e.length && (p = p - e.length), p
        },
        r = t.value.isHorizontal() ? {
            [t.value.rtlTranslate ? "right" : "left"]: `${i.offset}px`
        } : {
            top: `${i.offset}px`
        },
        {
            from: s,
            to: o
        } = i,
        l = t.value.params.loop ? -e.length : 0,
        a = t.value.params.loop ? e.length * 2 : e.length,
        c = [];
    for (let d = l; d < a; d += 1) d >= s && d <= o && c.push(e[n(d)]);
    return c.map(d => (d.props || (d.props = {}), d.props.style || (d.props.style = {}), d.props.swiperRef = t, d.props.style = r, V(d.type, { ...d.props
    }, d.children)))
}
const pi = {
        name: "Swiper",
        props: {
            tag: {
                type: String,
                default: "div"
            },
            wrapperTag: {
                type: String,
                default: "div"
            },
            modules: {
                type: Array,
                default: void 0
            },
            init: {
                type: Boolean,
                default: void 0
            },
            direction: {
                type: String,
                default: void 0
            },
            oneWayMovement: {
                type: Boolean,
                default: void 0
            },
            touchEventsTarget: {
                type: String,
                default: void 0
            },
            initialSlide: {
                type: Number,
                default: void 0
            },
            speed: {
                type: Number,
                default: void 0
            },
            cssMode: {
                type: Boolean,
                default: void 0
            },
            updateOnWindowResize: {
                type: Boolean,
                default: void 0
            },
            resizeObserver: {
                type: Boolean,
                default: void 0
            },
            nested: {
                type: Boolean,
                default: void 0
            },
            focusableElements: {
                type: String,
                default: void 0
            },
            width: {
                type: Number,
                default: void 0
            },
            height: {
                type: Number,
                default: void 0
            },
            preventInteractionOnTransition: {
                type: Boolean,
                default: void 0
            },
            userAgent: {
                type: String,
                default: void 0
            },
            url: {
                type: String,
                default: void 0
            },
            edgeSwipeDetection: {
                type: [Boolean, String],
                default: void 0
            },
            edgeSwipeThreshold: {
                type: Number,
                default: void 0
            },
            autoHeight: {
                type: Boolean,
                default: void 0
            },
            setWrapperSize: {
                type: Boolean,
                default: void 0
            },
            virtualTranslate: {
                type: Boolean,
                default: void 0
            },
            effect: {
                type: String,
                default: void 0
            },
            breakpoints: {
                type: Object,
                default: void 0
            },
            spaceBetween: {
                type: [Number, String],
                default: void 0
            },
            slidesPerView: {
                type: [Number, String],
                default: void 0
            },
            maxBackfaceHiddenSlides: {
                type: Number,
                default: void 0
            },
            slidesPerGroup: {
                type: Number,
                default: void 0
            },
            slidesPerGroupSkip: {
                type: Number,
                default: void 0
            },
            slidesPerGroupAuto: {
                type: Boolean,
                default: void 0
            },
            centeredSlides: {
                type: Boolean,
                default: void 0
            },
            centeredSlidesBounds: {
                type: Boolean,
                default: void 0
            },
            slidesOffsetBefore: {
                type: Number,
                default: void 0
            },
            slidesOffsetAfter: {
                type: Number,
                default: void 0
            },
            normalizeSlideIndex: {
                type: Boolean,
                default: void 0
            },
            centerInsufficientSlides: {
                type: Boolean,
                default: void 0
            },
            watchOverflow: {
                type: Boolean,
                default: void 0
            },
            roundLengths: {
                type: Boolean,
                default: void 0
            },
            touchRatio: {
                type: Number,
                default: void 0
            },
            touchAngle: {
                type: Number,
                default: void 0
            },
            simulateTouch: {
                type: Boolean,
                default: void 0
            },
            shortSwipes: {
                type: Boolean,
                default: void 0
            },
            longSwipes: {
                type: Boolean,
                default: void 0
            },
            longSwipesRatio: {
                type: Number,
                default: void 0
            },
            longSwipesMs: {
                type: Number,
                default: void 0
            },
            followFinger: {
                type: Boolean,
                default: void 0
            },
            allowTouchMove: {
                type: Boolean,
                default: void 0
            },
            threshold: {
                type: Number,
                default: void 0
            },
            touchMoveStopPropagation: {
                type: Boolean,
                default: void 0
            },
            touchStartPreventDefault: {
                type: Boolean,
                default: void 0
            },
            touchStartForcePreventDefault: {
                type: Boolean,
                default: void 0
            },
            touchReleaseOnEdges: {
                type: Boolean,
                default: void 0
            },
            uniqueNavElements: {
                type: Boolean,
                default: void 0
            },
            resistance: {
                type: Boolean,
                default: void 0
            },
            resistanceRatio: {
                type: Number,
                default: void 0
            },
            watchSlidesProgress: {
                type: Boolean,
                default: void 0
            },
            grabCursor: {
                type: Boolean,
                default: void 0
            },
            preventClicks: {
                type: Boolean,
                default: void 0
            },
            preventClicksPropagation: {
                type: Boolean,
                default: void 0
            },
            slideToClickedSlide: {
                type: Boolean,
                default: void 0
            },
            loop: {
                type: Boolean,
                default: void 0
            },
            loopedSlides: {
                type: Number,
                default: void 0
            },
            loopPreventsSliding: {
                type: Boolean,
                default: void 0
            },
            rewind: {
                type: Boolean,
                default: void 0
            },
            allowSlidePrev: {
                type: Boolean,
                default: void 0
            },
            allowSlideNext: {
                type: Boolean,
                default: void 0
            },
            swipeHandler: {
                type: Boolean,
                default: void 0
            },
            noSwiping: {
                type: Boolean,
                default: void 0
            },
            noSwipingClass: {
                type: String,
                default: void 0
            },
            noSwipingSelector: {
                type: String,
                default: void 0
            },
            passiveListeners: {
                type: Boolean,
                default: void 0
            },
            containerModifierClass: {
                type: String,
                default: void 0
            },
            slideClass: {
                type: String,
                default: void 0
            },
            slideActiveClass: {
                type: String,
                default: void 0
            },
            slideVisibleClass: {
                type: String,
                default: void 0
            },
            slideNextClass: {
                type: String,
                default: void 0
            },
            slidePrevClass: {
                type: String,
                default: void 0
            },
            wrapperClass: {
                type: String,
                default: void 0
            },
            lazyPreloaderClass: {
                type: String,
                default: void 0
            },
            lazyPreloadPrevNext: {
                type: Number,
                default: void 0
            },
            runCallbacksOnInit: {
                type: Boolean,
                default: void 0
            },
            observer: {
                type: Boolean,
                default: void 0
            },
            observeParents: {
                type: Boolean,
                default: void 0
            },
            observeSlideChildren: {
                type: Boolean,
                default: void 0
            },
            a11y: {
                type: [Boolean, Object],
                default: void 0
            },
            autoplay: {
                type: [Boolean, Object],
                default: void 0
            },
            controller: {
                type: Object,
                default: void 0
            },
            coverflowEffect: {
                type: Object,
                default: void 0
            },
            cubeEffect: {
                type: Object,
                default: void 0
            },
            fadeEffect: {
                type: Object,
                default: void 0
            },
            flipEffect: {
                type: Object,
                default: void 0
            },
            creativeEffect: {
                type: Object,
                default: void 0
            },
            cardsEffect: {
                type: Object,
                default: void 0
            },
            hashNavigation: {
                type: [Boolean, Object],
                default: void 0
            },
            history: {
                type: [Boolean, Object],
                default: void 0
            },
            keyboard: {
                type: [Boolean, Object],
                default: void 0
            },
            mousewheel: {
                type: [Boolean, Object],
                default: void 0
            },
            navigation: {
                type: [Boolean, Object],
                default: void 0
            },
            pagination: {
                type: [Boolean, Object],
                default: void 0
            },
            parallax: {
                type: [Boolean, Object],
                default: void 0
            },
            scrollbar: {
                type: [Boolean, Object],
                default: void 0
            },
            thumbs: {
                type: Object,
                default: void 0
            },
            virtual: {
                type: [Boolean, Object],
                default: void 0
            },
            zoom: {
                type: [Boolean, Object],
                default: void 0
            },
            grid: {
                type: [Object],
                default: void 0
            },
            freeMode: {
                type: [Boolean, Object],
                default: void 0
            },
            enabled: {
                type: Boolean,
                default: void 0
            }
        },
        emits: ["_beforeBreakpoint", "_containerClasses", "_slideClass", "_slideClasses", "_swiper", "_freeModeNoMomentumRelease", "activeIndexChange", "afterInit", "autoplay", "autoplayStart", "autoplayStop", "autoplayPause", "autoplayResume", "autoplayTimeLeft", "beforeDestroy", "beforeInit", "beforeLoopFix", "beforeResize", "beforeSlideChangeStart", "beforeTransitionStart", "breakpoint", "changeDirection", "click", "disable", "doubleTap", "doubleClick", "destroy", "enable", "fromEdge", "hashChange", "hashSet", "init", "keyPress", "lock", "loopFix", "momentumBounce", "navigationHide", "navigationShow", "navigationPrev", "navigationNext", "observerUpdate", "orientationchange", "paginationHide", "paginationRender", "paginationShow", "paginationUpdate", "progress", "reachBeginning", "reachEnd", "realIndexChange", "resize", "scroll", "scrollbarDragEnd", "scrollbarDragMove", "scrollbarDragStart", "setTransition", "setTranslate", "slideChange", "slideChangeTransitionEnd", "slideChangeTransitionStart", "slideNextTransitionEnd", "slideNextTransitionStart", "slidePrevTransitionEnd", "slidePrevTransitionStart", "slideResetTransitionStart", "slideResetTransitionEnd", "sliderMove", "sliderFirstMove", "slidesLengthChange", "slidesGridLengthChange", "snapGridLengthChange", "snapIndexChange", "swiper", "tap", "toEdge", "touchEnd", "touchMove", "touchMoveOpposite", "touchStart", "transitionEnd", "transitionStart", "unlock", "update", "virtualUpdate", "zoomChange"],
        setup(t, e) {
            let {
                slots: i,
                emit: n
            } = e;
            const {
                tag: r,
                wrapperTag: s
            } = t, o = D("swiper"), l = D(null), a = D(!1), c = D(!1), d = D(null), p = D(null), v = D(null), m = {
                value: []
            }, w = {
                value: []
            }, S = D(null), x = D(null), y = D(null), f = D(null), {
                params: u,
                passedParams: g
            } = we(t, !1);
            oe(i, m, w), v.value = g, w.value = m.value;
            const b = () => {
                oe(i, m, w), a.value = !0
            };
            u.onAny = function(C) {
                for (var h = arguments.length, O = new Array(h > 1 ? h - 1 : 0), T = 1; T < h; T++) O[T - 1] = arguments[T];
                n(C, ...O)
            }, Object.assign(u.on, {
                _beforeBreakpoint: b,
                _containerClasses(C, h) {
                    o.value = h
                }
            });
            const M = { ...u
            };
            if (delete M.wrapperClass, p.value = new K(M), p.value.virtual && p.value.params.virtual.enabled) {
                p.value.virtual.slides = m.value;
                const C = {
                    cache: !1,
                    slides: m.value,
                    renderExternal: h => {
                        l.value = h
                    },
                    renderExternalUpdate: !1
                };
                W(p.value.params.virtual, C), W(p.value.originalParams.virtual, C)
            }
            Se(() => {
                !c.value && p.value && (p.value.emitSlidesClasses(), c.value = !0);
                const {
                    passedParams: C
                } = we(t, !1), h = oi(C, v.value, m.value, w.value, O => O.props && O.props.key);
                v.value = C, (h.length || a.value) && p.value && !p.value.destroyed && ai({
                    swiper: p.value,
                    slides: m.value,
                    passedParams: C,
                    changedParams: h,
                    nextEl: S.value,
                    prevEl: x.value,
                    scrollbarEl: f.value,
                    paginationEl: y.value
                }), a.value = !1
            }), ye("swiper", p), $e(l, () => {
                Ne(() => {
                    di(p.value)
                })
            }), be(() => {
                d.value && (li({
                    el: d.value,
                    nextEl: S.value,
                    prevEl: x.value,
                    paginationEl: y.value,
                    scrollbarEl: f.value,
                    swiper: p.value
                }, u), n("swiper", p.value))
            }), Te(() => {
                p.value && !p.value.destroyed && p.value.destroy(!0, !1)
            });

            function E(C) {
                return u.virtual ? ui(p, C, l.value) : (C.forEach((h, O) => {
                    h.props || (h.props = {}), h.props.swiperRef = p, h.props.swiperSlideIndex = O
                }), C)
            }
            return () => {
                const {
                    slides: C,
                    slots: h
                } = oe(i, m, w);
                return V(r, {
                    ref: d,
                    class: De(o.value)
                }, [h["container-start"], V(s, {
                    class: ri(u.wrapperClass)
                }, [h["wrapper-start"], E(C), h["wrapper-end"]]), ze(t) && [V("div", {
                    ref: x,
                    class: "swiper-button-prev"
                }), V("div", {
                    ref: S,
                    class: "swiper-button-next"
                })], Ae(t) && V("div", {
                    ref: f,
                    class: "swiper-scrollbar"
                }), Be(t) && V("div", {
                    ref: y,
                    class: "swiper-pagination"
                }), h["container-end"]])
            }
        }
    },
    mi = {
        name: "SwiperSlide",
        props: {
            tag: {
                type: String,
                default: "div"
            },
            swiperRef: {
                type: Object,
                required: !1
            },
            swiperSlideIndex: {
                type: Number,
                default: void 0,
                required: !1
            },
            zoom: {
                type: Boolean,
                default: void 0,
                required: !1
            },
            lazy: {
                type: Boolean,
                default: !1,
                required: !1
            },
            virtualIndex: {
                type: [String, Number],
                default: void 0
            }
        },
        setup(t, e) {
            let {
                slots: i
            } = e, n = !1;
            const {
                swiperRef: r
            } = t, s = D(null), o = D("swiper-slide"), l = D(!1);

            function a(p, v, m) {
                v === s.value && (o.value = m)
            }
            be(() => {
                !r || !r.value || (r.value.on("_slideClass", a), n = !0)
            }), Ve(() => {
                n || !r || !r.value || (r.value.on("_slideClass", a), n = !0)
            }), Se(() => {
                !s.value || !r || !r.value || (typeof t.swiperSlideIndex < "u" && (s.value.swiperSlideIndex = t.swiperSlideIndex), r.value.destroyed && o.value !== "swiper-slide" && (o.value = "swiper-slide"))
            }), Te(() => {
                !r || !r.value || r.value.off("_slideClass", a)
            });
            const c = Fe(() => ({
                isActive: o.value.indexOf("swiper-slide-active") >= 0,
                isVisible: o.value.indexOf("swiper-slide-visible") >= 0,
                isPrev: o.value.indexOf("swiper-slide-prev") >= 0,
                isNext: o.value.indexOf("swiper-slide-next") >= 0
            }));
            ye("swiperSlide", c);
            const d = () => {
                l.value = !0
            };
            return () => V(t.tag, {
                class: De(`${o.value}`),
                ref: s,
                "data-swiper-slide-index": typeof t.virtualIndex > "u" && r && r.value && r.value.params.loop ? t.swiperSlideIndex : t.virtualIndex,
                onLoadCapture: d
            }, t.zoom ? V("div", {
                class: "swiper-zoom-container",
                "data-swiper-zoom": typeof t.zoom == "number" ? t.zoom : void 0
            }, [i.default && i.default(c.value), t.lazy && !l.value && V("div", {
                class: "swiper-lazy-preloader"
            })]) : [i.default && i.default(c.value), t.lazy && !l.value && V("div", {
                class: "swiper-lazy-preloader"
            })])
        }
    };

function fi(t, e, i, n) {
    return t.params.createElements && Object.keys(n).forEach(r => {
        if (!i[r] && i.auto === !0) {
            let s = F(t.el, `.${n[r]}`)[0];
            s || (s = Ce("div", n[r]), s.className = n[r], t.el.append(s)), i[r] = s, e[r] = s
        }
    }), i
}

function U(t) {
    return t === void 0 && (t = ""), `.${t.trim().replace(/([\.:!+\/])/g,"\\$1").replace(/ /g,".")}`
}

function hi(t) {
    let {
        swiper: e,
        extendParams: i,
        on: n,
        emit: r
    } = t;
    const s = "swiper-pagination";
    i({
        pagination: {
            el: null,
            bulletElement: "span",
            clickable: !1,
            hideOnClick: !1,
            renderBullet: null,
            renderProgressbar: null,
            renderFraction: null,
            renderCustom: null,
            progressbarOpposite: !1,
            type: "bullets",
            dynamicBullets: !1,
            dynamicMainBullets: 1,
            formatFractionCurrent: f => f,
            formatFractionTotal: f => f,
            bulletClass: `${s}-bullet`,
            bulletActiveClass: `${s}-bullet-active`,
            modifierClass: `${s}-`,
            currentClass: `${s}-current`,
            totalClass: `${s}-total`,
            hiddenClass: `${s}-hidden`,
            progressbarFillClass: `${s}-progressbar-fill`,
            progressbarOppositeClass: `${s}-progressbar-opposite`,
            clickableClass: `${s}-clickable`,
            lockClass: `${s}-lock`,
            horizontalClass: `${s}-horizontal`,
            verticalClass: `${s}-vertical`,
            paginationDisabledClass: `${s}-disabled`
        }
    }), e.pagination = {
        el: null,
        bullets: []
    };
    let o, l = 0;
    const a = f => (Array.isArray(f) || (f = [f].filter(u => !!u)), f);

    function c() {
        return !e.params.pagination.el || !e.pagination.el || Array.isArray(e.pagination.el) && e.pagination.el.length === 0
    }

    function d(f, u) {
        const {
            bulletActiveClass: g
        } = e.params.pagination;
        f && (f = f[`${u==="prev"?"previous":"next"}ElementSibling`], f && (f.classList.add(`${g}-${u}`), f = f[`${u==="prev"?"previous":"next"}ElementSibling`], f && f.classList.add(`${g}-${u}-${u}`)))
    }

    function p(f) {
        const u = f.target.closest(U(e.params.pagination.bulletClass));
        if (!u) return;
        f.preventDefault();
        const g = ee(u) * e.params.slidesPerGroup;
        if (e.params.loop) {
            if (e.realIndex === g) return;
            const b = e.getSlideIndexByData(g),
                M = e.getSlideIndexByData(e.realIndex);
            b > e.slides.length - e.loopedSlides && e.loopFix({
                direction: b > M ? "next" : "prev",
                activeSlideIndex: b,
                slideTo: !1
            }), e.slideToLoop(g)
        } else e.slideTo(g)
    }

    function v() {
        const f = e.rtl,
            u = e.params.pagination;
        if (c()) return;
        let g = e.pagination.el;
        g = a(g);
        let b, M;
        const E = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length,
            C = e.params.loop ? Math.ceil(E / e.params.slidesPerGroup) : e.snapGrid.length;
        if (e.params.loop ? (M = e.previousRealIndex || 0, b = e.params.slidesPerGroup > 1 ? Math.floor(e.realIndex / e.params.slidesPerGroup) : e.realIndex) : typeof e.snapIndex < "u" ? (b = e.snapIndex, M = e.previousSnapIndex) : (M = e.previousIndex || 0, b = e.activeIndex || 0), u.type === "bullets" && e.pagination.bullets && e.pagination.bullets.length > 0) {
            const h = e.pagination.bullets;
            let O, T, P;
            if (u.dynamicBullets && (o = ue(h[0], e.isHorizontal() ? "width" : "height", !0), g.forEach(L => {
                    L.style[e.isHorizontal() ? "width" : "height"] = `${o*(u.dynamicMainBullets+4)}px`
                }), u.dynamicMainBullets > 1 && M !== void 0 && (l += b - (M || 0), l > u.dynamicMainBullets - 1 ? l = u.dynamicMainBullets - 1 : l < 0 && (l = 0)), O = Math.max(b - l, 0), T = O + (Math.min(h.length, u.dynamicMainBullets) - 1), P = (T + O) / 2), h.forEach(L => {
                    const I = [...["", "-next", "-next-next", "-prev", "-prev-prev", "-main"].map(B => `${u.bulletActiveClass}${B}`)].map(B => typeof B == "string" && B.includes(" ") ? B.split(" ") : B).flat();
                    L.classList.remove(...I)
                }), g.length > 1) h.forEach(L => {
                const I = ee(L);
                I === b ? L.classList.add(...u.bulletActiveClass.split(" ")) : e.isElement && L.setAttribute("part", "bullet"), u.dynamicBullets && (I >= O && I <= T && L.classList.add(...`${u.bulletActiveClass}-main`.split(" ")), I === O && d(L, "prev"), I === T && d(L, "next"))
            });
            else {
                const L = h[b];
                if (L && L.classList.add(...u.bulletActiveClass.split(" ")), e.isElement && h.forEach((I, B) => {
                        I.setAttribute("part", B === b ? "bullet-active" : "bullet")
                    }), u.dynamicBullets) {
                    const I = h[O],
                        B = h[T];
                    for (let $ = O; $ <= T; $ += 1) h[$] && h[$].classList.add(...`${u.bulletActiveClass}-main`.split(" "));
                    d(I, "prev"), d(B, "next")
                }
            }
            if (u.dynamicBullets) {
                const L = Math.min(h.length, u.dynamicMainBullets + 4),
                    I = (o * L - o) / 2 - P * o,
                    B = f ? "right" : "left";
                h.forEach($ => {
                    $.style[e.isHorizontal() ? B : "top"] = `${I}px`
                })
            }
        }
        g.forEach((h, O) => {
            if (u.type === "fraction" && (h.querySelectorAll(U(u.currentClass)).forEach(T => {
                    T.textContent = u.formatFractionCurrent(b + 1)
                }), h.querySelectorAll(U(u.totalClass)).forEach(T => {
                    T.textContent = u.formatFractionTotal(C)
                })), u.type === "progressbar") {
                let T;
                u.progressbarOpposite ? T = e.isHorizontal() ? "vertical" : "horizontal" : T = e.isHorizontal() ? "horizontal" : "vertical";
                const P = (b + 1) / C;
                let L = 1,
                    I = 1;
                T === "horizontal" ? L = P : I = P, h.querySelectorAll(U(u.progressbarFillClass)).forEach(B => {
                    B.style.transform = `translate3d(0,0,0) scaleX(${L}) scaleY(${I})`, B.style.transitionDuration = `${e.params.speed}ms`
                })
            }
            u.type === "custom" && u.renderCustom ? (h.innerHTML = u.renderCustom(e, b + 1, C), O === 0 && r("paginationRender", h)) : (O === 0 && r("paginationRender", h), r("paginationUpdate", h)), e.params.watchOverflow && e.enabled && h.classList[e.isLocked ? "add" : "remove"](u.lockClass)
        })
    }

    function m() {
        const f = e.params.pagination;
        if (c()) return;
        const u = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length;
        let g = e.pagination.el;
        g = a(g);
        let b = "";
        if (f.type === "bullets") {
            let M = e.params.loop ? Math.ceil(u / e.params.slidesPerGroup) : e.snapGrid.length;
            e.params.freeMode && e.params.freeMode.enabled && M > u && (M = u);
            for (let E = 0; E < M; E += 1) f.renderBullet ? b += f.renderBullet.call(e, E, f.bulletClass) : b += `<${f.bulletElement} ${e.isElement?'part="bullet"':""} class="${f.bulletClass}"></${f.bulletElement}>`
        }
        f.type === "fraction" && (f.renderFraction ? b = f.renderFraction.call(e, f.currentClass, f.totalClass) : b = `<span class="${f.currentClass}"></span> / <span class="${f.totalClass}"></span>`), f.type === "progressbar" && (f.renderProgressbar ? b = f.renderProgressbar.call(e, f.progressbarFillClass) : b = `<span class="${f.progressbarFillClass}"></span>`), e.pagination.bullets = [], g.forEach(M => {
            f.type !== "custom" && (M.innerHTML = b || ""), f.type === "bullets" && e.pagination.bullets.push(...M.querySelectorAll(U(f.bulletClass)))
        }), f.type !== "custom" && r("paginationRender", g[0])
    }

    function w() {
        e.params.pagination = fi(e, e.originalParams.pagination, e.params.pagination, {
            el: "swiper-pagination"
        });
        const f = e.params.pagination;
        if (!f.el) return;
        let u;
        typeof f.el == "string" && e.isElement && (u = e.el.querySelector(f.el)), !u && typeof f.el == "string" && (u = [...document.querySelectorAll(f.el)]), u || (u = f.el), !(!u || u.length === 0) && (e.params.uniqueNavElements && typeof f.el == "string" && Array.isArray(u) && u.length > 1 && (u = [...e.el.querySelectorAll(f.el)], u.length > 1 && (u = u.filter(g => Me(g, ".swiper")[0] === e.el)[0])), Array.isArray(u) && u.length === 1 && (u = u[0]), Object.assign(e.pagination, {
            el: u
        }), u = a(u), u.forEach(g => {
            f.type === "bullets" && f.clickable && g.classList.add(f.clickableClass), g.classList.add(f.modifierClass + f.type), g.classList.add(e.isHorizontal() ? f.horizontalClass : f.verticalClass), f.type === "bullets" && f.dynamicBullets && (g.classList.add(`${f.modifierClass}${f.type}-dynamic`), l = 0, f.dynamicMainBullets < 1 && (f.dynamicMainBullets = 1)), f.type === "progressbar" && f.progressbarOpposite && g.classList.add(f.progressbarOppositeClass), f.clickable && g.addEventListener("click", p), e.enabled || g.classList.add(f.lockClass)
        }))
    }

    function S() {
        const f = e.params.pagination;
        if (c()) return;
        let u = e.pagination.el;
        u && (u = a(u), u.forEach(g => {
            g.classList.remove(f.hiddenClass), g.classList.remove(f.modifierClass + f.type), g.classList.remove(e.isHorizontal() ? f.horizontalClass : f.verticalClass), f.clickable && g.removeEventListener("click", p)
        })), e.pagination.bullets && e.pagination.bullets.forEach(g => g.classList.remove(...f.bulletActiveClass.split(" ")))
    }
    n("changeDirection", () => {
        if (!e.pagination || !e.pagination.el) return;
        const f = e.params.pagination;
        let {
            el: u
        } = e.pagination;
        u = a(u), u.forEach(g => {
            g.classList.remove(f.horizontalClass, f.verticalClass), g.classList.add(e.isHorizontal() ? f.horizontalClass : f.verticalClass)
        })
    }), n("init", () => {
        e.params.pagination.enabled === !1 ? y() : (w(), m(), v())
    }), n("activeIndexChange", () => {
        typeof e.snapIndex > "u" && v()
    }), n("snapIndexChange", () => {
        v()
    }), n("snapGridLengthChange", () => {
        m(), v()
    }), n("destroy", () => {
        S()
    }), n("enable disable", () => {
        let {
            el: f
        } = e.pagination;
        f && (f = a(f), f.forEach(u => u.classList[e.enabled ? "remove" : "add"](e.params.pagination.lockClass)))
    }), n("lock unlock", () => {
        v()
    }), n("click", (f, u) => {
        const g = u.target,
            b = a(e.pagination.el);
        if (e.params.pagination.el && e.params.pagination.hideOnClick && b && b.length > 0 && !g.classList.contains(e.params.pagination.bulletClass)) {
            if (e.navigation && (e.navigation.nextEl && g === e.navigation.nextEl || e.navigation.prevEl && g === e.navigation.prevEl)) return;
            const M = b[0].classList.contains(e.params.pagination.hiddenClass);
            r(M === !0 ? "paginationShow" : "paginationHide"), b.forEach(E => E.classList.toggle(e.params.pagination.hiddenClass))
        }
    });
    const x = () => {
            e.el.classList.remove(e.params.pagination.paginationDisabledClass);
            let {
                el: f
            } = e.pagination;
            f && (f = a(f), f.forEach(u => u.classList.remove(e.params.pagination.paginationDisabledClass))), w(), m(), v()
        },
        y = () => {
            e.el.classList.add(e.params.pagination.paginationDisabledClass);
            let {
                el: f
            } = e.pagination;
            f && (f = a(f), f.forEach(u => u.classList.add(e.params.pagination.paginationDisabledClass))), S()
        };
    Object.assign(e.pagination, {
        enable: x,
        disable: y,
        render: m,
        update: v,
        init: w,
        destroy: S
    })
}

function gi(t) {
    let {
        swiper: e,
        extendParams: i,
        on: n,
        emit: r,
        params: s
    } = t;
    e.autoplay = {
        running: !1,
        paused: !1,
        timeLeft: 0
    }, i({
        autoplay: {
            enabled: !1,
            delay: 3e3,
            waitForTransition: !0,
            disableOnInteraction: !0,
            stopOnLastSlide: !1,
            reverseDirection: !1,
            pauseOnMouseEnter: !1
        }
    });
    let o, l, a = s && s.autoplay ? s.autoplay.delay : 3e3,
        c = s && s.autoplay ? s.autoplay.delay : 3e3,
        d, p = new Date().getTime,
        v, m, w, S, x, y;

    function f(z) {
        !e || e.destroyed || !e.wrapperEl || z.target === e.wrapperEl && (e.wrapperEl.removeEventListener("transitionend", f), h())
    }
    const u = () => {
            if (e.destroyed || !e.autoplay.running) return;
            e.autoplay.paused ? v = !0 : v && (c = d, v = !1);
            const z = e.autoplay.paused ? d : p + c - new Date().getTime();
            e.autoplay.timeLeft = z, r("autoplayTimeLeft", z, z / a), l = requestAnimationFrame(() => {
                u()
            })
        },
        g = () => {
            let z;
            return e.virtual && e.params.virtual.enabled ? z = e.slides.filter(A => A.classList.contains("swiper-slide-active"))[0] : z = e.slides[e.activeIndex], z ? parseInt(z.getAttribute("data-swiper-autoplay"), 10) : void 0
        },
        b = z => {
            if (e.destroyed || !e.autoplay.running) return;
            cancelAnimationFrame(l), u();
            let N = typeof z > "u" ? e.params.autoplay.delay : z;
            a = e.params.autoplay.delay, c = e.params.autoplay.delay;
            const A = g();
            !Number.isNaN(A) && A > 0 && typeof z > "u" && (N = A, a = A, c = A), d = N;
            const k = e.params.speed,
                Y = () => {
                    !e || e.destroyed || (e.params.autoplay.reverseDirection ? !e.isBeginning || e.params.loop || e.params.rewind ? (e.slidePrev(k, !0, !0), r("autoplay")) : e.params.autoplay.stopOnLastSlide || (e.slideTo(e.slides.length - 1, k, !0, !0), r("autoplay")) : !e.isEnd || e.params.loop || e.params.rewind ? (e.slideNext(k, !0, !0), r("autoplay")) : e.params.autoplay.stopOnLastSlide || (e.slideTo(0, k, !0, !0), r("autoplay")), e.params.cssMode && (p = new Date().getTime(), requestAnimationFrame(() => {
                        b()
                    })))
                };
            return N > 0 ? (clearTimeout(o), o = setTimeout(() => {
                Y()
            }, N)) : requestAnimationFrame(() => {
                Y()
            }), N
        },
        M = () => {
            e.autoplay.running = !0, b(), r("autoplayStart")
        },
        E = () => {
            e.autoplay.running = !1, clearTimeout(o), cancelAnimationFrame(l), r("autoplayStop")
        },
        C = (z, N) => {
            if (e.destroyed || !e.autoplay.running) return;
            clearTimeout(o), z || (y = !0);
            const A = () => {
                r("autoplayPause"), e.params.autoplay.waitForTransition ? e.wrapperEl.addEventListener("transitionend", f) : h()
            };
            if (e.autoplay.paused = !0, N) {
                x && (d = e.params.autoplay.delay), x = !1, A();
                return
            }
            d = (d || e.params.autoplay.delay) - (new Date().getTime() - p), !(e.isEnd && d < 0 && !e.params.loop) && (d < 0 && (d = 0), A())
        },
        h = () => {
            e.isEnd && d < 0 && !e.params.loop || e.destroyed || !e.autoplay.running || (p = new Date().getTime(), y ? (y = !1, b(d)) : b(), e.autoplay.paused = !1, r("autoplayResume"))
        },
        O = () => {
            if (e.destroyed || !e.autoplay.running) return;
            const z = R();
            z.visibilityState === "hidden" && (y = !0, C(!0)), z.visibilityState === "visible" && h()
        },
        T = z => {
            z.pointerType === "mouse" && (y = !0, C(!0))
        },
        P = z => {
            z.pointerType === "mouse" && e.autoplay.paused && h()
        },
        L = () => {
            e.params.autoplay.pauseOnMouseEnter && (e.el.addEventListener("pointerenter", T), e.el.addEventListener("pointerleave", P))
        },
        I = () => {
            e.el.removeEventListener("pointerenter", T), e.el.removeEventListener("pointerleave", P)
        },
        B = () => {
            R().addEventListener("visibilitychange", O)
        },
        $ = () => {
            R().removeEventListener("visibilitychange", O)
        };
    n("init", () => {
        e.params.autoplay.enabled && (L(), B(), p = new Date().getTime(), M())
    }), n("destroy", () => {
        I(), $(), e.autoplay.running && E()
    }), n("beforeTransitionStart", (z, N, A) => {
        e.destroyed || !e.autoplay.running || (A || !e.params.autoplay.disableOnInteraction ? C(!0, !0) : E())
    }), n("sliderFirstMove", () => {
        if (!(e.destroyed || !e.autoplay.running)) {
            if (e.params.autoplay.disableOnInteraction) {
                E();
                return
            }
            m = !0, w = !1, y = !1, S = setTimeout(() => {
                y = !0, w = !0, C(!0)
            }, 200)
        }
    }), n("touchEnd", () => {
        if (!(e.destroyed || !e.autoplay.running || !m)) {
            if (clearTimeout(S), clearTimeout(o), e.params.autoplay.disableOnInteraction) {
                w = !1, m = !1;
                return
            }
            w && e.params.cssMode && h(), w = !1, m = !1
        }
    }), n("slideChange", () => {
        e.destroyed || !e.autoplay.running || (x = !0)
    }), Object.assign(e.autoplay, {
        start: M,
        stop: E,
        pause: C,
        resume: h
    })
}

function vi(t) {
    let {
        swiper: e,
        extendParams: i,
        emit: n,
        once: r
    } = t;
    i({
        freeMode: {
            enabled: !1,
            momentum: !0,
            momentumRatio: 1,
            momentumBounce: !0,
            momentumBounceRatio: 1,
            momentumVelocityRatio: 1,
            sticky: !1,
            minimumVelocity: .02
        }
    });

    function s() {
        if (e.params.cssMode) return;
        const a = e.getTranslate();
        e.setTranslate(a), e.setTransition(0), e.touchEventsData.velocities.length = 0, e.freeMode.onTouchEnd({
            currentPos: e.rtl ? e.translate : -e.translate
        })
    }

    function o() {
        if (e.params.cssMode) return;
        const {
            touchEventsData: a,
            touches: c
        } = e;
        a.velocities.length === 0 && a.velocities.push({
            position: c[e.isHorizontal() ? "startX" : "startY"],
            time: a.touchStartTime
        }), a.velocities.push({
            position: c[e.isHorizontal() ? "currentX" : "currentY"],
            time: q()
        })
    }

    function l(a) {
        let {
            currentPos: c
        } = a;
        if (e.params.cssMode) return;
        const {
            params: d,
            wrapperEl: p,
            rtlTranslate: v,
            snapGrid: m,
            touchEventsData: w
        } = e, x = q() - w.touchStartTime;
        if (c < -e.minTranslate()) {
            e.slideTo(e.activeIndex);
            return
        }
        if (c > -e.maxTranslate()) {
            e.slides.length < m.length ? e.slideTo(m.length - 1) : e.slideTo(e.slides.length - 1);
            return
        }
        if (d.freeMode.momentum) {
            if (w.velocities.length > 1) {
                const C = w.velocities.pop(),
                    h = w.velocities.pop(),
                    O = C.position - h.position,
                    T = C.time - h.time;
                e.velocity = O / T, e.velocity /= 2, Math.abs(e.velocity) < d.freeMode.minimumVelocity && (e.velocity = 0), (T > 150 || q() - C.time > 300) && (e.velocity = 0)
            } else e.velocity = 0;
            e.velocity *= d.freeMode.momentumVelocityRatio, w.velocities.length = 0;
            let y = 1e3 * d.freeMode.momentumRatio;
            const f = e.velocity * y;
            let u = e.translate + f;
            v && (u = -u);
            let g = !1,
                b;
            const M = Math.abs(e.velocity) * 20 * d.freeMode.momentumBounceRatio;
            let E;
            if (u < e.maxTranslate()) d.freeMode.momentumBounce ? (u + e.maxTranslate() < -M && (u = e.maxTranslate() - M), b = e.maxTranslate(), g = !0, w.allowMomentumBounce = !0) : u = e.maxTranslate(), d.loop && d.centeredSlides && (E = !0);
            else if (u > e.minTranslate()) d.freeMode.momentumBounce ? (u - e.minTranslate() > M && (u = e.minTranslate() + M), b = e.minTranslate(), g = !0, w.allowMomentumBounce = !0) : u = e.minTranslate(), d.loop && d.centeredSlides && (E = !0);
            else if (d.freeMode.sticky) {
                let C;
                for (let h = 0; h < m.length; h += 1)
                    if (m[h] > -u) {
                        C = h;
                        break
                    }
                Math.abs(m[C] - u) < Math.abs(m[C - 1] - u) || e.swipeDirection === "next" ? u = m[C] : u = m[C - 1], u = -u
            }
            if (E && r("transitionEnd", () => {
                    e.loopFix()
                }), e.velocity !== 0) {
                if (v ? y = Math.abs((-u - e.translate) / e.velocity) : y = Math.abs((u - e.translate) / e.velocity), d.freeMode.sticky) {
                    const C = Math.abs((v ? -u : u) - e.translate),
                        h = e.slidesSizesGrid[e.activeIndex];
                    C < h ? y = d.speed : C < 2 * h ? y = d.speed * 1.5 : y = d.speed * 2.5
                }
            } else if (d.freeMode.sticky) {
                e.slideToClosest();
                return
            }
            d.freeMode.momentumBounce && g ? (e.updateProgress(b), e.setTransition(y), e.setTranslate(u), e.transitionStart(!0, e.swipeDirection), e.animating = !0, te(p, () => {
                !e || e.destroyed || !w.allowMomentumBounce || (n("momentumBounce"), e.setTransition(d.speed), setTimeout(() => {
                    e.setTranslate(b), te(p, () => {
                        !e || e.destroyed || e.transitionEnd()
                    })
                }, 0))
            })) : e.velocity ? (n("_freeModeNoMomentumRelease"), e.updateProgress(u), e.setTransition(y), e.setTranslate(u), e.transitionStart(!0, e.swipeDirection), e.animating || (e.animating = !0, te(p, () => {
                !e || e.destroyed || e.transitionEnd()
            }))) : e.updateProgress(u), e.updateActiveIndex(), e.updateSlidesClasses()
        } else if (d.freeMode.sticky) {
            e.slideToClosest();
            return
        } else d.freeMode && n("_freeModeNoMomentumRelease");
        (!d.freeMode.momentum || x >= d.longSwipesMs) && (e.updateProgress(), e.updateActiveIndex(), e.updateSlidesClasses())
    }
    Object.assign(e, {
        freeMode: {
            onTouchStart: s,
            onTouchMove: o,
            onTouchEnd: l
        }
    })
}
export {
    gi as A, hi as P, mi as S, pi as a, vi as f
};