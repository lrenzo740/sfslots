import {
    _ as R,
    a3 as U,
    g as D,
    __tla as E
} from "./index.0a674315.js";
import {
    an as O,
    r as S,
    aa as T,
    ab as z,
    o as r,
    c as n,
    a as e,
    u as s,
    O as V,
    L as u,
    V as A,
    W as c,
    U as G,
    S as B,
    P as Q,
    a3 as W,
    Q as j,
    R as q
} from "./@vue.16908cbf.js";
import {
    b as F
} from "./vue-router.d17f0860.js";
import {
    u as H
} from "./vuex.7fead168.js";
import {
    u as J
} from "./vue-i18n.d9454f26.js";
import "./axios.4a70c6fc.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@intlify.7347860c.js";
let M, N = Promise.all([(() => {
    try {
        return E
    } catch {}
})()]).then(async () => {
    let p, g, d, v, h, _, f, k, y, C;
    p = {
        class: "green-headerMenu",
        ref: "headerMenu"
    }, g = {
        class: "green-headerMenu-left"
    }, d = ["src"], v = {
        class: "green-headerMenu-right"
    }, h = {
        alt: ""
    }, _ = {
        alt: ""
    }, f = {
        alt: ""
    }, k = {
        class: "languageList"
    }, y = ["onClick"], C = {
        class: "text"
    }, M = {
        __name: "green",
        setup(K) {
            const b = O(() => R(() =>
                    import ("./index.0a674315.js").then(async a => (await a.__tla, a)).then(a => a.a6), ["js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css"])),
                {
                    locale: $,
                    t: X
                } = J(),
                x = F(),
                o = H(),
                i = S(!1),
                L = a => new URL("/img/colors/" + D() + "/" + a + ".png",
                    import.meta.url).href,
                w = a => {
                    o.state.language = a, localStorage.setItem("language", a), globalVBus.$emit("refreshGameTypeVendorList"), o.dispatch("getMetas"), $.value = a, i.value = !1
                };
            return (a, l) => {
                const I = T("svg-icon"),
                    m = z("lazy");
                return r(), n("div", p, [e("div", g, [e("div", {
                    class: "logoBox",
                    onClick: l[0] || (l[0] = t => s(x).push("/index"))
                }, [s(o).state.decorators.logo ? (r(), n("img", {
                    key: 0,
                    src: s(o).state.decorators.logo,
                    alt: "logo",
                    class: "logo"
                }, null, 8, d)) : V("", !0)])]), e("div", v, [e("div", {
                    class: "languageBox",
                    onClick: l[1] || (l[1] = t => i.value = !0)
                }, [u(e("img", h, null, 512), [
                    [m, s(U)()]
                ])]), e("div", {
                    class: "searchBox",
                    onClick: l[2] || (l[2] = A(t => s(x).push("/game-search"), ["stop"]))
                }, [u(e("img", _, null, 512), [
                    [m, L("search")]
                ]), e("span", null, c(a.$t("search_page.title")), 1)]), e("div", {
                    class: "musicBox",
                    onClick: l[3] || (l[3] = t => s(o).state.showMusicList = !0)
                }, [u(e("img", f, null, 512), [
                    [m, L("music")]
                ]), e("span", null, c(a.$t("music.music")), 1)])]), G(s(b), {
                    modelValue: i.value,
                    "onUpdate:modelValue": l[4] || (l[4] = t => i.value = t),
                    class: "languageListDialog",
                    value: i.value,
                    onInput: l[5] || (l[5] = t => i.value = t),
                    title: a.$t("mine.language")
                }, {
                    footer: B(() => []),
                    default: B(() => [e("div", k, [(r(!0), n(Q, null, W(s(o).state.metaConfig.language, (t, P) => (r(), n("div", {
                        class: "item",
                        key: P,
                        onClick: Y => w(t.value)
                    }, [e("span", C, c(t.label), 1), e("span", {
                        class: j(["status", {
                            active: s(o).state.language === t.value
                        }])
                    }, [s(o).state.language === t.value ? (r(), q(I, {
                        key: 0,
                        iconClass: "ticked"
                    })) : V("", !0)], 2)], 8, y))), 128))])]),
                    _: 1
                }, 8, ["modelValue", "value", "title"])], 512)
            }
        }
    }
});
export {
    N as __tla, M as
    default
};