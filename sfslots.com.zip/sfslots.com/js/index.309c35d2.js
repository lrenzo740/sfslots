import {
    _ as D,
    a as y,
    $ as g,
    __tla as x
} from "./index.0a674315.js";
import {
    u as C
} from "./vuex.7fead168.js";
import {
    an as b,
    e as k,
    aa as E,
    o as S,
    R as V,
    S as r,
    a,
    u as n,
    W as c,
    U as B
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./vue-router.d17f0860.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./vue-i18n.d9454f26.js";
import "./@intlify.7347860c.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
let u, P = Promise.all([(() => {
    try {
        return x
    } catch {}
})()]).then(async () => {
    let l, p, s, i, m;
    l = {
        class: "downloadBox"
    }, p = {
        class: "detail"
    }, s = ["src"], i = {
        class: "text"
    }, m = {
        class: "btns"
    }, u = {
        __name: "index",
        props: ["value"],
        emits: ["update:value"],
        setup(_, {
            emit: v
        }) {
            const f = _,
                h = b(() => D(() =>
                    import ("./index.0a674315.js").then(async t => (await t.__tla, t)).then(t => t.a6), ["js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css"])),
                o = C(),
                d = k({
                    get() {
                        return f.value
                    },
                    set(t) {
                        v("update:value", t)
                    }
                }),
                w = () => {
                    if (!o.state.appDownloadInfo) return;
                    const t = document.createElement("a");
                    t.href = o.state.appDownloadInfo.downloadUrl, t.download = o.state.appDownloadInfo.name, document.body.appendChild(t), t.click(), document.body.removeChild(t), setTimeout(() => {
                        let e = y();
                        e.channelId && g.post("/trade/channel/report", {
                            type: 11,
                            channelId: e.channelId
                        })
                    }, 500)
                };
            return (t, e) => {
                const I = E("svg-icon");
                return S(), V(n(h), {
                    class: "app-download-dialog",
                    value: d.value,
                    onInput: e[0] || (e[0] = R => d.value = !1),
                    modalClose: !1,
                    title: " "
                }, {
                    title: r(() => []),
                    footer: r(() => []),
                    default: r(() => [a("div", l, [a("div", p, [a("img", {
                        src: n(o).state.appDownloadInfo.icon,
                        alt: ""
                    }, null, 8, s), a("div", i, c(n(o).state.appDownloadInfo.desc), 1)]), a("div", m, [a("div", {
                        class: "btn",
                        onClick: w
                    }, [B(I, {
                        iconClass: "android"
                    }), a("span", null, "Vers\xE3o normal (" + c(n(o).state.appDownloadInfo.packageSize_) + ")", 1)])])])]),
                    _: 1
                }, 8, ["value"])
            }
        }
    }
});
export {
    P as __tla, u as
    default
};