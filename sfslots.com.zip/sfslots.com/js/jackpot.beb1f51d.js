import {
    W as j,
    r as Y,
    __tla as H
} from "./index.0a674315.js";
import {
    b as O,
    u as Q
} from "./vue-router.d17f0860.js";
import {
    r as _,
    e as S,
    w as R,
    n as X,
    j as W,
    l as B,
    k as F,
    o as k,
    c as b,
    a as p,
    P as G,
    a3 as N,
    X as J,
    Q as K
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./vuex.7fead168.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./vue-i18n.d9454f26.js";
import "./@intlify.7347860c.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
let q, V = Promise.all([(() => {
    try {
        return H
    } catch {}
})()]).then(async () => {
    const T = "/png/jackpot1.1285e691.png",
        $ = "/png/jackpot2.302f4331.png";
    let y, h, f, v, P, I, u;
    y = {
        class: "count-box"
    }, h = {
        class: "notranslate count-to"
    }, f = ["data-text"], v = p("i", {
        style: {
            display: "inline-block",
            position: "relative",
            width: "0.795rem",
            height: "1.245rem",
            "background-position": "-15.735rem -18.495rem",
            "background-size": "21.93rem 21.285rem"
        }
    }, null, -1), P = [v], I = "2024-01-01T00:00:00Z", u = 5e3, q = {
        __name: "jackpot",
        props: ["itemInfo"],
        setup(A) {
            const n = A,
                D = O(),
                M = Q(),
                m = _(),
                l = _(null),
                E = ["-9.96", "-10.785", "-11.61", "-12.435", "-13.26", "-14.085", "-14.91", "-15.735", "-16.56", "-17.385"],
                C = S(() => {
                    let t = [];
                    return m.value && (t = m.value.split("")), t
                }),
                U = S(() => new URL(Object.assign({
                    "../../../assets/img/home/jackpot1.png": T,
                    "../../../assets/img/home/jackpot2.png": $
                })[`../../../assets/img/home/jackpot${n.itemInfo.style}.png`], self.location).href);
            R(m, (t, e) => {
                l.value && X(() => {
                    const o = document.querySelectorAll(`.jackpot-box-${n.itemInfo.position} .count-to li`);
                    if (o.length && !(!e || !e.length))
                        if (w(), t.length >= e.length)
                            if (t.length > e.length) {
                                let a = t.length - e.length;
                                for (var i = 0; i < a; i++) e = "7" + e;
                                e && e.length && e.split("").forEach((s, r) => {
                                    let c = o[r].querySelector("i");
                                    (t[r] === "," || t[r] === ".") && (c.style.width, c.style.backgroundPositionX = "-21.06rem", t[r] === "," && (c.style.backgroundPositionY = "0"), t[r] === "." && (c.style.backgroundPositionY = "-1.275rem")), g(s, t[r], c)
                                })
                            } else e && e.length && e.split("").forEach((a, s) => {
                                if (a !== t[s]) {
                                    let r = o[s].querySelector("i");
                                    (t[s] === "," || t[s] === ".") && (r.style.width, r.style.backgroundPositionX = "-21.06rem", t[s] === "," && (r.style.backgroundPositionY = "0"), t[s] === "." && (r.style.backgroundPositionY = "-1.275rem")), g(a, t[s], r)
                                }
                            });
                    else t.split("").forEach((a, s) => {
                        let r = o[s].querySelector("i");
                        (a === "," || a === ".") && (r.style.width, r.style.backgroundPositionX = "-21.06rem", a === "," && (r.style.backgroundPositionY = "0"), a === "." && (r.style.backgroundPositionY = "-1.275rem")), g(1, a, r)
                    })
                })
            });
            const w = () => {
                    const t = document.querySelectorAll(`.jackpot-box-${n.itemInfo.position} .count-to li`);
                    for (let e = 0; e < t.length; e++) {
                        let o = t[e].dataset.text,
                            i = t[e].querySelector("i");
                        i.style.backgroundPosition = L(o), (o === "," || o === ".") && (i.style.width = ".54rem")
                    }
                },
                L = t => {
                    let e = "";
                    switch (t) {
                        case ".":
                            e = "-21.06rem -1.275rem";
                            break;
                        case ",":
                            e = "-21.06rem -0";
                            break;
                        case "0":
                            e = "-9.96rem -18.495rem";
                            break;
                        case "1":
                            e = "-10.785rem -18.495rem";
                            break;
                        case "2":
                            e = "-11.61rem  -18.495rem";
                            break;
                        case "3":
                            e = "-12.435rem -18.495rem";
                            break;
                        case "4":
                            e = "-13.26rem -18.495rem";
                            break;
                        case "5":
                            e = "-14.085rem -18.495rem";
                            break;
                        case "6":
                            e = "-14.91rem -18.495rem";
                            break;
                        case "7":
                            e = "-15.735rem -18.495rem";
                            break;
                        case "8":
                            e = "-16.56rem -18.495rem";
                            break;
                        case "9":
                            e = "-17.385rem -18.495rem";
                            break
                    }
                    return e
                },
                g = (t, e, o) => {
                    let i = 0,
                        a = setInterval(() => {
                            if ((t === "," || t === ".") && (e === "," || e === ".")) {
                                o.style.width = ".54rem", o.style.backgroundPositionX = "-21.06rem", e === "," && (o.style.backgroundPositionY = "0"), e === "." && (o.style.backgroundPositionY = "-1.275rem"), clearInterval(a);
                                return
                            }
                            if (t !== "," && t !== "." && e !== "," && e !== "." && (o.style.width = ".795rem", o.style.backgroundPositionY = "-18.495rem"), t !== "," && t !== "." && (e === "," || e === ".")) {
                                e === "," ? o.style.backgroundPositionY = "0" : e === "." && (o.style.backgroundPositionY = "-1.275rem"), o.style.width = ".54rem", o.style.backgroundPositionX = "-21.06rem", clearInterval(a);
                                return
                            }
                            t === 0 ? t = 1 : t++, o.style.width = ".795rem", o.style.backgroundPositionX = E[t] + "rem", t >= 9 && (i++, t == e && i === 6 ? clearInterval(a) : t = -1), t == e && i === 6 && clearInterval(a)
                        }, 20)
                };
            W(() => {
                d(), typeof document.hidden < "u" && document.addEventListener("visibilitychange", function() {
                    document.visibilityState === "visible" ? M.name === "index" && d() : l.value && clearInterval(l.value)
                })
            });
            const x = t => {
                const e = new Date("2024-01-01T00:00:00Z").getTime(),
                    o = Math.max(new Date().getUTCMinutes(), 1) * Math.max(new Date().getUTCHours(), 1) * Z()(),
                    i = Math.floor(Date.now() / t) * t;
                let a = Math.floor((i - e) / t) * o;
                return n.itemInfo.minAmount + a % (n.itemInfo.maxAmount - n.itemInfo.minAmount + 1)
            };

            function Z() {
                let t = parseInt(new Date(I).getTime()),
                    e = 987654321;
                const o = 4294967295;
                return function() {
                    e = 36969 * (e & 65535) + (e >> 16) & o, t = 18e3 * (t & 65535) + (t >> 16) & o;
                    let i = (e << 16) + (t & 65535) >>> 0;
                    return i /= 2147483648, i
                }
            }
            B(() => {
                l.value && clearInterval(l.value)
            }), F(() => {
                d()
            });
            const d = () => {
                    m.value = j(Y(x(u))), X(() => {
                        w()
                    }), l.value = setInterval(() => {
                        m.value = j(Y(x(u)))
                    }, u)
                },
                z = () => {
                    let t = n.itemInfo.url;
                    D.push(`/sub-game?typeId=3&vendor=${t}`)
                };
            return (t, e) => (k(), b("div", {
                class: K(["jackpot-box", `jackpot-box-${n.itemInfo.position}`]),
                onClick: z
            }, [p("div", {
                class: "jackpot-box-item",
                style: J(`background-image:url(${U.value})`)
            }, [p("div", y, [p("ul", h, [(k(!0), b(G, null, N(C.value, o => (k(), b("li", {
                "data-text": o
            }, P, 8, f))), 256))])])], 4)], 2))
        }
    }
});
export {
    V as __tla, q as
    default
};