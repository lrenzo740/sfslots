import {
    r as i,
    w as C,
    j as O,
    aa as T,
    ab as w,
    o as g,
    c as I,
    a as u,
    L as z,
    V as _,
    u as B,
    W as N,
    O as b,
    U as S,
    d as U
} from "./@vue.16908cbf.js";
import {
    $ as V,
    o as $,
    __tla as D
} from "./index.0a674315.js";
import {
    u as E
} from "./vuex.7fead168.js";
import "./axios.4a70c6fc.js";
import "./vue-router.d17f0860.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./vue-i18n.d9454f26.js";
import "./@intlify.7347860c.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
let k, J = Promise.all([(() => {
    try {
        return D
    } catch {}
})()]).then(async () => {
    let m, c, v, d, h;
    m = {
        key: 0,
        class: "fixed-ad-component"
    }, c = {
        class: "adBox"
    }, v = {
        key: 0,
        class: "balanceTime"
    }, d = {
        class: "close"
    }, h = U({
        name: "true"
    }), k = Object.assign(h, {
        setup(L) {
            const M = E(),
                l = i(),
                n = i(!1),
                f = i(!1),
                y = i(),
                o = i(),
                p = i(null);
            C(M.state, a => {
                if (a.endMs) {
                    if (y.value === a.endMs) return;
                    y.value = a.endMs, o.value = a.endMs, p.value && clearInterval(p.value), p.value = setInterval(() => {
                        o.value >= 1e3 ? o.value = o.value - 1e3 : clearInterval(p.value)
                    }, 1e3)
                }
            }), O(() => {
                j()
            });
            const j = () => {
                    V.get("/user/site/banners", {
                        type: 5
                    }).then(a => {
                        if (a.code === 0) {
                            let {
                                list: e
                            } = a.data;
                            if (!e.length) return;
                            if (l.value = e[0], l.value && (n.value = !0), l.value.redirect == 2) try {
                                JSON.parse(l.value.redirectUrl).promotionType == 6 && (f.value = !0)
                            } catch {}
                        }
                    })
                },
                x = a => {
                    const e = [];
                    let t = parseInt(a / 36e5 + "", 10);
                    t ? (a -= t * 60 * 60 * 1e3, t < 10 && (t = "0" + t), e.push(t + ":")) : e.push("00:");
                    let s = parseInt(a / (60 * 1e3) + "", 10);
                    s ? (a -= s * 60 * 1e3, s < 10 && (s = "0" + s), e.push(s + ":")) : e.push("00:");
                    let r = parseInt(a / 1e3 + "", 10);
                    return r || +r == 0 ? (r < 10 && (r = "0" + r), e.push(r)) : e.push("00"), e.join("")
                };
            return (a, e) => {
                const t = T("svg-icon"),
                    s = w("lazy");
                return n.value ? (g(), I("div", m, [u("div", c, [z(u("img", {
                    class: "img",
                    onClick: e[0] || (e[0] = _(r => B($)(l.value), ["stop"]))
                }, null, 512), [
                    [s, l.value.image]
                ]), f.value && o.value ? (g(), I("span", v, N(x(o.value)), 1)) : b("", !0), u("div", {
                    class: "closeIcon",
                    onClick: e[1] || (e[1] = _(r => n.value = !1, ["stop"]))
                }, [u("div", d, [S(t, {
                    iconClass: "close"
                })])])])])) : b("", !0)
            }
        }
    })
});
export {
    J as __tla, k as
    default
};