const n = "/png/maintenance.44d56928.png";
export {
    n as _
};