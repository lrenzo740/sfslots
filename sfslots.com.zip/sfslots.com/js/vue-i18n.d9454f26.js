import {
    m as $,
    a as P,
    i as X,
    b as v,
    c as D,
    d as k,
    e as Ta,
    D as pe,
    f as R,
    g as T,
    h as z,
    j as U,
    r as Ea,
    k as Ia,
    l as Oa,
    n as ra,
    s as Ra,
    o as ha,
    p as We,
    u as K,
    q as Re,
    N as Na,
    t as ya,
    v as Ma,
    w as Pa,
    x as sa,
    C as Da,
    y as pa,
    z as He,
    A as Ve,
    B as Ue,
    E as Wa,
    F as Ca,
    G as $e,
    H as je,
    M as xe,
    I as Ge,
    J as Ye,
    K as Be,
    L as Xe,
    O as ze
} from "./@intlify.7347860c.js";
import {
    h as ca,
    g as Q,
    ak as wa,
    i as Sa,
    j as Aa,
    b as Ha,
    D as Va,
    r as W,
    e as C,
    F as Ua,
    w as he,
    P as $a,
    m as ja,
    U as xa,
    $ as Ga
} from "./@vue.16908cbf.js";
/*!
 * vue-i18n v9.2.2
 * (c) 2022 kazuya kawaguchi
 * Released under the MIT License.
 */
const Ya = "9.2.2";

function Ba() {
    typeof __INTLIFY_PROD_DEVTOOLS__ != "boolean" && (ra().__INTLIFY_PROD_DEVTOOLS__ = !1)
}
let ua = Da.__EXTEND_POINT__;
const M = () => ++ua,
    E = {
        UNEXPECTED_RETURN_TYPE: ua,
        INVALID_ARGUMENT: M(),
        MUST_BE_CALL_SETUP_TOP: M(),
        NOT_INSLALLED: M(),
        NOT_AVAILABLE_IN_LEGACY_MODE: M(),
        REQUIRED_VALUE: M(),
        INVALID_VALUE: M(),
        CANNOT_SETUP_VUE_DEVTOOLS_PLUGIN: M(),
        NOT_INSLALLED_WITH_PROVIDE: M(),
        UNEXPECTED_ERROR: M(),
        NOT_COMPATIBLE_LEGACY_VUE_I18N: M(),
        BRIDGE_SUPPORT_VUE_2_ONLY: M(),
        MUST_DEFINE_I18N_OPTION_IN_ALLOW_COMPOSITION: M(),
        NOT_AVAILABLE_COMPOSITION_IN_LEGACY: M(),
        __EXTEND_POINT__: M()
    };

function I(e, ...r) {
    return ha(e, null, void 0)
}
const Ne = $("__transrateVNode"),
    ye = $("__datetimeParts"),
    Me = $("__numberParts"),
    ia = $("__setPluralRules");
$("__intlifyMeta");
const oa = $("__injectWithOption");

function Pe(e) {
    if (!D(e)) return e;
    for (const r in e)
        if (We(e, r))
            if (!r.includes(".")) D(e[r]) && Pe(e[r]);
            else {
                const t = r.split("."),
                    n = t.length - 1;
                let l = e;
                for (let a = 0; a < n; a++) t[a] in l || (l[t[a]] = {}), l = l[t[a]];
                l[t[n]] = e[r], delete e[r], D(l[t[n]]) && Pe(l[t[n]])
            }
    return e
}

function le(e, r) {
    const {
        messages: t,
        __i18n: n,
        messageResolver: l,
        flatJson: a
    } = r, c = T(t) ? t : R(n) ? {} : {
        [e]: {}
    };
    if (R(n) && n.forEach(o => {
            if ("locale" in o && "resource" in o) {
                const {
                    locale: m,
                    resource: f
                } = o;
                m ? (c[m] = c[m] || {}, q(f, c[m])) : q(f, c)
            } else v(o) && q(JSON.parse(o), c)
        }), l == null && a)
        for (const o in c) We(c, o) && Pe(c[o]);
    return c
}
const te = e => !D(e) || R(e);

function q(e, r) {
    if (te(e) || te(r)) throw I(E.INVALID_VALUE);
    for (const t in e) We(e, t) && (te(e[t]) || te(r[t]) ? r[t] = e[t] : q(e[t], r[t]))
}

function ma(e) {
    return e.type
}

function fa(e, r, t) {
    let n = D(r.messages) ? r.messages : {};
    "__i18nGlobal" in t && (n = le(e.locale.value, {
        messages: n,
        __i18n: t.__i18nGlobal
    }));
    const l = Object.keys(n);
    l.length && l.forEach(a => {
        e.mergeLocaleMessage(a, n[a])
    }); {
        if (D(r.datetimeFormats)) {
            const a = Object.keys(r.datetimeFormats);
            a.length && a.forEach(c => {
                e.mergeDateTimeFormat(c, r.datetimeFormats[c])
            })
        }
        if (D(r.numberFormats)) {
            const a = Object.keys(r.numberFormats);
            a.length && a.forEach(c => {
                e.mergeNumberFormat(c, r.numberFormats[c])
            })
        }
    }
}

function Je(e) {
    return xa(Ga, null, e, 0)
}
const Ke = "__INTLIFY_META__";
let qe = 0;

function Qe(e) {
    return (r, t, n, l) => e(t, n, Q() || void 0, l)
}
const Xa = () => {
    const e = Q();
    let r = null;
    return e && (r = ma(e)[Ke]) ? {
        [Ke]: r
    } : null
};

function Ce(e = {}, r) {
    const {
        __root: t
    } = e, n = t === void 0;
    let l = k(e.inheritLocale) ? e.inheritLocale : !0;
    const a = W(t && l ? t.locale.value : v(e.locale) ? e.locale : pe),
        c = W(t && l ? t.fallbackLocale.value : v(e.fallbackLocale) || R(e.fallbackLocale) || T(e.fallbackLocale) || e.fallbackLocale === !1 ? e.fallbackLocale : a.value),
        o = W(le(a.value, e)),
        m = W(T(e.datetimeFormats) ? e.datetimeFormats : {
            [a.value]: {}
        }),
        f = W(T(e.numberFormats) ? e.numberFormats : {
            [a.value]: {}
        });
    let g = t ? t.missingWarn : k(e.missingWarn) || z(e.missingWarn) ? e.missingWarn : !0,
        F = t ? t.fallbackWarn : k(e.fallbackWarn) || z(e.fallbackWarn) ? e.fallbackWarn : !0,
        b = t ? t.fallbackRoot : k(e.fallbackRoot) ? e.fallbackRoot : !0,
        d = !!e.fallbackFormat,
        y = U(e.missing) ? e.missing : null,
        h = U(e.missing) ? Qe(e.missing) : null,
        w = U(e.postTranslation) ? e.postTranslation : null,
        j = t ? t.warnHtmlMessage : k(e.warnHtmlMessage) ? e.warnHtmlMessage : !0,
        S = !!e.escapeParameter;
    const x = t ? t.modifiers : T(e.modifiers) ? e.modifiers : {};
    let A = e.pluralRules || t && t.pluralRules,
        _;
    _ = (() => {
        n && ze(null);
        const s = {
            version: Ya,
            locale: a.value,
            fallbackLocale: c.value,
            messages: o.value,
            modifiers: x,
            pluralRules: A,
            missing: h === null ? void 0 : h,
            missingWarn: g,
            fallbackWarn: F,
            fallbackFormat: d,
            unresolving: !0,
            postTranslation: w === null ? void 0 : w,
            warnHtmlMessage: j,
            escapeParameter: S,
            messageResolver: e.messageResolver,
            __meta: {
                framework: "vue"
            }
        };
        s.datetimeFormats = m.value, s.numberFormats = f.value, s.__datetimeFormatters = T(_) ? _.__datetimeFormatters : void 0, s.__numberFormatters = T(_) ? _.__numberFormatters : void 0;
        const u = pa(s);
        return n && ze(u), u
    })(), K(_, a.value, c.value);

    function G() {
        return [a.value, c.value, o.value, m.value, f.value]
    }
    const Y = C({
            get: () => a.value,
            set: s => {
                a.value = s, _.locale = a.value
            }
        }),
        J = C({
            get: () => c.value,
            set: s => {
                c.value = s, _.fallbackLocale = c.value, K(_, a.value, s)
            }
        }),
        re = C(() => o.value),
        se = C(() => m.value),
        ce = C(() => f.value);

    function ue() {
        return U(w) ? w : null
    }

    function ie(s) {
        w = s, _.postTranslation = s
    }

    function oe() {
        return y
    }

    function H(s) {
        s !== null && (h = Qe(s)), y = s, _.missing = h
    }
    const V = (s, u, p, N, Oe, ae) => {
        G();
        let B;
        if (__INTLIFY_PROD_DEVTOOLS__) try {
            Ue(Xa()), n || (_.fallbackContext = t ? Wa() : void 0), B = s(_)
        } finally {
            Ue(null), n || (_.fallbackContext = void 0)
        } else B = s(_);
        if (X(B) && B === Ca) {
            const [ka, ft] = u();
            return t && b ? N(t) : Oe(ka)
        } else {
            if (ae(B)) return B;
            throw I(E.UNEXPECTED_RETURN_TYPE)
        }
    };

    function Z(...s) {
        return V(u => Reflect.apply(je, null, [u, ...s]), () => $e(...s), "translate", u => Reflect.apply(u.t, u, [...s]), u => u, u => v(u))
    }

    function me(...s) {
        const [u, p, N] = s;
        if (N && !D(N)) throw I(E.INVALID_ARGUMENT);
        return Z(u, p, P({
            resolvedMessage: !0
        }, N || {}))
    }

    function fe(...s) {
        return V(u => Reflect.apply(Ye, null, [u, ...s]), () => Ge(...s), "datetime format", u => Reflect.apply(u.d, u, [...s]), () => xe, u => v(u))
    }

    function _e(...s) {
        return V(u => Reflect.apply(Xe, null, [u, ...s]), () => Be(...s), "number format", u => Reflect.apply(u.n, u, [...s]), () => xe, u => v(u))
    }

    function ge(s) {
        return s.map(u => v(u) || X(u) || k(u) ? Je(String(u)) : u)
    }
    const be = {
        normalize: ge,
        interpolate: s => s,
        type: "vnode"
    };

    function ve(...s) {
        return V(u => {
            let p;
            const N = u;
            try {
                N.processor = be, p = Reflect.apply(je, null, [N, ...s])
            } finally {
                N.processor = null
            }
            return p
        }, () => $e(...s), "translate", u => u[Ne](...s), u => [Je(u)], u => R(u))
    }

    function de(...s) {
        return V(u => Reflect.apply(Xe, null, [u, ...s]), () => Be(...s), "number format", u => u[Me](...s), () => [], u => v(u) || R(u))
    }

    function Le(...s) {
        return V(u => Reflect.apply(Ye, null, [u, ...s]), () => Ge(...s), "datetime format", u => u[ye](...s), () => [], u => v(u) || R(u))
    }

    function Fe(s) {
        A = s, _.pluralRules = A
    }

    function ke(s, u) {
        const p = v(u) ? u : a.value,
            N = ee(p);
        return _.messageResolver(N, s) !== null
    }

    function Te(s) {
        let u = null;
        const p = sa(_, c.value, a.value);
        for (let N = 0; N < p.length; N++) {
            const Oe = o.value[p[N]] || {},
                ae = _.messageResolver(Oe, s);
            if (ae != null) {
                u = ae;
                break
            }
        }
        return u
    }

    function Ee(s) {
        const u = Te(s);
        return u ? ? (t ? t.tm(s) || {} : {})
    }

    function ee(s) {
        return o.value[s] || {}
    }

    function Ie(s, u) {
        o.value[s] = u, _.messages = o.value
    }

    function i(s, u) {
        o.value[s] = o.value[s] || {}, q(u, o.value[s]), _.messages = o.value
    }

    function L(s) {
        return m.value[s] || {}
    }

    function ba(s, u) {
        m.value[s] = u, _.datetimeFormats = m.value, He(_, s, u)
    }

    function va(s, u) {
        m.value[s] = P(m.value[s] || {}, u), _.datetimeFormats = m.value, He(_, s, u)
    }

    function da(s) {
        return f.value[s] || {}
    }

    function La(s, u) {
        f.value[s] = u, _.numberFormats = f.value, Ve(_, s, u)
    }

    function Fa(s, u) {
        f.value[s] = P(f.value[s] || {}, u), _.numberFormats = f.value, Ve(_, s, u)
    }
    qe++, t && Re && (he(t.locale, s => {
        l && (a.value = s, _.locale = s, K(_, a.value, c.value))
    }), he(t.fallbackLocale, s => {
        l && (c.value = s, _.fallbackLocale = s, K(_, a.value, c.value))
    }));
    const O = {
        id: qe,
        locale: Y,
        fallbackLocale: J,
        get inheritLocale() {
            return l
        },
        set inheritLocale(s) {
            l = s, s && t && (a.value = t.locale.value, c.value = t.fallbackLocale.value, K(_, a.value, c.value))
        },
        get availableLocales() {
            return Object.keys(o.value).sort()
        },
        messages: re,
        get modifiers() {
            return x
        },
        get pluralRules() {
            return A || {}
        },
        get isGlobal() {
            return n
        },
        get missingWarn() {
            return g
        },
        set missingWarn(s) {
            g = s, _.missingWarn = g
        },
        get fallbackWarn() {
            return F
        },
        set fallbackWarn(s) {
            F = s, _.fallbackWarn = F
        },
        get fallbackRoot() {
            return b
        },
        set fallbackRoot(s) {
            b = s
        },
        get fallbackFormat() {
            return d
        },
        set fallbackFormat(s) {
            d = s, _.fallbackFormat = d
        },
        get warnHtmlMessage() {
            return j
        },
        set warnHtmlMessage(s) {
            j = s, _.warnHtmlMessage = s
        },
        get escapeParameter() {
            return S
        },
        set escapeParameter(s) {
            S = s, _.escapeParameter = s
        },
        t: Z,
        getLocaleMessage: ee,
        setLocaleMessage: Ie,
        mergeLocaleMessage: i,
        getPostTranslationHandler: ue,
        setPostTranslationHandler: ie,
        getMissingHandler: oe,
        setMissingHandler: H,
        [ia]: Fe
    };
    return O.datetimeFormats = se, O.numberFormats = ce, O.rt = me, O.te = ke, O.tm = Ee, O.d = fe, O.n = _e, O.getDateTimeFormat = L, O.setDateTimeFormat = ba, O.mergeDateTimeFormat = va, O.getNumberFormat = da, O.setNumberFormat = La, O.mergeNumberFormat = Fa, O[oa] = e.__injectWithOption, O[Ne] = ve, O[ye] = Le, O[Me] = de, O
}

function za(e) {
    const r = v(e.locale) ? e.locale : pe,
        t = v(e.fallbackLocale) || R(e.fallbackLocale) || T(e.fallbackLocale) || e.fallbackLocale === !1 ? e.fallbackLocale : r,
        n = U(e.missing) ? e.missing : void 0,
        l = k(e.silentTranslationWarn) || z(e.silentTranslationWarn) ? !e.silentTranslationWarn : !0,
        a = k(e.silentFallbackWarn) || z(e.silentFallbackWarn) ? !e.silentFallbackWarn : !0,
        c = k(e.fallbackRoot) ? e.fallbackRoot : !0,
        o = !!e.formatFallbackMessages,
        m = T(e.modifiers) ? e.modifiers : {},
        f = e.pluralizationRules,
        g = U(e.postTranslation) ? e.postTranslation : void 0,
        F = v(e.warnHtmlInMessage) ? e.warnHtmlInMessage !== "off" : !0,
        b = !!e.escapeParameterHtml,
        d = k(e.sync) ? e.sync : !0;
    let y = e.messages;
    if (T(e.sharedMessages)) {
        const _ = e.sharedMessages;
        y = Object.keys(_).reduce((G, Y) => {
            const J = G[Y] || (G[Y] = {});
            return P(J, _[Y]), G
        }, y || {})
    }
    const {
        __i18n: h,
        __root: w,
        __injectWithOption: j
    } = e, S = e.datetimeFormats, x = e.numberFormats, A = e.flatJson;
    return {
        locale: r,
        fallbackLocale: t,
        messages: y,
        flatJson: A,
        datetimeFormats: S,
        numberFormats: x,
        missing: n,
        missingWarn: l,
        fallbackWarn: a,
        fallbackRoot: c,
        fallbackFormat: o,
        modifiers: m,
        pluralRules: f,
        postTranslation: g,
        warnHtmlMessage: F,
        escapeParameter: b,
        messageResolver: e.messageResolver,
        inheritLocale: d,
        __i18n: h,
        __root: w,
        __injectWithOption: j
    }
}

function De(e = {}, r) {
    {
        const t = Ce(za(e)),
            n = {
                id: t.id,
                get locale() {
                    return t.locale.value
                },
                set locale(l) {
                    t.locale.value = l
                },
                get fallbackLocale() {
                    return t.fallbackLocale.value
                },
                set fallbackLocale(l) {
                    t.fallbackLocale.value = l
                },
                get messages() {
                    return t.messages.value
                },
                get datetimeFormats() {
                    return t.datetimeFormats.value
                },
                get numberFormats() {
                    return t.numberFormats.value
                },
                get availableLocales() {
                    return t.availableLocales
                },
                get formatter() {
                    return {
                        interpolate() {
                            return []
                        }
                    }
                },
                set formatter(l) {},
                get missing() {
                    return t.getMissingHandler()
                },
                set missing(l) {
                    t.setMissingHandler(l)
                },
                get silentTranslationWarn() {
                    return k(t.missingWarn) ? !t.missingWarn : t.missingWarn
                },
                set silentTranslationWarn(l) {
                    t.missingWarn = k(l) ? !l : l
                },
                get silentFallbackWarn() {
                    return k(t.fallbackWarn) ? !t.fallbackWarn : t.fallbackWarn
                },
                set silentFallbackWarn(l) {
                    t.fallbackWarn = k(l) ? !l : l
                },
                get modifiers() {
                    return t.modifiers
                },
                get formatFallbackMessages() {
                    return t.fallbackFormat
                },
                set formatFallbackMessages(l) {
                    t.fallbackFormat = l
                },
                get postTranslation() {
                    return t.getPostTranslationHandler()
                },
                set postTranslation(l) {
                    t.setPostTranslationHandler(l)
                },
                get sync() {
                    return t.inheritLocale
                },
                set sync(l) {
                    t.inheritLocale = l
                },
                get warnHtmlInMessage() {
                    return t.warnHtmlMessage ? "warn" : "off"
                },
                set warnHtmlInMessage(l) {
                    t.warnHtmlMessage = l !== "off"
                },
                get escapeParameterHtml() {
                    return t.escapeParameter
                },
                set escapeParameterHtml(l) {
                    t.escapeParameter = l
                },
                get preserveDirectiveContent() {
                    return !0
                },
                set preserveDirectiveContent(l) {},
                get pluralizationRules() {
                    return t.pluralRules || {}
                },
                __composer: t,
                t(...l) {
                    const [a, c, o] = l, m = {};
                    let f = null,
                        g = null;
                    if (!v(a)) throw I(E.INVALID_ARGUMENT);
                    const F = a;
                    return v(c) ? m.locale = c : R(c) ? f = c : T(c) && (g = c), R(o) ? f = o : T(o) && (g = o), Reflect.apply(t.t, t, [F, f || g || {}, m])
                },
                rt(...l) {
                    return Reflect.apply(t.rt, t, [...l])
                },
                tc(...l) {
                    const [a, c, o] = l, m = {
                        plural: 1
                    };
                    let f = null,
                        g = null;
                    if (!v(a)) throw I(E.INVALID_ARGUMENT);
                    const F = a;
                    return v(c) ? m.locale = c : X(c) ? m.plural = c : R(c) ? f = c : T(c) && (g = c), v(o) ? m.locale = o : R(o) ? f = o : T(o) && (g = o), Reflect.apply(t.t, t, [F, f || g || {}, m])
                },
                te(l, a) {
                    return t.te(l, a)
                },
                tm(l) {
                    return t.tm(l)
                },
                getLocaleMessage(l) {
                    return t.getLocaleMessage(l)
                },
                setLocaleMessage(l, a) {
                    t.setLocaleMessage(l, a)
                },
                mergeLocaleMessage(l, a) {
                    t.mergeLocaleMessage(l, a)
                },
                d(...l) {
                    return Reflect.apply(t.d, t, [...l])
                },
                getDateTimeFormat(l) {
                    return t.getDateTimeFormat(l)
                },
                setDateTimeFormat(l, a) {
                    t.setDateTimeFormat(l, a)
                },
                mergeDateTimeFormat(l, a) {
                    t.mergeDateTimeFormat(l, a)
                },
                n(...l) {
                    return Reflect.apply(t.n, t, [...l])
                },
                getNumberFormat(l) {
                    return t.getNumberFormat(l)
                },
                setNumberFormat(l, a) {
                    t.setNumberFormat(l, a)
                },
                mergeNumberFormat(l, a) {
                    t.mergeNumberFormat(l, a)
                },
                getChoiceIndex(l, a) {
                    return -1
                },
                __onComponentInstanceCreated(l) {
                    const {
                        componentInstanceCreatedListener: a
                    } = e;
                    a && a(l, n)
                }
            };
        return n
    }
}
const we = {
    tag: {
        type: [String, Object]
    },
    locale: {
        type: String
    },
    scope: {
        type: String,
        validator: e => e === "parent" || e === "global",
        default: "parent"
    },
    i18n: {
        type: Object
    }
};

function Ja({
    slots: e
}, r) {
    return r.length === 1 && r[0] === "default" ? (e.default ? e.default() : []).reduce((n, l) => n = [...n, ...R(l.children) ? l.children : [l]], []) : r.reduce((t, n) => {
        const l = e[n];
        return l && (t[n] = l()), t
    }, {})
}

function _a(e) {
    return $a
}
const Ze = {
    name: "i18n-t",
    props: P({
        keypath: {
            type: String,
            required: !0
        },
        plural: {
            type: [Number, String],
            validator: e => X(e) || !isNaN(e)
        }
    }, we),
    setup(e, r) {
        const {
            slots: t,
            attrs: n
        } = r, l = e.i18n || Se({
            useScope: e.scope,
            __useComponent: !0
        });
        return () => {
            const a = Object.keys(t).filter(F => F !== "_"),
                c = {};
            e.locale && (c.locale = e.locale), e.plural !== void 0 && (c.plural = v(e.plural) ? +e.plural : e.plural);
            const o = Ja(r, a),
                m = l[Ne](e.keypath, o, c),
                f = P({}, n),
                g = v(e.tag) || D(e.tag) ? e.tag : _a();
            return ca(g, f, m)
        }
    }
};

function Ka(e) {
    return R(e) && !v(e[0])
}

function ga(e, r, t, n) {
    const {
        slots: l,
        attrs: a
    } = r;
    return () => {
        const c = {
            part: !0
        };
        let o = {};
        e.locale && (c.locale = e.locale), v(e.format) ? c.key = e.format : D(e.format) && (v(e.format.key) && (c.key = e.format.key), o = Object.keys(e.format).reduce((b, d) => t.includes(d) ? P({}, b, {
            [d]: e.format[d]
        }) : b, {}));
        const m = n(e.value, c, o);
        let f = [c.key];
        R(m) ? f = m.map((b, d) => {
            const y = l[b.type],
                h = y ? y({
                    [b.type]: b.value,
                    index: d,
                    parts: m
                }) : [b.value];
            return Ka(h) && (h[0].key = `${b.type}-${d}`), h
        }) : v(m) && (f = [m]);
        const g = P({}, a),
            F = v(e.tag) || D(e.tag) ? e.tag : _a();
        return ca(F, g, f)
    }
}
const ea = {
        name: "i18n-n",
        props: P({
            value: {
                type: Number,
                required: !0
            },
            format: {
                type: [String, Object]
            }
        }, we),
        setup(e, r) {
            const t = e.i18n || Se({
                useScope: "parent",
                __useComponent: !0
            });
            return ga(e, r, Na, (...n) => t[Me](...n))
        }
    },
    aa = {
        name: "i18n-d",
        props: P({
            value: {
                type: [Number, Date],
                required: !0
            },
            format: {
                type: [String, Object]
            }
        }, we),
        setup(e, r) {
            const t = e.i18n || Se({
                useScope: "parent",
                __useComponent: !0
            });
            return ga(e, r, ya, (...n) => t[ye](...n))
        }
    };

function qa(e, r) {
    const t = e;
    if (e.mode === "composition") return t.__getInstance(r) || e.global; {
        const n = t.__getInstance(r);
        return n != null ? n.__composer : e.global.__composer
    }
}

function Qa(e) {
    const r = c => {
        const {
            instance: o,
            modifiers: m,
            value: f
        } = c;
        if (!o || !o.$) throw I(E.UNEXPECTED_ERROR);
        const g = qa(e, o.$),
            F = ta(f);
        return [Reflect.apply(g.t, g, [...la(F)]), g]
    };
    return {
        created: (c, o) => {
            const [m, f] = r(o);
            Re && e.global === f && (c.__i18nWatcher = he(f.locale, () => {
                o.instance && o.instance.$forceUpdate()
            })), c.__composer = f, c.textContent = m
        },
        unmounted: c => {
            Re && c.__i18nWatcher && (c.__i18nWatcher(), c.__i18nWatcher = void 0, delete c.__i18nWatcher), c.__composer && (c.__composer = void 0, delete c.__composer)
        },
        beforeUpdate: (c, {
            value: o
        }) => {
            if (c.__composer) {
                const m = c.__composer,
                    f = ta(o);
                c.textContent = Reflect.apply(m.t, m, [...la(f)])
            }
        },
        getSSRProps: c => {
            const [o] = r(c);
            return {
                textContent: o
            }
        }
    }
}

function ta(e) {
    if (v(e)) return {
        path: e
    };
    if (T(e)) {
        if (!("path" in e)) throw I(E.REQUIRED_VALUE, "path");
        return e
    } else throw I(E.INVALID_VALUE)
}

function la(e) {
    const {
        path: r,
        locale: t,
        args: n,
        choice: l,
        plural: a
    } = e, c = {}, o = n || {};
    return v(t) && (c.locale = t), X(l) && (c.plural = l), X(a) && (c.plural = a), [r, o, c]
}

function Za(e, r, ...t) {
    const n = T(t[0]) ? t[0] : {},
        l = !!n.useI18nComponentName;
    (k(n.globalInstall) ? n.globalInstall : !0) && (e.component(l ? "i18n" : Ze.name, Ze), e.component(ea.name, ea), e.component(aa.name, aa)), e.directive("t", Qa(r))
}

function et(e, r, t) {
    return {
        beforeCreate() {
            const n = Q();
            if (!n) throw I(E.UNEXPECTED_ERROR);
            const l = this.$options;
            if (l.i18n) {
                const a = l.i18n;
                l.__i18n && (a.__i18n = l.__i18n), a.__root = r, this === this.$root ? this.$i18n = na(e, a) : (a.__injectWithOption = !0, this.$i18n = De(a))
            } else l.__i18n ? this === this.$root ? this.$i18n = na(e, l) : this.$i18n = De({
                __i18n: l.__i18n,
                __injectWithOption: !0,
                __root: r
            }) : this.$i18n = e;
            l.__i18nGlobal && fa(r, l, l), e.__onComponentInstanceCreated(this.$i18n), t.__setInstance(n, this.$i18n), this.$t = (...a) => this.$i18n.t(...a), this.$rt = (...a) => this.$i18n.rt(...a), this.$tc = (...a) => this.$i18n.tc(...a), this.$te = (a, c) => this.$i18n.te(a, c), this.$d = (...a) => this.$i18n.d(...a), this.$n = (...a) => this.$i18n.n(...a), this.$tm = a => this.$i18n.tm(a)
        },
        mounted() {},
        unmounted() {
            const n = Q();
            if (!n) throw I(E.UNEXPECTED_ERROR);
            delete this.$t, delete this.$rt, delete this.$tc, delete this.$te, delete this.$d, delete this.$n, delete this.$tm, t.__deleteInstance(n), delete this.$i18n
        }
    }
}

function na(e, r) {
    e.locale = r.locale || e.locale, e.fallbackLocale = r.fallbackLocale || e.fallbackLocale, e.missing = r.missing || e.missing, e.silentTranslationWarn = r.silentTranslationWarn || e.silentFallbackWarn, e.silentFallbackWarn = r.silentFallbackWarn || e.silentFallbackWarn, e.formatFallbackMessages = r.formatFallbackMessages || e.formatFallbackMessages, e.postTranslation = r.postTranslation || e.postTranslation, e.warnHtmlInMessage = r.warnHtmlInMessage || e.warnHtmlInMessage, e.escapeParameterHtml = r.escapeParameterHtml || e.escapeParameterHtml, e.sync = r.sync || e.sync, e.__composer[ia](r.pluralizationRules || e.pluralizationRules);
    const t = le(e.locale, {
        messages: r.messages,
        __i18n: r.__i18n
    });
    return Object.keys(t).forEach(n => e.mergeLocaleMessage(n, t[n])), r.datetimeFormats && Object.keys(r.datetimeFormats).forEach(n => e.mergeDateTimeFormat(n, r.datetimeFormats[n])), r.numberFormats && Object.keys(r.numberFormats).forEach(n => e.mergeNumberFormat(n, r.numberFormats[n])), e
}
const at = $("global-vue-i18n");

function bt(e = {}, r) {
    const t = k(e.legacy) ? e.legacy : !0,
        n = k(e.globalInjection) ? e.globalInjection : !0,
        l = t ? !!e.allowComposition : !0,
        a = new Map,
        [c, o] = tt(e, t),
        m = $("");

    function f(b) {
        return a.get(b) || null
    }

    function g(b, d) {
        a.set(b, d)
    }

    function F(b) {
        a.delete(b)
    } {
        const b = {
            get mode() {
                return t ? "legacy" : "composition"
            },
            get allowComposition() {
                return l
            },
            async install(d, ...y) {
                d.__VUE_I18N_SYMBOL__ = m, d.provide(d.__VUE_I18N_SYMBOL__, b), !t && n && mt(d, b.global), Za(d, b, ...y), t && d.mixin(et(o, o.__composer, b));
                const h = d.unmount;
                d.unmount = () => {
                    b.dispose(), h()
                }
            },
            get global() {
                return o
            },
            dispose() {
                c.stop()
            },
            __instances: a,
            __getInstance: f,
            __setInstance: g,
            __deleteInstance: F
        };
        return b
    }
}

function Se(e = {}) {
    const r = Q();
    if (r == null) throw I(E.MUST_BE_CALL_SETUP_TOP);
    if (!r.isCE && r.appContext.app != null && !r.appContext.app.__VUE_I18N_SYMBOL__) throw I(E.NOT_INSLALLED);
    const t = lt(r),
        n = rt(t),
        l = ma(r),
        a = nt(e, l);
    if (t.mode === "legacy" && !e.__useComponent) {
        if (!t.allowComposition) throw I(E.NOT_AVAILABLE_IN_LEGACY_MODE);
        return ut(r, a, n, e)
    }
    if (a === "global") return fa(n, e, l), n;
    if (a === "parent") {
        let m = st(t, r, e.__useComponent);
        return m == null && (m = n), m
    }
    const c = t;
    let o = c.__getInstance(r);
    if (o == null) {
        const m = P({}, e);
        "__i18n" in l && (m.__i18n = l.__i18n), n && (m.__root = n), o = Ce(m), ct(c, r), c.__setInstance(r, o)
    }
    return o
}

function tt(e, r, t) {
    const n = wa(); {
        const l = r ? n.run(() => De(e)) : n.run(() => Ce(e));
        if (l == null) throw I(E.UNEXPECTED_ERROR);
        return [n, l]
    }
}

function lt(e) {
    {
        const r = Sa(e.isCE ? at : e.appContext.app.__VUE_I18N_SYMBOL__);
        if (!r) throw I(e.isCE ? E.NOT_INSLALLED_WITH_PROVIDE : E.UNEXPECTED_ERROR);
        return r
    }
}

function nt(e, r) {
    return Ta(e) ? "__i18n" in r ? "local" : "global" : e.useScope ? e.useScope : "local"
}

function rt(e) {
    return e.mode === "composition" ? e.global : e.global.__composer
}

function st(e, r, t = !1) {
    let n = null;
    const l = r.root;
    let a = r.parent;
    for (; a != null;) {
        const c = e;
        if (e.mode === "composition") n = c.__getInstance(a);
        else {
            const o = c.__getInstance(a);
            o != null && (n = o.__composer, t && n && !n[oa] && (n = null))
        }
        if (n != null || l === a) break;
        a = a.parent
    }
    return n
}

function ct(e, r, t) {
    Aa(() => {}, r), Ha(() => {
        e.__deleteInstance(r)
    }, r)
}

function ut(e, r, t, n = {}) {
    const l = r === "local",
        a = Va(null);
    if (l && e.proxy && !(e.proxy.$options.i18n || e.proxy.$options.__i18n)) throw I(E.MUST_DEFINE_I18N_OPTION_IN_ALLOW_COMPOSITION);
    const c = k(n.inheritLocale) ? n.inheritLocale : !0,
        o = W(l && c ? t.locale.value : v(n.locale) ? n.locale : pe),
        m = W(l && c ? t.fallbackLocale.value : v(n.fallbackLocale) || R(n.fallbackLocale) || T(n.fallbackLocale) || n.fallbackLocale === !1 ? n.fallbackLocale : o.value),
        f = W(le(o.value, n)),
        g = W(T(n.datetimeFormats) ? n.datetimeFormats : {
            [o.value]: {}
        }),
        F = W(T(n.numberFormats) ? n.numberFormats : {
            [o.value]: {}
        }),
        b = l ? t.missingWarn : k(n.missingWarn) || z(n.missingWarn) ? n.missingWarn : !0,
        d = l ? t.fallbackWarn : k(n.fallbackWarn) || z(n.fallbackWarn) ? n.fallbackWarn : !0,
        y = l ? t.fallbackRoot : k(n.fallbackRoot) ? n.fallbackRoot : !0,
        h = !!n.fallbackFormat,
        w = U(n.missing) ? n.missing : null,
        j = U(n.postTranslation) ? n.postTranslation : null,
        S = l ? t.warnHtmlMessage : k(n.warnHtmlMessage) ? n.warnHtmlMessage : !0,
        x = !!n.escapeParameter,
        A = l ? t.modifiers : T(n.modifiers) ? n.modifiers : {},
        _ = n.pluralRules || l && t.pluralRules;

    function ne() {
        return [o.value, m.value, f.value, g.value, F.value]
    }
    const G = C({
            get: () => a.value ? a.value.locale.value : o.value,
            set: i => {
                a.value && (a.value.locale.value = i), o.value = i
            }
        }),
        Y = C({
            get: () => a.value ? a.value.fallbackLocale.value : m.value,
            set: i => {
                a.value && (a.value.fallbackLocale.value = i), m.value = i
            }
        }),
        J = C(() => a.value ? a.value.messages.value : f.value),
        re = C(() => g.value),
        se = C(() => F.value);

    function ce() {
        return a.value ? a.value.getPostTranslationHandler() : j
    }

    function ue(i) {
        a.value && a.value.setPostTranslationHandler(i)
    }

    function ie() {
        return a.value ? a.value.getMissingHandler() : w
    }

    function oe(i) {
        a.value && a.value.setMissingHandler(i)
    }

    function H(i) {
        return ne(), i()
    }

    function V(...i) {
        return a.value ? H(() => Reflect.apply(a.value.t, null, [...i])) : H(() => "")
    }

    function Z(...i) {
        return a.value ? Reflect.apply(a.value.rt, null, [...i]) : ""
    }

    function me(...i) {
        return a.value ? H(() => Reflect.apply(a.value.d, null, [...i])) : H(() => "")
    }

    function fe(...i) {
        return a.value ? H(() => Reflect.apply(a.value.n, null, [...i])) : H(() => "")
    }

    function _e(i) {
        return a.value ? a.value.tm(i) : {}
    }

    function ge(i, L) {
        return a.value ? a.value.te(i, L) : !1
    }

    function Ae(i) {
        return a.value ? a.value.getLocaleMessage(i) : {}
    }

    function be(i, L) {
        a.value && (a.value.setLocaleMessage(i, L), f.value[i] = L)
    }

    function ve(i, L) {
        a.value && a.value.mergeLocaleMessage(i, L)
    }

    function de(i) {
        return a.value ? a.value.getDateTimeFormat(i) : {}
    }

    function Le(i, L) {
        a.value && (a.value.setDateTimeFormat(i, L), g.value[i] = L)
    }

    function Fe(i, L) {
        a.value && a.value.mergeDateTimeFormat(i, L)
    }

    function ke(i) {
        return a.value ? a.value.getNumberFormat(i) : {}
    }

    function Te(i, L) {
        a.value && (a.value.setNumberFormat(i, L), F.value[i] = L)
    }

    function Ee(i, L) {
        a.value && a.value.mergeNumberFormat(i, L)
    }
    const ee = {
        get id() {
            return a.value ? a.value.id : -1
        },
        locale: G,
        fallbackLocale: Y,
        messages: J,
        datetimeFormats: re,
        numberFormats: se,
        get inheritLocale() {
            return a.value ? a.value.inheritLocale : c
        },
        set inheritLocale(i) {
            a.value && (a.value.inheritLocale = i)
        },
        get availableLocales() {
            return a.value ? a.value.availableLocales : Object.keys(f.value)
        },
        get modifiers() {
            return a.value ? a.value.modifiers : A
        },
        get pluralRules() {
            return a.value ? a.value.pluralRules : _
        },
        get isGlobal() {
            return a.value ? a.value.isGlobal : !1
        },
        get missingWarn() {
            return a.value ? a.value.missingWarn : b
        },
        set missingWarn(i) {
            a.value && (a.value.missingWarn = i)
        },
        get fallbackWarn() {
            return a.value ? a.value.fallbackWarn : d
        },
        set fallbackWarn(i) {
            a.value && (a.value.missingWarn = i)
        },
        get fallbackRoot() {
            return a.value ? a.value.fallbackRoot : y
        },
        set fallbackRoot(i) {
            a.value && (a.value.fallbackRoot = i)
        },
        get fallbackFormat() {
            return a.value ? a.value.fallbackFormat : h
        },
        set fallbackFormat(i) {
            a.value && (a.value.fallbackFormat = i)
        },
        get warnHtmlMessage() {
            return a.value ? a.value.warnHtmlMessage : S
        },
        set warnHtmlMessage(i) {
            a.value && (a.value.warnHtmlMessage = i)
        },
        get escapeParameter() {
            return a.value ? a.value.escapeParameter : x
        },
        set escapeParameter(i) {
            a.value && (a.value.escapeParameter = i)
        },
        t: V,
        getPostTranslationHandler: ce,
        setPostTranslationHandler: ue,
        getMissingHandler: ie,
        setMissingHandler: oe,
        rt: Z,
        d: me,
        n: fe,
        tm: _e,
        te: ge,
        getLocaleMessage: Ae,
        setLocaleMessage: be,
        mergeLocaleMessage: ve,
        getDateTimeFormat: de,
        setDateTimeFormat: Le,
        mergeDateTimeFormat: Fe,
        getNumberFormat: ke,
        setNumberFormat: Te,
        mergeNumberFormat: Ee
    };

    function Ie(i) {
        i.locale.value = o.value, i.fallbackLocale.value = m.value, Object.keys(f.value).forEach(L => {
            i.mergeLocaleMessage(L, f.value[L])
        }), Object.keys(g.value).forEach(L => {
            i.mergeDateTimeFormat(L, g.value[L])
        }), Object.keys(F.value).forEach(L => {
            i.mergeNumberFormat(L, F.value[L])
        }), i.escapeParameter = x, i.fallbackFormat = h, i.fallbackRoot = y, i.fallbackWarn = d, i.missingWarn = b, i.warnHtmlMessage = S
    }
    return Ua(() => {
        if (e.proxy == null || e.proxy.$i18n == null) throw I(E.NOT_AVAILABLE_COMPOSITION_IN_LEGACY);
        const i = a.value = e.proxy.$i18n.__composer;
        r === "global" ? (o.value = i.locale.value, m.value = i.fallbackLocale.value, f.value = i.messages.value, g.value = i.datetimeFormats.value, F.value = i.numberFormats.value) : l && Ie(i)
    }), ee
}
const it = ["locale", "fallbackLocale", "availableLocales"],
    ot = ["t", "rt", "d", "n", "tm"];

function mt(e, r) {
    const t = Object.create(null);
    it.forEach(n => {
        const l = Object.getOwnPropertyDescriptor(r, n);
        if (!l) throw I(E.UNEXPECTED_ERROR);
        const a = ja(l.value) ? {
            get() {
                return l.value.value
            },
            set(c) {
                l.value.value = c
            }
        } : {
            get() {
                return l.get && l.get()
            }
        };
        Object.defineProperty(t, n, a)
    }), e.config.globalProperties.$i18n = t, ot.forEach(n => {
        const l = Object.getOwnPropertyDescriptor(r, n);
        if (!l || !l.value) throw I(E.UNEXPECTED_ERROR);
        Object.defineProperty(e.config.globalProperties, `$${n}`, l)
    })
}
Ea(Ma);
Ia(Pa);
Oa(sa);
Ba();
if (__INTLIFY_PROD_DEVTOOLS__) {
    const e = ra();
    e.__INTLIFY__ = !0, Ra(e.__INTLIFY_DEVTOOLS_GLOBAL_HOOK__)
}
export {
    bt as c, Se as u
};