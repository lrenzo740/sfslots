import {
    u as N
} from "./vuex.7fead168.js";
import {
    b as Q,
    u as U
} from "./vue-router.d17f0860.js";
import {
    e as v,
    f as X,
    h as Y,
    j as Z,
    F as ee,
    S as D,
    T as te,
    __tla as oe
} from "./index.0a674315.js";
import {
    u as se
} from "./vue-i18n.d9454f26.js";
import {
    o as a,
    c as l,
    a as i,
    u as e,
    W as n,
    P as u,
    a3 as d,
    O as m
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@intlify.7347860c.js";
let E, ae = Promise.all([(() => {
    try {
        return oe
    } catch {}
})()]).then(async () => {
    let b, y, g, h, w, k, F, x, I, T, _, C, $, B, L, S, V, A, P, j, q, O, R, W;
    b = {
        class: "home-footer"
    }, y = {
        class: "innerBox"
    }, g = {
        class: "mixBox"
    }, h = {
        class: "home-footer-top"
    }, w = {
        key: 0,
        class: "home-footer-top-box"
    }, k = {
        key: 0,
        class: "cassino footer-item"
    }, F = {
        class: "title"
    }, x = ["onClick"], I = {
        key: 1,
        class: "games footer-item"
    }, T = {
        class: "title"
    }, _ = ["onClick"], C = {
        key: 2,
        class: "support footer-item"
    }, $ = {
        class: "title"
    }, B = ["onClick"], L = {
        class: "home-footer-companyInfo"
    }, S = {
        key: 0,
        class: "text"
    }, V = {
        class: "home-footer-middle"
    }, A = {
        class: "home-footer-middle-box"
    }, P = {
        key: 1,
        class: "bigIcons"
    }, j = ["src"], q = {
        key: 2,
        class: "smallIcons"
    }, O = ["src"], R = {
        class: "home-footer-bottom"
    }, W = {
        key: 0,
        class: "copyRight"
    }, E = {
        __name: "footer_green",
        setup(le) {
            const t = N(),
                p = Q(),
                z = U(),
                {
                    t: G
                } = se(),
                H = o => {
                    p.push(ee[o])
                },
                J = o => {
                    if (z.name === "index") {
                        let c = t.state.tableList.find(r => r.type == o.value),
                            s = t.state.tableList.findIndex(r => r.type == o.value);
                        if (o.value == 99 || o.value == 98) {
                            let r = o.value == 99 ? "collect" : "recent";
                            globalVBus.$emit("changeTag", r), s = t.state.tableList.findIndex(f => f.type == 0), c = t.state.tableList.find(f => f.type == 0), p.replace("/index?gameType=0"), globalVBus.$emit("changeActiveTab", s, c)
                        } else z.query.gameType != o.value && p.replace("/index?gameType=" + o.value), globalVBus.$emit("changeActiveTab", s, c)
                    } else p.push("/index?gameType=" + o.value)
                },
                K = o => {
                    if (!D[o]) return te(G("footer.none"));
                    p.push(D[o])
                },
                M = o => {
                    o && window.open(o, "new")
                };
            return (o, c) => (a(), l("div", b, [i("div", y, [i("div", g, [i("div", h, [e(t).state.webFooter.modules && e(t).state.webFooter.modules.status ? (a(), l("div", w, [e(t).state.webFooter.modules.funcs.length ? (a(), l("div", k, [i("div", F, n(o.$t("footer.cassino")), 1), i("ul", null, [(a(!0), l(u, null, d(e(t).state.webFooter.modules.funcs, s => (a(), l("li", {
                key: s.value,
                onClick: r => H(s.value)
            }, n(e(v)(e(X)(s.value))), 9, x))), 128))])])) : m("", !0), e(t).state.webFooter.modules.gameTypes.length ? (a(), l("div", I, [i("div", T, n(o.$t("footer.games")), 1), i("ul", null, [(a(!0), l(u, null, d(e(t).state.webFooter.modules.gameTypes, (s, r) => (a(), l("li", {
                key: s.value,
                onClick: f => J(s)
            }, n(e(v)(e(Y)(s.value))), 9, _))), 128))])])) : m("", !0), e(t).state.webFooter.modules.supps.length ? (a(), l("div", C, [i("div", $, n(o.$t("footer.support")), 1), i("ul", null, [(a(!0), l(u, null, d(e(t).state.webFooter.modules.supps, s => (a(), l("li", {
                key: s.value,
                onClick: r => K(s.value)
            }, n(e(v)(e(Z)(s.value))), 9, B))), 128))])])) : m("", !0)])) : m("", !0)]), i("div", L, [e(t).state.webFooter.companyInfo && e(t).state.webFooter.companyInfo.status ? (a(), l("div", S, n(e(t).state.webFooter.companyInfo.desc), 1)) : m("", !0)]), i("div", V, [i("div", A, [e(t).state.techSupport ? (a(), l("div", {
                key: 0,
                class: "home-footer-middle-support",
                onClick: c[0] || (c[0] = s => M(e(t).state.techSupport))
            }, n(o.$t("footer.technicalSupport")), 1)) : m("", !0), e(t).state.webFooter.partners && e(t).state.webFooter.partners.status ? (a(), l("div", P, [(a(!0), l(u, null, d(e(t).state.webFooter.partners.images, (s, r) => (a(), l("img", {
                src: s,
                key: r
            }, null, 8, j))), 128))])) : m("", !0), e(t).state.webFooter.licenses && e(t).state.webFooter.licenses.status ? (a(), l("div", q, [(a(!0), l(u, null, d(e(t).state.webFooter.licenses.images, (s, r) => (a(), l("img", {
                src: s,
                key: r
            }, null, 8, O))), 128))])) : m("", !0)])])]), i("div", R, [e(t).state.webFooter.contactInfo && e(t).state.webFooter.contactInfo.status ? (a(), l("div", W, n(e(t).state.webFooter.contactInfo.contact) + " " + n(e(t).state.webFooter.contactInfo.copyright) + " ", 1)) : m("", !0), i("div", {
                class: "complaintBtn",
                onClick: c[1] || (c[1] = s => e(p).push("/complaint"))
            }, n(o.$t("complaint.title")), 1)])])]))
        }
    }
});
export {
    ae as __tla, E as
    default
};