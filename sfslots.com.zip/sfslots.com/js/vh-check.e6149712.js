import {
    c as U,
    a as T
} from "./clipboard.f53621db.js";
var b = {
    exports: {}
};
(function(E, k) {
    (function(o, u) {
        E.exports = u()
    })(U, function() {
        /*! *****************************************************************************
        	    Copyright (c) Microsoft Corporation. All rights reserved.
        	    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
        	    this file except in compliance with the License. You may obtain a copy of the
        	    License at http://www.apache.org/licenses/LICENSE-2.0

        	    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
        	    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
        	    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
        	    MERCHANTABLITY OR NON-INFRINGEMENT.

        	    See the Apache Version 2.0 License for specific language governing permissions
        	    and limitations under the License.
        	    ***************************************************************************** */
        var o = function() {
            return o = Object.assign || function(t) {
                for (var n, r = 1, i = arguments.length; r < i; r++) {
                    n = arguments[r];
                    for (var v in n) Object.prototype.hasOwnProperty.call(n, v) && (t[v] = n[v])
                }
                return t
            }, o.apply(this, arguments)
        };

        function u() {
            var e = document.createElement("div");
            return e.style.cssText = "position: fixed; top: 0; height: 100vh; pointer-events: none;", document.documentElement.insertBefore(e, document.documentElement.firstChild), e
        }

        function V(e) {
            document.documentElement.removeChild(e)
        }

        function m() {
            var e = u(),
                t = window.innerHeight,
                n = e.offsetHeight,
                r = n - t;
            return V(e), {
                vh: n,
                windowHeight: t,
                offset: r,
                isNeeded: r !== 0,
                value: 0
            }
        }

        function c() {}

        function h() {
            var e = m();
            return e.value = e.offset, e
        }

        function O() {
            var e = m();
            return e.value = e.windowHeight * .01, e
        }
        var y = Object.freeze({
            noop: c,
            computeDifference: h,
            redefineVhUnit: O
        });

        function l(e) {
            return typeof e == "string" && e.length > 0
        }

        function N(e) {
            return typeof e == "function"
        }
        var s = Object.freeze({
            cssVarName: "vh-offset",
            redefineVh: !1,
            method: h,
            force: !1,
            bind: !0,
            updateOnTouch: !1,
            onUpdate: c
        });

        function j(e) {
            if (l(e)) return o({}, s, {
                cssVarName: e
            });
            if (typeof e != "object") return s;
            var t = {
                    force: e.force === !0,
                    bind: e.bind !== !1,
                    updateOnTouch: e.updateOnTouch === !0,
                    onUpdate: N(e.onUpdate) ? e.onUpdate : c
                },
                n = e.redefineVh === !0;
            return t.method = y[n ? "redefineVhUnit" : "computeDifference"], t.cssVarName = l(e.cssVarName) ? e.cssVarName : n ? "vh" : s.cssVarName, t
        }
        var f = !1,
            d = [];
        try {
            var a = Object.defineProperty({}, "passive", {
                get: function() {
                    f = !0
                }
            });
            window.addEventListener("test", a, a), window.removeEventListener("test", a, a)
        } catch {
            f = !1
        }

        function p(e, t) {
            d.push({
                eventName: e,
                callback: t
            }), window.addEventListener(e, t, f ? {
                passive: !0
            } : !1)
        }

        function x() {
            d.forEach(function(e) {
                window.removeEventListener(e.eventName, e.callback)
            }), d = []
        }

        function g(e, t) {
            document.documentElement.style.setProperty("--" + e, t.value + "px")
        }

        function w(e, t) {
            return o({}, e, {
                unbind: x,
                recompute: t.method
            })
        }

        function C(e) {
            var t = Object.freeze(j(e)),
                n = w(t.method(), t);
            if (!n.isNeeded && !t.force || (g(t.cssVarName, n), t.onUpdate(n), !t.bind)) return n;

            function r() {
                window.requestAnimationFrame(function() {
                    var i = t.method();
                    g(t.cssVarName, i), t.onUpdate(w(i, t))
                })
            }
            return n.unbind(), p("orientationchange", r), t.updateOnTouch && p("touchmove", r), n
        }
        return C
    })
})(b);
var z = b.exports;
const H = T(z);
export {
    H as v
};