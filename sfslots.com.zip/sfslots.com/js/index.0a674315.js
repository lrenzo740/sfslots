var $n = Object.defineProperty;
var Xn = ($, K, J) => K in $ ? $n($, K, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: J
}) : $[K] = J;
var Da = ($, K, J) => (Xn($, typeof K != "symbol" ? K + "" : K, J), J);
import {
    r as H,
    w as $e,
    n as Xe,
    aa as Qa,
    o as A,
    R as O,
    S as Oa,
    L as at,
    a as T,
    U,
    W as ba,
    M as et,
    Y as tt,
    e as ka,
    c as F,
    Q as sa,
    aj as fa,
    f as nt,
    j as ai,
    F as ei,
    u as c,
    O as Z,
    am as ti,
    T as ni,
    an as E,
    ao as Ya,
    V as $a,
    G as Xa,
    h as it
} from "./@vue.16908cbf.js";
import {
    a as rt
} from "./axios.4a70c6fc.js";
import {
    c as ii,
    u as ot
} from "./vuex.7fead168.js";
import {
    c as ri,
    a as oi,
    u as si,
    b as li
} from "./vue-router.d17f0860.js";
import {
    E as di,
    p as mi,
    e as st,
    i as ci,
    a as ui
} from "./element-plus.c133b52b.js";
import {
    L as Za,
    s as gi,
    a as lt,
    b as pi
} from "./vant.be74fb7c.js";
import {
    c as _i,
    u as hi
} from "./vue-i18n.d9454f26.js";
import "./nprogress.1adef0ba.js";
import {
    X as G
} from "./xe-utils.0e898ace.js";
import {
    C as B
} from "./crypto-js.bfe2481f.js";
import {
    D as W
} from "./decimal.js.d133ee8e.js";
import {
    i as bi
} from "./@fingerprintjs.bfff8371.js";
import {
    v as ki
} from "./vh-check.e6149712.js";
import {
    i as fi
} from "./vue-lazyload.38f311e8.js";
import {
    j as yi
} from "./@lucky-canvas.861f1f96.js";
import {
    R as xi
} from "./vue-dragscroll.ace105ad.js";
import "./@vant.359a3f91.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./@intlify.7347860c.js";
import "./tslib.521c7ea7.js";
import "./vue-demi.71ba0ef2.js";
let I, la, dt, ae, La, mt, ct, ut, gt, x, pt, _t, ht, bt, kt, ft, yt, xt, vt, wt, aa, At, Pt, Mt, It, Ct, ja, l, Tt, h, Na, Bt, Rt, Et, ee, St, Dt, Ot, Zt, te, Lt, jt, da, Nt, ne, Vt, qt, Ht, na, ma, Ft, Ut, Kt, zt, s, N, Gt, Wt, Jt, ie, Qt, re, vi = (async () => {
    Tt = function() {
            import.meta.url,
                import ("_").then(async e => (await e.__tla, e)).catch(() => 1);
            async function* a() {}
        },
        function() {
            const a = document.createElement("link").relList;
            if (a && a.supports && a.supports("modulepreload")) return;
            for (const n of document.querySelectorAll('link[rel="modulepreload"]')) t(n);
            new MutationObserver(n => {
                for (const o of n)
                    if (o.type === "childList")
                        for (const m of o.addedNodes) m.tagName === "LINK" && m.rel === "modulepreload" && t(m)
            }).observe(document, {
                childList: !0,
                subtree: !0
            });

            function e(n) {
                const o = {};
                return n.integrity && (o.integrity = n.integrity), n.referrerPolicy && (o.referrerPolicy = n.referrerPolicy), n.crossOrigin === "use-credentials" ? o.credentials = "include" : n.crossOrigin === "anonymous" ? o.credentials = "omit" : o.credentials = "same-origin", o
            }

            function t(n) {
                if (n.ep) return;
                n.ep = !0;
                const o = e(n);
                fetch(n.href, o)
            }
        }();
    let $, K, J, oe, se, ya, le, de, me, ia, ra, Va, ce;
    $ = "modulepreload", K = function(a) {
        return "/" + a
    }, J = {}, l = function(a, e, t) {
        if (!e || e.length === 0) return a();
        const n = document.getElementsByTagName("link");
        return Promise.all(e.map(o => {
            if (o = K(o), o in J) return;
            J[o] = !0;
            const m = o.endsWith(".css"),
                k = m ? '[rel="stylesheet"]' : "";
            if (t)
                for (let P = n.length - 1; P >= 0; P--) {
                    const w = n[P];
                    if (w.href === o && (!m || w.rel === "stylesheet")) return
                } else if (document.querySelector(`link[href="${o}"]${k}`)) return;
            const g = document.createElement("link");
            if (g.rel = m ? "stylesheet" : $, m || (g.as = "script", g.crossOrigin = ""), g.href = o, document.head.appendChild(g), m) return new Promise((P, w) => {
                g.addEventListener("load", P), g.addEventListener("error", () => w(new Error(`Unable to preload CSS for ${o}`)))
            })
        })).then(() => a())
    }, oe = {
        home: {
            noData: "No Data",
            loadMore: "Load More",
            moreTipsText1: "Currently displaying ",
            moreTipsText2: "Hot games out of ",
            moreTipsText3: "",
            maintain: "Under maintenance",
            all: "All",
            maintainText: "Under Maint",
            limitAmountTips: "Your balance is insufficient {currency}{balance}; deposit to dominate the scene!",
            top: "Top"
        },
        footer: {
            cassino: "Casino",
            games: "Games",
            support: "Support",
            none: "Temporarily closed",
            funcList: {
                reward: "Reward",
                rebate: "Rebate",
                vip: "VIP",
                agent: "Agent",
                event: "Event",
                task: "Mission"
            },
            gameList: {
                hot: "Hot",
                card: "Card",
                fish: "Fish",
                digital: "Slot",
                live: "Live",
                sports: "Sports",
                recent: "Recent",
                collect: "Favorite"
            },
            supportList: {
                support: "Online Service",
                advise: "Feedback to get rewards",
                faq: "Help Center"
            },
            technicalSupport: "Technical Support"
        },
        new_player: {
            title: "Benefits for new players",
            proceed: "Proceed",
            collect: "Receive",
            collected: "Received",
            reward: "Bonus",
            tips1: "Do not show again today",
            tips2: "Never prompt",
            collectAll: "All received",
            tip3: "Not eligible for receipt",
            tip4: "Please bind the payment account first"
        },
        search_page: {
            title: "Search",
            result: "Search Result",
            popular: "Hot",
            recent: "Recent",
            favorites: "Favorite",
            record: "History",
            clear: "Delete All"
        },
        sub_game: {
            search: "Search Games",
            all: "All"
        },
        vip_item: {
            accumulated_deposits: "Accumulated deposits",
            current_stream: "Current turnover",
            relegation_deposits: "Relegation deposit",
            relegation_stream: "Relegation turnover",
            tips1: "You still need",
            tips2: "deposit to upgrade to",
            tips3: "turnover to upgrade to",
            maxLevel: "Already the highest level",
            privilege: "Privileged",
            challenge_game: "Breakthrough game",
            go: "Go a look",
            unset: "You have not set a birthday yet",
            tips: "Hint",
            confirmText: "Move to setting",
            cancelText: "Chat next time"
        },
        vip_lucky_wheel: {
            daily_lottery: "Daily draw",
            upgrade_vip: "Upgrade VIP",
            current: "Current",
            lottery_draw: "Number of draws",
            winning_record: "Winning record",
            tips1: "The number of draws has been finish",
            tips2: "Congratulations on getting ",
            tips3: "amount"
        },
        vip_birthday: {
            title: "Birthday Bonus",
            collect: "Receive",
            collected: "Received"
        },
        vip_reward: {
            title: "VIP rewards",
            upgrade: "To achieve next level ",
            recharge: "Deposit an Additional ",
            bet: "Bet an Additional ",
            collect_all: "Claim All",
            collect_record: "History",
            level_list: "VIP Level List",
            upgrade_rewards: "Promotion Bonus",
            relegation_conditions: "Relegation Conditions",
            daily_rewards: "Daily Bonus",
            weekly_rewards: "Weekly Bonus",
            monthly_rewards: "Monthly Bonus",
            privilege: "VIP Privilege",
            rule_description: "VIP Rules Description",
            title1: "Upgrade reward rules",
            text1: "After meeting the conditions for VIP promotion (meeting the requirements for recharge and code accumulation), members will be promoted to the corresponding VIP level and can receive promotion bonuses. If multiple upgrades are made at one time, members can receive bonuses for all promotion levels.",
            title2: "Weekly reward rules",
            text2: "When the weekly recharge and betting amount reaches the current VIP level and the corresponding weekly reward requirements, members can receive the corresponding weekly salary, which is reset at 00:00 every Monday.",
            title3: "Monthly reward rules",
            text3: "When the monthly recharge and betting meet the VIP requirements of that month, you can receive the corresponding monthly salary, which will be reset at 00:00 on the first day of each month.",
            none_reward: "No rewards available to claim",
            rule_detail: "1.Promotion standard: Meet the VIP promotion requirements (i.e., both deposit or valid bets meet the criteria) to upgrade to the corresponding VIP level and receive the corresponding promotion bonus. If you consecutively upgrade multiple levels, you can only receive the current level's promotion bonus.Real-time bonuses can be claimed;<br/>2.Daily Bonus: By meeting the current level's daily deposit and valid betting requirements, you can receive the corresponding daily bonus. If consecutively advancing across multiple levels, only the current level's daily bonus can be obtained.Real-time bonuses can be claimed;<br/>3.Weekly Bonus: By meeting the deposit and valid betting requirements for the current level each week, one can receive the corresponding weekly bonus. If consecutively advancing across multiple levels, only the weekly bonus of the current level can be obtained.Real-time bonuses can be claimed;<br/>4.Monthly Bonus: By meeting the deposit and valid betting requirements for the current level each month, one can receive the corresponding monthly salary bonus. If consecutively advancing across multiple levels, only the monthly bonus of the current level can be obtained.Real-time bonuses can be claimed;<br/>5.Reward expiraten time: The received bonus is retained for %d days. If not claimed actively during this period, it will be automatically credited to the account. For example: if a reward is obtained on January 1st and retained for %d days, it will be automatically credited to the account on January %d at 00:00:00.<br/>6.Audit Note: VIP bonuses need to be wagered 10 times (i.e., audited, played through, or through valid bets) to be eligible for withdrawal, Wagering is not limited to any game platform;<br/>7.Event Statement: This feature is only for the account owner's normal gaming betting. Renting accounts, risk-free betting (matching, brushing, low odds), malicious arbitrage, using plugins, bots, exploiting agreements, vulnerabilities, interfaces, group control, or other technical means are prohibited. Once verified, the platform reserves the right to terminate member logins, suspend member website usage, and confiscate bonuses and improper profits without prior notice.<br/>8.Explanation: By claiming VIP rewards, the platform assumes that the member agrees to comply with the corresponding conditions and related regulations. To avoid misunderstandings in text interpretation, the platform reserves the final right to interpret this event. ",
            current_level: "Current Level"
        },
        vip_reward_upgrade: {
            level: "Level",
            reward_conditions: "Reward conditions",
            operate: "Operating",
            recharge: "Recharge",
            bet: "Place bet",
            collected: "Received",
            collect: "Receive",
            bonus: "Bonus",
            text1: "Daily valid bets",
            text2: "Weekly valid bets",
            text3: "Monthly valid bets",
            text4: "Daily deposit",
            text5: "Weekly deposit",
            text6: "Monthly deposit",
            text7: "Deposit for promotion",
            text8: "Bet for promotion",
            text9: "Daily withdrawal total limit",
            text10: "Daily withdrawal count limit",
            text11: "Number of fee-free transactions per day",
            tips_title: "Tips",
            tips_content_recharge: "To promote to the next level, you need to deposit an additional amount based on the accumulative deposit. For example: to upgrade from VIP1 with a recharge requirement of 1000 to VIP2 with a requirement of 2000, the member needs to accumulate 1000 + 2000 = 3000 to upgrade to VIP2, and so on. ",
            tips_content_bet: "To promote to the next level, you need to bet an additional amount based on the accumulative bet. For example: to upgrade from VIP1 with a bet requirement of 1000 to VIP2 with a requirement of 2000, the member needs to accumulate 1000 + 2000 = 3000 to upgrade to VIP2, and so on. ",
            unlimited: "Unlimited",
            text12: "Deposit last month",
            text13: "Bet last month"
        },
        mine: {
            upgrade: "Level Up",
            recharge: "Recharge again",
            bet: "Bet again",
            need_recharge: "Deposit for promotion",
            need_bet: "Bet for promotion",
            account_detail: "Statement",
            bet_record: "Bet Records",
            personal_report: "Reports",
            service_setting: "Withdrawal Management",
            invite: "Agent",
            account: "Account",
            help_center: "FAQ",
            music: "Music",
            advise: "Feedback to get rewards",
            about_us: "About",
            address_manage: "Address administration",
            security_center: "Security Center",
            language: "Language",
            exit: "Quit",
            tips1: "Log out from account?",
            tips: "Reminder",
            id: "ID",
            tab_account: "Profile",
            message: "Message",
            wallet: "Main Wallet",
            exchange: "Withdraw",
            deposit: "Deposit",
            income: "Interest",
            login_pwd: "login password",
            exchange_pwd: "Withdrawal Password",
            million_monthly: "million monthly",
            support: "Support",
            search_balance: "Retrieve the balance",
            request_label: "Remaining",
            request_recharge: "amount for deposit"
        },
        advise: {
            message_title: "Message Center",
            welcome_title: "Professional full-time customer service is always online to help you with any questions.",
            welcome_text: "24/7 Online Service",
            customer: "Online service",
            title: "Feedback to get rewards",
            faq: "FAQ",
            read: "Have read",
            unread: "Unread",
            advise_reward: "Create",
            my_record: "Mine",
            content_title: "Feedback Content",
            content_tips: "(Suggestions for revision)",
            entry: "Your opinions are valuable to us. Any worthwhile suggestions will be considered, and once adopted, the level of importance will determine the cash reward. Please feel free to express yourself!",
            annex: "Attachment",
            annex_tips: "(Easier to be adopted)",
            upload_tips: "Supports image and video format, size should not exceed 40MB",
            advise_title: "Reward Rules",
            advise_tips: "We have set a huge bonus to collect feedback specifically to optimize our system and features for a better experience for you! Once adopted, rewards will be given based on the importance (excluding non-adopted ones).",
            submit: "Submit feedback",
            replied: "Replied",
            feedback: "Feedback content",
            reply: "Reply content",
            submit_tips: "Submission content must be longer than 10 words",
            bonus: "Bonus",
            contact: "Contact Now"
        },
        mine_info: {
            title: "Profile",
            avatar: "Profile picture",
            useName: "Username",
            realName: "Actual name",
            name_tips: "Please enter your actual name",
            sex: "Gender",
            man: "Male",
            woman: "Female",
            birthday: "Birthday (cannot be modified once set)",
            phone: "Phone number",
            email: "E-mail",
            receive_address: "Shipping address",
            no_address: "There is currently no default shipping address",
            save: "Save",
            choose_date: "Select date",
            email_error_tips: "E-mail format is incorrect",
            cancel: "Cancel",
            confirm: "Confirm",
            bindPhone: "Bind Phone",
            tips1: "Facebook cannot be empty",
            tips2: "Telegram cannot be empty",
            tips3: "Whatsapp cannot be empty",
            tips4: "Do you really want to return?",
            tips5: "Current changes not yet saved. If you return, the changes will not take effect",
            copySuccess: "Success"
        },
        agent: {
            not_have: "none",
            extension_course: "Agent Network",
            change: "Change",
            claimable: "Collectable",
            direct_subordinate: "Direct subordinates",
            my_superiors: "My superiors",
            unlimited_level_difference: "Unlimited Level Difference (Daily settlement)",
            agency_mode: "Agency mode",
            share: "Share",
            agent: "Agent",
            my_promotion: "Promotion Sharing",
            my_data: "My Data",
            tutorial: "Agent Network",
            tab_commission: "Commission",
            my_performance: "Performance",
            my_member: "Performance",
            commission_rate: "Commission Rate",
            all_types: "All types",
            all_data: "All data",
            finance: "Subordinate Finance",
            wagers: "Subordinate Wagers",
            stats: "Subordinate Stats",
            claims: "Subordinate Claims",
            account: "Account",
            superior: "Superior ID",
            can_receive: "Collectable",
            receive: "Claim",
            save: "SAVE",
            my_link: "My Link",
            commission: "Commission",
            detail: "Details",
            total_commission: "Total commission",
            received: "Commission Collected",
            unclaimed: "Last Commission",
            member: "Performance",
            total_members: "Total",
            direct_members: "Direct Subordinates",
            other_members: "Others",
            total_income: "Total Perf.",
            direct_income: "Sub's Perf.",
            other_income: "Others' Perf.",
            bet: "Subordinate's Wagers",
            total_effective_bet: "Total valid bets",
            total_bet_number: "Total no. of bet",
            total_profit_loss: "Total W/L",
            more: "More",
            to: "to",
            start_date: "Start time",
            end_date: "End Time",
            all: "All",
            time: "Time",
            type: "Type",
            bet_amount: "Bet amount",
            bet_number: "Number of bettors",
            join_time: "Join time",
            personnel: "member",
            number: "Level",
            effective_bet_unit: "Performance",
            unit: "(Unit: 10,000)",
            per_commission: "Rebate amount per 10,000",
            collect_record: "History",
            search: "Inquire",
            noData: "No Data",
            collected_commission: "Commission Collected",
            collected_time: "Collection time",
            amount: "Amount",
            myId: "My ID",
            share_title1: "",
            share_title2: "Promotional link",
            net_profit: "Net profit",
            total_net_profit: "Total net profit",
            total_discount: "Total discount",
            valid_people: "Effective number",
            valid_text1: "Valid deposit\u2265",
            valid_text2: "\uFF0Cwhich is the valid number of people",
            deposit_amount: "Deposit amount",
            agent_tier: "Agent tier",
            promotion_conditions: "Promotion conditions<br/>(Accumulative Performance)",
            commission_detail_title: "Commission details",
            commission_detail_endTime: "Settlement date",
            commission_detail_placeholder: "Settlement date",
            commission_detail_table1: "Enter member ID",
            commission_detail_table2: "Superior",
            commission_detail_table3: "Betting data",
            commission_detail_table4: "Commission",
            commission_detail_label1: "Direct data",
            commission_detail_label2: "Other data",
            commission_detail_label3: "Total data",
            commission_detail_label4: "Direct commission",
            commission_detail_label5: "Other commissions",
            commission_detail_label6: "Total commission",
            my_performance_label1: "Number of people under direct supervision",
            my_performance_label2: "Direct betting amount",
            my_performance_label3: "Direct commission",
            my_performance_label4: "Other people",
            my_performance_label5: "Other betting amounts",
            my_performance_label6: "Other commissions",
            all_data_table1: "Join time",
            all_data_table2: "Member ID",
            all_data_table3: "Deposit",
            all_data_table4: "Valid bet",
            all_data_table5: "Total W/L",
            all_data_label1: "Subordinate Deposits",
            all_data_label2: "Direct first deposit",
            all_data_label3: "Other Deposit",
            all_data_label4: "Other first deposit",
            all_data_label5: "Total deposit",
            all_data_label6: "Total first-deposit players",
            direct_finance_table1: "His subordinates",
            direct_finance_table2: "Deposit",
            direct_finance_table3: "Withdraw",
            direct_finance_table4: "Difference",
            direct_finance_table5: "Balance",
            direct_finance_table6: "Time(s)",
            direct_finance_label1: "Total Deposit",
            direct_finance_label2: "Number of deposits",
            direct_finance_label3: "First Deposit",
            direct_finance_label4: "Number of first deposit players",
            direct_finance_label5: "Total withdrawal",
            direct_finance_label6: "Withdrawal times",
            direct_bet_detail: "Betting Details",
            direct_bet_table1: "His subordinates",
            direct_bet_table2: "Valid Bets",
            direct_bet_table3: "Total W/L",
            direct_bet_table4: "Time(s)",
            direct_bet_label1: "Direct valid bets",
            direct_bet_label2: "Other valid bets",
            direct_bet_label3: "Total valid bets",
            direct_bet_label4: "Direct wins/losses",
            direct_bet_label5: "Other wins/losses",
            direct_bet_label6: "Total W/L",
            direct_bet_detail1: "Game platform",
            direct_bet_detail2: "Game name",
            direct_bet_detail3: "Valid Bets",
            direct_bet_detail4: "Win/Loss",
            direct_bet_detail5: "Total valid bets",
            direct_bet_detail6: "Total number of bets",
            direct_bet_detail7: "Total W/L",
            direct_data_date: "Date",
            direct_data_table1: "His subordinates",
            direct_data_table2: "Deposit amount",
            direct_data_table3: "Sign up date",
            direct_data_table4: "Valid bets",
            direct_data_table5: "Login date",
            direct_data_table6: "Current",
            direct_data_table7: "Status",
            direct_data_text1: "Yes",
            direct_data_text2: "No",
            direct_data_text3: "Not allowed to accept prizes",
            direct_data_text4: "Freeze",
            direct_data_text5: "Normal",
            direct_data_text6: "Online",
            direct_data_text7: "Offline",
            direct_data_sum1: "Number of registrations",
            direct_data_sum2: "Number of deposits",
            direct_data_sum3: "Number of first deposit players",
            direct_data_sum4: "Deposit amount",
            direct_data_sum5: "Valid bets",
            direct_award_table1: "Total Claimed",
            direct_award_table2: "Event Claimed",
            direct_award_table3: "Mission Claimed",
            direct_award_table4: "Rebate Claimed",
            direct_award_table5: "VIP Claimed",
            direct_award_table6: "Agent Commission",
            direct_award_table7: "Interest Earnings",
            my_data_text1: "Add direct members",
            my_data_text2: "Number of first deposit players",
            my_data_text3: "Number of deposits",
            my_data_text4: "Deposit amount",
            my_data_text5: "Performance",
            my_data_text6: "Commission",
            my_data_text7: "Data overview",
            my_data_text8: "My team",
            my_data_text9: "Total number of people",
            my_data_text10: "Direct subordinates",
            my_data_text11: "Other subordinates",
            my_data_text12: "Performance",
            my_data_text13: "Total Perf.",
            my_data_text14: "Sub's Perf.",
            my_data_text15: "Others' Perf.",
            my_data_text16: "Commission",
            my_data_text17: "Total Commission",
            my_data_text18: "Direct Commission",
            my_data_text19: "Other Commission",
            my_data_date1: "Yesterday",
            my_data_date2: "Today",
            my_data_date3: "This Week",
            my_data_date4: "Last Week",
            my_data_date5: "This Month",
            my_data_date6: "Last Month",
            performanceDetail: {
                performance: "Performance",
                winLose: "Member profit and loss",
                discount: "Claim discount"
            },
            commissionDetail: {
                member: "Contributors",
                performance: "Performance",
                commission: "Commission",
                gameType: "Game type"
            }
        },
        wallet: {
            all: "ALL",
            wallet: "Main Wallet",
            center_wallet: "central wallet",
            one_click_recycling: "One click to retrieve",
            venue_wallet: "Game Venue Wallet",
            balance: "Current balance",
            placeholder: "Platform Search",
            tips: "Anda hanya boleh mendapatkan gandaan integer baki (iaitu, tiada titik perpuluhan)"
        },
        exchange: {
            exchange: "Withdraw",
            exchange_record: "Withdraw Records",
            audit_record: "Audit Report",
            account_manage: "Manage Account",
            account_balance: "Balance",
            withdrawable_balance: "The balance available for withdrawal",
            need_bet: "Still need to place a bet",
            can_withdraw: "Withdrawable",
            auditing: "Under review",
            detailInfo: "Details",
            standard_withdrawal: "Standard Withdrawal",
            tips1: "Please enter the exchange amount",
            tips2: "Please select a withdrawal account first",
            all: "All",
            exchange_pwd: "Withdrawal Password",
            confirm: "Confirm",
            add_account: "Add new account",
            tips3: "Withdrawal Password Cannot be empty",
            tips4: "incorrect password",
            accumulate_exchange: "Cumulative exchange",
            order_no: "Order No.",
            success: "Succeed",
            fail: "Failure",
            checking: "In review",
            today: "Today",
            yesterday: "Yesterday",
            seven_days: "7 days",
            fifteen_days: "15 days",
            thirty_days: "30 days",
            total_waiting_audit: "Total amount to be audited",
            audit_detail: "Audit details",
            transaction_type: "Transaction Type",
            audit_progress: "Audit progress",
            amount: "Transaction amount",
            audit_multiplier: "Audit multiple",
            to_be_audit: "Awaiting audit",
            audited: "Audited",
            create_time: "Created time",
            exchange_account: "Manage Account",
            digital_currency: "Digital currency",
            add: "Add",
            tips5: "Please enter your Phone account",
            tips6: "Please enter the 11-digit number",
            tips7: "Please enter the 11-digit CPF number",
            tips8: "The PIX account cannot be blank",
            tips9: "Can not be empty",
            add_digital_currency: "Add digital currency",
            tips10: "Please enter your cryptocurrency address",
            tips11: "The address field cannot be blank",
            tips12: "Make sure the currency, protocol and address match, otherwise the amount will not be credited.",
            tips13: "The address cannot be empty",
            tips14: "Only supports adding one CPF account at most",
            tips15: "Name cannot be empty",
            tips16: "Please enter the name",
            deleteTips: "Confirm to delete current account",
            tips17: "The number of accounts added has reached the upper limit",
            tips18: "Please carefully check the name and card number, otherwise it will not be credited",
            tips19: "Only 1 PIX account of PIX-CPF type can be added",
            tips20: "Please check carefully, otherwise it will not be credited.",
            tips21: "Please enter the eleven phone number, starting with 0",
            tips22: "Note: Please ensure that the withdrawal name and withdrawal information are consistent to avoid withdrawal failure.",
            sendTo: "Issued to",
            addWalletBtn: "Confirm",
            detail: {
                title: "Withdrawal details",
                type: "Transaction Type",
                withdraw: "Withdraw",
                methods: "Withdrawal method",
                fee: "Handling fee",
                createTime: "Creation time",
                orderNo: "Order number",
                remark: "Remark"
            }
        },
        recharge: {
            recharge: "Deposit",
            recharge_online: "Online Deposit",
            digital_currency: "Online Banking Payment",
            recharge_record: "Deposit Records",
            recharge_amount: "Deposit Amount",
            recharge_tips: "Bonus event explanation",
            recharge_tipsText: "Deposit according to the recommended amount to receive the corresponding bonus. The bonus amount stacks with the deposit bonus.",
            currency: "BRL",
            terms: "Bonus event explanation",
            recharge_now: "Deposit Now",
            USDT_rate: "USDT rate",
            tips1: "Please fill in the payer's wallet address correctly to receive the money normally.",
            tips2: "Enter the wallet address of the payer",
            tips3: "Please enter the amount",
            tips4: "Please enter address",
            tips5: "Please fill in the TxId of the transaction",
            tips6: "Order has expired, please resubmit the order",
            submit: "Submit",
            total_deposit: "Total deposits",
            recharge_detail: "Deposit details",
            trade_type: "Transaction Type",
            recharge_type: "Recharge method",
            recharge_channel: "Recharge channel",
            create_time: "Created time",
            order_no: "Order No.",
            free: "Free",
            min: "Min",
            max: "Max",
            exchangeRate: "Exchange rate",
            addPoint: "Add point",
            jump_tips: "Click Confirm to jump to the payment page",
            recharge_exchange_rate_tipsText: "Click to switch the exchange currency"
        },
        account: {
            account_detail: "Statement",
            bet_record: "Bet Records",
            personal_report: "Report",
            all: "All",
            time: "Time",
            transaction_type: "Transaction Type",
            detail: "detailed information",
            quantity: "quantity",
            total_deposits: "total deposit",
            accumulated_withdrawals: "Cumulative withdrawals",
            type: "type",
            platform: "platform",
            game: "Games",
            effective_betting: "Valid bet",
            profit_loss: "profit and loss",
            bet_number: "Number of bets",
            bet_total: "Total bets",
            total_win_loss: "Overall win/loss"
        },
        login: {
            password_login: "Password login",
            msg_login: "SMS login",
            tips1: "Enter 6 to 16 characters, letters/numbers/symbols are supported",
            remember_password: "Remember Me",
            forget_password: "Forgot password",
            login: "Login",
            register: "Register an account",
            other_login_methods: "Other login methods",
            tips2: "User length is less than 4 digits",
            tips3: "Password format is incorrect",
            telephone: "phone number",
            enter_password: "Password",
            again_enter_password: "Please confirm the password again, the same as the password!",
            strength: "Strength",
            register2: "Account Register",
            register3: "Register",
            tips4: "Enter 4 to 16 characters, letters/numbers are supported, and the first character must be a letter",
            tips5: "The entered mobile number is incorrect",
            tips6: "Verification code entered is incorrect",
            text1: "I am over 18 years old, have read, and agree to the ",
            agreement: "\u300AUser Agreement\u300B",
            login_now: "Login Now",
            general_registration: "Normal registration",
            mobile_registration: "Register by mobile phone",
            tips7: "Two passwords are inconsistent",
            tips8: "Please check the User Agreement box first",
            tips9: "Password format is incorrect",
            tips10: "The password entered twice is inconsistent",
            tips11: "the phone number is incorrect",
            tips12: "Verification code is incorrect",
            reset_password: "Password reset",
            reset_exchangePwd: "Withdrawal Password reset",
            confirm: "Confirm",
            username: "Member account",
            send_code: "send",
            code: "Captcha",
            tips13: "Pls Enter 6 digits",
            rewardTips: "Registration bonus",
            agreement_btn: "I have read",
            successText: "Verification passed",
            failText: "Verification failed, please try again",
            sliderText: "Drag the slider to complete the puzzle",
            login_pwd: "Login password",
            verify_login_pwd: "Verify Login Password",
            customer_service: "Customer Service"
        },
        side_bar: {
            bet_record: "Bet Records",
            agency: "Agent",
            event_title: "Offer Center",
            event: "Event",
            task: "Mission",
            rebate: "Rebate",
            reward: "Claim",
            history: "History",
            fees: "Interest",
            dealer: "Dealer",
            vip: "VIP",
            pending: "Claim",
            agent: "Agent",
            network: "Network",
            download: "APP download",
            customer_service: "Customer Service",
            faq: "FAQ",
            about_us: "About",
            closed: "Not available yet",
            exchange: "Withdraw",
            account_manage: "Manage Account"
        },
        header_menu: {
            recharge: "Deposit",
            withdraw: "Withdraw",
            login: "Login",
            or: " Or ",
            register: "Register",
            tips: "In game"
        },
        common: {
            confirm: "Confirm",
            cancel: "Cancel",
            no_remind: "No more reminders today",
            pls: "Please",
            add_to: "Add to",
            home_screen: " to home screen",
            no_data: "No data yet",
            tips: "Tips",
            day: "day",
            hour: "hour",
            minutes: "minute",
            second: "second",
            recharge: "Deposit",
            exit: "Log out",
            refresh: "Refresh",
            full_screen: "Full Screen"
        },
        promotion_event: {
            mixed: "All",
            collect_all: "Receive all",
            collect_record: "History",
            coming: "Please stay tuned",
            end: "ended",
            collect: "Receive",
            collected: "Received",
            incomplete: "undone",
            continuous_login: "Log in for",
            day: "day",
            days: "days in a row",
            deposit_required: "Need to recharge",
            bet: "Betting",
            di: "Day",
            mysterious_bonus: "Mystery Bonus",
            total_collect: "Received in total",
            loss: "Yesterday's loss",
            relief: "Today's rescue reward",
            loss_amount: "Amount of loss",
            additional_rewards: "Additional Rewards",
            back: "Back",
            link: "Exclusive link",
            quick_share: "Quick share",
            effective_people: "Effective lower-level people",
            request_qty: "Required quantity",
            activity_conditions: "Activity conditions",
            effective_qty: "Effective promotion number",
            effective_bind_phone: "Effectively promote the number of people bound to mobile phones",
            effective_recharge: "Effective promoter recharge amount",
            effective_bet: "Effective promoter code amount",
            people: "people",
            detail: "Details",
            promotion_tips_title: "What is the number of players effectively promoted? (fulfill all the conditions indicated below)",
            subordinate_recharge: "The subordinate has accumulated deposit",
            subordinate_bet: "The subordinate has accumulated bet",
            maximum: "Maximum",
            aforementioned: "Or the aforementioned",
            more: "More",
            apply: "Apply for discount",
            apply_now: "Apply now",
            apply_placeholder: "Please enter the answer",
            apply_tips: "Please fill in all answers",
            my_referrals: "My Referrals",
            account: "Account",
            accumulated_recharge: "Accumulated recharge",
            accumulated_bets: "Accumulated bets",
            status: "Status",
            efficient: "Efficient",
            invalid: "Invalid",
            balance_time: "Number of applications remaining",
            tips: "Tips",
            tips1: "1. After the promoted people need to bind their mobile phones, the number of people to be promoted will be the effective number;",
            tips2: "2.After the current progress reaches the number of people promoted, you can receive the withdrawable balance CPF in one go\uFF1B",
            rewardAmount: "Reward amount",
            currentProcess: "Current progress",
            bindPhone: "Bind mobile phone",
            receive_success: "Received successfully",
            valid_people: "Valid people",
            registerTime: "Registration time",
            recharge: "Recharge",
            bet: "Bet",
            request_recharge: "Recharge amount",
            tips3: "Recharge {amount} today to get the highest claim amount in the next tier.",
            tips4: "Effective promotion: The subordinates need to recharge {amount}, place bets {bet}, and bind mobile phone.",
            tips5: "Effective promotion: The subordinates need to recharge {amount}, place bets {bet}.",
            break_through_text1: "Today\u2019s game",
            break_through_text2: "Number of levels",
            break_through_text3: "Number of people invited",
            break_through_text4: "Invitation reward amount",
            break_through_text5: "Total coding for breaking through levels",
            break_through_text6: "Extra bonus for passing levels",
            break_through_text7: "Number of levels cleared today",
            break_through_text8: "Reward amount for the number of invitees today",
            break_through_text9: "Total coding for today\u2019s pass",
            break_through_text10: "Today\u2019s level reward",
            break_through_text11: "Received rewards",
            break_through_text12: "Rewards to be claimed",
            break_through_text13: "Same IP",
            balance_relief_fund_text1: "Members who have recharged",
            balance_relief_fund_text2: "Account balance is less than",
            balance_relief_fund_text3: "The proportion of reward recharge amount",
            balance_relief_fund_text4: "Account balance is less than",
            balance_relief_fund_text5: "The coding amount reaches",
            balance_relief_fund_text6: "Reward coding amount proportion",
            balance_relief_fund_text7: "Reward distribution",
            balance_relief_fund_text8: "The system will automatically issue rewards when reached",
            balance_relief_fund_text9: "Members who have not recharged",
            balance_relief_fund_text10: "Reward amount",
            balance_relief_fund_text11: "Calculation of rewards for recharged members: total recharge amount x set ratio or fixed reward amount",
            balance_relief_fund_text12: "For example: Member A has recharged 1000 and the reward distribution ratio is 5%, then he can get the reward: 1000x5%=50",
            balance_relief_fund_text13: "Calculation of rewards for unrecharged members: total coding amount x set ratio or fixed reward amount",
            balance_relief_fund_text14: "For example: Member B has not recharged, coded 500, and the reward distribution ratio is 1.5%, then he can get the reward: 500x1.5%=7.5",
            balance_relief_fund_text15: "Number of times receiving prizes",
            balance_relief_fund_text16: "After a recharged member claims the prize, if the member becomes bankrupt for the second time, he or she needs to top up again to claim the prize.",
            balance_relief_fund_text17: "After a member who has not recharged has claimed the prize, he or she who goes bankrupt for the second time must re-accumulate the code amount before he or she can claim the prize.",
            balance_relief_fund_text18: "Reward amount"
        },
        promotion_task: {
            current_PA: "Current PA",
            reset_PA: "PA reset time",
            collect_all: "Claim All",
            collect_record: "History",
            next: "Go",
            collect: "Receive",
            collected: "Received",
            bonus: "Claim",
            rule_title1: "1\u3001Task time",
            rule_title2: "2\u3001Task conditions\uFF1A",
            rule_title3: "3\u3001Task content\uFF1A",
            news_title: "New player Bonus",
            news_rule_text1: "Limited time mission (valid within",
            news_rule_text2: "days after registration)",
            news_rule_text3: "Complete relevant settings and secure link to our account",
            news_rule_text4: "1.very new registered account can complete the above tasks, and upon completion, will receive a certain amount of bonus. The higher the difficulty, the greater the reward.",
            news_rule_text5: "2.As each account is entirely anonymous, once stolen, resulting in a loss of funds, it will be unrecoverable. Therefore, we mandate linking two-step verification, especially when adding withdrawal addresses, to prove it's a personal operaten and ensure your security.",
            news_rule_text6: "3.Conditions fulfilled to claim directly, and can be claimed directly on any iOS,Android platform; they will expire if not claimed (failure to claim is considered voluntary forfeiture).",
            news_rule_text7: "4.Due to the relatively high bonus for this task, the bonus requires ",
            news_rule_text8: " times audit (i.e., audit, wagering, or valid bets) for withdrawal, without restrictions on game platforms.",
            news_rule_text9: "5.This task is exclusively for the account holder's normal manual operatens; renting, using cheats, bots, cross-account gambling, mutual brushing, arbitrage, API, protocols, exploiting vulnerabilities, group controls, or other technical means are prohibited. Violations will result in the cancellation or deduction of rewards, account freezing, or even placement in a blacklist.",
            news_rule_text10: "6.In order to avoid differences in text understanding, the platform will retain the final interpretation of this event.",
            daily_title: "Daily Mission",
            weekly_title: "Weekly Mission",
            daily_text1: "Long-term tasks (reset every day at 00:00)",
            daily_text2: "Daily completion of deposits, bets, or audit",
            daily_text3: "1.The following tasks can be performed every day, including daily recharge, single-game betting or other betting. After completing the task, you can get a certain amount of rewards. The greater the difficulty, the greater the reward;",
            daily_text4: "2.If you meet the conditions, you can withdraw money directly. Different amounts can be mentioned in one lump sum. It is recommended to download the high-definition version of the app for a more enjoyable experience.",
            daily_text5: "3.iOS, Android, H5, and PC can be collected directly and will become invalid upon expiration (that is, failure to actively collect them will be deemed as giving up);",
            daily_text6: "4\u3001The bonus obtained from this task (excluding the main bonus) must reach",
            daily_text7: "times the current betting amount (i.e. review, betting or valid betting) before it can be withdrawn;",
            daily_text8: "5.This task is only for the account owner to play normally. It is strictly prohibited to use leasing plans, use simulators (fraudulent programs), robots, intentional betting with different accounts, intentional configuration, collaboration, association, agreement, exploiting loopholes, group control or other technical means to participate, otherwise the rewards will be confiscated, frozen or removed from the rewards deductions, and may even be blacklisted.",
            daily_text9: "6.In order to avoid differences in text understanding, the platform will reserve the final right of interpretation of this event.",
            weekly_text1: "Long-term tasks (reset every week at 00:00)",
            weekly_text2: "Weekly completion of deposits, bets, or audit",
            weekly_text3: "1.The following tasks can be performed every week, including weekly recharge, single-game betting or other betting. After completing the task, you can get a certain amount of rewards. The greater the difficulty, the greater the reward;"
        },
        promotion_rebate: {
            today_effective_betting: "Can be collected today",
            collect_all: "Claim All",
            collect_record: "History",
            effective_betting: "Valid Bets",
            rebate_ratio: "Rebate rate",
            can_be_claimed: "Available for collect",
            next_ratio: "Lower ratio"
        },
        promotion_fees: {
            deposited: "Deposited",
            year_rate: "annual interest rate",
            settlement_cycle: "Settlement period",
            accumulated_claimed: "Total claimed",
            deposit: "Deposit",
            withdraw: "Transfer out",
            unclaimed: "Awaiting collection",
            withdrawal_of_interest: "Claim",
            tips1_1: "Interest can be collected after",
            tips1_2: "",
            detail: "Record details",
            rules: "Interest rules",
            tips2: "You can collect it after the countdown is completed.",
            claim_interest: "Receive interest",
            total_income: "Total Earnings",
            time: "Time",
            amount: "Amount",
            hour: "Hour",
            type: "Type",
            quantity: "Amount",
            account_balance: "Account Balance",
            tips3: "Transfers in and out will not undergo verification, only claimed interest is required",
            current_time: "Current time",
            all: "All",
            tips4: "After this deposit, the first interest generated will occur at:",
            min_deposit: "Minimum single transfer amount ",
            min_deposit_end: "integers only",
            deposit_balance: "Transfer in",
            output_value: "Production value",
            tips5: "Once you withdraw, you will lose the interest for the most recent period",
            exchange_pwd: "Withdrawal Password",
            forget_pwd: "Forgot Password",
            support: "support",
            tips6: "At least withdraw 1 amount each time",
            tips7: "The amount entered cannot be empty",
            tups8: "Please enter the 6-digit redemption password",
            rule_title1: "1\u3001Earnings Introduction:",
            rule_title2: "2\u3001Settlement cycle\uFF1A",
            rule_title3: "3\u3001Annual interest rate\uFF1A",
            rule_title4: "4\u3001Calculation formula\uFF1A",
            rule_title5: "5\u3001Example\uFF1A",
            rule_title6: "6\u3001Entry threshold: ",
            rule_title7: "7\u3001Interest interest cap:",
            rule_title8: "8\u3001Collection time\uFF1A",
            rule_title9: "9\u3001Auditing multiple: ",
            rule_title10: "10\u3001Event statement\uFF1A",
            rule_title11: "11\u3001Explanation:",
            rule_text1: "The amount deposited into the interest pool must satisfy at least one full cycle in order to accrue interest.",
            rule_text2: "If transferred in advance, no revenue is calculated for that period.",
            rule_text3: "For example: if the current settlement cycle is ",
            rule_text4: "hours, then the amount transferred at 2023-01-01 00:00:01 will accrue interest in the first period at ",
            rule_text5: "day",
            rule_text6: "",
            rule_text7: "The current interest settlement period is ",
            rule_text8: "hour",
            rule_text9: "Current annual interest rate is",
            rule_text10: "Interest income = deposit amount * annual interest rate / settlement period\uFF1B",
            rule_text11: "A deposited 10,000 on 2023-01-01 00:00:01, the annual interest rate is ",
            rule_text12: "and the settlement period is",
            rule_text13: "hours, then the first interest income is obtained in  ",
            rule_text14: "",
            rule_text15: "Calculated as follows:",
            rule_text16: "Down payment interest=",
            rule_text17: "Each transfer amount must be greater than or equal to",
            rule_text18: "\uFF0C with no upper limit on the transfer amount. The more you transfer, the greater the earnings;",
            rule_text19: "There is no cap on the current interest rate. Remember to collect your income regularly or frequently to avoid missing out on more income! ;",
            rule_text20: "Can claim on the next day, meaning that the interest generated on the same day can be claimed after 00:00 the next day;",
            rule_text21: "The current audition multiple is ",
            rule_text22: " times (betting turnover requirement). This means that the interest received must be bet before withdrawal. BetNo specific valid platformsOnly the received interest requires auditing, while the principal amount transferred in or out does not require auditing;",
            rule_text23: "This function is limited to the account owner for normal game betting. Account leasing, risk-free betting (betting, betting, low-loss betting), malicious arbitrage, use of plug-ins, robots, exploiting protocols, vulnerabilities, interfaces,Group control or other technical means are prohibited. Once verified, the platform reserves the right to terminate member logins, suspend member website usage, and confiscate bonuses and improper profits without prior notice;",
            rule_text24: "After investigation, the platform has the right to terminate member login, suspend member websites, confiscate bonuses and ban games.",
            rule_text25: "When members claim interest rewards, this platform will default to members agreeing and complying with the corresponding conditions and other related regulations. To avoid ambiguity in understanding, this platform reserves the final interpretation of this activity;"
        },
        records: {
            reward: "Claim",
            rebate: "Rebate"
        },
        set_exchange_pwd: {
            title: "Withdrawal Password",
            tips: "It's your first withdrawal, you need to set a withdrawal password first",
            subTitle: "Set Up Withdrawal Password",
            exchange_pwd: "Redeem password",
            confirm_pwd: "Confirm Password",
            confirm: "Confirm",
            tips1: "Two passwords are inconsistent",
            tips2: "Reminder: It is very important to redeem a password, make sure to remember and save it, and do not tell anyone. If there is a loss, the asset will not be recoverable.",
            tips3: "The password length must be 6 digits",
            tips4: "6 digits"
        },
        bottom_menu: {
            index: "Home",
            promotion: "Offers",
            vip: "VIP",
            recharge: "Deposit",
            me: "Profile",
            exchange: "Withdraw",
            rebate: "Rebate",
            task: "Mission",
            agent: "Agent"
        },
        lucky_wheel_activity: {
            spin: `Instant
Draw`,
            text1: "Current Lucky Points",
            text2: "Bets required",
            text3: "to obtain",
            text4: "Lucky Points",
            silver: "Silver",
            gold: "Golden",
            diamond: "Diamond",
            text5: "{amount} Lucky value",
            tab1: "Award Notification",
            tab2: "My Records",
            text6: "get it in "
        },
        pop_red_envelopes: {
            text1: "Rain of red envelopes",
            text2: "OPEN",
            text3: "Congratulations for the prize",
            text4: "The bonus has been deposited into your wallet",
            tips1: "Tips",
            tips2: "After closing, the red envelope in this round no longer appears. When voluntarily abandoning the reward."
        },
        message_center: {
            support: "Support",
            news: "News",
            notification: "Notification",
            marquee: "Marquee",
            feedback: "Feedback to get rewards"
        },
        finish_register: {
            title: "Reminder",
            text: "Registered successfully! Let's play a game now~",
            btn: "Deposit Now"
        },
        newbie_bonus: {
            title: "New Player Bonus",
            paste: "Paste",
            placeholder: "Please enter the redemption code",
            bonus_amount: "Bonus amount",
            btn: "Claim Bonus",
            tips: "Congratulations, you have won {reward} bonus\uFF01"
        },
        claim: {
            title: "Claim",
            reward: "Reward",
            active_level: "Active level",
            time: "Time",
            name: "Name",
            source: "Source",
            status: "Status",
            claim: "Claim",
            detailTitle: "Reward source",
            reward_name: "Reward name",
            reward_time: "Reward time",
            amount: "Amount",
            point: "Active level",
            available_time: "Available time",
            rewards: "Rewards",
            claimable_time: "Claimable time",
            validity_period: "Validity period"
        },
        music: {
            music: "Music",
            cycle: "Cycle",
            shuffle: "Shuffle",
            repeat: "Repeat",
            downloaded: "Downloaded",
            system_music: "System Music",
            my_music: "My Music",
            deleteTips: "Last song,which cannot be deleted"
        },
        add_tips_dialog: {
            title1: "Add to Home Screen",
            subTitle1: '1. Click the "More" icon, then click "Add to Home Screen"',
            subTitle2: '2. Click "Add," then select "Add"',
            text1: "Share...",
            text2: "Find on the webpage",
            text3: "Add to Home Screen",
            text4: "Desktop site",
            text5: "Add to Home Screen",
            text6: "Cancel",
            text7: "Add",
            title2: "Add to main screen",
            text8: "Add to Quick Notes",
            text9: "Find on page",
            text10: "Add to main screen",
            text11: "Bookmark",
            text12: "A shortcut will be added to your home screen for quick access to this website"
        },
        first_charge_pop: {
            title: "First Deposit Extra Reward",
            text1: "First Deposit",
            text2: "Reward Amount",
            btn: "Go"
        },
        tutorial: {
            text: `
        <h1><strong>Example:</strong></h1>
        <p>Assuming the current commission rate for valid bets between 0-10,000 is 100 for every 10,000 bets
            (1%), and for bets above 10,000 is 300 for every 10,000 bets (3%). A is the first to discover
            the opportunity and immediately recruits B1, B2, and B3; B1 further recruits C1 and C2; B2 has
            no subordinates; B3 recruits the strong C3. On the second day, B1's valid bets are 500, B2's
            valid bets are 3,000, B3's valid bets are 2,000, C1's valid bets are 1,000, C2's valid bets are
            2,000, and C3's valid bets reach 20,000.</p><span>The profit calculation between them is as
            follows:</span>
        <ul>
            <li><strong>1. B1's Commission</strong> (direct contributions from C1 and C2) = (1,000+2,000) *
                1% = <em>30</em></li>
            <li><strong>2. B2's Commission</strong> (no subordinates) = (0+0) * 1% = <em>0</em></li>
            <li><strong>3. B3's Commission</strong> (direct contribution from C3) = 20,000 * 3% =
                <em>600</em></li>
            <li><strong>4. A's Commission</strong> (direct contributions from subordinates B1, B2, and B3,
                and other subordinates C1, C2, and C3) are as follows:<ul>
                    <li><strong>(1) A's Direct Commission</strong> (direct contributions from B1, B2, and
                        B3) = (500+3,000+2,000) * 3% = <em>165</em></li>
                    <li><strong>(2) A's Other Commission</strong> (other contributions from C1, C2) =
                        (1,000+2,000) * 2% = <em>60</em></li>
                    <li><strong>(3) A's Total Commission</strong> (direct + other) = 165 + 60 = <em>225</em>
                    </li>
                </ul>
            </li>
            <li><strong>5. Summary:</strong>
                <ul>
                    <li><strong>(1) Direct Team:</strong> Refers to the direct subordinates recruited by A,
                        i.e., the direct relationship with A, collectively referred to as the direct team.
                    </li>
                    <li><strong>(2) Other Teams:</strong> Refers to the subordinates recruited by A's
                        subordinates, which are beyond the other relationship with A, i.e., subordinates of
                        subordinates, subordinates of subordinates of subordinates, and so on, collectively
                        referred to as other teams; because this agency model can recruit subordinates
                        infinitely, for the sake of explanation, this article only takes a 2-tier structure
                        as an example.</li>
                    <li><strong>(3) Explanation of A:</strong> A's direct performance is 5,500 and another
                        performance is 20,000 (due to the strong performance of C3), with a total
                        performance of 28,500, corresponding to a commission rate of 3%. Since B1's total
                        performance is 3,000, only enjoying a 1% commission, while A's total performance is
                        28500, enjoying a 3% commission rate, there is a tier differential between A and B1,
                        the difference being: 3% - 1% = 2%, this difference is the part contributed by C1
                        and C2 to A, so C1 and C2 contribute to A: (1,000+2,000) * 2% = 60, there is no tier
                        differential between A and B3, so C3 contributes no commission to A.</li>
                    <li><strong>(4) Explanation of B1:</strong> B1 has subordinates C1 and C2, with a direct
                        performance of 3,000, corresponding to a commission rate of 1%.</li>
                    <li><strong>(5) Explanation of B2:</strong> B2 may be lazy and not recruit subordinates,
                        thus no income.</li>
                    <li><strong>(6) Explanation of B3:</strong> Although B3 joined late and belongs to A's
                        subordinate, its subordinate C3 is strong, with a direct performance of 20,000,
                        allowing B3 to directly enjoy a higher commission rate of 3%.</li>
                    <li><strong>(7) Rule Summary:</strong> Regardless of when you join, under whose
                        subordinate, and no matter what level you are in, your income is never affected. You
                        no longer suffer from the losses of others' subordinates, and your recruitment is
                        not restricted. This is a fair and just agency model, and joining late does not mean
                        you will always be at the bottom.</li>
                </ul>
            </li>
        </ul>
        `
        },
        dealer: {
            title: "Dealer",
            tutorial: "Tutorial",
            home: "Home",
            review: "Review",
            performance: "My performance",
            member: "My members",
            game: "Game data",
            record: "Get records",
            ladder: "Reward ladder"
        },
        dealer_tutorial: {
            title: "First full red mode",
            text1: "Your first deposit reward: 15/person + additional tier rewards",
            text2: "The reward limit cannot be greater than your own limit",
            ruleTitle: "Your top-up total:",
            ruleText1: "For example, if the general agent has a first-time deposit reward of 15 per person, and if 100 people are developed to recharge, the recharge reward = 100*15=<b>1500</b>, and the lower-level management is allocated a reward of 14 per person, if the manager develops 100 people to recharge, the difference will be obtained 100*(15-14)=100. If the management develops lower-level employees and develops 100 people to recharge, the general agent can get the difference 100*(15-12)=<b>300</b>, and so on; the general agent gets The quota = own 1500 + management balance 100 + employee balance 300 +...",
            ruleText2: "Calculation of other tiered reward difference: According to the number of people and reward configuration, the difference can still be calculated. For example, if the total agent reaches 50 people, the reward is 100, and if the lower-level management set up 50 people, the reward is 90, you can still get <b>10</b> difference"
        },
        dealer_home: {
            dealerId: "Dealer ID",
            superiorId: "Superior ID",
            level: "level",
            firstRecharge: "Your first deposit",
            person: "person",
            complaint: "Complaint",
            camReceive: "Receivable",
            received: "Received",
            myLink: "My link",
            myReview: "My review",
            reviewNum: "Quantity to be reviewed",
            operation: "Operate",
            reviewBtn: "To review",
            reward_setting: "Reward settings",
            firstRecharge_per_reward: "First deposit reward per person",
            firstRecharge_ext_reward: "Extra rewards for first deposit",
            reward_ladder: "Reward ladder",
            check: "Check",
            reward_sum: "Reward statistics",
            personal_reward: "Number of people reward",
            ext_reward: "Additional rewards",
            total_reward: "Total reward"
        },
        dealer_complaint: {
            title1: "Complain to dealer",
            title2: "Complaint record",
            placeholder: "Please enter the complaint content",
            submit: "Submit",
            tips: "In order to ensure the normal operation of the agent, you can file a complaint against the behavior of unscrupulous dealers, and the platform will handle it for you."
        },
        dealer_review: {
            placeholder: "Enter member ID",
            check: "Inquire",
            contact_setting: "Contact settings",
            memberId: "Member ID",
            contactInfo: "Contact information",
            remark: "Remark",
            applyTime: "Application time",
            review: "Review"
        },
        dealer_performance: {
            first_person: "Number of people making first deposit",
            time: "Time",
            dealer_person: "Number of dealers",
            recharge_person: "Number of people making first deposit",
            reward: "Accumulation of rewards"
        },
        dealer_member: {
            placeholder: "Enter member ID",
            check: "Inquire",
            registerTime: "Registration time",
            account: "Member ID",
            accountRemark: "Member account remarks",
            superiorId: "Superior ID",
            isRecharge: "Whether to recharge",
            dealer: "Dealer",
            user: "Ordinary member"
        },
        dealer_record: {
            received: "Commission received",
            receive_time: "Collection time",
            received: "Received"
        },
        dealer_contact_setting: {
            show: "Customer service display",
            contactMethod: "Contact information can be submitted",
            modify: "Revise",
            tips1: "Please select contact information",
            tips2: "Fill in at least one customer service information"
        },
        dealer_ladder: {
            currentNum: "The current number of people making first deposits",
            tab1: "Rewards for people who recharge",
            tab2: "VIP promotion rewards",
            receivedReward: "Commission received",
            levelUpNum: "Number of promotions",
            firstRecharge: "Number of people making first deposit",
            reward: "Award",
            vipLevel: "VIP level"
        },
        dealer_join_dialog: {
            title1: "Contact us",
            title2: "Apply to become a dealer",
            table1: "Contact details",
            table2: "Remark",
            table3: "Application time",
            table4: "State",
            table5: "Operate",
            btn1: "Resubmit",
            btn2: "Check",
            text1: "Select contact information",
            text2: "Fill in contact information",
            text3: "Remark",
            btn3: "Cancel",
            btn4: "Confirm",
            btn5: "Cancel",
            btn6: "Resubmit",
            tips1: "Please select contact information",
            tips2: "Please fill in contact information"
        },
        dealer_review_detail: {
            title: "Review operations",
            account: "Member account",
            applyTime: "Application time",
            contactType: "Contact type",
            contactInfo: "Contact information",
            applyRemark: "Application remark",
            rechargeReward: "First deposit reward",
            person: "person",
            extReward: "Additional rewards",
            lower_recharge_reward_setting: "Lower level first deposit reward configuration",
            lower_recharge_extReward_setting: "Additional bonus configuration for first deposit at lower level",
            rechargePerson: "Number of people recharging",
            myReward: "My reward",
            max_reward: "The maximum reward that can be set",
            next_reward_setting: "Lower level reward settings",
            withdraw_setting: "Withdrawal settings",
            can_withdraw: "Can withdraw cash",
            cannot_withdraw: "Withdrawal is not possible",
            edit_setting: "Edit settings",
            can_edit: "Can edit",
            cannot_edit: "Not editable",
            level_name: "Level name",
            account_remark: "Member account remarks",
            reject: "Reject",
            pass: "Pass",
            tips1: "Please set all lower-level reward settings",
            tips2: "Please set the first deposit reward configuration for the lower level",
            tips3: "Please set the additional reward configuration for the first deposit at the lower level",
            tips4: "Please set edit configuration",
            tips5: "Please enter a level name",
            tips6: "Please set the withdrawal configuration"
        },
        complaint: {
            title: "Complaint",
            site_complaint: "Site complaints",
            email: "Email",
            tipsTitle: "Illustrate",
            tips: "In order to ensure the normal operation of the site, you can lodge a complaint against unscrupulous site behavior and the platform will handle it for you.",
            emailError1: "Email can not be empty",
            emailError2: "Email format is incorrect",
            placeholderText: "Please enter the site complaint content"
        },
        upload: {
            uploading: "uploading...",
            tips1: "The upload size of a single file cannot exceed",
            tips2: "The total file upload size cannot exceed",
            tips3: "File upload size cannot exceed"
        },
        recharge_order_detail: {
            title: "Deposit",
            tips1: "Please open your payment app and scan or copy and paste the QR code below to complete your purchase;",
            tips2: "This QR code can only be paid once. If you need to pay again, please go back and recharge;",
            tips3: "After the payment is successful, you can return to the game lobby and wait for points to be added!",
            effectTime: "Effective time",
            copyText: "Copy QR code",
            copyAddress: "QR code address ...",
            label1: "Order Status",
            label2: "Creation Time",
            label3: "Order Number",
            label4: "Merchant order number",
            waiting: "To be paid",
            success: "Paid",
            warning: "The QR code has expired",
            tips4: "Please return to the lobby to place an order again. The current page will be closed in 10 seconds.",
            tips5: "Select",
            tips6: " Close now ",
            tips7: "Or",
            tips8: " check order",
            tips9: "Successfully received",
            tips10: "The system has automatically assigned you points.",
            tips11: "The current page will be closed in 10 seconds."
        },
        check_pwd_dialog: {
            title: "Enter PIN",
            text1: "Withdrawal Password",
            text2: "For your account safety, please enter the withdrawal password",
            text3: "Forgot password?",
            btnText: "Confirm",
            tips1: "6 digits"
        }
    }, se = {
        home: {
            noData: "Sem Registros",
            loadMore: "Carregar mais",
            moreTipsText1: "A exbir",
            moreTipsText2: "jogos entre",
            moreTipsText3: "Popular jogos",
            maintain: "Manuten\xE7\xE3o",
            all: "Tudo",
            maintainText: "Manuten\xE7\xE3o",
            limitAmountTips: "Seu equil\xEDbrio \xE9 insuficiente {currency}{balance}, apresse -se e ganhe um pequeno dinheiro para matar o quarteto!",
            top: "Topo"
        },
        footer: {
            cassino: "Cassino",
            games: "Jogos",
            support: "Suporte",
            none: "INACESS\xCDVEL POR ENQUANTO",
            funcList: {
                reward: "B\xF4nus",
                rebate: "Rebate",
                vip: "VIP",
                agent: "Convidar",
                event: "Eventos",
                task: "Miss\xE3o"
            },
            gameList: {
                hot: "Popular",
                card: "Cartas",
                fish: "Pescaria",
                digital: "Slots",
                live: "Ao Vivo",
                sports: "Esporte",
                recent: "Recente",
                collect: "Favoritos"
            },
            supportList: {
                support: "Suporte online",
                advise: "B\xF4nus de Sugest\xE3o",
                faq: "Central de Ajuda"
            },
            technicalSupport: "Suporte t\xE9cnico"
        },
        new_player: {
            title: "Beneficios paranovos jogadores",
            proceed: "Prosseguir",
            collect: "Receber",
            collected: "Recebido",
            reward: "B\xF4nus",
            tips1: "N\xE3o estou mais aparecendo hoje",
            tips2: "Ocultar permanentemente",
            collectAll: "Coletar Tudo",
            tip3: "N\xE3o eleg\xEDvel para recebimento",
            tip4: "Vincule a conta de pagamento primeiro"
        },
        search_page: {
            title: "Pesquisar",
            result: "Pesquisar",
            popular: "Popular",
            recent: "Recente",
            favorites: "Favorites",
            record: "Pesquisas Recentes",
            clear: "LIMPAR TODOS OS DADOS"
        },
        sub_game: {
            search: "Procurar jogos",
            all: "Todus"
        },
        vip_item: {
            accumulated_deposits: "SALDO ACUMULADO",
            current_stream: "AUDITORIA ATUAL",
            relegation_deposits: "DEP\xD3SITO PARA MANTER-SE NO N\xCDVEL ATUAL",
            relegation_stream: "AUDITORIA PARA MANTER-SE NO N\xCDVEL ATUAL",
            tips1: "VOC\xCA PRECISA DE",
            tips2: " EM DEP\xD3SITO PARA IR AO PR\xD3XIMO N\xCDVEL",
            tips3: "DE AUDITORIA PARA IR AO PR\xD3XIMO N\xCDVEL",
            maxLevel: "J\xC1 EST\xC1 NO N\xCDVEL M\xC1XIMO",
            privilege: "REGALIAS",
            challenge_game: "JOGOS DE DESAFIO",
            go: "D\xCA UMA OLHADA",
            unset: "VOC\xCA AINDA N\xC3O INSERIU O SEU ANIVERS\xC1RIO",
            tips: "DICAS",
            confirmText: "V\xC1 A CONFIGURA\xC7\xC3O",
            cancelText: "DEIXA PARA PR\xD3XIMA VEZ"
        },
        vip_lucky_wheel: {
            daily_lottery: "SORTEIO DI\xC1RIO",
            upgrade_vip: "PROMOVER PARA VIP",
            current: "ATUAL",
            lottery_draw: "N\xFAmero de sorteios",
            winning_record: "Recorde vencedor",
            tips1: "ATINGIU A QUANTIDADE M\xC1XIMA DE SORTEIO",
            tips2: "PARAB\xC9NS, GANHOU",
            tips3: "REAIS"
        },
        vip_birthday: {
            title: "BRINDE DE ANIVERSARIANTE",
            collect: "Receber",
            collected: "Recebido"
        },
        vip_reward: {
            title: "RECOMPENSA DE VIP",
            upgrade: "Para o pr\xF3ximo n\xEDvel",
            recharge: "Recarregue mais ",
            bet: "APOSTAR NOVAMENTE",
            collect_all: "Coletar Tudo",
            collect_record: "Reg de Coletas",
            level_list: "Lista de n\xEDveis VIP",
            upgrade_rewards: "Recompensas de upgrade",
            relegation_conditions: "Condi\xE7\xF5es de rebaixamento",
            daily_rewards: "B\xF4nus di\xE1rio",
            weekly_rewards: "B\xF4nus semanal",
            monthly_rewards: "B\xF4nus mensal",
            privilege: "Privil\xE9gio VIP",
            rule_description: "Instru\xE7\xF5es sobre regras VIP",
            title1: "REGRAS DE PROMO\xC7\xC3O DE N\xCDVEL",
            text1: "SATISFAZENDO AS CONDI\xC7\xD5ES DE PROMO\xC7\xC3O DE VIP (DEPOIS DE SATISFAZER \xC0S EXIG\xCANCIAS DE AUDITORIA E DE RECARGA), O MEMBRO SER\xC1 PROMOVIDO A VIP CORRESPONDENTE E PODER\xC1 RECEBER B\xD5NUS DE PROMO\xC7\xC3O. CASO O MEMBRO PROMOVER V\xC1RIOS N\xCDVEIS DE UMA VEZ, PODER\xC1 RECEBER DE UMA VEZ OS PR\xCAMIOS E RECOMPENSAS DE CADA N\xCDVEL CORRESPONDENTES.",
            title2: " Sal\xE1rio Semanal",
            text2: "QUANDO A QUANTIA DE RECERGA E DE APOSTAS ATINGIR \xC0 EXG\xCANCIA CORRESPONDENTE AO SEU N\xCDVEL DE VIP. O MEMBRO PODER\xC1 RECEBER A RECOMPENSA SEMANAL. OS DADOS S\xC3O RESETADOS TODAS AS SEGUNDAS-FEIRA \xC0S 00:00 HORAS.",
            title3: "Lulu mensal",
            text3: "QUANDO A QUANTIA DE RECERGA E DE APOSTAS ATINGIR \xC0 EXG\xCANCIA CORRESPONDENTE AO SEU N\xCDVEL DE VIP. O MEMBRO PODER\xC1 RECEBER A RECOMPENSA MENSAL. OS DADOS S\xC3O RESETADOS TODAS OS DIAS PRIMEIRO \xC0S 00:00 HORAS.",
            none_reward: "N\xC3O H\xC1 RECOMPENSA PARA RECEBER",
            rule_detail: `1.Padr\xE3o de promo\xE7\xE3o: atenda aos requisitos da promo\xE7\xE3o VIP (ou seja, a recarga ou apostas efetivas \xE9 atendida com as condi\xE7\xF5es), voc\xEA pode avan\xE7ar para o n\xEDvel VIP correspondente e obter o b\xF4nus de promo\xE7\xE3o correspondente.O b\xF4nus pode ser recebido de tempos em tempos;
        <br/>2.Sal\xE1rio di\xE1rio: Se a recarga di\xE1ria e as apostas v\xE1lidas atenderem aos requisitos salariais di\xE1rios do n\xEDvel atual, voc\xEA poder\xE1 obter o b\xF4nus salarial di\xE1rio correspondente. Se voc\xEA avan\xE7ar para v\xE1rios n\xEDveis consecutivos, s\xF3 poder\xE1 obter o b\xF4nus salarial di\xE1rio do atual n\xEDvel.O b\xF4nus pode ser recebido de tempos em tempos;
        <br/>3.Sal\xE1rio Semanal: Se a recarga semanal e as apostas v\xE1lidas atenderem ao n\xEDvel atual de requisitos salariais semanais, voc\xEA poder\xE1 obter o b\xF4nus salarial semanal correspondente. Se voc\xEA avan\xE7ar para v\xE1rios n\xEDveis consecutivos, poder\xE1 obter apenas o n\xEDvel atual de b\xF4nus salarial semanal.O b\xF4nus pode ser recebido de tempos em tempos;
        <br/>4.Lulu mensal: recarga mensal e apostas efetivas para atender ao n\xEDvel atual do Lulu mensal, e voc\xEA pode obter o b\xF4nus de pr\xEAmio mensal correspondente.O b\xF4nus pode ser recebido de tempos em tempos;
        <br/>5.Tempo de vencimento da recompensa: reservas de longo prazo para b\xF4nus obtidos, voc\xEA precisa receber manualmente;
        <br/>6.Instru\xE7\xF5es para auditoria: o b\xF4nus VIP oferecido pode ser levantado apenas ap\xF3s o cumprimento do requisito de rollover 10x (ou seja, auditoria, apostas ou apostas v\xE1lidas), independentemente da plataforma em que joga;
        <br/>7.Declara\xE7\xF5es: Esta fun\xE7\xE3o est\xE1 limitada \xE0s opera\xE7\xF5es normais dos titulares de contas. \xC9 proibido alugar contas, efetuar apostas sem risco (apostas com contas diferentes, swiping m\xFAtuo e swiping de odds baixas), arbitragem viciosa, utilizar plug-ins, rob\xF4s, explora\xE7\xE3o de acordos, lacunas, interfaces, controlo de grupo ou outros meios t\xE9cnicos de participa\xE7\xE3o; caso contr\xE1rio, uma vez provado, a plataforma tem o direito de proibir os membros de iniciar sess\xE3o, suspender a utiliza\xE7\xE3o do nosso website, e confiscar o b\xF4nus e os ganhos indevidos, sem qualquer aviso especial;
        <br/>8.Instru\xE7\xF5es: Ao reclamar o b\xF4nus VIP, considera-se que os membros aceitam e cumprem as regras correspondentes. A fim de evitar diferen\xE7as na compreens\xE3o do texto, a plataforma reserva o direito final de interpretar esta atividade.`,
            current_level: "kasalukuyang lebel"
        },
        vip_reward_upgrade: {
            level: "n\xEDvel",
            reward_conditions: "CONDI\xC7\xD5ES DA RECOMPENSA",
            operate: "OPERAR",
            recharge: "RECARGA",
            bet: "APOSTAR",
            collected: "Recebido",
            collect: "Receber",
            bonus: "B\xF4nus",
            text1: "Apostas v\xE1lidas di\xE1rias",
            text2: "Apostas v\xE1lidas para a semana",
            text3: "Apostas v\xE1lidas mensais",
            text4: "Dep\xF3sito di\xE1rio",
            text5: "Dep\xF3sito semanal",
            text6: "Dep\xF3sito mensal",
            text7: "Dep\xF3sito necess\xE1rio para promo\xE7\xE3o",
            text8: "Aposte na promo\xE7\xE3o",
            text9: "O valor total da retirada di\xE1ria",
            text10: "O limite superior da retirada di\xE1ria",
            text11: "Taxas de isen\xE7\xE3o di\xE1ria caneta",
            tips_title: "Termos de uso",
            tips_content_recharge: "Para serem promovidos para o n\xEDvel seguinte, os membros devem recarregar mais com base nas recargas acumuladas existentes. Por exemplo: \xC9 necess\xE1rio recarregar 1000 para ser promovido a VIP1, e \xE9 necess\xE1rio recarregar 2000 para ser promovido a VIP2, assim, os membros dever\xE3o recarregar 1000+2000=3000 no total para serem promovidos a VIP2, etc.",
            tips_content_bet: "Para passar para o pr\xF3ximo n\xEDvel, voc\xEA precisa apostar um valor adicional com base na aposta acumulativa. Por exemplo: para fazer upgrade de VIP1 com exig\xEAncia de aposta de 1.000 para VIP2 com exig\xEAncia de 2.000, o membro precisa acumular 1.000 + 2.000 = 3.000 para fazer upgrade para VIP2, e assim por diante.",
            unlimited: "Ilimitado",
            text12: "Dep\xF3sito no m\xEAs passado",
            text13: "Apostei no m\xEAs passado"
        },
        mine: {
            upgrade: "Coletared",
            recharge: "RECARGA NOVAMENTE",
            bet: "APOSTAR NOVAMENTE",
            need_recharge: "Dep\xF3sito necess\xE1rio para promo\xE7\xE3o",
            need_bet: "Aposta necess\xE1ria",
            account_detail: "Detalhes da Conta",
            bet_record: "Apostas",
            personal_report: "Relat\xF3rio Pessoal",
            service_setting: "Configura de saque",
            invite: "Convidar",
            account: "Conta",
            help_center: "FAQ",
            music: "M\xFAsica",
            advise: "B\xF4nus de Sugest\xE3o",
            about_us: "Sobre",
            address_manage: "CONTROLE DE ENDERE\xC7OCS",
            security_center: "Centro de Seguran\xE7a",
            language: "Idioma",
            exit: "Sair",
            tips1: "Deseja terminar sess\xE3o da conta",
            tips: "Dicas",
            id: "ID",
            tab_account: "Dados",
            message: "Mensagens",
            wallet: "Recuperar o saldo",
            exchange: "Saque",
            deposit: "Dep\xF3sito",
            income: "Juros",
            login_pwd: "Palavra-passe de in\xEDcio de sess\xE3o",
            exchange_pwd: "Senha de Saque",
            million_monthly: "milh\xF5es mensais",
            support: "Suporte",
            search_balance: "Recuperar o saldo",
            request_label: "Restantes",
            request_recharge: "Valor restante para aposta"
        },
        advise: {
            message_title: "Centro de mensagens",
            welcome_title: "Servi\xE7o ao cliente dispon\xEDvel para ajudar a solucionar problemas e responder a d\xFAvidas apresentadas.",
            welcome_text: "Apoio online 24/7",
            customer: "servi\xE7o on-line",
            title: "B\xD4NUS DE SUGEST\xD5ES",
            faq: "FAQ",
            read: "Lidos",
            unread: "N\xE3o lidos",
            advise_reward: "Criar",
            my_record: "Meu",
            content_title: "Conte\xFAdo do coment\xE1rio",
            content_tips: "(Relate os problemas e farei melhorias)",
            entry: "Qualquer feedback seu \xE9 muito importante para n\xF3s. Opini\xF5es adotadas resultam em diferentes recompensas em dinheiro dependendo do grau de import\xE2ncia. Convidamos voc\xEA a comentar!",
            annex: "Anexo",
            annex_tips: "(Mais f\xE1cil de adotar)",
            upload_tips: "\xC9 suportado o envio de imagens e v\xEDdeos (tamanho n\xE3o superior a 40MB)",
            advise_title: "Regras para recompensas",
            advise_tips: "Estabelecemos uma grande recompensa para recolher sugest\xF5es que permitam otimizar o sistema e o seu funcionamento, a fim de lhe proporcionar uma melhor experi\xEAncia! Caso sejam adotadas, ser\xE3o concedidas recompensas.",
            submit: "Submeter coment\xE1rio",
            replied: "RESPONDIDO",
            feedback: "CONTE\xDADO DE RELATOS",
            reply: "CONTE\xDADO DE RESPOSTAS",
            submit_tips: "M\xCDNIMO DE 10 PALAVRAS PARA ENTREGAR",
            bonus: "B\xF4nus",
            contact: "Contactar agora"
        },
        mine_info: {
            title: "Informa\xE7\xF5es pessoais",
            avatar: "Mudar Avatar",
            useName: "Nome de Usu\xE1rio",
            realName: "NOME COMPLETO",
            name_tips: "por favor digite seu nome verdadeiro",
            sex: "SEXO",
            man: "Masculino",
            woman: "Feminino",
            birthday: "Selecione a data de nascimento",
            phone: "CELULAR",
            email: "E-MAIL",
            receive_address: "ENDERE\xC7O DE ENTREGA",
            no_address: "SEM INFORMA\xC7\xD5ES DE ENDERE\xC7O DE ENTREGA",
            save: "SALVAR",
            choose_date: "ESCOLHER A DATA",
            email_error_tips: "FORMATO DE E-MAIL INCORRETO",
            cancel: "CANCELAR",
            confirm: "Configurar",
            bindPhone: "Vincular Telefone",
            tips1: "O Facebook n\xE3o pode ficar vazio",
            tips2: "O Telegrama n\xE3o pode ficar vazio",
            tips3: "O Whatsapp n\xE3o pode ficar vazio",
            tips4: "Deseja mesmo retornar?",
            tips5: "As modifica\xE7\xF5es atuais ainda n\xE3o guardadas. Se voltar, as modifica\xE7\xF5es n\xE3o ter\xE3o efeito",
            copySuccess: "Success"
        },
        agent: {
            not_have: "nenhum",
            extension_course: "Rede do Agente",
            change: "Alterar",
            claimable: "Colet\xE1vel",
            direct_subordinate: "Subordinados diretos",
            my_superiors: "Conta Superior",
            unlimited_level_difference: "Diff\xE9rence de niveau infini (N\u0153ud de jour)",
            agency_mode: "Modo de Agente",
            share: "Partilhar",
            agent: "Convidar",
            my_promotion: "Link de Convite",
            my_data: "Meus Dados",
            tutorial: "Tutorial de promo\xE7\xE3o",
            my_performance: "Meu Rendimento",
            tab_commission: "Minha Comiss\xE3o",
            my_member: "Desempenho",
            commission_rate: "Taxa de Comiss\xE3o",
            all_types: "Todo Tipo",
            all_data: "Todos os dados",
            finance: "Finan\xE7as dos Subordinados",
            wagers: "Apostas dos Subordinados",
            stats: "Dados do Subordinado",
            claims: "Resgates dos subordinados",
            account: "Minha identidade",
            superior: "ID superior",
            can_receive: "Colet\xE1vel",
            receive: "Receber",
            save: "Clique Para Salvar",
            my_link: "Meu Link",
            commission: "Comiss\xE3o",
            detail: "Detalhes",
            total_commission: "Comiss\xE3o total",
            received: "Coletar",
            unclaimed: "Coletared",
            member: "MEMBROS",
            total_members: "TOTAL DE MEMBROS",
            direct_members: "MEMBROS DIRETOS",
            other_members: "OUTROS MEMBROS",
            total_income: "TOTAL DE RECEITA",
            direct_income: "RECEITAS DIRETAS",
            other_income: "OUTRAS RECEITAS",
            bet: "Apostas",
            total_effective_bet: "TOTAL DE APOSTAS V\xC1LIDAS",
            total_bet_number: "TOTAL DE TICKET DE APOSTAS",
            total_profit_loss: "BALAN\xC7O",
            more: "MAIS",
            to: "AT\xC9",
            start_date: "HORA DE IN\xCDCIO",
            end_date: "HORA DE T\xC9RMINO",
            all: "Todus",
            time: "TEMPO",
            type: "TIPO",
            bet_amount: "VALOR DE APOSTA",
            bet_number: "QUANTIDADE DE APOSTADORES",
            join_time: "HORA DE INGRESS\xC3O",
            personnel: "MEMBROS",
            number: "N\xEDvel",
            effective_bet_unit: "Desempenho",
            unit: "(Unid: 10,000)",
            per_commission: "Valor do <br> desconto por <br> 10,000",
            collect_record: "Hist\xF3rico",
            search: "Introduza o ID de Membro",
            noData: "Sem Registros",
            collected_commission: "Comiss\xE3o recebida",
            collected_time: "Hora de recolha",
            amount: "Colet\xE1vel",
            myId: "Minha identidade",
            share_title1: "Link promocional de",
            share_title2: "",
            net_profit: "Lucro l\xEDquido",
            total_net_profit: "Lucro l\xEDquido total",
            total_discount: "Desconto total",
            valid_people: "N\xFAmero v\xE1lido de pessoas",
            valid_text1: "Dep\xF3sito v\xE1lido\u2265",
            valid_text2: ", que \xE9 o n\xFAmero v\xE1lido de pessoas",
            deposit_amount: "Valor de recarga",
            agent_tier: "N\xEDvel do Agente",
            promotion_conditions: "Condi\xE7\xF5es da promo\xE7\xE3o<br/>(resultados acumulados)",
            commission_detail_title: "Detalhes da comiss\xE3o",
            commission_detail_endTime: "Data de liquida\xE7\xE3o",
            commission_detail_placeholder: "Insira o ID",
            commission_detail_table1: "ID",
            commission_detail_table2: "Superior",
            commission_detail_table3: "Dados de apostas",
            commission_detail_table4: "Comiss\xE3o",
            commission_detail_label1: "Dados diretos",
            commission_detail_label2: "Outros dados",
            commission_detail_label3: "Dados totais",
            commission_detail_label4: "Comiss\xE3o direta",
            commission_detail_label5: "Outras comiss\xF5es",
            commission_detail_label6: "Comiss\xE3o total",
            my_performance_label1: "N\xFAmero de pessoas sob supervis\xE3o direta",
            my_performance_label2: "Valor da aposta direta",
            my_performance_label3: "Comiss\xE3o direta",
            my_performance_label4: "Outras pessoas",
            my_performance_label5: "Outros valores de apostas",
            my_performance_label6: "Outras comiss\xF5es",
            all_data_table1: "HORA DE INGRESS\xC3O",
            all_data_table2: "ID de membro",
            all_data_table3: "Dep\xF3sito",
            all_data_table4: "Aposta v\xE1lida",
            all_data_table5: "Perdas e ganhos totais",
            all_data_label1: "Recarga Direta",
            all_data_label2: "Primeira recarga direta",
            all_data_label3: "Outro Dep\xF3sito",
            all_data_label4: "Outras recargas iniciais",
            all_data_label5: "Dep\xF3sito Total",
            all_data_label6: "Total de jogadores fazendo primeiros dep\xF3sitos",
            direct_finance_table1: "Subordinados Dele",
            direct_finance_table2: "Dep\xF3sito",
            direct_finance_table3: "Saque",
            direct_finance_table4: "Diferen\xE7a",
            direct_finance_table5: "Saldo",
            direct_finance_table6: "Vezes",
            direct_finance_label1: "Dep\xF3sito Total",
            direct_finance_label2: "Dep\xF3sitos",
            direct_finance_label3: "Dep\xF3sito Inicial",
            direct_finance_label4: "Primeiros Dep\xF3sitos",
            direct_finance_label5: "Total de Saques",
            direct_finance_label6: "N\xFAmero de Saques",
            direct_bet_detail: "Detalhes da aposta",
            direct_bet_table1: "Subordinados Dele",
            direct_bet_table2: "Apostas V\xE1lidas",
            direct_bet_table3: "Total de V/D",
            direct_bet_table4: "Vezes",
            direct_bet_label1: "Aposta v\xE1lida direta",
            direct_bet_label2: "Outras apostas eficazes",
            direct_bet_label3: "Total de apostas v\xE1lidas",
            direct_bet_label4: "V/D diretas",
            direct_bet_label5: "Outras V/D",
            direct_bet_label6: "Total de V/D",
            direct_bet_detail1: "Plataforma de jogo",
            direct_bet_detail2: "Nome do jogo",
            direct_bet_detail3: "Apostas V\xE1lidas",
            direct_bet_detail4: "V/D dos membros",
            direct_bet_detail5: "Total de apostas v\xE1lidas",
            direct_bet_detail6: "Total de apostas",
            direct_bet_detail7: "Total de V/D",
            direct_data_date: "Data",
            direct_data_table1: "Subordinados Dele",
            direct_data_table2: "Dep\xF3sito",
            direct_data_table3: "Data de Cadastro",
            direct_data_table4: "Apostas V\xE1lidas",
            direct_data_table5: "Data de login",
            direct_data_table6: "Atual",
            direct_data_table7: "Estado",
            direct_data_text1: "Sim",
            direct_data_text2: "N\xE3o",
            direct_data_text3: "N\xE3o \xE9 permitido aceitar pr\xEAmios",
            direct_data_text4: "Congelar",
            direct_data_text5: "Normal",
            direct_data_text6: "On-line",
            direct_data_text7: "Desligado",
            direct_data_sum1: "N\xFAmero de inscritos",
            direct_data_sum2: "Dep\xF3sitos",
            direct_data_sum3: "Primeiros Dep\xF3sitos",
            direct_data_sum4: "Dep\xF3sito",
            direct_data_sum5: "Apostas V\xE1lidas",
            direct_award_table1: "Total Recebido",
            direct_award_table2: "Evento Recebido",
            direct_award_table3: "Miss\xE3o Recebida",
            direct_award_table4: "Cashback Recebido",
            direct_award_table5: "VIP Recebido",
            direct_award_table6: "Comiss\xE3o do Agente",
            direct_award_table7: "Juros da Poupan\xE7a",
            my_data_text1: "Adicionar membros diretos",
            my_data_text2: "Primeiros Dep\xF3sitos",
            my_data_text3: "Dep\xF3sitos",
            my_data_text4: "Dep\xF3sito",
            my_data_text5: "Desempenho",
            my_data_text6: "Comiss\xE3o",
            my_data_text7: "Vis\xE3o Geral dos Dados",
            my_data_text8: "Meu Time",
            my_data_text9: "Membros",
            my_data_text10: "Membros Diretos",
            my_data_text11: "Outros Membros",
            my_data_text12: "Desempenho",
            my_data_text13: "Rendimento Total",
            my_data_text14: "D. Direto",
            my_data_text15: "D. dos Outros",
            my_data_text16: "Comiss\xE3o",
            my_data_text17: "Comiss\xF5es Totais",
            my_data_text18: "Comiss\xE3o Direta",
            my_data_text19: "Outra Comiss\xE3o",
            my_data_date1: "Ontem",
            my_data_date2: "Hoje",
            my_data_date3: "Est\xE1 Semana",
            my_data_date4: "\xDAltima Semana",
            my_data_date5: "Este M\xEAs",
            my_data_date6: "M\xEAs Passado",
            performanceDetail: {
                performance: "Rendimento",
                winLose: "Lucro e perda de membro",
                discount: "Resgatar desconto"
            },
            commissionDetail: {
                member: "Colaboradores",
                performance: "Desempenho",
                commission: "Comiss\xE3o",
                gameType: "Tipo de jogo"
            }
        },
        wallet: {
            all: "Tudos",
            wallet: "Carteira central",
            center_wallet: "Carteira central",
            one_click_recycling: "Transfer\xEAncia por um clique",
            venue_wallet: "CARTEIRA NO CENTRO DE JOGOS",
            balance: "Saldo atual",
            placeholder: "Pesquisa de plataforma",
            tips: "Voc\xEA s\xF3 pode recuperar o m\xFAltiplo inteiro do equil\xEDbrio (ou seja, sem ponto decimal)"
        },
        exchange: {
            exchange: "Saque",
            exchange_record: "Registro de Retiradas",
            audit_record: "Registros de Auditoria",
            account_manage: "Gerenciar Conta",
            account_balance: "Saldo da Conta",
            withdrawable_balance: "Saldo dispon\xEDvel para retirada",
            need_bet: "Ainda preciso fazer uma aposta",
            can_withdraw: "Pode ser retirado",
            auditing: "Em curso",
            detailInfo: "Detalhes",
            standard_withdrawal: "Retirada Padr\xE3o",
            tips1: "INSERIR O VALOR DE RESGATE",
            tips2: "Selecione primeiro a conta para levantamento",
            all: "Todus",
            exchange_pwd: "Senha de Saque",
            confirm: "Confirmar",
            add_account: "Adicionar Conta",
            tips3: "CAMPO SENHA N\xC3O PODE SER EM BRANCO",
            tips4: "SENHA N\xC3O CONFERE",
            accumulate_exchange: "Retiradas Acumuladas",
            order_no: "N\xBA do Pedido",
            success: "SUCESSO",
            fail: "Falha",
            checking: "Em curso",
            today: "HOJE",
            yesterday: "ONTEM",
            seven_days: "7 DIAS",
            fifteen_days: "15 DIAS",
            thirty_days: "30 DIAS",
            total_waiting_audit: "Total pendente de auditoria",
            audit_detail: "Detalhes da auditoria",
            transaction_type: "Tipo de Transa\xE7\xE3o",
            audit_progress: "Status da auditoria",
            amount: "Valor da transa\xE7\xE3o",
            audit_multiplier: "Vezes auditado",
            to_be_audit: "N\xE3o Come\xE7ou",
            audited: "Completado",
            create_time: "Hora de Cria\xE7\xE3o",
            exchange_account: "Gerenciar Conta",
            digital_currency: "CRIPTOATIVO",
            add: "Adicionar",
            tips5: "Introduza a sua conta PIX",
            tips6: "Inserir 11 Digitos",
            tips7: "Introduza o n\xFAmero de 11 d\xEDgitos do CPF",
            tips8: "CHAVE PIX N\xC3O PODE SER EM BRANCO",
            tips9: "N\xC3O PODE SER EM BRANCO",
            add_digital_currency: "Adicionar  CRIPTOATIVO",
            tips10: "INFORMAR A CARTEIRA DIGITAL (WALLET)",
            tips11: "ENDERE\xC7O N\xC3O PODE SER EM BRANCO",
            tips12: "CONFIRMAR MOEDA, ACORDO E ENDERE\xC7O COMPAT\xCDVEL, DO CONTR\xC1RIO, O VALOR N\xC3O SER\xC1 ACRESCENTADO.",
            tips13: "ENDERE\xC7O N\xC3O PODE SER EM BRANCO",
            tips14: "Suporta apenas adi\xE7\xE3o de no m\xE1ximo uma conta CPF",
            tips15: "O nome n\xE3o pode ficar vazio",
            tips16: "Introduza o nome",
            deleteTips: "Confirme para excluir a conta atual",
            tips17: "O n\xFAmero de contas adicionadas atingiu o limite m\xE1ximo",
            tips18: "Verifique cuidadosamente o nome e o n\xFAmero do cart\xE3o, caso contr\xE1rio, n\xE3o poder\xE1 ser creditado",
            tips19: "Conta pix do tipo pix-cpf pode adicionar apenas 1",
            tips20: "Verifique cuidadosamente, caso contr\xE1rio, n\xE3o ser\xE1 creditado.",
            tips21: "Please enter the eleven phone number, starting with 0",
            tips22: "Note: Please ensure that the withdrawal name and withdrawal information are consistent to avoid withdrawal failure.",
            sendTo: "Emitindo paraPIX",
            addWalletBtn: "Confirmar",
            detail: {
                title: "Detalhes de Retirada",
                type: "Tipo de transa\xE7\xE3o",
                withdraw: "Retirar",
                methods: "M\xE9todo de retirada",
                fee: "Taxa de manuseio",
                createTime: "Hora de cria\xE7\xE3o",
                orderNo: "N\xFAmero do pedido",
                remark: "Observa\xE7\xE3o"
            }
        },
        recharge: {
            recharge: "Dep\xF3sito",
            recharge_online: "Dep\xF3sito on-line",
            digital_currency: "Pagamento banc\xE1rio on-line",
            recharge_record: "Registro de recarga",
            recharge_amount: "Valor do Dep\xF3sito",
            recharge_tips: "Detalhes adicionais do evento de b\xF3nus",
            recharge_tipsText: "Os membros podem receber os b\xF4nus correspondentes apenas depois de depositarem o montante recomendado. O b\xF3nus adicional e o b\xF3nus de dep\xF3sito podem ser acumulados e oferecidos",
            currency: "REAL BR",
            terms: "Detalhes adicionais do evento de b\xF3nus",
            recharge_now: "Recarregue Agora",
            USDT_rate: "Taxa de c\xE2mbio/ USDT",
            tips1: "Preencha corretamente o endere\xE7o da carteira do pagador para pode ser creditado normalmente",
            tips2: "Introduza o endere\xE7o da carteira do pagador",
            tips3: "INSERIR O VALOR",
            tips4: "INSERIR O ENDERE\xC7O DA CARTEIRA DIGITAL",
            tips5: "Introduza o n.\xBA de encomenda/Token/TxID para verifica\xE7\xE3o do dep\xF3sito",
            tips6: "Pedido Expirado",
            submit: "Entregar",
            total_deposit: "Dep\xF3sito Total",
            recharge_detail: "Detalhes do Dep\xF3sito",
            trade_type: "Tipo de transa\xE7\xE3o",
            recharge_type: "M\xE9todo de Recarga",
            recharge_channel: "Canal de recarga",
            create_time: "Hora de Cria\xE7\xE3o",
            order_no: "N\xBA do Pedido",
            free: "Gr\xE1tis",
            min: "M\xEDnimo",
            max: "M\xE1ximo",
            exchangeRate: "Taxa de c\xE2mbio",
            addPoint: "Cima",
            jump_tips: "Clique em Confirmar para ir para a p\xE1gina de pagamento",
            recharge_exchange_rate_tipsText: "Clique para mudar a moeda de c\xE2mbio"
        },
        account: {
            account_detail: "Detalhes da Conta",
            bet_record: "Apostas",
            personal_report: "Relat\xF3rio Pessoal",
            all: "Todus",
            time: "DATA",
            transaction_type: "Tipos",
            detail: "Detalhes",
            quantity: "Quantia",
            total_deposits: "Dep\xF3sito Total",
            accumulated_withdrawals: "Retiradas Acumuladas",
            type: "Todu Tipos",
            platform: "Plataformas",
            game: "JOGOS",
            effective_betting: "Apostas V\xE1lidas",
            profit_loss: "Ganhos e Perdas",
            bet_number: "Total de Apostas V\xE1lidas",
            bet_total: "N\xFAmero total de apostas efetuadas",
            total_win_loss: "Vit\xF3rias/Perdas Total"
        },
        login: {
            password_login: "LOGIN COM SENHA",
            msg_login: "LOGIN COM SMS",
            tips1: "6-16 caracteres, incluindo pelo menos duas letras/n\xFAmeros/s\xEDmbolos",
            remember_password: "Lembrar Senha",
            forget_password: "Esqueceu a Senha",
            login: "Login",
            register: "Registra uma Conta",
            other_login_methods: "Outros m\xE9todos de in\xEDcio de sess\xE3o",
            tips2: "USU\xC1RIO MENOR QUE 4 D\xCDGITOS",
            tips3: "FORMATO DE SENHA INCORRETO",
            telephone: "N\xDAMERO DE CELULAR",
            enter_password: "Senha",
            again_enter_password: "Confirme a senha novamente, o mesmo que a senha!",
            strength: "For\xE7a",
            register2: "Registre sua conta",
            register3: "Registro",
            tips4: "4-16 caracteres, incluindo pelo menos duas letras/n\xFAmeros/s\xEDmbolos",
            tips5: "O formato do n\xFAmero de telefone est\xE1 incorreto",
            tips6: "C\xD3DIGO DE CONFIRMA\xC7\xC3O INCORRETO",
            text1: "Tenho 18 anos, li e concordo com",
            agreement: "\u300AContrato do usu\xE1rio\u300B",
            login_now: "Login Agora",
            general_registration: "REGISTRO COMUM",
            mobile_registration: "REGISTRO COM CELULAR",
            tips7: "A SENHA REPETIDA N\xC3O CONFERE",
            tips8: "FAVOR CONCORDAR O TERMO DE USO",
            tips9: "FORMATO DA SENHA INCORRETO",
            tips10: "A SENHA REPETIDA N\xC3O CONFERE",
            tips11: "CELULAR INCORRETO",
            tips12: "C\xD3DIGO DE CONFIRMA\xC7\xC3O INCORRETO",
            reset_password: "RESETAR A SENHA",
            reset_exchangePwd: "Redefinir senha de resgate",
            confirm: "CONFIRMAR",
            username: "Nome de Usu\xE1rio",
            send_code: "ENVIAR",
            code: "C\xD3DIGO DE CONFIRMA\xC7\xC3O",
            tips13: "Insira 6 d\xEDgitos",
            rewardTips: "B\xF4nus de cadastro",
            agreement_btn: "Lido e Compreendido",
            successText: "Verifica\xE7\xE3o aprovada",
            failText: "Falha na verifica\xE7\xE3o. Por favor tente novamente",
            sliderText: "Arraste o controle deslizante para completar o quebra-cabe\xE7a",
            login_pwd: "Palavra-passe de in\xEDcio de sess\xE3o",
            verify_login_pwd: "Verifica a senha",
            customer_service: "Atendimento ao cliente"
        },
        side_bar: {
            bet_record: "Apostas",
            agency: "Agente",
            event_title: "Promo\xE7\xE3o",
            event: "Evento",
            task: "Miss\xE3o",
            rebate: "Rebate",
            reward: "Pendente",
            history: "Reg de Coletas",
            fees: "Juros",
            dealer: "Distribuidor",
            vip: "VIP",
            pending: "Pendente",
            agent: "Convide",
            network: "Status da Rede",
            download: "Baixar APP",
            customer_service: "Suporte",
            faq: "FAQ",
            about_us: "Sobre ",
            closed: "EM DESENVOLVIMENTO",
            exchange: "Withdraw",
            account_manage: "Gerenciar Conta"
        },
        header_menu: {
            recharge: "Dep\xF3sito",
            withdraw: "Saque",
            login: "Entrar",
            or: " Ou ",
            register: "Registro",
            tips: "Usar no jogo"
        },
        common: {
            confirm: "Confirmar",
            cancel: "Cancelar",
            no_remind: "N\xE3o estou mais aparecendo hoje",
            pls: "FAVOR",
            add_to: "Adicionar",
            home_screen: "VOLTAR PARA HOME",
            no_data: "SEM DADOS",
            tips: "DICAS",
            day: "Dia",
            hour: "HORA",
            minutes: "MINUTO",
            second: "SEGUNDOS",
            recharge: "Dep\xF3sito",
            exit: "Terminar sess\xE3o",
            refresh: "Atualizar",
            full_screen: "Ecr\xE3 inteiro"
        },
        promotion_event: {
            mixed: "Misto",
            collect_all: "Coletar Tudo",
            collect_record: "Reg de Coletas",
            coming: "AGURADEM",
            end: "T\xC9RMINO",
            collect: "Receber ",
            collected: "Recebido",
            incomplete: "N\xC3O CONCLU\xCDDO",
            continuous_login: "FAZER LOGIN",
            day: "DIA",
            days: "DIAS",
            deposit_required: "PRECISA RECARREGAR",
            bet: "APOSTAR",
            di: "DIA",
            mysterious_bonus: "B\xD4NUS SURPRESO",
            total_collect: "TOTAL J\xC1 RESGATADO",
            loss: "Perda de ontem",
            relief: "Recompensa de resgate de hoje",
            loss_amount: "Quantidade de perda",
            additional_rewards: "Recompensas adicionais",
            back: "Retornar",
            link: "Link exclusivo",
            quick_share: "Partilha r\xE1pida",
            effective_people: "Pessoas de n\xEDvel inferior eficazes",
            request_qty: "Quantidade requerida",
            activity_conditions: "Condi\xE7\xF5es de atividade",
            effective_qty: "N\xFAmero de promo\xE7\xE3o efetivo",
            effective_bind_phone: "Promover eficazmente o n\xFAmero de pessoas ligadas aos telem\xF3veis",
            effective_recharge: "Valor efetivo de recarga do promotor",
            effective_bet: "Quantidade efetiva do c\xF3digo do promotor",
            people: "pessoas",
            detail: "Detalhes",
            promotion_tips_title: "Qual \xE9 o n\xFAmero de jogadores efetivamente promovidos?(cumprir todas as condi\xE7\xF5es indicadas abaixo)",
            subordinate_recharge: "O subordinado acumulou recargas",
            subordinate_bet: "O subordinado acumulou apostas",
            maximum: "M\xE1xima",
            aforementioned: "Ou o acima mencionado",
            more: "Mais",
            apply: "Solicite desconto",
            apply_now: "Aplique agora",
            apply_placeholder: "Por favor insira a resposta",
            apply_tips: "Por favor preencha todas as respostas",
            my_referrals: "Meus Indicados",
            account: "Conta",
            accumulated_recharge: "Recarga acumulada",
            accumulated_bets: "Apostas acumuladas",
            status: "Status",
            efficient: "Eficiente",
            invalid: "Invavlid",
            balance_time: "N\xFAmero de inscri\xE7\xF5es restantes",
            tips: "Pontas",
            tips1: "1. Depois que as pessoas promovidas precisarem vincular seus celulares, o n\xFAmero de pessoas a serem promovidas ser\xE1 o n\xFAmero efetivo;",
            tips2: "2. Ap\xF3s o avan\xE7o atual atingir o n\xFAmero de pessoas promovidas, voc\xEA poder\xE1 receber o CPF do saldo sac\xE1vel de uma s\xF3 vez;",
            rewardAmount: "Valor da recompensa",
            currentProcess: "Progresso atual",
            bindPhone: "Vincular celular",
            receive_success: "Recebido com sucesso",
            valid_people: "N\xFAmero v\xE1lido de pessoas",
            registerTime: "Hora de registro",
            recharge: "Recarregue",
            bet: "Aposta",
            request_recharge: "Valor de recarga",
            tips3: "Recarregue {amount} hoje para obter o valor de reivindica\xE7\xE3o mais alto no pr\xF3ximo n\xEDvel.",
            tips4: "Promo\xE7\xE3o eficaz: os subordinados precisam recarregar {amount}, fazer apostas {bet} e vincular o celular.",
            tips5: "Promo\xE7\xE3o eficaz: os subordinados precisam recarregar {amount}, fazer apostas {bet}.",
            break_through_text1: "O jogo de hoje",
            break_through_text2: "N\xFAmero de n\xEDveis",
            break_through_text3: "N\xFAmero de pessoas convidadas",
            break_through_text4: "Valor da recompensa do convite",
            break_through_text5: "Codifica\xE7\xE3o total para romper n\xEDveis",
            break_through_text6: "B\xF4nus extra para passar de n\xEDvel",
            break_through_text7: "N\xFAmero de n\xEDveis limpos hoje",
            break_through_text8: "Valor da recompensa pelo n\xFAmero de convidados hoje",
            break_through_text9: "Codifica\xE7\xE3o total para o passe de hoje",
            break_through_text10: "Recompensa de n\xEDvel de hoje",
            break_through_text11: "Recompensas recebidas",
            break_through_text12: "Recompensas a serem reivindicadas",
            break_through_text13: "Mesmo IP",
            balance_relief_fund_text1: "Membros que recarregaram",
            balance_relief_fund_text2: "O saldo da conta \xE9 menor que",
            balance_relief_fund_text3: "A propor\xE7\xE3o do valor de recarga de recompensa",
            balance_relief_fund_text4: "O saldo da conta \xE9 menor que",
            balance_relief_fund_text5: "A quantidade de codifica\xE7\xE3o atinge",
            balance_relief_fund_text6: "Propor\xE7\xE3o do valor da codifica\xE7\xE3o de recompensa",
            balance_relief_fund_text7: "Distribui\xE7\xE3o de recompensas",
            balance_relief_fund_text8: "O sistema emitir\xE1 recompensas automaticamente quando alcan\xE7ado",
            balance_relief_fund_text9: "Membros que n\xE3o recarregaram",
            balance_relief_fund_text10: "Valor da recompensa",
            balance_relief_fund_text11: "C\xE1lculo de recompensas para membros recarregados: valor total de recarga x propor\xE7\xE3o definida ou valor fixo de recompensa",
            balance_relief_fund_text12: "Por exemplo: O membro A recarregou 1.000 e a propor\xE7\xE3o de distribui\xE7\xE3o de recompensa \xE9 de 5%, ent\xE3o ele pode receber a recompensa: 1.000x5% = 50",
            balance_relief_fund_text13: "C\xE1lculo de recompensas para membros n\xE3o cobrados: valor total de codifica\xE7\xE3o x propor\xE7\xE3o definida ou valor fixo de recompensa",
            balance_relief_fund_text14: "Por exemplo: o membro B n\xE3o recarregou, codificou 500 e a propor\xE7\xE3o de distribui\xE7\xE3o de recompensa \xE9 de 1,5%, ent\xE3o ele pode receber a recompensa: 500x1,5%=7,5",
            balance_relief_fund_text15: "N\xFAmero de vezes que recebeu pr\xEAmios",
            balance_relief_fund_text16: "Depois que um membro recarregado reivindicar o pr\xEAmio, se o membro falir pela segunda vez, ele precisar\xE1 recarregar novamente para reivindicar o pr\xEAmio.",
            balance_relief_fund_text17: "Depois que um membro que n\xE3o recarregou tiver reivindicado o pr\xEAmio, aquele que falir pela segunda vez dever\xE1 acumular novamente o valor do c\xF3digo antes de poder reivindicar o pr\xEAmio.",
            balance_relief_fund_text18: "Valor da recompensa"
        },
        promotion_task: {
            current_PA: "PA Atual",
            reset_PA: "Hor\xE1rio de retomar PA",
            collect_all: "Coletar Tudo",
            collect_record: "Reg de Coletas",
            next: "Prosseguir",
            collect: "Receber ",
            collected: "Recebido",
            bonus: "B\xF4nus",
            rule_title1: "1\u3001Hora da tarefa",
            rule_title2: "2\u3001Condi\xE7\xF5es da tarefa\uFF1A",
            rule_title3: "3\u3001Conte\xFAdo da tarefa\uFF1A",
            news_title: "Beneficios paranovos jogadores",
            news_rule_text1: "Tarefas com tempo limitado (v\xE1lido durante ",
            news_rule_text2: "ap\xF3s o registo)",
            news_rule_text3: "Complete as defini\xE7\xF5es relevantes e a liga\xE7\xE3o de seguran\xE7a da nossa conta",
            news_rule_text4: "1.Todas as Membros rec\xE9m-registrados completar as tarefas acima mencionadas e receber um determinado montante de b\xF4nus ap\xF3s a conclus\xE3o da tarefa, quanto maior for a dificuldade, maior ser\xE1 a recompensa.",
            news_rule_text5: "2.Visto que cada conta \xE9 completamente an\xF3nima, se a mesma for roubada, n\xE3o ser\xE1 poss\xEDvel recuperar a perda de fundos resultante do roubo. Por conseguinte, impusemos um processo de verifica\xE7\xE3o das contas em duas etapas, em particular a inclus\xE3o do e-mail de pagamento para validar as a\xE7\xF5es realizadas pelo propriet\xE1rio da conta e garantir a seguran\xE7a da sua conta.",
            news_rule_text6: "3.Receber diretamente quando as condi\xE7\xF5es s\xE3o cumpridas. Pode receber diretamente em qualquer um dos pontos das iOS,Android,H5,PC, os fundos s\xE3o considerados nulos quando expirados (considerados voluntariamente perdidos quando n\xE3o recolhidos pelo utilizador).",
            news_rule_text7: "4.Devido ao elevado b\xF3nus atribu\xEDdo por esta miss\xE3o, o b\xF4nus oferecido necessita de",
            news_rule_text8: "X corrente (ou seja, auditoria, participa\xE7\xF5es ou apostas v\xE1lidas) para poder receber o dinheiro. As participa\xE7\xF5es n\xE3o est\xE3o limitadas a plataformas espec\xEDficas.",
            news_rule_text9: "5.Esta miss\xF5es tem utiliza\xE7\xE3o limitada ao propriet\xE1rio da conta para uma jogabilidade normal. O recurso a esquemas de aluguer, a utiliza\xE7\xE3o de simuladores (programas de burla), robots, apostas intencionais com contas diferentes, configura\xE7\xF5es intencionais, concerta\xE7\xE3o, associa\xE7\xE3o, acordo, utiliza\xE7\xE3o de lacunas, controlo de grupo ou outros meios t\xE9cnicos de participa\xE7\xE3o s\xE3o estritamente proibidos, caso contr\xE1rio, as recompensas ser\xE3o confiscadas, congeladas ou deduzidas da recompensa, ou as contas poder\xE3o mesmo ser postas na lista negra.",
            news_rule_text10: "6.Para evitar diferen\xE7as no entendimento do texto, a plataforma manter\xE1 a interpreta\xE7\xE3o final deste evento.",
            daily_title: "Miss\xE3o Di\xE1rio",
            weekly_title: "Miss\xE3o SEMANAL",
            daily_text1: "Miss\xE3o de longo prazo(Redefinir todos os dias \xE0s 00:00)",
            daily_text2: "RECARGA INTEGRAL DI\xC1RIO, PODEM SER RECARGA OU AUDITORIA",
            daily_text3: "1.DIARIAMENTE PODE REALIZAR AS SEGUINTES TAREFAS: RECARGA DI\xC1RIA, APOSTA SINGULAR OU OUTRAS APOSTAS. CONCLUINDO AS TAREFAS, PODE PLEITEAR AS RECOMPENSAS. QUANTO MAIOR A DIFICULDADE DA TAREFA, MAIOR O VALOR DA RECOMPENSA.",
            daily_text4: "2.CASO ATINGIR AS EXIG\xCANCIAS, PODE SOLICITAR O RESGATE. VALORES DIFERENTES PODE SOLICITAR SAQUE POR TRANSA\xC7\xC3O. RECOMENDAMOS QUE BAIXE O APP DE ALTA RESOLU\xC7\xC3O, EXPLORANDO O M\xC1XIMO DE DIVERS\xC3O.",
            daily_text5: "3.IOS, ANDROID, H5 OU PC. MONTANTES VENCIDOS CONSIDERAM DESIST\xCANCIA (O N\xC3O RESGATE CONSIDERA COMO DESIST\xCANCIA POR PARTE DE USU\xC1RIO)",
            daily_text6: "4\u3001AS RECOMPENSAS DA PRESENTE TAREFA (O MONTANTE PRINCIPAL N\xC3O INCLUSO), S\xD3 \xC9 POSS\xCDVEL O RESGATE DEPOIS DE ATINGIR",
            daily_text7: "X EM VALORES DE APOSTAS (QUE S\xC3O AN\xC1LISE, APOSTAS OU APOSTAS V\xC1LIDAS)",
            daily_text8: "5.Esta miss\xF5es tem utiliza\xE7\xE3o limitada ao propriet\xE1rio da conta para uma jogabilidade normal. O recurso a esquemas de aluguer, a utiliza\xE7\xE3o de simuladores (programas de burla), robots, apostas intencionais com contas diferentes, configura\xE7\xF5es intencionais, concerta\xE7\xE3o, associa\xE7\xE3o, acordo, utiliza\xE7\xE3o de lacunas, controlo de grupo ou outros meios t\xE9cnicos de participa\xE7\xE3o s\xE3o estritamente proibidos, caso contr\xE1rio, as recompensas ser\xE3o confiscadas, congeladas ou deduzidas da recompensa, ou as contas poder\xE3o mesmo ser postas na lista negra.",
            daily_text9: "6.Para evitar diferen\xE7as no entendimento do texto, a plataforma manter\xE1 a interpreta\xE7\xE3o final deste evento.",
            weekly_text1: "Miss\xE3o de longo prazo(Redefinir todos os dias \xE0s 00:00)",
            weekly_text2: "RECARGA INTEGRAL SEMANAL, PODEM SER RECARGA OU AUDITORIA",
            weekly_text3: "1.SEMANALMENTE PODE REALIZAR AS SEGUINTES TAREFAS: RECARGA DI\xC1RIA, APOSTA SINGULAR OU OUTRAS APOSTAS. CONCLUINDO AS TAREFAS, PODE PLEITEAR AS RECOMPENSAS. QUANTO MAIOR A DIFICULDADE DA TAREFA, MAIOR O VALOR DA RECOMPENSA."
        },
        promotion_rebate: {
            today_effective_betting: "APOSTA V\xC1LIDA DO DIA",
            collect_all: "Coletar Tudo",
            collect_record: "Reg de Coletas",
            effective_betting: "Valid bet",
            rebate_ratio: "Taxa de Cashback",
            can_be_claimed: "Available for collect",
            next_ratio: "Lower ratio"
        },
        promotion_fees: {
            deposited: "INSERIDO",
            year_rate: "JUROS ANUAL",
            settlement_cycle: "FECHAMENTO PERI\xD3DICA",
            accumulated_claimed: "SAQUES ACUMULADOS",
            deposit: "DEP\xD3SITO",
            withdraw: "Retirar",
            unclaimed: "A RECEBER",
            withdrawal_of_interest: "Receber",
            tips1_1: "PODER\xC1 RESGATAR OS JUROS AP\xD3S \xC0S ",
            tips1_2: "HORAS",
            detail: "DETALHES",
            rules: "REGRAS",
            tips2: "PODER\xC1 RESGATAR AO CONCLUIR A CONTAGEM REGRESSIVA",
            claim_interest: "Receber JUROS",
            total_income: "TOTAL DE RECEITA",
            time: "Horas",
            amount: "Quantia",
            hour: "HORA",
            type: "Tipos",
            quantity: "QUANTIDADE",
            account_balance: "SALDO DA CONTA",
            tips3: "N\xC3O HAVER\xC1 AUDITORIA SOBRE DEP\xD3SITOS E SAQUES. SOMENTE OS JUROS SER\xC3O AUDITADOS",
            current_time: "TEMPO ATUAL",
            all: "Todus",
            tips4: "TEMPO ESTIMADO DA CHEGADA DOS JUROS",
            min_deposit: "DEP\xD3SITO M\xCDNIMO POR VEZ",
            min_deposit_end: "",
            deposit_balance: "SALDO DEPOSIT\xC1VEL",
            output_value: "VALOR DE SA\xCDDA",
            tips5: "CASO REALIZAR O SAQUE, PERDER\xC1 OS JUROS DO \xDALTIMO PER\xCDODO",
            exchange_pwd: "SENHA PARA SAQUE",
            forget_pwd: "ESQUECI A SENHA",
            support: "SUPORTE",
            tips6: "VALOR M\xCDNIMO DE SAQUE POR VEZ 1",
            tips7: "CAMPO VALOR N\xC3O PODE SER EM BRANCO",
            tups8: "FAVOR INSERIR A SENHA DE 6 CARACTERES DE RESGATE",
            rule_title1: "1\u3001Introdu\xE7\xE3o \xE0 renda\uFF1A",
            rule_title2: "2\u3001Ciclo de liquida\xE7\xE3o\uFF1A",
            rule_title3: "3\u3001Taxa de juros anual\uFF1A",
            rule_title4: "4\u3001F\xF3rmula de c\xE1lculo\uFF1A",
            rule_title5: "5\u3001Exemplo\uFF1A",
            rule_title6: "6\u3001Limiar de torneamento\uFF1A",
            rule_title7: "7\u3001Limite de juros\uFF1A",
            rule_title8: "8\u3001Receba tempo\uFF1A",
            rule_title9: "9\u3001Auditoria m\xFAltipla\uFF1A",
            rule_title10: "10\u3001Declara\xE7\xE3o do evento\uFF1A",
            rule_title11: "11\u3001Explica\xE7\xE3o\uFF1A",
            rule_text1: "O valor depositado no tesouro de juros deve satisfazer pelo menos um ciclo completo para gerar juros. ",
            rule_text2: "Se for transferido antecipadamente, a renda n\xE3o ser\xE1 calculada nesse ciclo. ",
            rule_text3: "Por exemplo: o ciclo de liquida\xE7\xE3o atual \xE9 de ",
            rule_text4: " horas, ent\xE3o 2023-01-01 00:00:01 O valor transferido acumular\xE1 juros no primeiro ciclo em",
            rule_text5: "Dia",
            rule_text6: " ",
            rule_text7: "O ciclo de liquida\xE7\xE3o dos juros atuais \xE9 de ",
            rule_text8: " ",
            rule_text9: "A taxa de juros anual atual \xE9",
            rule_text10: "Receita de juros = valor do dep\xF3sito * Ciclo anual de taxa de juros / liquida\xE7\xE3o;",
            rule_text11: "A deposita 10.000 em 01-01-2023 00:00:01, a taxa de juros anual \xE9",
            rule_text12: "e o per\xEDodo de liquida\xE7\xE3o \xE9 ",
            rule_text13: "horas, ent\xE3o a primeira receita de juros \xE9 obtida em",
            rule_text14: " ",
            rule_text15: "O c\xE1lculo \xE9 o seguinte:",
            rule_text16: "Primeiros juros =",
            rule_text17: "A quantidade de cada transfer\xEAncia deve ser maior que igual a",
            rule_text18: "\uFF0C a quantidade ilimitada do valor da transfer\xEAncia, quanto maior a maior renda;",
            rule_text19: "O interesse atual n\xE3o \xE9 limitado, lembre -se de receber a renda regular ou frequentemente, para n\xE3o perder mais renda!",
            rule_text20: "Atualmente, \xE9 coletado no dia seguinte, ou seja, o interesse gerado naquele dia e n\xE3o ser\xE1 coletado at\xE9 0 horas no dia seguinte;",
            rule_text21: "O m\xFAltiplo de audi\xE7\xE3o atual \xE9",
            rule_text22: " Times (requisitos de fluxo de apostas), ou seja, os juros recebidos, voc\xEA precisa obter a apostaPlataforma v\xE1lida ilimitadaO interesse limitado ao interesse que voc\xEA recebe \xE9 necess\xE1rio e o principal que \xE9 transferido para a transfer\xEAncia n\xE3o tem requisitos para revis\xE3o;",
            rule_text23: "Esta fun\xE7\xE3o \xE9 limitada \xE0 conta.  Tenho uma apostas normal de jogo e \xE9 proibido alugar uma conta, sem apostas de risco (para jogos de azar, emparelhamento, baixa compensa\xE7\xE3o, escovar \xE1gua), Arbitragem maliciosa, usando processos de plug -in, rob\xF4s, rob\xF4s utilizam acordos, vulnerabilidades, interfaces,Controle de grupo ou outros meios t\xE9cnicos para participar. ",
            rule_text24: "Depois que a investiga\xE7\xE3o \xE9 verdadeira, a plataforma tem o direito de rescindir o login dos membros, suspender o membro de sites e confiscar b\xF4nus e lucratividade inadequada.",
            rule_text25: "Quando os membros recebem recompensas do tesouro de juros, essa plataforma ser\xE1 o consentimento dos membros padr\xE3o e cumprir\xE1 condi\xE7\xF5es relevantes, como condi\xE7\xF5es correspondentes;"
        },
        records: {
            reward: "B\xD4NUS",
            rebate: "Rebate"
        },
        set_exchange_pwd: {
            title: "Senha de Saque",
            tips: "Voc\xEA \xE9 a primeira retirada, voc\xEA precisa definir a senha de retirada primeiro",
            subTitle: "Defina sua senha de saque",
            exchange_pwd: "Senha de Saque",
            confirm_pwd: "Confirme sua senha",
            confirm: "Confirmar",
            tips1: "As senhas inseridas duas vezes s\xE3o inconsistentes",
            tips2: "Lembrete caloroso: A senha de resgate \xE9 muito importante. Lembre-se de lembr\xE1-la e guard\xE1-la. N\xE3o conte a ningu\xE9m. Se ocorrer uma perda, os ativos n\xE3o ser\xE3o recuperados.",
            tips3: "O comprimento da senha deve ter 6 n\xFAmeros",
            tips4: "6 n\xFAmeros"
        },
        bottom_menu: {
            index: "Inicio",
            promotion: "Promo\xE7\xE3o",
            vip: "VIP",
            recharge: "Dep\xF3sito",
            me: "Perfil",
            exchange: "Saque",
            rebate: "Rebate",
            task: "Miss\xE3o",
            agent: "Convide"
        },
        lucky_wheel_activity: {
            spin: `SORT
EIO`,
            text1: "Pontos de sorte atuais",
            text2: "Ainda precisa de apostar",
            text3: "para obter",
            text4: "Pontos de sorte",
            silver: "Prata",
            gold: "Ouro",
            diamond: "Diamante",
            text5: "{amount} Pontos de sorte",
            tab1: "Notifica\xE7\xE3o de Pr\xEAmio",
            tab2: "NotifiMeus Registros",
            text6: "obt\xEA -lo em"
        },
        pop_red_envelopes: {
            text1: "Chuva de pacotes vermelhos",
            text2: "ABRIR",
            text3: "PARAB\xC9NS pelo pr\xEAmio",
            text4: "O b\xF4nus foi depositado na sua carteira",
            tips1: "Dicas",
            tips2: "Ap\xF3s o fechamento, o envelope vermelho nesta rodada n\xE3o aparece mais. Quando abandonar voluntariamente a recompensa."
        },
        message_center: {
            support: "Suporte",
            news: "Not\xEDcia",
            notification: "Notifica\xE7\xE3o",
            marquee: "Painel Rolante",
            feedback: "B\xF4nus de Sugest\xE3o"
        },
        finish_register: {
            title: "Dicas",
            text: "Registado com \xEAxito! Jogue uma ronda~",
            btn: "Recarregue Agora"
        },
        newbie_bonus: {
            title: "B\xF4nus de novo jogador",
            paste: "Paste",
            placeholder: "Introduza o c\xF3digo de resgate",
            bonus_amount: "Valor do b\xF4nus",
            btn: "Reivindicar b\xF4nus",
            tips: "Parab\xE9ns, voc\xEA ganhou {reward} b\xF4nus\uFF01"
        },
        claim: {
            title: "Pendente",
            reward: "B\xF4nus",
            active_level: "Atividade",
            time: "Horas",
            name: "Nomes",
            source: "Fonte",
            status: "Status",
            claim: "Receber",
            detailTitle: "Fonte de recompensa",
            reward_name: "Nome da recompensa",
            reward_time: "Tempo de recompensa",
            amount: "Quantia",
            point: "Atividade",
            available_time: "Hor\xE1rio dispon\xEDvel",
            rewards: "Recompensas",
            claimable_time: "Tempo exig\xEDvel",
            validity_period: "Per\xEDodo de validade"
        },
        music: {
            music: "M\xFAsica",
            cycle: "Ciclo",
            shuffle: "Aleat\xF3rio",
            repeat: "Repetir",
            downloaded: "Transferido",
            system_music: "Sistema de M\xFAsica",
            my_music: "Minhas m\xFAsicas",
            deleteTips: "\xDAltima m\xFAsica, que n\xE3o pode ser exclu\xEDda"
        },
        add_tips_dialog: {
            title1: "Adicionar \xE0 tela inicial",
            subTitle1: '1. Toque no \xEDcone "Mais" e, em seguida, toque em Adicionar ao ecr\xE3 principal',
            subTitle2: "2. Clique em Adicionar e selecione \u201CAdicionar\u201D",
            text1: "Compartilhar...",
            text2: "Procurar na p\xE1gina web",
            text3: "Adicionar \xE0 tela inicial",
            text4: "Website de computador",
            text5: "Adicionar \xE0 tela inicial",
            text6: "Cancelar",
            text7: "Adicionar",
            title2: "Adicionar \xE0 tela inicial",
            text8: "Adicionar a memorando r\xE1pido",
            text9: "Encontrar na p\xE1gina",
            text10: "Adicionar \xE0 tela inicial",
            text11: "Marcador",
            text12: "Ser\xE1 adicionado um \xEDcone ao seu ecr\xE3 inicial para aceder rapidamente a este website"
        },
        first_charge_pop: {
            title: "B\xF4nus Extra De Dep\xF3sito Inicial",
            text1: "Primeiro dep\xF3sito",
            text2: "Valor Da Recompensa",
            btn: "Prosseguir"
        },
        tutorial: {
            text: `
            <h1><strong>Um exemplo \xE9 o seguinte:</strong></h1>
            <p>Suponha que as apostas efetivas atuais de 0 a 10.000 receber\xE3o uma comiss\xE3o de 100 (ou seja, 1%) para
                cada 10.000, e o apostas efetivas acima de 10.000 receber\xE3o uma comiss\xE3o de 300 para cada 10.000. (ou
                seja, 3%), A foi o primeiro a descobrir oportunidades de neg\xF3cios neste site e imediatamente desenvolveu
                B1, B2 e B3. B1 desenvolveu ainda mais C1 e C2. B2 desenvolveu sem subordinados, e a B3 desenvolveu o
                relativamente poderoso C3. No segundo dia, a aposta efetiva de B1 \xE9 500, a aposta efetiva de B2 \xE9 3.000,
                a aposta efetiva de B3 \xE9 2.000, a aposta efetiva de C1 \xE9 1.000, a aposta efetiva de C2 \xE9 2.000 e a
                aposta efetiva de C3 \xE9 de at\xE9 20.000. </p><span>Ent\xE3o o m\xE9todo de c\xE1lculo da renda entre eles \xE9 o
                seguinte: </span>
            <ul>
                <li><strong>1. Comiss\xE3o de B1</strong> (contribui\xE7\xF5es diretas de C1 e C2) = (1000 + 2000) * 1% =
                    <em>30</em></li>
                <li><strong>2. Comiss\xE3o de B2</strong> (sem subordinados) = (0+0) * 1% = <em> 0</em></li>
                <li><strong>3. Comiss\xE3o B3</strong> (contribui\xE7\xE3o direta de C3) = 20.000 * 3% = <em>600</em></li>
                <li> <strong>4. Al\xE9m das contribui\xE7\xF5es dos subordinados diretos B1, B2 e B3, a comiss\xE3o de A tamb\xE9m
                        adv\xE9m das contribui\xE7\xF5es dos demais subordinados C1, C2 e C3, conforme segue: </strong>
                    <ul>
                        <li><strong>( 1 )Comiss\xE3o direta de A</strong>(contribui\xE7\xF5es diretas de B1, B2 e B3) =
                            (500+3000+2000) * 3% = <em>165</em></li>
                        <li><strong>( 2) Outras comiss\xF5es de A</strong>(das contribui\xE7\xF5es C1, C2)=(1000+2000) * 2%=
                            <em>60</em></li>
                        <li><strong>(3)Comiss\xE3o total de A </strong>(direto + outro) = 165+60 = <em>225</em></li>
                    </ul>
                </li>
                <li><strong>5. Resumo: </strong>
                    <ul>
                        <li><strong>(1) Equipe direta</strong>: refere-se aos subordinados desenvolvidos diretamente por
                            A, ou seja, o primeiro n\xEDvel de relacionamento com A, denominados coletivamente como equipe
                            direta. </li>
                        <li><strong>(2) Outras equipes</strong>: Refere-se \xE0quelas que s\xE3o desenvolvidas por
                            subordinados de A. Possuem relacionamento de segundo n\xEDvel com A ou superior, ou seja,
                            subordinados de subordinados , e os subordinados dos subordinados.. etc., coletivamente
                            referidos como outras equipes; como esse modelo de ag\xEAncia pode desenvolver subordinados
                            ilimitados, para conveni\xEAncia da explica\xE7\xE3o, este artigo toma apenas a estrutura de 2 n\xEDveis
                            como exemplo. </li>
                        <li><strong>(3) Descri\xE7\xE3o de A</strong>: O desempenho direto de A \xE9 5.500 e o outro desempenho \xE9
                            20.000 (devido ao poder de C3). O desempenho total \xE9 28.500 e a comiss\xE3o correspondente a
                            taxa \xE9 de 3%. Como B1 tem um desempenho total de 3.000 e desfruta de um desconto de apenas
                            1%, enquanto A tem um desempenho total de 28.500 e desfruta de uma taxa de desconto de 3%,
                            ent\xE3o haver\xE1 uma diferen\xE7a de desconto entre A e B1. A diferen\xE7a \xE9: 3% -1% =2%, essa
                            diferen\xE7a \xE9 a parte contribu\xEDda por C1 e C2 para A, ent\xE3o C1 e C2 contribuem para A:
                            (1000+2000)* 2%=60, n\xE3o h\xE1 diferen\xE7a extrema entre A e B3, ent\xE3o C3 contribui para A A
                            comiss\xE3o de contribui\xE7\xE3o \xE9 0. </li>
                        <li><strong>(4) Descri\xE7\xE3o de B1</strong>: B1 tem subordinados C1 e C2. Como o desempenho direto
                            \xE9 3.000, o \xEDndice de desconto correspondente \xE9 de 1%. </li>
                        <li><strong>(5) Explica\xE7\xE3o B2 </strong>: B2 pode ser pregui\xE7oso e n\xE3o se beneficiar\xE1 se n\xE3o
                            desenvolver seus subordinados. </li>
                        <li><strong>(6) Explica\xE7\xE3o B3</strong>: Embora B3 tenha aderido relativamente tarde e seja
                            subordinado de A, seu subordinado C3 \xE9 muito poderoso e tem um desempenho direto de 20.000,
                            permitindo que B3 diretamente desfrutar de comiss\xF5es mais elevadas.A propor\xE7\xE3o \xE9 de 3%.
                        </li>
                        <li><strong>(7) Resumo das regras</strong>: N\xE3o importa quando voc\xEA ingressa, de quem voc\xEA \xE9
                            subordinado, n\xE3o importa em que n\xEDvel voc\xEA est\xE1, sua renda nunca ser\xE1 afetada e voc\xEA n\xE3o
                            sofre mais as perdas dos subordinados dos outros., o desenvolvimento n\xE3o \xE9 restrito. Este \xE9
                            um modelo de ag\xEAncia absolutamente justo e imparcial, e ningu\xE9m estar\xE1 sempre por baixo s\xF3
                            porque entrou tarde. </li>
                    </ul>
                </li>
            </ul>
        `
        },
        dealer: {
            title: "Distribuidor",
            tutorial: "Tutorial",
            home: "Primeira p\xE1gina",
            review: "An\xE1lise",
            performance: "Minha performance",
            member: "Meus membros",
            game: "Dados do jogo",
            record: "Obtenha registros",
            ladder: "Escada de recompensa"
        },
        dealer_tutorial: {
            title: "Primeiro modo vermelho completo",
            text1: "Sua recompensa de primeiro dep\xF3sito: 15/pessoa + recompensas de n\xEDvel adicional",
            text2: "O limite de recompensa n\xE3o pode ser maior que o seu pr\xF3prio limite",
            ruleTitle: "Seu total de recarga:",
            ruleText1: "Por exemplo, se o agente geral tiver uma recompensa de primeiro dep\xF3sito de 15 por pessoa e se 100 pessoas forem desenvolvidas para recarregar, a recompensa de recarga = 100*15=<b>1500</b>, e o n\xEDvel inferior a gest\xE3o recebe uma recompensa de 14 por pessoa, se o gestor desenvolver 100 pessoas para recarregar, a diferen\xE7a ser\xE1 obtida 100*(15-14)=100. Se a gest\xE3o desenvolver funcion\xE1rios de n\xEDvel inferior e desenvolver 100 pessoas para recarregar, o. o agente geral pode obter a diferen\xE7a 100*(15-12)=<b>300</b>, e assim por diante; o agente geral obt\xE9m a cota = pr\xF3prio 1.500 + saldo de gerenciamento 100 + saldo de funcion\xE1rio 300 +...",
            ruleText2: "C\xE1lculo de outras diferen\xE7as de recompensa em n\xEDveis: De acordo com o n\xFAmero de pessoas e a configura\xE7\xE3o da recompensa, a diferen\xE7a ainda pode ser calculada. Por exemplo, se o agente total atingir 50 pessoas, a recompensa ser\xE1 100, e se a gest\xE3o de n\xEDvel inferior configurar 50. gente, a recompensa \xE9 90, voc\xEA ainda pode ganhar <b>10</b> de diferen\xE7a"
        },
        dealer_home: {
            dealerId: "ID do revendedor",
            superiorId: "ID superior",
            level: "N\xEDvel",
            firstRecharge: "Seu primeiro dep\xF3sito",
            complaint: "Reclama\xE7\xE3o",
            camReceive: "Pode receber pr\xEAmios",
            received: "Recebeu o pr\xEAmio",
            myLink: "Meu link",
            myReview: "Minha cr\xEDtica",
            reviewNum: "Quantidade a ser revisada",
            operation: "Operar",
            reviewBtn: "Rever",
            reward_setting: "Configura\xE7\xF5es de recompensa",
            firstRecharge_per_reward: "Recompensa de primeiro dep\xF3sito por pessoa",
            firstRecharge_ext_reward: "Recompensas extras para primeiro dep\xF3sito",
            reward_ladder: "Escada de recompensa",
            check: "Verificar",
            reward_sum: "Estat\xEDsticas de recompensa",
            personal_reward: "N\xFAmero de pessoas recompensadas",
            ext_reward: "Recompensas adicionais",
            total_reward: "Recompensa total"
        },
        dealer_home: {
            dealerId: "ID do revendedor",
            superiorId: "ID superior",
            level: "N\xEDvel",
            firstRecharge: "Seu primeiro dep\xF3sito",
            person: "pessoa",
            complaint: "Reclama\xE7\xE3o",
            camReceive: "Pode receber pr\xEAmios",
            received: "Recebeu o pr\xEAmio",
            myLink: "Meu link",
            reward_setting: "Configura\xE7\xF5es de recompensa",
            firstRecharge_per_reward: "Recompensa de primeiro dep\xF3sito por pessoa",
            firstRecharge_ext_reward: "Recompensas extras para primeiro dep\xF3sito",
            reward_ladder: "Escada de recompensa",
            check: "Verificar",
            reward_sum: "Estat\xEDsticas de recompensa",
            personal_reward: "N\xFAmero de pessoas recompensadas",
            ext_reward: "Recompensas adicionais",
            total_reward: "Recompensa total"
        },
        dealer_complaint: {
            title1: "Reclamar ao revendedor",
            title2: "Registro de reclama\xE7\xE3o",
            placeholder: "Insira o conte\xFAdo da reclama\xE7\xE3o",
            submit: "Enviar",
            tips: "Para garantir o funcionamento normal do agente, voc\xEA pode registrar uma reclama\xE7\xE3o contra o comportamento de revendedores inescrupulosos, e a plataforma cuidar\xE1 disso para voc\xEA."
        },
        dealer_review: {
            placeholder: "Insira o ID do membro",
            check: "Investigar",
            contact_setting: "Configura\xE7\xF5es de contato",
            memberId: "ID de membro",
            contactInfo: "Informa\xE7\xF5es de contato",
            remark: "Observa\xE7\xE3o",
            applyTime: "Tempo de aplica\xE7\xE3o",
            review: "An\xE1lise"
        },
        dealer_performance: {
            first_person: "N\xFAmero de pessoas que fazem o primeiro dep\xF3sito",
            time: "Tempo",
            dealer_person: "N\xFAmero de revendedores",
            recharge_person: "N\xFAmero de pessoas que fazem o primeiro dep\xF3sito",
            reward: "Ac\xFAmulo de recompensas"
        },
        dealer_member: {
            placeholder: "Insira o ID do membro",
            check: "Investigar",
            registerTime: "Hora do registro",
            account: "ID de membro",
            accountRemark: "Observa\xE7\xF5es sobre contas de membros",
            superiorId: "ID superior",
            isRecharge: "Quer recarregar",
            dealer: "Distribuidor",
            user: "Membro comum"
        },
        dealer_record: {
            received: "Comiss\xE3o recebida",
            receive_time: "Hor\xE1rio de coleta",
            received: "Recebido"
        },
        dealer_contact_setting: {
            show: "Exibi\xE7\xE3o de atendimento ao cliente",
            contactMethod: "Informa\xE7\xF5es de contato podem ser enviadas",
            modify: "Rever",
            tips1: "Selecione informa\xE7\xF5es de contato",
            tips2: "Preencha pelo menos uma informa\xE7\xE3o de atendimento ao cliente"
        },
        dealer_ladder: {
            currentNum: "O n\xFAmero atual de pessoas que fazem primeiros dep\xF3sitos",
            tab1: "Recompensas para quem recarrega",
            tab2: "Recompensas de promo\xE7\xE3o VIP",
            receivedReward: "Comiss\xE3o recebida",
            levelUpNum: "N\xFAmero de promo\xE7\xF5es",
            firstRecharge: "N\xFAmero de pessoas que fazem o primeiro dep\xF3sito",
            reward: "pr\xEAmio",
            vipLevel: "N\xEDvel VIP"
        },
        dealer_join_dialog: {
            title1: "Contate-nos",
            title2: "Inscreva-se para se tornar um revendedor",
            table1: "Detalhes do contato",
            table2: "Observa\xE7\xE3o",
            table3: "Tempo de aplica\xE7\xE3o",
            table4: "Estado",
            table5: "operar",
            btn1: "Reenviar",
            btn2: "Verificar",
            text1: "Selecione informa\xE7\xF5es de contato",
            text2: "Preencha as informa\xE7\xF5es de contato",
            text3: "Observa\xE7\xE3o",
            btn3: "Cancelar",
            btn4: "Claro",
            btn5: "Cancelar",
            btn6: "Reenviar",
            tips1: "Selecione informa\xE7\xF5es de contato",
            tips2: "Por favor preencha as informa\xE7\xF5es de contato"
        },
        dealer_review_detail: {
            title: "Revisar opera\xE7\xF5es",
            account: "Conta de membro",
            applyTime: "Tempo de aplica\xE7\xE3o",
            contactType: "Informa\xE7\xF5es de contato",
            contactInfo: "Conte\xFAdo de contato",
            applyRemark: "Notas de aplica\xE7\xE3o",
            rechargeReward: "Recompensa do primeiro dep\xF3sito",
            person: "pessoas",
            extReward: "Recompensas adicionais",
            lower_recharge_reward_setting: "Configura\xE7\xE3o de recompensa de primeiro dep\xF3sito de n\xEDvel inferior",
            lower_recharge_extReward_setting: "Configura\xE7\xE3o de b\xF4nus adicional para primeiro dep\xF3sito em n\xEDvel inferior",
            rechargePerson: "N\xFAmero de pessoas recarregando",
            myReward: "Minha recompensa",
            max_reward: "A recompensa m\xE1xima que pode ser definida",
            next_reward_setting: "Configura\xE7\xF5es de recompensa de n\xEDvel inferior",
            withdraw_setting: "Configura\xE7\xF5es de retirada",
            can_withdraw: "Pode sacar dinheiro",
            cannot_withdraw: "A retirada n\xE3o \xE9 poss\xEDvel",
            edit_setting: "Editar Configura\xE7\xF5es",
            can_edit: "Pode editar",
            cannot_edit: "N\xE3o edit\xE1vel",
            level_name: "Nome do n\xEDvel",
            account_remark: "Observa\xE7\xF5es sobre contas de membros",
            reject: "Rejeitar",
            pass: "Passar",
            tips1: "Defina todas as configura\xE7\xF5es de recompensa de n\xEDvel inferior",
            tips2: "Defina a configura\xE7\xE3o da recompensa do primeiro dep\xF3sito para o n\xEDvel inferior",
            tips3: "Defina a configura\xE7\xE3o de recompensa adicional para o primeiro dep\xF3sito no n\xEDvel inferior",
            tips4: "Defina a configura\xE7\xE3o de edi\xE7\xE3o",
            tips5: "Por favor insira um nome de n\xEDvel",
            tips6: "Por favor, defina a configura\xE7\xE3o de retirada"
        },
        complaint: {
            title: "Reclama\xE7\xE3o",
            site_complaint: "Reclama\xE7\xF5es do site",
            email: "E-mail",
            tipsTitle: "Ilustrar",
            tips: "Para garantir o funcionamento normal do site, voc\xEA pode apresentar uma reclama\xE7\xE3o contra comportamento inescrupuloso do site e a plataforma tratar\xE1 disso para voc\xEA.",
            emailError1: "O e-mail n\xE3o pode ficar vazio",
            emailError2: "O formato do e-mail est\xE1 incorreto",
            placeholderText: "Insira o conte\xFAdo da reclama\xE7\xE3o do site"
        },
        upload: {
            uploading: "Enviando...",
            tips1: "O tamanho de upload de um \xFAnico arquivo n\xE3o pode exceder",
            tips2: "O tamanho total do upload do arquivo n\xE3o pode exceder",
            tips3: "O tamanho do upload do arquivo n\xE3o pode exceder"
        },
        recharge_order_detail: {
            title: "Dep\xF3sito",
            tips1: "Abra seu aplicativo de pagamento e digitalize ou copie e cole o c\xF3digo QR abaixo para concluir sua compra;",
            tips2: "Este c\xF3digo QR s\xF3 pode ser pago uma vez. Se precisar pagar novamente, volte e recarregue;",
            tips3: "Ap\xF3s o pagamento ser bem-sucedido, voc\xEA pode retornar ao lobby do jogo e aguardar a adi\xE7\xE3o de pontos!",
            effectTime: "Tempo efetivo",
            copyText: "Copiar c\xF3digo QR",
            copyAddress: "Endere\xE7o do c\xF3digo QR ...",
            label1: "Status do pedido",
            label2: "Hora de Cria\xE7\xE3o",
            label3: "N\xFAmero do Pedido",
            label4: "N\xFAmero do pedido do comerciante",
            waiting: "Registros de Auditoria",
            success: "Pago",
            warning: "O c\xF3digo QR expirou",
            tips4: "Por favor, retorne ao lobby para fazer um pedido novamente. A p\xE1gina atual ser\xE1 fechada em 10 segundos.",
            tips5: "Selecionar",
            tips6: " Fechar agora ",
            tips7: "ou",
            tips8: " verificar pedido",
            tips9: "Recebido com sucesso",
            tips10: "O sistema atribuiu pontos automaticamente a voc\xEA.",
            tips11: "A p\xE1gina atual ser\xE1 fechada em 10 segundos."
        },
        check_pwd_dialog: {
            title: "Enter PIN",
            text1: "Withdrawal Password",
            text2: "For your account safety, please enter the withdrawal password",
            text3: "Forgot password?",
            btnText: "Confirm",
            tips1: "6 digits"
        }
    }, ya = {
        home: {
            noData: "\u6CA1\u6709\u6570\u636E",
            loadMore: "\u52A0\u8F7D\u66F4\u591A",
            moreTipsText1: "Currently displaying ",
            moreTipsText2: "Hot games out of ",
            moreTipsText3: "",
            maintain: "\u6E38\u620F\u7EF4\u62A4\u4E2D",
            all: "\u5168\u90E8",
            maintainText: "\u7EF4\u62A4\u4E2D",
            limitAmountTips: "\u60A8\u7684\u4F59\u989D\u4E0D\u8DB3 {currency}{balance}, \u5145\u503C\u79F0\u9738\u73B0\u573A!",
            top: "Top"
        },
        footer: {
            cassino: "Cassino",
            games: "\u6E38\u620F",
            support: "Suporte",
            none: "\u6682\u672A\u5F00\u653E",
            funcList: {
                reward: "\u5956\u52B1",
                rebate: "\u8FD4\u6C34",
                vip: "VIP",
                agent: "\u8FD4\u4F63",
                event: "\u6D3B\u52A8",
                task: "\u4EFB\u52A1"
            },
            gameList: {
                hot: "\u70ED\u95E8",
                card: "\u68CB\u724C",
                fish: "\u6355\u9C7C",
                digital: "\u7535\u5B50",
                live: "\u89C6\u8BAF",
                sports: "\u4F53\u80B2",
                recent: "\u6700\u8FD1\u6E38\u620F",
                collect: "\u4E2A\u4EBA\u6536\u85CF"
            },
            supportList: {
                support: "\u5728\u7EBF\u652F\u6301",
                advise: "\u5EFA\u8BAE\u6709\u5956",
                faq: "\u5E2E\u52A9\u4E2D\u5FC3"
            },
            technicalSupport: "\u6280\u672F\u652F\u6301"
        },
        new_player: {
            title: "Benefits for new players",
            proceed: "Proceed",
            collect: "collect",
            collected: "collected",
            reward: "Bonus",
            tips1: "Do not show again in this session",
            tips2: "Never warn (check in task center)",
            collectAll: "Collect All",
            tip3: "\u4E0D\u7B26\u5408\u9886\u53D6\u6761\u4EF6",
            tip4: "\u8BF7\u5148\u7ED1\u5B9A\u6536\u6B3E\u65B9\u5F0F"
        },
        search_page: {
            title: "\u641C\u7D22",
            result: "\u641C\u7D22",
            popular: "\u70ED\u95E8",
            recent: "\u6700\u8FD1\u6E38\u620F",
            favorites: "\u4E2A\u4EBA\u6536\u85CF",
            record: "\u641C\u7D22\u7ED3\u679C",
            clear: "Delete All"
        },
        sub_game: {
            search: "\u641C\u7D22",
            all: "\u5168\u90E8"
        },
        vip_item: {
            accumulated_deposits: "\u7D2F\u8BA1\u5B58\u6B3E",
            current_stream: "\u5F53\u524D\u6D41\u6C34",
            relegation_deposits: "\u4FDD\u7EA7\u5B58\u6B3E",
            relegation_stream: "\u4FDD\u7EA7\u6D41\u6C34",
            tips1: "\u60A8\u8FD8\u9700\u8981",
            tips2: "\u5B58\u6B3E\u5347\u7EA7\u81F3",
            tips3: "\u6D41\u6C34\u5347\u7EA7\u81F3",
            maxLevel: "\u5DF2\u7ECF\u662F\u6700\u9AD8\u7B49\u7EA7",
            privilege: "\u7279\u6743",
            challenge_game: "\u95EF\u5173\u6E38\u620F",
            go: "\u53BB\u770B\u770B",
            unset: "\u60A8\u8FD8\u672A\u8BBE\u7F6E\u751F\u65E5",
            tips: "\u63D0\u793A",
            confirmText: "\u524D\u5F80\u8BBE\u7F6E",
            cancelText: "\u4E0B\u6B21\u518D\u8BF4"
        },
        vip_lucky_wheel: {
            daily_lottery: "\u6BCF\u65E5\u62BD\u5956",
            upgrade_vip: "\u5347\u7EA7VIP",
            current: "\u5F53\u524D",
            lottery_draw: "\u62BD\u5956\u6B21\u6570",
            winning_record: "\u4E2D\u5956\u8BB0\u5F55",
            tips1: "\u62BD\u5956\u6B21\u6570\u5DF2\u7ECF\u7528\u5B8C",
            tips2: "\u606D\u559C\u60A8\uFF0C\u83B7\u5F97",
            tips3: "\u91D1\u989D"
        },
        vip_birthday: {
            title: "\u751F\u65E5\u5F69\u86CB",
            collect: "\u9886\u53D6",
            collected: "\u5DF2\u9886\u53D6"
        },
        vip_reward: {
            title: "VIP\u5956\u52B1",
            upgrade: "\u5347\u7EA7",
            recharge: "\u518D\u5145\u503C",
            bet: "\u518D\u4E0B\u6CE8",
            collect_all: "\u4E00\u952E\u9886\u53D6",
            collect_record: "\u9886\u53D6\u8BB0\u5F55",
            level_list: "VIP\u7B49\u7EA7\u5217\u8868",
            upgrade_rewards: "\u5347\u7EA7\u5956\u52B1",
            relegation_conditions: "\u4FDD\u7EA7\u6761\u4EF6",
            daily_rewards: "\u6BCF\u65E5\u5956\u52B1",
            weekly_rewards: "\u6BCF\u5468\u5956\u52B1",
            monthly_rewards: "\u6BCF\u6708\u5956\u52B1",
            privilege: "VIP\u7279\u6743",
            rule_description: "VIP\u89C4\u5219\u8BF4\u660E",
            title1: "\u5347\u7EA7\u5956\u52B1\u89C4\u5219",
            text1: "\u6EE1\u8DB3vip\u664B\u7EA7\u6761\u4EF6\u540E\uFF08\u6EE1\u8DB3\u5145\u503C \u3001\u6253\u7801\u7D2F\u8BA1\u8981\u6C42\uFF09\uFF0C\u4F1A\u5458\u5C06\u664B\u7EA7\u81F3\u76F8\u5E94\u7684vip\u7B49\u7EA7\uFF0C\u5E76\u53EF\u9886\u53D6\u664B\u7EA7\u5956\u91D1\uFF0C\u5982\u679C\u4E00\u6B21\u6027\u5347\u7EA7\u591A\u4E2A\uFF0C\u5219\u53EF\u4EE5\u9886\u53D6\u6240\u6709\u664B\u7EA7\u7EA7\u522B\u5956\u91D1\u3002",
            title2: "\u6BCF\u5468\u5956\u52B1\u89C4\u5219",
            text2: "\u6BCF\u5468\u5145\u503C\u548C\u6295\u6CE8\u91D1\u989D\u8FBE\u5230\u5F53\u524Dvip\u7EA7\u522B\uFF0C\u5BF9\u5E94\u7684\u5468\u5956\u52B1\u8981\u6C42\u65F6\uFF0C\u4F1A\u5458\u53EF\u4EE5\u9886\u53D6\u76F8\u5E94\u7684\u5468\u85AA\uFF0C\u6BCF\u5468\u4E0000:00\u91CD\u7F6E\u3002",
            title3: "\u6BCF\u6708\u5956\u52B1\u89C4\u5219",
            text3: "\u6BCF\u6708\u5145\u503C\u548C\u6295\u6CE8\u8FBE\u5230\u5F53\u6708vip\u8981\u6C42\u65F6\uFF0C\u53EF\u4EE5\u9886\u53D6\u76F8\u5E94\u6708\u85AA\uFF0C\u6708\u85AA\u5C06\u4E8E\u6BCF\u6708\u9996\u65E500:00\u91CD\u7F6E\u3002",
            rule_detail: "1.\u664B\u7EA7\u6807\u51C6\uFF1A\u6EE1\u8DB3VIP\u664B\u7EA7\u6761\u4EF6\uFF08\u5373\u5B58\u6B3E\u6216\u6709\u6548\u6295\u6CE8\u5747\u7B26\u5408\u6807\u51C6\uFF09\u5373\u53EF\u5347\u7EA7\u81F3\u76F8\u5E94VIP\u7B49\u7EA7\uFF0C\u5E76\u83B7\u5F97\u76F8\u5E94\u664B\u7EA7\u5956\u91D1\u3002\u5982\u679C\u8FDE\u7EED\u5347\u7EA7\u591A\u4E2A\u7EA7\u522B\uFF0C\u5219\u53EA\u80FD\u83B7\u5F97\u5F53\u524D\u7EA7\u522B\u7684\u664B\u5347\u5956\u91D1\u3002\u53EF\u5B9E\u65F6\u9886\u53D6\u5956\u91D1\uFF1B<br/>2.\u6BCF\u65E5\u5956\u91D1\uFF1A\u6EE1\u8DB3\u5F53\u524D\u7EA7\u522B\u7684\u6BCF\u65E5\u5B58\u6B3E\u548C\u6709\u6548\u6295\u6CE8\u8981\u6C42\uFF0C\u5373\u53EF\u83B7\u5F97\u76F8\u5E94\u7684\u6BCF\u65E5\u5956\u91D1\u3002\u5982\u679C\u8FDE\u7EED\u664B\u7EA7\u591A\u4E2A\u7EA7\u522B\uFF0C\u5219\u53EA\u80FD\u83B7\u5F97\u5F53\u524D\u7EA7\u522B\u7684\u6BCF\u65E5\u5956\u91D1\u3002\u53EF\u5B9E\u65F6\u9886\u53D6\u5956\u91D1\uFF1B<br/>3.\u6BCF\u5468\u5956\u91D1\uFF1A\u6BCF\u5468\u6EE1\u8DB3\u5F53\u524D\u7EA7\u522B\u7684\u5B58\u6B3E\u548C\u6709\u6548\u6295\u6CE8\u8981\u6C42\uFF0C\u5373\u53EF\u83B7\u5F97\u76F8\u5E94\u7684\u6BCF\u5468\u5956\u91D1\u3002\u82E5\u8FDE\u7EED\u664B\u7EA7\u591A\u4E2A\u7EA7\u522B\uFF0C\u5219\u53EA\u80FD\u83B7\u5F97\u5F53\u524D\u7EA7\u522B\u7684\u6BCF\u5468\u5956\u91D1\u3002\u53EF\u5B9E\u65F6\u9886\u53D6\u5956\u91D1\uFF1B<br/>4.\u6708\u5956\u91D1\uFF1A\u6BCF\u6708\u6EE1\u8DB3\u5F53\u524D\u7EA7\u522B\u7684\u5B58\u6B3E\u548C\u6709\u6548\u6295\u6CE8\u8981\u6C42\uFF0C\u5373\u53EF\u83B7\u5F97\u76F8\u5E94\u7684\u6708\u5DE5\u8D44\u5956\u91D1\u3002\u82E5\u8FDE\u7EED\u664B\u7EA7\u591A\u4E2A\u7EA7\u522B\uFF0C\u5219\u53EA\u80FD\u83B7\u5F97\u5F53\u524D\u7EA7\u522B\u7684\u6BCF\u6708\u5956\u91D1\u3002\u53EF\u5B9E\u65F6\u9886\u53D6\u5956\u91D1\uFF1B<br/>5.\u5956\u52B1\u6709\u6548\u671F\uFF1A\u6536\u5230\u7684\u5956\u52B1\u4FDD\u7559%d\u5929\u3002\u5982\u679C\u5728\u6B64\u671F\u95F4\u6CA1\u6709\u4E3B\u52A8\u9886\u53D6\uFF0C\u5219\u4F1A\u81EA\u52A8\u8BB0\u5165\u8D26\u6237\u3002\u4F8B\u5982\uFF1A\u5982\u679C1\u67081\u65E5\u83B7\u5F97\u5956\u52B1\u5E76\u4FDD\u7559%d\u5929\uFF0C\u5219\u8BE5\u5956\u52B1\u5C06\u57281\u6708%d\u768400:00:00\u81EA\u52A8\u5B58\u5165\u8D26\u6237\u3002<br/>6.\u5BA1\u6838\u6CE8\uFF1AVIP\u5956\u91D1\u9700\u4E0B\u6CE810\u500D\uFF08\u5373\u5BA1\u6838\u3001\u73A9\u8FC7\u3001\u6216\u901A\u8FC7\u6709\u6548\u6295\u6CE8\uFF09\u624D\u6709\u8D44\u683C\u63D0\u73B0\uFF0C\u4E0B\u6CE8\u4E0D\u9650\u4E8E\u4EFB\u4F55\u6E38\u620F\u5E73\u53F0\uFF1B<br/>7.\u6D3B\u52A8\u58F0\u660E\uFF1A\u6B64\u529F\u80FD\u4EC5\u9002\u7528\u4E8E\u8D26\u6237\u6240\u6709\u8005\u7684\u6B63\u5E38\u535A\u5F69\u6295\u6CE8\u3002\u7981\u6B62\u79DF\u7528\u8D26\u6237\u3001\u65E0\u98CE\u9669\u6295\u6CE8\uFF08\u64AE\u5408\u3001\u5237\u5355\u3001\u4F4E\u8D54\u7387\uFF09\u3001\u6076\u610F\u5957\u5229\u3001\u4F7F\u7528\u63D2\u4EF6\u3001\u673A\u5668\u4EBA\u3001\u5229\u7528\u534F\u8BAE\u3001\u6F0F\u6D1E\u3001\u63A5\u53E3\u3001\u7FA4\u63A7\u7B49\u6280\u672F\u624B\u6BB5\u3002\u4E00\u7ECF\u6838\u5B9E\uFF0C\u5E73\u53F0\u4FDD\u7559\u7EC8\u6B62\u4F1A\u5458\u767B\u5F55\u3001\u6682\u505C\u4F1A\u5458\u7F51\u7AD9\u4F7F\u7528\u3001\u6CA1\u6536\u5956\u91D1\u53CA\u4E0D\u5F53\u5229\u6DA6\u7684\u6743\u5229\uFF0C\u6055\u4E0D\u53E6\u884C\u901A\u77E5\u3002<br/>8.\u8BF4\u660E\uFF1A\u5E73\u53F0\u9886\u53D6VIP\u5956\u52B1\u5373\u89C6\u4E3A\u4F1A\u5458\u540C\u610F\u9075\u5B88\u76F8\u5E94\u6761\u4EF6\u53CA\u76F8\u5173\u89C4\u5B9A\u3002\u4E3A\u907F\u514D\u6587\u5B57\u89E3\u91CA\u4E0A\u7684\u8BEF\u89E3\uFF0C\u5E73\u53F0\u4FDD\u7559\u672C\u6B21\u6D3B\u52A8\u7684\u6700\u7EC8\u89E3\u91CA\u6743\u3002",
            none_reward: "\u6CA1\u6709\u53EF\u4EE5\u9886\u53D6\u7684\u5956\u52B1",
            current_level: "\u5F53\u524D\u7B49\u7EA7"
        },
        vip_reward_upgrade: {
            level: "\u7B49\u7EA7",
            reward_conditions: "\u5956\u52B1\u6761\u4EF6",
            operate: "\u64CD\u4F5C",
            recharge: "\u5145\u503C",
            bet: "\u4E0B\u6CE8",
            collected: "\u5DF2\u9886\u53D6",
            collect: "\u9886\u53D6",
            bonus: "\u5956\u91D1",
            text1: "\u65E5\u6709\u6548\u6295\u6CE8",
            text2: "\u5468\u6709\u6548\u6295\u6CE8",
            text3: "\u6708\u6709\u6548\u6295\u6CE8",
            text4: "\u65E5\u5145\u503C",
            text5: "\u5468\u5145\u503C",
            text6: "\u6708\u5145\u503C",
            text7: "\u5347\u7EA7\u9700\u8981\u5B58\u6B3E",
            text8: "\u5347\u7EA7\u9700\u8981\u6295\u6CE8",
            text9: "\u6BCF\u65E5\u63D0\u6B3E\u603B\u989D\u9650\u989D",
            text10: "\u6BCF\u65E5\u63D0\u6B3E\u6B21\u6570\u9650\u5236",
            text11: "\u6BCF\u65E5\u514D\u624B\u7EED\u8D39\u4EA4\u6613\u7B14\u6570",
            tips_title: "\u63D0\u793A",
            tips_content_recharge: "\u60F3\u8981\u5347\u7EA7\u5230\u4E0B\u4E00\u4E2A\u7EA7\u522B\uFF0C\u60A8\u9700\u8981\u5728\u7D2F\u8BA1\u5B58\u6B3E\u7684\u57FA\u7840\u4E0A\u8FFD\u52A0\u5B58\u5165\u91D1\u989D\u3002\u4F8B\u5982\uFF1A\u4ECE\u5145\u503C\u8981\u6C421000\u7684VIP1\u5347\u7EA7\u5230\u5145\u503C\u8981\u6C422000\u7684VIP2\uFF0C\u4F1A\u5458\u9700\u8981\u7D2F\u8BA11000+2000=3000\u624D\u80FD\u5347\u7EA7\u5230VIP2\uFF0C\u4EE5\u6B64\u7C7B\u63A8\u3002",
            tips_content_bet: "\u60F3\u8981\u5347\u7EA7\u5230\u4E0B\u4E00\u4E2A\u7EA7\u522B\uFF0C\u60A8\u9700\u8981\u5728\u7D2F\u8BA1\u6295\u6CE8\u7684\u57FA\u7840\u4E0A\u8FFD\u52A0\u6295\u6CE8\u91D1\u989D\u3002\u4F8B\u5982\uFF1A\u4ECE\u6295\u6CE8\u8981\u6C421000\u7684VIP1\u5347\u7EA7\u5230\u6295\u6CE8\u8981\u6C422000\u7684VIP2\uFF0C\u4F1A\u5458\u9700\u8981\u7D2F\u8BA11000+2000=3000\u624D\u80FD\u5347\u7EA7\u5230VIP2\uFF0C\u4EE5\u6B64\u7C7B\u63A8\u3002",
            unlimited: "\u4E0D\u9650\u5236",
            text12: "\u4E0A\u4E2A\u6708\u5145\u503C",
            text13: "\u4E0A\u4E2A\u6708\u6295\u6CE8"
        },
        mine: {
            upgrade: "\u5347\u7EA7",
            recharge: "\u518D\u5145\u503C",
            bet: "\u518D\u4E0B\u6CE8",
            need_recharge: "\u5347\u7EA7\u9700\u8981\u5145\u503C",
            need_bet: "\u5347\u7EA7\u9700\u8981\u4E0B\u6CE8",
            account_detail: "\u8D26\u53F7\u8BE6\u7EC6\u8D44\u6599",
            bet_record: "\u6295\u6CE8\u8BB0\u5F55",
            personal_report: "\u4E2A\u4EBA\u62A5\u544A",
            service_setting: "\u670D\u52A1\u8BBE\u7F6E",
            invite: "\u9080\u8BF7",
            account: "\u8D26\u53F7",
            help_center: "\u5E2E\u52A9\u4E2D\u5FC3",
            music: "\u97F3\u4E50",
            advise: "\u610F\u89C1\u53CD\u9988",
            about_us: "\u5173\u4E8E\u6211\u4EEC",
            address_manage: "\u5730\u5740\u7BA1\u7406",
            security_center: "\u5B89\u5168\u4E2D\u5FC3",
            language: "\u8BED\u8A00",
            exit: "\u9000\u51FA",
            tips1: "\u786E\u5B9A\u9000\u51FA\u5F53\u524D\u8D26\u6237\u5417",
            tips: "\u63D0\u793A",
            id: "ID",
            tab_account: "\u4E2A\u4EBA\u8D44\u6599",
            message: "\u6D88\u606F",
            wallet: "\u94B1\u5305",
            exchange: "\u5151\u6362",
            deposit: "\u5B58\u6B3E",
            income: "\u5B58\u94B1\u5B9D",
            login_pwd: "\u767B\u5F55\u5BC6\u7801",
            exchange_pwd: "\u5151\u6362\u5BC6\u7801",
            million_monthly: "\u6BCF\u6708\u767E\u4E07",
            support: "\u652F\u6301",
            search_balance: "\u67E5\u8BE2\u4F59\u989D",
            request_label: "\u8DDD\u79BB",
            request_recharge: "\u5145\u503C\u91D1\u989D"
        },
        advise: {
            message_title: "\u6D88\u606F\u4E2D\u5FC3",
            welcome_title: "\u4E13\u4E1A\u7684\u5168\u804C\u5BA2\u670D\u968F\u65F6\u5728\u7EBF\u4E3A\u60A8\u89E3\u7B54\u4EFB\u4F55\u95EE\u9898\u3002",
            welcome_text: "\u5168\u5929\u5019\u5728\u7EBF\u670D\u52A1",
            customer: "\u5728\u7EBF\u5BA2\u670D",
            title: "\u5EFA\u8BAE\u6709\u5956",
            faq: "\u5E38\u89C1\u95EE\u9898",
            read: "\u5DF2\u8BFB",
            unread: "\u672A\u8BFB",
            advise_reward: "\u521B\u5EFA",
            my_record: "\u6211\u7684\u8BB0\u5F55",
            content_title: "\u53CD\u9988\u5185\u5BB9",
            content_tips: "(\u53CD\u9988\u7684\u5185\u5BB9\uFF0C\u6211\u4EEC\u4F1A\u6539\u8FDB)",
            entry: "\u60A8\u7684\u610F\u89C1\u5BF9\u6211\u4EEC\u5F88\u6709\u4EF7\u503C\u3002\u4EFB\u4F55\u6709\u4EF7\u503C\u7684\u5EFA\u8BAE\u90FD\u4F1A\u88AB\u8003\u8651\uFF0C\u4E00\u65E6\u88AB\u91C7\u7EB3\uFF0C\u91CD\u8981\u6027\u5C06\u51B3\u5B9A\u73B0\u91D1\u5956\u52B1\u3002\u6211\u4EEC\u9080\u8BF7\u60A8\u53D1\u8868\u5EFA\u8BAE\uFF01",
            annex: "\u9644\u4EF6",
            annex_tips: "(\u66F4\u6613\u4E8E\u91C7\u7528)",
            upload_tips: "\u652F\u6301\u56FE\u7247\u6216\u89C6\u9891\uFF0C\u5927\u5C0F\u4E0D\u8D85\u8FC740M",
            advise_title: "\u5956\u52B1\u89C4\u5219",
            advise_tips: "\u5956\u52B1\u89C4\u5219\u6211\u4EEC\u8BBE\u7F6E\u4E86\u4E00\u4E2A\u5DE8\u5927\u7684\u5956\u91D1\u6765\u6536\u96C6\u53CD\u9988\uFF0C\u4E13\u95E8\u7528\u4E8E\u4F18\u5316\u6211\u4EEC\u7684\u7CFB\u7EDF\u548C\u529F\u80FD\uFF0C\u4E3A\u60A8\u63D0\u4F9B\u66F4\u597D\u7684\u4F53\u9A8C\uFF01\u4E00\u65E6\u88AB\u91C7\u7EB3\uFF0C\u5C06\u6839\u636E\u91CD\u8981\u6027\u7ED9\u4E88\u5956\u52B1\uFF08\u4E0D\u5305\u62EC\u672A\u88AB\u91C7\u7EB3\u7684\uFF09\u3002",
            submit: "\u63D0\u4EA4\u53CD\u9988",
            replied: "\u5DF2\u56DE\u590D",
            feedback: "\u53CD\u9988\u5185\u5BB9",
            reply: "\u56DE\u590D\u5185\u5BB9",
            submit_tips: "\u63D0\u4EA4\u5185\u5BB9\u5FC5\u987B\u5927\u4E8E10\u4E2A\u5B57",
            bonus: "\u5956\u91D1",
            contact: "\u9A6C\u4E0A\u8054\u7CFB"
        },
        mine_info: {
            title: "\u4E2A\u4EBA\u8D44\u6599",
            avatar: "\u4E2A\u4EBA\u5934\u50CF",
            useName: "\u7528\u6237\u540D",
            realName: "\u771F\u5B9E\u59D3\u540D",
            name_tips: "\u8BF7\u8F93\u5165\u771F\u5B9E\u59D3\u540D",
            sex: "\u6027\u522B",
            man: "\u7537",
            woman: "\u5973",
            birthday: "\u51FA\u751F\u65E5\u671F",
            phone: "\u624B\u673A\u53F7\u7801",
            email: "\u7535\u5B50\u90AE\u7BB1",
            receive_address: "\u6536\u8D27\u5730\u5740",
            no_address: "\u6682\u65E0\u9ED8\u8BA4\u6536\u8D27\u5730\u5740",
            save: "\u4FDD\u5B58",
            choose_date: "\u9009\u62E9\u65E5\u671F",
            email_error_tips: "\u90AE\u7BB1\u683C\u5F0F\u4E0D\u6B63\u786E",
            cancel: "\u53D6\u6D88",
            confirm: "\u786E\u8BA4",
            bindPhone: "\u7ED1\u5B9A\u624B\u673A\u53F7",
            tips1: "Facebook \u4E0D\u80FD\u4E3A\u7A7A",
            tips2: "Telegram \u4E0D\u80FD\u4E3A\u7A7A",
            tips3: "Whatsapp \u4E0D\u80FD\u4E3A\u7A7A",
            tips4: "\u786E\u5B9A\u8981\u9000\u51FA\u5417\uFF1F",
            tips5: "\u5F53\u524D\u66F4\u6539\u5C1A\u672A\u4FDD\u5B58\u3002\u5982\u679C\u60A8\u8FD4\u56DE\uFF0C\u66F4\u6539\u5C06\u4E0D\u4F1A\u751F\u6548",
            copySuccess: "\u590D\u5236\u6210\u529F"
        },
        agent: {
            not_have: "\u65E0",
            extension_course: "\u63A8\u5E7F\u6559\u7A0B",
            change: "\u66F4\u6362",
            claimable: "\u53EF\u9886\u53D6",
            direct_subordinate: "\u76F4\u5C5E\u4E0B\u7EA7",
            my_superiors: "\u6211\u7684\u4E0A\u7EA7",
            unlimited_level_difference: "\u65E0\u9650\u7EA7\u5DEE (\u65E5\u7ED3)",
            agency_mode: "\u4EE3\u7406\u6A21\u5F0F",
            share: "\u5206\u4EAB",
            agent: "\u4EE3\u7406",
            my_promotion: "\u6211\u7684\u63A8\u5E7F",
            my_data: "\u6211\u7684\u6570\u636E",
            tutorial: "\u6559\u7A0B",
            tab_commission: "\u6211\u7684\u4F63\u91D1",
            my_performance: "\u6211\u7684\u4E1A\u7EE9",
            my_member: "\u8868\u73B0",
            commission_rate: "\u4F63\u91D1\u6BD4\u4F8B",
            all_types: "\u6240\u6709\u7C7B\u578B",
            all_data: "\u6240\u6709\u6570\u636E",
            finance: "\u76F4\u5C5E\u8D22\u52A1",
            wagers: "\u76F4\u5C5E\u6295\u6CE8",
            stats: "\u76F4\u5C5E\u6570\u636E",
            claims: "\u76F4\u5C5E\u9886\u53D6",
            account: "\u8D26\u53F7",
            superior: "\u4E0A\u7EA7",
            can_receive: "\u53EF\u9886\u53D6",
            receive: "\u9886\u53D6",
            save: "\u4FDD\u5B58",
            my_link: "\u6211\u7684\u94FE\u63A5",
            commission: "\u4F63\u91D1",
            detail: "\u8BE6\u60C5",
            total_commission: "\u4F63\u91D1\u603B\u989D",
            received: "\u5DF2\u9886\u53D6",
            unclaimed: "\u672A\u9886\u53D6",
            member: "\u6210\u5458",
            total_members: "\u6210\u5458\u603B\u6570",
            direct_members: "\u76F4\u5C5E\u6210\u5458",
            other_members: "\u5176\u4ED6\u6210\u5458",
            total_income: "\u603B\u6536\u5165",
            direct_income: "\u76F4\u5C5E\u6536\u5165",
            other_income: "\u5176\u4ED6\u6536\u5165",
            bet: "\u6295\u6CE8",
            total_effective_bet: "\u6709\u6548\u6295\u6CE8\u603B\u989D",
            total_bet_number: "\u6295\u6CE8\u5355\u603B\u6570",
            total_profit_loss: "\u603B\u635F\u5931\u548C\u6536\u76CA",
            more: "\u66F4\u591A",
            to: "\u81F3",
            start_date: "\u5F00\u59CB\u65F6\u95F4",
            end_date: "\u7ED3\u675F\u65F6\u95F4",
            all: "\u5168\u90E8",
            time: "\u65F6\u95F4",
            type: "\u7C7B\u578B",
            bet_amount: "\u6295\u6CE8\u989D",
            bet_number: "\u6295\u6CE8\u4EBA\u6570",
            join_time: "\u52A0\u5165\u65F6\u95F4",
            personnel: "\u4EBA\u5458",
            number: "\u5E8F\u53F7",
            effective_bet_unit: "\u4E1A\u7EE9",
            unit: "\uFF08\u5355\u4F4D\uFF1A\u4E07\uFF09",
            per_commission: "\u6BCF\u4E07\u8FD4\u4F63\u91D1\u989D",
            collect_record: "\u9886\u53D6\u8BB0\u5F55",
            search: "\u67E5\u8BE2",
            noData: "\u6682\u65E0\u6570\u636E",
            collected_commission: "\u5DF2\u9886\u53D6\u4F63\u91D1",
            collected_time: "\u9886\u53D6\u65F6\u95F4",
            amount: "\u91D1\u989D",
            myId: "\u6211\u7684\u8D26\u53F7",
            share_title1: "",
            share_title2: "\u63A8\u5E7F\u94FE\u63A5",
            net_profit: "\u51C0\u76C8\u5229",
            total_net_profit: "\u51C0\u76C8\u5229\u603B\u989D",
            total_discount: "\u4F18\u60E0\u603B\u989D",
            valid_people: "\u6709\u6548\u4EBA\u6570",
            valid_text1: "\u6709\u6548\u4EBA\u6570\u2265",
            valid_text2: "\uFF0C\u4E3A\u6709\u6548\u4EBA\u6570",
            deposit_amount: "\u5145\u503C\u91D1\u989D",
            agent_tier: "\u4EE3\u7406\u7EA7\u522B",
            promotion_conditions: "\u664B\u7EA7\u8981\u6C42",
            commission_detail_title: "\u4F63\u91D1\u8BE6\u60C5",
            commission_detail_endTime: "\u7ED3\u7B97\u65E5\u671F",
            commission_detail_placeholder: "\u8F93\u5165\u4F1A\u5458ID",
            commission_detail_table1: "\u4F1A\u5458ID",
            commission_detail_table2: "\u4E0A\u7EA7",
            commission_detail_table3: "\u6295\u6CE8\u6570\u636E",
            commission_detail_table4: "\u4F63\u91D1",
            commission_detail_label1: "\u76F4\u5C5E\u6570\u636E",
            commission_detail_label2: "\u5176\u4ED6\u6570\u636E",
            commission_detail_label3: "\u603B\u6570\u636E",
            commission_detail_label4: "\u76F4\u5C5E\u4F63\u91D1",
            commission_detail_label5: "\u5176\u4ED6\u4F63\u91D1",
            commission_detail_label6: "\u603B\u4F63\u91D1",
            my_performance_label1: "\u76F4\u5C5E\u4EBA\u6570",
            my_performance_label2: "\u76F4\u5C5E\u6295\u6CE8\u989D",
            my_performance_label3: "\u76F4\u5C5E\u4F63\u91D1",
            my_performance_label4: "\u5176\u4ED6\u4EBA\u6570",
            my_performance_label5: "\u5176\u4ED6\u6295\u6CE8\u989D",
            my_performance_label6: "\u5176\u4ED6\u4F63\u91D1",
            all_data_table1: "\u52A0\u5165\u65F6\u95F4",
            all_data_table2: "\u4F1A\u5458ID",
            all_data_table3: "\u8BA2\u91D1",
            all_data_table4: "\u6709\u6548\u6295\u6CE8",
            all_data_table5: "\u603B\u635F\u5931\u548C\u6536\u76CA",
            all_data_label1: "\u76F4\u5C5E\u5145\u503C\u91D1\u989D",
            all_data_label2: "\u76F4\u5C5E\u9996\u5145\u4EBA\u6570",
            all_data_label3: "\u5176\u4ED6\u5145\u503C\u91D1\u989D",
            all_data_label4: "\u5176\u4ED6\u5145\u503C\u4EBA\u6570",
            all_data_label5: "\u603B\u5145\u503C\u91D1\u989D",
            all_data_label6: "\u603B\u5145\u503C\u4EBA\u6570",
            direct_finance_table1: "\u4ED6\u7684\u4E0B\u7EA7",
            direct_finance_table2: "\u5145\u503C",
            direct_finance_table3: "\u63D0\u73B0",
            direct_finance_table4: "\u5145\u63D0\u5DEE",
            direct_finance_table5: "\u4F59\u989D",
            direct_finance_table6: "\u6B21",
            direct_finance_label1: "\u603B\u5145\u503C\u91D1\u989D",
            direct_finance_label2: "\u5145\u503C\u4EBA\u6570",
            direct_finance_label3: "\u9996\u5145\u91D1\u989D",
            direct_finance_label4: "\u9996\u5145\u4EBA\u6B21",
            direct_finance_label5: "\u603B\u63D0\u73B0\u91D1\u989D",
            direct_finance_label6: "\u63D0\u73B0\u6B21\u6570",
            direct_bet_detail: "\u6295\u6CE8\u660E\u7EC6",
            direct_bet_table1: "\u4ED6\u7684\u4E0B\u7EA7",
            direct_bet_table2: "\u6709\u6548\u6295\u6CE8",
            direct_bet_table3: "\u7D2F\u8BA1\u8F93\u8D62",
            direct_bet_table4: "\u6B21",
            direct_bet_label1: "\u76F4\u5C5E\u6709\u6548\u6295\u6CE8",
            direct_bet_label2: "\u5176\u4ED6\u6709\u6548\u6295\u6CE8",
            direct_bet_label3: "\u603B\u6709\u6548\u6295\u6CE8",
            direct_bet_label4: "\u76F4\u5C5E\u8F93\u8D62",
            direct_bet_label5: "\u5176\u4ED6\u8F93\u8D62",
            direct_bet_label6: "\u603B\u8F93\u8D62",
            direct_bet_detail1: "\u5382\u5546",
            direct_bet_detail2: "\u6E38\u620F\u540D",
            direct_bet_detail3: "\u6709\u6548\u6295\u6CE8",
            direct_bet_detail4: "\u7D2F\u8BA1\u76C8\u4E8F",
            direct_bet_detail5: "\u603B\u6295\u6CE8",
            direct_bet_detail6: "\u603B\u6295\u6CE8\u6B21\u6570",
            direct_bet_detail7: "\u603B\u635F\u76CA",
            direct_data_date: "\u65E5\u671F",
            direct_data_table1: "\u4ED6\u7684\u4E0B\u7EA7",
            direct_data_table2: "\u5145\u503C\u91D1\u989D",
            direct_data_table3: "\u6CE8\u518C\u65E5\u671F",
            direct_data_table4: "\u6709\u6548\u6295\u6CE8",
            direct_data_table5: "\u767B\u5F55\u65E5\u671F",
            direct_data_table6: "\u5F53\u524D",
            direct_data_table7: "\u72B6\u6001",
            direct_data_text1: "Yes",
            direct_data_text2: "No",
            direct_data_text3: "Not allowed to accept prizes",
            direct_data_text4: "Freeze",
            direct_data_text5: "Normal",
            direct_data_text6: "Online",
            direct_data_text7: "Offline",
            direct_data_sum1: "\u6CE8\u518C\u4EBA\u6570",
            direct_data_sum2: "\u5145\u503C\u4EBA\u6B21",
            direct_data_sum3: "\u9996\u5145\u4EBA\u6570",
            direct_data_sum4: "\u5145\u503C\u91D1\u989D",
            direct_data_sum5: "\u6709\u6548\u6295\u6CE8",
            direct_award_table1: "Total Claimed",
            direct_award_table2: "Activity Claimed",
            direct_award_table3: "Task Claimed",
            direct_award_table4: "Rebate Claimed",
            direct_award_table5: "VIP Claimed",
            direct_award_table6: "Agent Commission",
            direct_award_table7: "Interest Earnings",
            my_data_text1: "\u65B0\u589E\u76F4\u5C5E\u4F1A\u5458",
            my_data_text2: "\u9996\u5145\u4EBA\u6570",
            my_data_text3: "\u5145\u503C\u4EBA\u6B21",
            my_data_text4: "\u5145\u503C\u91D1\u989D",
            my_data_text5: "\u4E1A\u7EE9",
            my_data_text6: "\u4F63\u91D1",
            my_data_text7: "\u6570\u636E\u6982\u89C8",
            my_data_text8: "\u6211\u7684\u56E2\u961F",
            my_data_text9: "\u603B\u4EBA\u6570",
            my_data_text10: "\u76F4\u5C5E\u4EBA\u6570",
            my_data_text11: "\u5176\u4ED6\u4EBA\u6570",
            my_data_text12: "\u6211\u7684\u4E1A\u7EE9",
            my_data_text13: "\u603B\u4E1A\u7EE9",
            my_data_text14: "\u76F4\u5C5E\u4E1A\u7EE9",
            my_data_text15: "\u5176\u4ED6\u4E1A\u7EE9",
            my_data_text16: "\u6211\u7684\u4F63\u91D1",
            my_data_text17: "\u603B\u4F63\u91D1",
            my_data_text18: "\u76F4\u5C5E\u4F63\u91D1",
            my_data_text19: "\u5176\u4ED6\u4F63\u91D1",
            my_data_date1: "\u6628\u65E5",
            my_data_date2: "\u4ECA\u65E5",
            my_data_date3: "\u672C\u5468",
            my_data_date4: "\u4E0A\u5468",
            my_data_date5: "\u672C\u6708",
            my_data_date6: "\u4E0A\u6708",
            performanceDetail: {
                performance: "\u8D21\u732E\u4E1A\u7EE9",
                winLose: "\u4F1A\u5458\u76C8\u4E8F",
                discount: "\u4F18\u60E0\u9886\u53D6"
            },
            commissionDetail: {
                member: "\u8D21\u732E\u4EBA\u6570",
                performance: "\u4E1A\u7EE9",
                commission: "\u4F63\u91D1",
                gameType: "\u6E38\u620F\u7C7B\u578B"
            }
        },
        wallet: {
            all: "\u5168\u90E8",
            wallet: "\u94B1\u5305",
            center_wallet: "\u4E2D\u5FC3\u94B1\u5305",
            one_click_recycling: "\u4E00\u952E\u56DE\u6536",
            venue_wallet: "\u6E38\u620F\u573A\u9986\u94B1\u5305",
            balance: "\u8D26\u6237\u4F59\u989D",
            placeholder: "\u5E73\u53F0\u641C\u7D22",
            tips: "\u53EA\u80FD\u68C0\u7D22\u4F59\u989D\u7684\u6574\u6570\u500D\uFF08\u5373\u6CA1\u6709\u5C0F\u6570\u70B9\uFF09"
        },
        exchange: {
            exchange: "\u5151\u6362",
            exchange_record: "\u5151\u6362\u8BB0\u5F55",
            audit_record: "\u7A3D\u6838\u8BB0\u5F55",
            account_manage: "\u8D26\u53F7\u7BA1\u7406",
            account_balance: "\u8D26\u6237\u4F59\u989D",
            withdrawable_balance: "\u53EF\u63D0\u73B0\u4F59\u989D",
            need_bet: "\u8FD8\u9700\u4E0B\u6CE8",
            can_withdraw: "\u53EF\u63D0\u73B0",
            auditing: "\u6B63\u5728\u7A3D\u6838",
            detailInfo: "\u8BE6\u60C5",
            standard_withdrawal: "\u6807\u51C6\u63D0\u6B3E",
            tips1: "\u8BF7\u8F93\u5165\u5151\u6362\u91D1\u989D",
            tips2: "\u8BF7\u9009\u62E9\u63D0\u6B3E\u8D26\u6237",
            all: "\u5168\u90E8",
            exchange_pwd: "\u5151\u6362\u5BC6\u7801",
            confirm: "\u786E\u8BA4",
            add_account: "\u65B0\u589E\u8D26\u6237",
            tips3: "\u5BC6\u7801\u4E0D\u80FD\u4E3A\u7A7A",
            tips4: "\u5BC6\u7801\u9519\u8BEF",
            accumulate_exchange: "\u7D2F\u8BA1\u5151\u6362",
            order_no: "\u8BA2\u5355\u53F7",
            success: "\u6210\u529F",
            fail: "\u5931\u8D25",
            checking: "\u5BA1\u6838\u4E2D",
            today: "\u4ECA\u5929",
            yesterday: "\u6628\u5929",
            seven_days: "7\u5929",
            fifteen_days: "15\u5929",
            thirty_days: "30\u5929",
            total_waiting_audit: "\u5F85\u7A3D\u6838\u603B\u989D",
            audit_detail: "\u7A3D\u6838\u8BE6\u60C5",
            transaction_type: "\u4EA4\u6613\u7C7B\u578B",
            audit_progress: "\u7A3D\u6838\u8FDB\u5EA6",
            amount: "\u4EA4\u6613\u989D",
            audit_multiplier: "\u7A3D\u6838\u500D\u6570",
            to_be_audit: "\u5F85\u7A3D\u6838",
            audited: "\u5DF2\u7A3D\u6838",
            create_time: "\u521B\u5EFA\u65F6\u95F4",
            exchange_account: "\u5151\u6362\u8D26\u6237",
            digital_currency: "\u6570\u5B57\u8D27\u5E01",
            add: "\u6DFB\u52A0",
            tips5: "\u8F93\u5165\u60A8\u7684\u624B\u673A\u8D26\u53F7",
            tips6: "\u8BF7\u8F93\u516511\u4F4D\u53F7\u7801",
            tips7: "\u8F93\u5165\u60A8\u768411\u4F4D\u516C\u79EF\u91D1\u53F7\u7801",
            tips8: "PIX\u8D26\u53F7\u4E0D\u80FD\u4E3A\u7A7A",
            tips9: "\u4E0D\u80FD\u4E3A\u7A7A",
            add_digital_currency: "\u6DFB\u52A0\u6570\u5B57\u8D27\u5E01",
            tips10: "\u8BF7\u8F93\u5165\u52A0\u5BC6\u8D27\u5E01\u5730\u5740",
            tips11: "\u5730\u5740\u5B57\u6BB5\u4E0D\u80FD\u4E3A\u7A7A",
            tips12: "\u786E\u8BA4\u8D27\u5E01\u3001\u534F\u8BAE\u548C\u5730\u5740\u5339\u914D\uFF0C\u5426\u5219\u91D1\u989D\u5C06\u4E0D\u4F1A\u8BB0\u5165\u3002",
            tips13: "\u5730\u5740\u4E0D\u80FD\u4E3A\u7A7A",
            tips14: "\u6700\u591A\u53EA\u652F\u6301\u589E\u52A0\u4E00\u4E2ACPF\u8D26\u6237",
            tips15: "\u59D3\u540D\u4E0D\u80FD\u4E3A\u7A7A",
            tips16: "\u8BF7\u8F93\u5165\u59D3\u540D",
            deleteTips: "\u786E\u8BA4\u5220\u9664\u8D26\u53F7\uFF1F",
            tips17: "\u8D26\u53F7\u6DFB\u52A0\u6570\u91CF\u5DF2\u8FBE\u4E0A\u9650",
            tips18: "Please carefully check the name and card number, otherwise it will not be credited",
            tips19: "Only 1 PIX account of PIX-CPF type can be added",
            tips20: "Please check carefully, otherwise it will not be credited.",
            tips21: "Please enter the eleven phone number, starting with 0",
            tips22: "\u6CE8\uFF1A\u8BF7\u786E\u4FDD\u63D0\u6B3E\u540D\u79F0\u548C\u63D0\u6B3E\u4FE1\u606F\u4E00\u81F4\uFF0C\u907F\u514D\u63D0\u6B3E\u5931\u8D25\u3002",
            sendTo: "\u53D1\u653E\u81F3",
            addWalletBtn: "\u786E\u8BA4",
            detail: {
                title: "\u63D0\u73B0\u8BE6\u60C5",
                type: "\u4EA4\u6613\u7C7B\u578B",
                withdraw: "\u63D0\u73B0",
                methods: "\u63D0\u73B0\u65B9\u5F0F",
                fee: "\u624B\u7EED\u8D39",
                createTime: "\u521B\u5EFA\u65F6\u95F4",
                orderNo: "\u8BA2\u5355\u53F7",
                remark: "\u5907\u6CE8"
            }
        },
        recharge: {
            recharge: "\u5B58\u6B3E",
            recharge_online: "\u5728\u7EBF\u5145\u503C",
            digital_currency: "\u7F51\u94F6\u652F\u4ED8",
            recharge_record: "\u5B58\u6B3E\u8BB0\u5F55",
            recharge_amount: "\u5B58\u6B3E\u91D1\u989D",
            recharge_tips: "\u5956\u52B1\u6D3B\u52A8\u8BF4\u660E",
            recharge_tipsText: "\u6839\u636E\u63A8\u8350\u91D1\u989D\u5B58\u6B3E\u5373\u53EF\u83B7\u5F97\u76F8\u5E94\u7684\u5956\u91D1\u3002\u5956\u91D1\u91D1\u989D\u4E0E\u5B58\u6B3E\u5956\u91D1\u53E0\u52A0\u3002",
            currency: "\u96F7\u4E9A\u5C14",
            terms: "\u4F7F\u7528\u6761\u6B3E",
            recharge_now: "\u7ACB\u5373\u5145\u503C",
            USDT_rate: "USDT\u6C47\u7387",
            tips1: "\u8BF7\u6B63\u786E\u586B\u5199\u4ED8\u6B3E\u4EBA\u94B1\u5305\u5730\u5740\u624D\u80FD\u6B63\u5E38\u5230\u8D26",
            tips2: "\u8F93\u5165\u4ED8\u6B3E\u4EBA\u7684\u94B1\u5305\u5730\u5740",
            tips3: "\u8BF7\u8F93\u5165\u91D1\u989D",
            tips4: "\u8BF7\u8F93\u5165\u5730\u5740",
            tips5: "\u8BF7\u586B\u5199\u4EA4\u6613\u7684TxId",
            tips6: "\u8BA2\u5355\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u63D0\u4EA4\u8BA2\u5355",
            submit: "\u63D0\u4EA4",
            total_deposit: "\u603B\u5B58\u6B3E",
            recharge_detail: "\u5B58\u6B3E\u8BE6\u60C5",
            trade_type: "\u4EA4\u6613\u7C7B\u578B",
            recharge_type: "\u5145\u503C\u65B9\u5F0F",
            recharge_channel: "\u5145\u503C\u901A\u9053",
            create_time: "\u521B\u5EFA\u65F6\u95F4",
            order_no: "\u8BA2\u5355\u53F7",
            free: "\u514D\u8D39",
            min: "\u6700\u5C0F",
            max: "\u6700\u5927",
            exchangeRate: "\u6C47\u7387",
            addPoint: "\u589E\u52A0\u6570\u91CF",
            jump_tips: "\u70B9\u51FB\u786E\u8BA4\u8DF3\u8F6C\u5230\u652F\u4ED8\u9875\u9762",
            recharge_exchange_rate_tipsText: "\u70B9\u51FB\u53EF\u4EE5\u5207\u6362\u5151\u6362\u5E01\u79CD"
        },
        account: {
            account_detail: "\u8D26\u53F7\u8BE6\u7EC6\u8D44\u6599",
            bet_record: "\u6295\u6CE8\u8BB0\u5F55",
            personal_report: "\u4E2A\u4EBA\u62A5\u544A",
            all: "\u5168\u90E8",
            time: "\u65F6\u95F4",
            transaction_type: "\u4EA4\u6613\u7C7B\u578B",
            detail: "\u8BE6\u7EC6\u4FE1\u606F",
            quantity: "\u6570\u91CF",
            total_deposits: "\u603B\u5B58\u6B3E",
            accumulated_withdrawals: "\u7D2F\u8BA1\u63D0\u6B3E",
            type: "\u7C7B\u578B",
            platform: "\u5E73\u53F0",
            game: "\u6E38\u620F",
            effective_betting: "\u6709\u6548\u6295\u6CE8",
            profit_loss: "\u635F\u76CA",
            bet_number: "\u6295\u6CE8\u6B21\u6570",
            bet_total: "\u6295\u6CE8\u603B\u6570",
            total_win_loss: "\u603B\u80DC/\u8D1F"
        },
        login: {
            password_login: "\u5BC6\u7801\u767B\u5F55",
            msg_login: "\u77ED\u4FE1\u767B\u5F55",
            tips1: "\u8F93\u51656\u523016\u4E2A\u5B57\u7B26\uFF0C\u652F\u6301\u5B57\u6BCD/\u6570\u5B57/\u7B26\u53F7",
            remember_password: "\u8BB0\u4F4F\u5BC6\u7801",
            forget_password: "\u5FD8\u8BB0\u5BC6\u7801",
            login: "\u767B\u5F55",
            register: "\u6CE8\u518C\u8D26\u53F7",
            other_login_methods: "\u5176\u4ED6\u767B\u5F55\u65B9\u5F0F",
            tips2: "\u7528\u6237\u957F\u5EA6\u5C0F\u4E8E4\u4F4D\u6570",
            tips3: "\u5BC6\u7801\u683C\u5F0F\u4E0D\u6B63\u786E",
            telephone: "\u624B\u673A\u53F7\u7801",
            enter_password: "\u8F93\u5165\u5BC6\u7801",
            again_enter_password: "\u518D\u6B21\u8F93\u5165\u5BC6\u7801",
            strength: "\u5F3A\u5EA6",
            register2: "\u8D26\u53F7\u6CE8\u518C",
            register3: "\u6CE8\u518C",
            tips4: "\u8F93\u51654\u523016\u4E2A\u5B57\u7B26\uFF0C\u652F\u6301\u5B57\u6BCD/\u6570\u5B57\uFF0C\u9996\u4F4D\u5FC5\u987B\u5B57\u6BCD",
            tips5: "\u8F93\u5165\u7684\u624B\u673A\u53F7\u7801\u4E0D\u6B63\u786E",
            tips6: "\u8F93\u5165\u7684\u9A8C\u8BC1\u7801\u4E0D\u6B63\u786E",
            text1: "\u6211\u5DF2\u5E74\u6EE118\u5C81\uFF0C\u5DF2\u9605\u8BFB\u5E76\u63A5\u53D7",
            agreement: "\u300A\u7528\u6237\u534F\u8BAE\u300B",
            login_now: "\u7ACB\u5373\u767B\u5F55",
            general_registration: "\u666E\u901A\u6CE8\u518C",
            mobile_registration: "\u624B\u673A\u6CE8\u518C",
            tips7: "\u4E24\u6B21\u5BC6\u7801\u4E0D\u4E00\u81F4",
            tips8: "\u8BF7\u540C\u610F\u534F\u5B9A\u4E66",
            tips9: "\u5BC6\u7801\u683C\u5F0F\u4E0D\u6B63\u786E",
            tips10: "\u4E24\u6B21\u8F93\u5165\u5BC6\u7801\u4E0D\u4E00\u81F4",
            tips11: "\u624B\u673A\u53F7\u7801\u4E0D\u6B63\u786E",
            tips12: "\u9A8C\u8BC1\u7801\u4E0D\u6B63\u786E",
            reset_password: "\u91CD\u8BBE\u5BC6\u7801",
            reset_exchangePwd: "\u91CD\u8BBE\u5151\u6362\u5BC6\u7801",
            confirm: "\u786E\u5B9A",
            username: "\u7528\u6237\u540D",
            send_code: "\u53D1\u9001\u9A8C\u8BC1\u7801",
            code: "\u9A8C\u8BC1\u7801",
            tips13: "\u8F93\u51656\u4F4D\u6570\u5B57",
            rewardTips: "\u6CE8\u518C\u5956\u91D1",
            agreement_btn: "\u6211\u5DF2\u77E5\u6089",
            successText: "\u9A8C\u8BC1\u901A\u8FC7",
            failText: "\u9A8C\u8BC1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5",
            sliderText: "\u62D6\u52A8\u6ED1\u5757\u5B8C\u6210\u62FC\u56FE",
            login_pwd: "\u767B\u5F55\u5BC6\u7801",
            verify_login_pwd: "\u9A8C\u8BC1\u767B\u5F55\u5BC6\u7801",
            customer_service: "Customer Service"
        },
        side_bar: {
            bet_record: "\u6295\u6CE8\u8BB0\u5F55",
            agency: "\u4EE3\u7406",
            event_title: "\u63A8\u5E7F",
            event: "\u6D3B\u52A8",
            task: "\u4EFB\u52A1",
            rebate: "\u8FD4\u6C34",
            reward: "\u5956\u91D1",
            history: "\u9886\u53D6\u8BB0\u5F55",
            fees: "\u5B58\u94B1\u5B9D",
            dealer: "\u7ECF\u9500\u5546",
            vip: "VIP",
            pending: "\u5F85\u9886\u53D6",
            agent: "\u4EE3\u7406",
            network: "\u7F51\u7EDC",
            download: "\u4E0B\u8F7DAPP",
            customer_service: "\u5BA2\u670D",
            faq: "\u5E38\u89C1\u95EE\u9898",
            about_us: "\u5173\u4E8E\u6211\u4EEC",
            closed: "\u6682\u672A\u5F00\u653E",
            exchange: "\u63D0\u73B0",
            account_manage: "\u8D26\u53F7\u7BA1\u7406"
        },
        header_menu: {
            recharge: "\u5145\u503C",
            withdraw: "\u63D0\u53D6",
            login: "\u767B\u5F55",
            or: " Or ",
            register: "\u6CE8\u518C",
            tips: "\u4F7F\u7528\u6E38\u620F\u4E2D"
        },
        common: {
            confirm: "\u786E\u8BA4",
            cancel: "\u53D6\u6D88",
            no_remind: "No more reminders today",
            pls: "\u8BF7",
            add_to: "\u6DFB\u52A0\u5230",
            home_screen: "\u4E3B\u5C4F\u5E55",
            no_data: "\u6682\u65E0\u6570\u636E",
            tips: "\u63D0\u793A",
            day: "\u5929",
            hour: "\u65F6",
            minutes: "\u5206",
            second: "\u79D2",
            recharge: "\u5145\u503C",
            exit: "\u9000\u51FA",
            refresh: "\u66F4\u65B0",
            full_screen: "\u5168\u5C4F"
        },
        promotion_event: {
            mixed: "\u7EFC\u5408\u7684",
            collect_all: "\u5168\u90E8\u9886\u53D6",
            collect_record: "\u9886\u53D6\u8BB0\u5F55",
            coming: "\u656C\u8BF7\u671F\u5F85",
            end: "\u5DF2\u7ED3\u675F",
            collect: "\u9886\u53D6",
            collected: "\u5DF2\u9886\u53D6",
            incomplete: "\u672A\u5B8C\u6210",
            continuous_login: "\u8FDE\u7EED\u767B\u5F55",
            day: "\u5929",
            days: "\u5929",
            deposit_required: "\u9700\u8981\u5145\u503C",
            bet: "\u6295\u6CE8",
            di: "\u7B2C",
            mysterious_bonus: "\u795E\u79D8\u5956\u91D1",
            total_collect: "\u5171\u9886\u53D6",
            loss: "\u6628\u5929\u7684\u635F\u5931",
            relief: "\u4ECA\u5929\u6551\u63F4\u5956\u52B1",
            loss_amount: "\u635F\u5931\u91D1\u989D",
            additional_rewards: "\u989D\u5916\u5956\u52B1",
            back: "\u8FD4\u56DE",
            link: "\u4F60\u7684\u63A8\u5E7F\u94FE\u63A5",
            quick_share: "\u5FEB\u901F\u5206\u4EAB",
            effective_people: "\u6709\u6548\u63A8\u5E7F\u4EBA\u5458",
            request_qty: "\u8981\u6C42\u6570\u91CF",
            activity_conditions: "\u6D3B\u52A8\u6761\u4EF6",
            effective_qty: "\u6709\u6548\u63A8\u5E7F\u4EBA\u6570",
            effective_bind_phone: "\u6709\u6548\u63A8\u5E7F\u7ED1\u5B9A\u624B\u673A\u4EBA\u6570",
            effective_recharge: "\u6709\u6548\u63A8\u5E7F\u4EBA\u5145\u503C\u91D1\u989D",
            effective_bet: "\u6709\u6548\u63A8\u5E7F\u4EBA\u6253\u7801\u91D1\u989D",
            people: "\u4EBA",
            detail: "\u8BE6\u60C5",
            promotion_tips_title: "\u6709\u6548\u664B\u5347\u7684\u73A9\u5BB6\u4EBA\u6570\u662F\u591A\u5C11\uFF1F\uFF08\u6EE1\u8DB3\u4EE5\u4E0B\u6240\u6709\u6761\u4EF6\uFF09",
            subordinate_recharge: "\u88AB\u63A8\u5E7F\u4EBA\u5458\u5DF2\u7D2F\u8BA1\u5145\u503C",
            subordinate_bet: "\u88AB\u63A8\u5E7F\u4EBA\u5458\u5DF2\u7D2F\u8BA1\u6295\u6CE8",
            maximum: "\u6700\u5927\u503C",
            aforementioned: "\u6216\u8005\u4E0A\u8FF0\u63D0\u53CA\u7684",
            more: "\u66F4\u591A",
            apply: "\u7533\u8BF7\u4F18\u60E0",
            apply_now: "\u73B0\u5728\u7533\u8BF7",
            apply_placeholder: "\u8BF7\u8F93\u5165\u7B54\u6848",
            apply_tips: "\u8BF7\u586B\u5199\u6240\u6709\u7B54\u6848",
            my_referrals: "\u6211\u7684\u63A8\u8350",
            account: "\u8D26\u53F7",
            accumulated_recharge: "\u7D2F\u8BA1\u5145\u503C",
            accumulated_bets: "\u7D2F\u8BA1\u6295\u6CE8",
            status: "\u72B6\u6001",
            efficient: "\u6709\u6548",
            invalid: "\u65E0\u6548",
            balance_time: "\u5269\u4F59\u7533\u8BF7\u6B21\u6570",
            tips: "\u6CE8",
            tips1: "1.\u88AB\u63A8\u5E7F\u4EBA\u5458\u9700\u7ED1\u5B9A\u624B\u673A\u540E\uFF0C\u5219\u4E3A\u6709\u6548\u63A8\u5E7F\u4EBA\u6570\uFF1B",
            tips2: "2.\u5F53\u524D\u8FDB\u5EA6\u8FBE\u5230\u63A8\u5E7F\u4EBA\u6570\u540E\uFF0C\u53EF\u4E00\u6B21\u6027\u9886\u53D6\u5230\u53EF\u63D0\u73B0\u4F59\u989DCPF\uFF1B",
            rewardAmount: "\u5956\u52B1\u91D1\u989D",
            currentProcess: "\u5F53\u524D\u8FDB\u5EA6",
            bindPhone: "\u7ED1\u5B9A\u624B\u673A",
            receive_success: "\u9886\u53D6\u6210\u529F",
            valid_people: "\u6709\u6548\u4EBA\u6570",
            registerTime: "\u6CE8\u518C\u65F6\u95F4",
            recharge: "\u5145\u503C",
            bet: "\u6253\u7801",
            request_recharge: "\u5145\u503C\u989D\u5EA6",
            tips3: "\u4ECA\u65E5\u518D\u5145\u503C{amount}\u53EF\u83B7\u5F97\u4E0B\u4E2A\u6863\u4F4D\u6700\u9AD8\u9886\u53D6\u91D1\u989D\u3002",
            tips4: "\u6709\u6548\u63A8\u5E7F\uFF1A\u9700\u4E0B\u7EA7\u7D2F\u8BA1\u5145\u503C {amount} \uFF0C\u6295\u6CE8 {bet} \uFF0C\u7ED1\u5B9A\u624B\u673A",
            tips5: "\u6709\u6548\u63A8\u5E7F\uFF1A\u9700\u4E0B\u7EA7\u7D2F\u8BA1\u5145\u503C {amount} \uFF0C\u6295\u6CE8 {bet} \u3002",
            break_through_text1: "\u4ECA\u65E5\u95EF\u5173\u6E38\u620F",
            break_through_text2: "\u5173\u5361\u6570",
            break_through_text3: "\u9080\u8BF7\u4EBA\u6570",
            break_through_text4: "\u9080\u8BF7\u5956\u52B1\u91D1\u989D",
            break_through_text5: "\u95EF\u5173\u603B\u6253\u7801",
            break_through_text6: "\u95EF\u5173\u989D\u5916\u5956\u91D1",
            break_through_text7: "\u4ECA\u65E5\u95EF\u5173\u6570",
            break_through_text8: "\u4ECA\u65E5\u9080\u8BF7\u4EBA\u6570\u5956\u52B1\u91D1\u989D",
            break_through_text9: "\u4ECA\u65E5\u95EF\u5173\u603B\u6253\u7801",
            break_through_text10: "\u4ECA\u65E5\u95EF\u5173\u989D\u5EA6\u5956\u52B1",
            break_through_text11: "\u5DF2\u9886\u53D6\u5956\u52B1",
            break_through_text12: "\u5F85\u9886\u53D6\u5956\u52B1",
            break_through_text13: "\u540CIP",
            balance_relief_fund_text1: "\u5DF2\u5145\u503C\u8FC7\u7684\u4F1A\u5458",
            balance_relief_fund_text2: "\u8D26\u6237\u4F59\u989D\u5C0F\u4E8E",
            balance_relief_fund_text3: "\u5956\u52B1\u5145\u503C\u91D1\u989D\u6BD4\u4F8B\u7684",
            balance_relief_fund_text4: "\u8D26\u6237\u4F59\u989D\u5C0F\u4E8E",
            balance_relief_fund_text5: "\u6253\u7801\u91D1\u989D\u8FBE\u5230",
            balance_relief_fund_text6: "\u5956\u52B1\u6253\u7801\u91D1\u989D\u6BD4\u4F8B\u7684",
            balance_relief_fund_text7: "\u5956\u52B1\u53D1\u653E",
            balance_relief_fund_text8: "\u8FBE\u5230\u65F6\u7CFB\u7EDF\u81EA\u52A8\u53D1\u653E\u5956\u52B1",
            balance_relief_fund_text9: "\u672A\u5145\u503C\u8FC7\u7684\u4F1A\u5458",
            balance_relief_fund_text10: "\u5956\u52B1\u989D\u5EA6",
            balance_relief_fund_text11: "\u5DF2\u5145\u503C\u4F1A\u5458\u6D3E\u5956\u8BA1\u7B97\uFF1A\u603B\u5145\u503C\u989D\u5EA6x\u8BBE\u5B9A\u6BD4\u4F8B\u6216\u56FA\u5B9A\u5956\u52B1\u989D\u5EA6",
            balance_relief_fund_text12: "\u5982\uFF1A\u4F1A\u5458a\u5DF2\u5145\u503C1000\uFF0C\u6D3E\u5956\u6BD4\u4F8B5%\uFF0C\u5219\u53EF\u83B7\u5F97\u5956\u52B1\uFF1A1000x5%=50",
            balance_relief_fund_text13: "\u672A\u5145\u503C\u4F1A\u5458\u6D3E\u5956\u8BA1\u7B97\uFF1A\u603B\u6253\u7801\u989D\u5EA6x\u8BBE\u5B9A\u6BD4\u4F8B\u6216\u56FA\u5B9A\u5956\u52B1\u989D\u5EA6",
            balance_relief_fund_text14: "\u5982\uFF1A\u4F1A\u5458b\u672A\u5145\u503C\uFF0C\u6253\u7801500\uFF0C\u6D3E\u5956\u6BD4\u4F8B1.5%\uFF0C\u5219\u53EF\u83B7\u5F97\u5956\u52B1\uFF1A500x1.5%=7.5",
            balance_relief_fund_text15: "\u9886\u5956\u6B21\u6570",
            balance_relief_fund_text16: "\u5DF2\u5145\u503C\u4F1A\u5458\u9886\u5956\u540E\uFF0C\u7B2C\u4E8C\u6B21\u7834\u4EA7\u9700\u8981\u518D\u6B21\u5145\u503C\u540E\u53EF\u9886\u5956",
            balance_relief_fund_text17: "\u672A\u5145\u503C\u4F1A\u5458\u9886\u5956\u540E\uFF0C\u7B2C\u4E8C\u6B21\u7834\u4EA7\u9700\u91CD\u65B0\u7D2F\u8BA1\u8FBE\u5230\u6253\u7801\u989D\u5EA6\u540E\u53EF\u9886\u5956",
            balance_relief_fund_text18: "\u5956\u52B1\u91D1\u989D"
        },
        promotion_task: {
            current_PA: "\u5F53\u524DPA",
            reset_PA: "PA\u590D\u4F4D\u65F6\u95F4",
            collect_all: "\u4E00\u952E\u9886\u53D6",
            collect_record: "\u9886\u53D6\u8BB0\u5F55",
            next: "\u7EE7\u7EED",
            collect: "\u9886\u53D6",
            collected: "\u5DF2\u9886\u53D6",
            bonus: "\u5956\u91D1",
            rule_title1: "\u4E00\u3001\u4EFB\u52A1\u65F6\u95F4",
            rule_title2: "\u4E8C\u3001\u4EFB\u52A1\u6761\u4EF6\uFF1A",
            rule_title3: "\u4E09\u3001\u4EFB\u52A1\u5185\u5BB9\uFF1A",
            news_title: "\u65B0\u73A9\u5BB6\u798F\u5229",
            news_rule_text1: "\u9650\u65F6\u4EFB\u52A1\uFF08\u6CE8\u518C\u540E",
            news_rule_text2: "\u5929\u5185\u6709\u6548\uFF09",
            news_rule_text3: "\u5B8C\u6210\u76F8\u5173\u8BBE\u7F6E\u548C\u6211\u4EEC\u7684\u8D26\u6237\u5B89\u5168\u94FE\u63A5",
            news_rule_text4: "1.\u6240\u6709\u65B0\u6CE8\u518C\u4F1A\u5458\u5B8C\u6210\u4E0A\u8FF0\u4EFB\u52A1\uFF0C\u5B8C\u6210\u4EFB\u52A1\u540E\u53EF\u83B7\u5F97\u4E00\u5B9A\u6570\u989D\u7684\u5956\u52B1\uFF0C\u96BE\u5EA6\u8D8A\u9AD8\uFF0C\u5956\u52B1\u8D8A\u9AD8\u3002",
            news_rule_text5: "2.\u7531\u4E8E\u6BCF\u4E2A\u8D26\u6237\u90FD\u662F\u5B8C\u5168\u533F\u540D\u7684\uFF0C\u5982\u679C\u88AB\u76D7\uFF0C\u5C06\u65E0\u6CD5\u8FFD\u56DE\u56E0\u88AB\u76D7\u800C\u9020\u6210\u7684\u4EFB\u4F55\u8D44\u91D1\u635F\u5931\u3002\u56E0\u6B64\uFF0C\u6211\u4EEC\u5B9E\u65BD\u4E86\u4E24\u6B65\u5E10\u6237\u9A8C\u8BC1\u6D41\u7A0B\uFF0C\u7279\u522B\u662F\u5305\u542B\u4ED8\u6B3E\u7535\u5B50\u90AE\u4EF6\uFF0C\u4EE5\u9A8C\u8BC1\u5E10\u6237\u6240\u6709\u8005\u6240\u91C7\u53D6\u7684\u64CD\u4F5C\u5E76\u786E\u4FDD\u5176\u5E10\u6237\u7684\u5B89\u5168\u3002",
            news_rule_text6: "3.\u6EE1\u8DB3\u6761\u4EF6\u76F4\u63A5\u63A5\u6536\u3002\u53EF\u4EE5\u76F4\u63A5\u5728iOS\u3001Android\u3001H5\u3001PC\u4EFB\u610F\u4E00\u4E2A\u79EF\u5206\u9886\u53D6\uFF0C\u8D44\u91D1\u8FC7\u671F\u89C6\u4E3A\u4F5C\u5E9F\uFF08\u7528\u6237\u672A\u9886\u53D6\u89C6\u4E3A\u81EA\u613F\u4E22\u5931\uFF09\u3002",
            news_rule_text7: "4.\u7531\u4E8E\u672C\u6B21\u4EFB\u52A1\u5956\u91D1\u8F83\u9AD8\uFF0C\u6240\u63D0\u4F9B\u7684\u5956\u91D1\u9700\u8981",
            news_rule_text8: "\u500D\u5F53\u524D\uFF08\u5373\u5BA1\u6838\u3001\u53C2\u4E0E\u6216\u6709\u6548\u6295\u6CE8\uFF09\u624D\u80FD\u6536\u5230\u5956\u91D1\u3002\u53C2\u4E0E\u4E0D\u9650\u4E8E\u7279\u5B9A\u5E73\u53F0\u3002",
            news_rule_text9: "5.\u6B64\u4EFB\u52A1\u4EC5\u9650\u8D26\u53F7\u6240\u6709\u8005\u6B63\u5E38\u6E38\u620F\u3002\u4E25\u7981\u4F7F\u7528\u79DF\u8D41\u65B9\u6848\u3001\u4F7F\u7528\u6A21\u62DF\u5668\uFF08\u8BC8\u9A97\u7A0B\u5E8F\uFF09\u3001\u673A\u5668\u4EBA\u3001\u4E0D\u540C\u8D26\u6237\u6545\u610F\u6295\u6CE8\u3001\u6545\u610F\u914D\u7F6E\u3001\u534F\u540C\u3001\u5173\u8054\u3001\u534F\u8BAE\u3001\u5229\u7528\u6F0F\u6D1E\u3001\u7FA4\u63A7\u6216\u5176\u4ED6\u6280\u672F\u624B\u6BB5\u53C2\u4E0E\uFF0C\u5426\u5219\u5956\u52B1\u5C06\u88AB\u6CA1\u6536\u3001\u51BB\u7ED3\u6216\u4ECE\u5956\u52B1\u4E2D\u6263\u9664\uFF0C\u751A\u81F3\u53EF\u80FD\u88AB\u5217\u5165\u9ED1\u540D\u5355\u3002",
            news_rule_text10: "6.\u4E3A\u907F\u514D\u5BF9\u6587\u5B57\u7406\u89E3\u4EA7\u751F\u5206\u6B67\uFF0C\u5E73\u53F0\u5C06\u4FDD\u7559\u5BF9\u672C\u6B21\u6D3B\u52A8\u7684\u6700\u7EC8\u89E3\u91CA\u6743\u3002",
            daily_title: "\u6BCF\u65E5\u4EFB\u52A1",
            weekly_title: "\u6BCF\u5468\u4EFB\u52A1",
            daily_text1: "\u957F\u671F\u4EFB\u52A1\uFF08\u6BCF\u592900:00\u91CD\u7F6E\uFF09",
            daily_text2: "\u6BCF\u65E5\u5168\u989D\u5145\u503C\u3001\u6253\u7801\u5747\u53EF",
            daily_text3: "1.\u6BCF\u5929\u53EF\u4EE5\u8FDB\u884C\u4EE5\u4E0B\u4EFB\u52A1\uFF0C\u5305\u62EC\u6BCF\u65E5\u5145\u503C\u3001\u5355\u573A\u6295\u6CE8\u6216\u5176\u4ED6\u6295\u6CE8\u3002\u5B8C\u6210\u4EFB\u52A1\u540E\u53EF\u4EE5\u83B7\u5F97\u4E00\u5B9A\u6570\u989D\u7684\u5956\u52B1\u3002\u96BE\u5EA6\u8D8A\u5927\uFF0C\u5956\u52B1\u8D8A\u5927\uFF1B",
            daily_text4: "2.\u5982\u679C\u7B26\u5408\u6761\u4EF6\uFF0C\u53EF\u4EE5\u76F4\u63A5\u63D0\u73B0\u3002\u4E0D\u540C\u91D1\u989D\u53EF\u4E00\u7B14\u4E00\u63D0\uFF0C\u5EFA\u8BAE\u4E0B\u8F7D\u9AD8\u6E05\u7248\u5E94\u7528\uFF0C\u4F53\u9A8C\u66F4\u6109\u5FEB\u3002",
            daily_text5: "3.iOS\u3001Android\u3001H5\u3001PC\u76F4\u63A5\u9886\u53D6\uFF0C\u8FC7\u671F\u5931\u6548\uFF08\u5373\u4E0D\u4E3B\u52A8\u9886\u53D6\u89C6\u4E3A\u653E\u5F03\uFF09\uFF1B",
            daily_text6: "4\u3001\u672C\u6B21\u4EFB\u52A1\u6240\u83B7\u5F97\u7684\u5956\u91D1\uFF08\u4E0D\u542B\u4E3B\u5956\u91D1\uFF09\u9700\u8FBE\u5230\u5F53\u524D\u6295\u6CE8\u989D\u7684",
            daily_text7: "\u500D\uFF08\u5373\u5BA1\u6838\u3001\u6295\u6CE8\u6216\u6709\u6548\u6295\u6CE8\uFF09\u540E\u624D\u80FD\u63D0\u53D6\uFF1B",
            daily_text8: "5.\u6B64\u4EFB\u52A1\u4EC5\u9650\u8D26\u53F7\u6240\u6709\u8005\u6B63\u5E38\u6E38\u620F\u3002\u4E25\u7981\u4F7F\u7528\u79DF\u8D41\u65B9\u6848\u3001\u4F7F\u7528\u6A21\u62DF\u5668\uFF08\u8BC8\u9A97\u7A0B\u5E8F\uFF09\u3001\u673A\u5668\u4EBA\u3001\u4E0D\u540C\u8D26\u6237\u6545\u610F\u6295\u6CE8\u3001\u6545\u610F\u914D\u7F6E\u3001\u534F\u540C\u3001\u5173\u8054\u3001\u534F\u8BAE\u3001\u5229\u7528\u6F0F\u6D1E\u3001\u7FA4\u63A7\u6216\u5176\u4ED6\u6280\u672F\u624B\u6BB5\u53C2\u4E0E\uFF0C\u5426\u5219\u5956\u52B1\u5C06\u88AB\u6CA1\u6536\u3001\u51BB\u7ED3\u6216\u4ECE\u5956\u52B1\u4E2D\u6263\u9664\uFF0C\u751A\u81F3\u53EF\u80FD\u88AB\u5217\u5165\u9ED1\u540D\u5355\u3002",
            daily_text9: "6.\u4E3A\u907F\u514D\u5BF9\u6587\u5B57\u7406\u89E3\u4EA7\u751F\u5206\u6B67\uFF0C\u5E73\u53F0\u5C06\u4FDD\u7559\u5BF9\u672C\u6B21\u6D3B\u52A8\u7684\u6700\u7EC8\u89E3\u91CA\u6743\u3002",
            weekly_text1: "\u957F\u671F\u4EFB\u52A1\uFF08\u6BCF\u546800:00\u91CD\u7F6E\uFF09",
            weekly_text2: "\u6BCF\u5468\u5168\u989D\u5145\u503C\u3001\u6253\u7801\u5747\u53EF",
            weekly_text3: "1.\u6BCF\u5468\u53EF\u4EE5\u8FDB\u884C\u4EE5\u4E0B\u4EFB\u52A1\uFF0C\u5305\u62EC\u6BCF\u5468\u5145\u503C\u3001\u5355\u573A\u6295\u6CE8\u6216\u5176\u4ED6\u6295\u6CE8\u3002\u5B8C\u6210\u4EFB\u52A1\u540E\u53EF\u4EE5\u83B7\u5F97\u4E00\u5B9A\u6570\u989D\u7684\u5956\u52B1\u3002\u96BE\u5EA6\u8D8A\u5927\uFF0C\u5956\u52B1\u8D8A\u5927\uFF1B"
        },
        promotion_rebate: {
            today_effective_betting: "\u4ECA\u65E5\u6709\u6548\u6295\u6CE8",
            collect_all: "\u4E00\u952E\u9886\u53D6",
            collect_record: "\u9886\u53D6\u8BB0\u5F55",
            effective_betting: "\u6709\u6548\u6295\u6CE8",
            rebate_ratio: "\u8FD4\u6C34\u6BD4\u4F8B",
            can_be_claimed: "\u53EF\u9886\u53D6",
            next_ratio: "\u4E0B\u6863\u6BD4\u4F8B"
        },
        promotion_fees: {
            deposited: "\u5DF2\u5B58\u5165",
            year_rate: "\u5E74\u5229\u7387",
            settlement_cycle: "\u7ED3\u7B97\u5468\u671F",
            accumulated_claimed: "\u7D2F\u8BA1\u5DF2\u9886\u53D6",
            deposit: "\u5B58\u5165",
            withdraw: "\u53D6\u51FA",
            unclaimed: "\u5F85\u9886\u53D6",
            withdrawal_of_interest: "\u63D0\u53D6\u5229\u606F",
            tips1_1: "\u5229\u606F\u53EF\u4E8E",
            tips1_2: "\u540E\u9886\u53D6",
            detail: "\u8BE6\u60C5",
            rules: "\u89C4\u5219",
            tips2: "\u5012\u8BA1\u65F6\u5B8C\u6210\u53EF\u4EE5\u9886\u53D6",
            claim_interest: "\u9886\u53D6\u5229\u606F",
            total_income: "\u603B\u6536\u5165",
            time: "\u65F6\u95F4",
            amount: "\u91D1\u989D",
            hour: "\u5C0F\u65F6",
            type: "\u7C7B\u578B",
            quantity: "\u6570\u91CF",
            account_balance: "\u8D26\u6237\u4F59\u989D",
            tips3: "\u5B58\u5165\u548C\u53D6\u51FA\u4E0D\u4F1A\u4EA7\u751F\u5BA1\u8BA1\uFF0C\u4EC5\u5BF9\u6536\u5230\u7684\u5229\u606F\u8FDB\u884C\u5BA1\u8BA1",
            current_time: "\u5F53\u524D\u65F6\u95F4",
            all: "\u5168\u90E8",
            tips4: "\u9884\u8BA1\u5229\u606F\u5230\u8FBE\u65F6\u95F4",
            min_deposit: "\u6BCF\u6B21\u81F3\u5C11\u5B58\u5165",
            min_deposit_end: "",
            deposit_balance: "\u5B58\u5165\u4F59\u989D",
            output_value: "\u4EA7\u503C",
            tips5: "\u4E00\u65E6\u4F60\u63D0\u53D6\uFF0C\u4F60\u5C06\u5931\u53BB\u6700\u8FD1\u4E00\u4E2A\u5468\u671F\u7684\u5229\u606F",
            exchange_pwd: "\u63D0\u53D6\u5BC6\u7801",
            forget_pwd: "\u5FD8\u8BB0\u5BC6\u7801",
            support: "\u652F\u6301",
            tips6: "\u6BCF\u6B21\u81F3\u5C11\u53D6\u51FA\u91D1\u989D1",
            tips7: "\u8F93\u5165\u7684\u91D1\u989D\u4E0D\u80FD\u4E3A\u7A7A",
            tups8: "\u8BF7\u8F93\u51656\u4F4D\u6570\u5151\u6362\u5BC6\u7801",
            rule_title1: "1\u3001\u6536\u76CA\u4ECB\u7ECD\uFF1A",
            rule_title2: "2\u3001\u7ED3\u7B97\u5468\u671F\uFF1A",
            rule_title3: "3\u3001\u5E74\u5229\u7387\uFF1A",
            rule_title4: "4\u3001\u8BA1\u7B97\u516C\u5F0F\uFF1A",
            rule_title5: "5\u3001\u793A\u4F8B\uFF1A",
            rule_title6: "6\u3001\u8F6C\u8D26\u95E8\u69DB\uFF1A",
            rule_title7: "7.\u5229\u606F\u9650\u5236\uFF1A",
            rule_title8: "8\u3001\u9886\u53D6\u65F6\u95F4\uFF1A",
            rule_title9: "9\u3001\u5BA1\u6838\u500D\u6570\uFF1A",
            rule_title10: "10\u3001\u6D3B\u52A8\u58F0\u660E\uFF1A",
            rule_title11: "11\u3001\u8BF4\u660E\uFF1A",
            rule_text1: "\u5B58\u5165\u5229\u606F\u5E93\u7684\u91D1\u989D\u5FC5\u987B\u6EE1\u8DB3\u81F3\u5C11\u4E00\u4E2A\u5B8C\u6574\u7684\u5468\u671F\u624D\u80FD\u4EA7\u751F\u5229\u606F\u3002",
            rule_text2: "\u5982\u679C\u63D0\u524D\u8F6C\u79FB\uFF0C\u5219\u8BE5\u5468\u671F\u4E0D\u8BA1\u7B97\u6536\u5165\u3002",
            rule_text3: "\u4F8B\u5982\uFF1A\u5F53\u524D\u7ED3\u7B97\u5468\u671F\u4E3A",
            rule_text4: "\u5C0F\u65F6\uFF0C\u52192023-01-01 00:00:01 \u8F6C\u8D26\u91D1\u989D\u5C06\u5728",
            rule_text5: "\u5929",
            rule_text6: "\u7B2C\u4E00\u4E2A\u5468\u671F\u8BA1\u606F\uFF1B",
            rule_text7: "\u5F53\u524D\u7ED3\u606F\u5468\u671F\u4E3A",
            rule_text8: "\u5C0F\u65F6",
            rule_text9: "\u5F53\u524D\u5E74\u5229\u7387",
            rule_text10: "\u5229\u606F\u6536\u5165=\u5B58\u6B3E\u91D1\u989D*\u5E74\u5229\u7387/\u7ED3\u7B97\u5468\u671F\uFF1B",
            rule_text11: "A\u4E8E2023-01-01 00:00:01\u5B58\u6B3E10,000\uFF0C\u5E74\u5229\u7387\u4E3A",
            rule_text12: "\u7ED3\u7B97\u5468\u671F\u4E3A",
            rule_text13: "\u5C0F\u65F6\uFF0C\u56E0\u6B64\u4E8E",
            rule_text14: "\u83B7\u5F97\u7B2C\u4E00\u7B14\u5229\u606F\u6536\u5165",
            rule_text15: "\u8BA1\u7B97\u5982\u4E0B\uFF1A",
            rule_text16: "\u9996\u4ED8\u5229\u606F=",
            rule_text17: "\u6BCF\u6B21\u8F6C\u8D26\u91D1\u989D\u5FC5\u987B\u5927\u4E8E\u7B49\u4E8E",
            rule_text18: "\uFF0C\u8F6C\u8D26\u91D1\u989D\u65E0\u4E0A\u9650\uFF0C\u8D8A\u5927\u6536\u76CA\u8D8A\u5927\uFF1B",
            rule_text19: "\u5F53\u524D\u5229\u606F\u4E0D\u9650\u5236\uFF0C\u8BB0\u5F97\u5B9A\u671F\u6216\u7ECF\u5E38\u6536\u5230\u6536\u5165\uFF0C\u4EE5\u514D\u635F\u5931\u66F4\u591A\u6536\u5165\uFF01",
            rule_text20: "\u76EE\u524D\u4E3A\u6B21\u65E5\u9886\u53D6\uFF0C\u5373\u5F53\u5929\u4EA7\u751F\u7684\u5229\u606F\uFF0C\u76F4\u5230\u6B21\u65E50\u70B9\u624D\u4F1A\u9886\u53D6\uFF1B",
            rule_text21: "\u5F53\u524D\u5BA1\u6838\u500D\u6570\u4E3A",
            rule_text22: "\u500D\uFF08\u6295\u6CE8\u6D41\u91CF\u8981\u6C42\uFF09\uFF0C\u5373\u6536\u5230\u7684\u5229\u606F\uFF0C\u60A8\u9700\u8981\u83B7\u5F97\u6295\u6CE8\u65E0\u9650\u5236\u7684\u6709\u6548\u5E73\u53F0\u5229\u606F\u4EC5\u9650\u4E8E\u60A8\u6536\u5230\u7684\u5229\u606F\u548C\u8F6C\u5165\u8F6C\u8D26\u7684\u672C\u91D1\u6CA1\u6709\u5BA1\u67E5\u8981\u6C42\uFF1B",
            rule_text23: "\u6211\u6709\u6B63\u5E38\u8D4C\u535A\u6295\u6CE8\uFF0C\u7981\u6B62\u79DF\u7528\u8D26\u6237\uFF0C\u65E0\u98CE\u9669\u6295\u6CE8\uFF08\u8D4C\u535A\uFF0C\u914D\u5BF9\uFF0C\u4F4E\u8865\u507F\uFF0C\u5237\u6C34\uFF09\uFF0C\u6076\u610F\u4EF2\u88C1\uFF0C\u4F7F\u7528\u63D2\u4EF6\u6D41\u7A0B\uFF0C\u673A\u5668\u4EBA\uFF0C\u673A\u5668\u4EBA\u4F7F\u7528\u534F\u8BAE\uFF0C\u6F0F\u6D1E\uFF0C\u63A5\u53E3\uFF0C\u7FA4\u63A7\u6216\u5176\u4ED6\u6280\u672F\u624B\u6BB5\u53C2\u4E0E\u3002",
            rule_text24: "\u7ECF\u8C03\u67E5\u5C5E\u5B9E\u540E\uFF0C\u5E73\u53F0\u6709\u6743\u7EC8\u6B62\u4F1A\u5458\u767B\u5F55\u3001\u6682\u505C\u4F1A\u5458\u7F51\u7AD9\u3001\u6CA1\u6536\u5956\u91D1\u53CA\u4E0D\u8DB3\u7684\u76C8\u5229\u80FD\u529B\u3002",
            rule_text25: "\u4F1A\u5458\u9886\u53D6\u606F\u5E93\u5956\u52B1\u65F6\uFF0C\u672C\u5E73\u53F0\u5C06\u9ED8\u8BA4\u4F1A\u5458\u540C\u610F\u5E76\u9075\u5B88\u76F8\u5E94\u6761\u4EF6\u7B49\u76F8\u5173\u6761\u4EF6\uFF1B"
        },
        records: {
            reward: "\u5956\u91D1",
            rebate: "\u8FD4\u6C34"
        },
        set_exchange_pwd: {
            title: "\u5151\u6362\u5BC6\u7801",
            tips: "\u60A8\u662F\u7B2C\u4E00\u6B21\u63D0\u73B0\uFF0C\u9700\u8981\u5148\u8BBE\u7F6E\u63D0\u73B0\u5BC6\u7801",
            subTitle: "\u8BBE\u7F6E\u5151\u6362\u5BC6\u7801",
            exchange_pwd: "\u5151\u6362\u5BC6\u7801",
            confirm_pwd: "\u786E\u8BA4\u5BC6\u7801",
            confirm: "\u786E\u8BA4",
            tips1: "\u4E24\u6B21\u8F93\u5165\u7684\u5BC6\u7801\u4E0D\u4E00\u81F4",
            tips2: "\u6E29\u99A8\u63D0\u793A\uFF1A\u5151\u6362\u5BC6\u7801\u975E\u5E38\u91CD\u8981\uFF0C\u786E\u4FDD\u8BB0\u4F4F\u5E76\u4FDD\u5B58\uFF0C\u4E0D\u8981\u544A\u8BC9\u4EFB\u4F55\u4EBA\uFF0C\u5982\u679C\u53D1\u751F\u635F\u5931\uFF0C\u8D44\u4EA7\u5C06\u65E0\u6CD5\u8FFD\u56DE\u3002",
            tips3: "\u5BC6\u7801\u957F\u5EA6\u5FC5\u987B\u4E3A6\u4F4D\u6570\u5B57",
            tips4: "6\u4F4D\u6570\u5B57"
        },
        bottom_menu: {
            index: "Home",
            promotion: "Promotion",
            vip: "VIP",
            recharge: "Recharge",
            me: "Mine",
            exchange: "Exchange",
            rebate: "Rebate",
            task: "Task",
            agent: "Agent"
        },
        lucky_wheel_activity: {
            spin: "\u62BD\u5956",
            text1: "\u5F53\u524D\u5E78\u8FD0\u503C",
            text2: "\u9700\u8981\u6295\u6CE8",
            text3: "\u624D\u80FD\u83B7\u5F97",
            text4: "\u5E78\u8FD0\u503C",
            silver: "\u767D\u94F6",
            gold: "\u9EC4\u91D1",
            diamond: "\u94BB\u77F3",
            text5: "{amount} \u5E78\u8FD0\u503C",
            tab1: "\u83B7\u5956\u901A\u77E5",
            tab2: "\u6211\u7684\u8BB0\u5F55",
            text6: "\u83B7\u5F97"
        },
        pop_red_envelopes: {
            text1: "\u7EA2\u5305\u96E8",
            text2: "\u6253\u5F00",
            text3: "\u606D\u559C\u83B7\u5956",
            text4: "\u5956\u91D1\u5DF2\u5B58\u5165\u60A8\u7684\u94B1\u5305",
            tips1: "\u63D0\u793A",
            tips2: "\u662F\u5426\u653E\u5F03\u9886\u53D6\u7EA2\u5305\uFF0C\u5173\u95ED\u540E\uFF0C\u672C\u8F6E\u7EA2\u5305\u4E0D\u518D\u51FA\u73B0\u3002"
        },
        message_center: {
            support: "\u5BA2\u670D",
            news: "\u6D88\u606F",
            notification: "\u901A\u77E5",
            marquee: "\u8DD1\u9A6C\u706F",
            feedback: "\u5EFA\u8BAE\u6709\u5956"
        },
        finish_register: {
            title: "\u63D0\u793A",
            text: "\u6CE8\u518C\u6210\u529F\uFF01\u73B0\u5728\u6211\u4EEC\u6765\u73A9\u4E2A\u6E38\u620F\u5427~",
            btn: "\u53BB\u5145\u503C"
        },
        newbie_bonus: {
            title: "\u65B0\u4EBA\u5F69\u91D1",
            paste: "\u7C98\u8D34",
            placeholder: "\u8BF7\u8F93\u5165\u5151\u6362\u7801",
            bonus_amount: "\u5956\u91D1\u91D1\u989D",
            btn: "\u9886\u53D6\u5956\u52B1",
            tips: "\u606D\u559C\u60A8\uFF0C\u83B7\u5F97\u4E86 {reward} \u5F69\u91D1\uFF01"
        },
        claim: {
            title: "\u5F85\u9886\u53D6",
            reward: "\u5956\u91D1",
            active_level: "\u6D3B\u8DC3\u5EA6",
            time: "\u65F6\u95F4",
            name: "\u6D3B\u52A8\u540D",
            source: "\u6765\u6E90",
            status: "\u72B6\u6001",
            claim: "\u9886\u53D6",
            detailTitle: "\u5956\u52B1\u6765\u6E90",
            reward_name: "\u5956\u52B1\u540D\u79F0",
            reward_time: "\u5956\u52B1\u65F6\u95F4",
            amount: "\u91D1\u989D",
            point: "\u6D3B\u8DC3\u5EA6",
            available_time: "\u6709\u6548\u65F6\u95F4",
            rewards: "\u5956\u52B1",
            claimable_time: "\u53EF\u9886\u53D6\u65F6\u95F4",
            validity_period: "\u6709\u6548\u671F"
        },
        music: {
            music: "\u97F3\u4E50",
            cycle: "\u5FAA\u73AF",
            shuffle: "\u968F\u673A",
            repeat: "\u5355\u66F2",
            downloaded: "\u5DF2\u4E0B\u8F7D",
            system_music: "\u7CFB\u7EDF\u97F3\u4E50",
            my_music: "\u6211\u7684\u97F3\u4E50",
            deleteTips: "\u5DF2\u7ECF\u662F\u6700\u540E\u4E00\u9996\uFF0C\u4E0D\u80FD\u5220\u9664"
        },
        add_tips_dialog: {
            title1: "Add to Home Screen",
            subTitle1: '1. Click the "More" icon, then click "Add to Home Screen"',
            subTitle2: '2. Click "Add," then select "Add"',
            text1: "Share...",
            text2: "Find on the webpage",
            text3: "Add to Home Screen",
            text4: "Desktop site",
            text5: "Add to Home Screen",
            text6: "Cancel",
            text7: "Add",
            title2: "Add to main screen",
            text8: "Add to Quick Notes",
            text9: "Find on page",
            text10: "Add to main screen",
            text11: "Bookmark",
            text12: "A shortcut will be added to your home screen for quick access to this website"
        },
        first_charge_pop: {
            title: "First Deposit Extra Reward",
            text1: "First Deposit",
            text2: "Reward Amount",
            btn: "Go"
        },
        tutorial: {
            text: `
        <h1><strong>Example:</strong></h1>
        <p>Assuming the current commission rate for valid bets between 0-10,000 is 100 for every 10,000 bets
            (1%), and for bets above 10,000 is 300 for every 10,000 bets (3%). A is the first to discover
            the opportunity and immediately recruits B1, B2, and B3; B1 further recruits C1 and C2; B2 has
            no subordinates; B3 recruits the strong C3. On the second day, B1's valid bets are 500, B2's
            valid bets are 3,000, B3's valid bets are 2,000, C1's valid bets are 1,000, C2's valid bets are
            2,000, and C3's valid bets reach 20,000.</p><span>The profit calculation between them is as
            follows:</span>
        <ul>
            <li><strong>1. B1's Commission</strong> (direct contributions from C1 and C2) = (1,000+2,000) *
                1% = <em>30</em></li>
            <li><strong>2. B2's Commission</strong> (no subordinates) = (0+0) * 1% = <em>0</em></li>
            <li><strong>3. B3's Commission</strong> (direct contribution from C3) = 20,000 * 3% =
                <em>600</em></li>
            <li><strong>4. A's Commission</strong> (direct contributions from subordinates B1, B2, and B3,
                and other subordinates C1, C2, and C3) are as follows:<ul>
                    <li><strong>(1) A's Direct Commission</strong> (direct contributions from B1, B2, and
                        B3) = (500+3,000+2,000) * 3% = <em>165</em></li>
                    <li><strong>(2) A's Other Commission</strong> (other contributions from C1, C2) =
                        (1,000+2,000) * 2% = <em>60</em></li>
                    <li><strong>(3) A's Total Commission</strong> (direct + other) = 165 + 60 = <em>225</em>
                    </li>
                </ul>
            </li>
            <li><strong>5. Summary:</strong>
                <ul>
                    <li><strong>(1) Direct Team:</strong> Refers to the direct subordinates recruited by A,
                        i.e., the direct relationship with A, collectively referred to as the direct team.
                    </li>
                    <li><strong>(2) Other Teams:</strong> Refers to the subordinates recruited by A's
                        subordinates, which are beyond the other relationship with A, i.e., subordinates of
                        subordinates, subordinates of subordinates of subordinates, and so on, collectively
                        referred to as other teams; because this agency model can recruit subordinates
                        infinitely, for the sake of explanation, this article only takes a 2-tier structure
                        as an example.</li>
                    <li><strong>(3) Explanation of A:</strong> A's direct performance is 5,500 and another
                        performance is 20,000 (due to the strong performance of C3), with a total
                        performance of 28,500, corresponding to a commission rate of 3%. Since B1's total
                        performance is 3,000, only enjoying a 1% commission, while A's total performance is
                        28500, enjoying a 3% commission rate, there is a tier differential between A and B1,
                        the difference being: 3% - 1% = 2%, this difference is the part contributed by C1
                        and C2 to A, so C1 and C2 contribute to A: (1,000+2,000) * 2% = 60, there is no tier
                        differential between A and B3, so C3 contributes no commission to A.</li>
                    <li><strong>(4) Explanation of B1:</strong> B1 has subordinates C1 and C2, with a direct
                        performance of 3,000, corresponding to a commission rate of 1%.</li>
                    <li><strong>(5) Explanation of B2:</strong> B2 may be lazy and not recruit subordinates,
                        thus no income.</li>
                    <li><strong>(6) Explanation of B3:</strong> Although B3 joined late and belongs to A's
                        subordinate, its subordinate C3 is strong, with a direct performance of 20,000,
                        allowing B3 to directly enjoy a higher commission rate of 3%.</li>
                    <li><strong>(7) Rule Summary:</strong> Regardless of when you join, under whose
                        subordinate, and no matter what level you are in, your income is never affected. You
                        no longer suffer from the losses of others' subordinates, and your recruitment is
                        not restricted. This is a fair and just agency model, and joining late does not mean
                        you will always be at the bottom.</li>
                </ul>
            </li>
        </ul>
        `
        },
        dealer: {
            title: "\u7ECF\u9500\u5546",
            tutorial: "\u6559\u7A0B",
            home: "\u9996\u9875",
            review: "\u5BA1\u6838",
            performance: "\u6211\u7684\u4E1A\u7EE9",
            member: "\u6211\u7684\u6210\u5458",
            game: "\u6E38\u620F\u6570\u636E",
            record: "\u9886\u53D6\u8BB0\u5F55",
            ladder: "\u5956\u52B1\u9636\u68AF"
        },
        dealer_tutorial: {
            title: "\u9996\u5145\u5206\u7EA2\u6A21\u5F0F",
            text1: "\u4F60\u7684\u9996\u5145\u4EBA\u6570\u5956\u52B1:15/\u4EBA+\u989D\u5916\u9636\u68AF\u5956\u52B1",
            text2: "\u5956\u52B1\u4E0A\u9650\u4E0D\u53EF>\u81EA\u5DF1\u4E0A\u9650",
            ruleTitle: "\u60A8\u7684\u5145\u503C\u603B\u8BA1\uFF1A",
            ruleText1: "\u5982\u603B\u4EE3\u9996\u5145\u4EBA\u6570\u5956\u52B115\u6BCF\u4EBA\uFF0C\u53D1\u5C55100\u4EBA\u5145\u503C\u5956\u52B1=100*15=<b>1500</b>\uFF0C\u5BF9\u4E0B\u7EA7\u7BA1\u7406\u914D\u7F6E\u4E86\u5956\u52B114\u6BCF\u4EBA\uFF0C\u82E5\u7BA1\u7406\u53D1\u5C55100\u4EBA\u5145\u503C\uFF0C\u53EF\u83B7\u5DEE\u989D100*\uFF0815-14\uFF09=100\uFF0C\u82E5\u7BA1\u7406\u53D1\u5C55\u4E0B\u7EA7\u5458\u5DE5\uFF0C\u53D1\u5C55100\u4EBA\u5145\u503C\uFF0C\u603B\u4EE3\u53EF\u4EE5\u5F97\u5230\u5DEE\u989D100*\uFF0815-12\uFF09=<b>300</b>\uFF0C\u4EE5\u6B64\u7C7B\u63A8\uFF1B\u603B\u4EE3\u5F97\u5230\u7684\u989D\u5EA6=\u81EA\u5DF11500+\u7BA1\u7406\u5DEE\u989D100+\u5458\u5DE5\u5DEE\u989D300+...",
            ruleText2: "\u5176\u4ED6\u9636\u68AF\u5956\u52B1\u5DEE\u989D\u8BA1\u7B97\uFF1A\u6839\u636E\u4EBA\u6570\u548C\u5956\u52B1\u914D\u7F6E\uFF0C\u4ECD\u53EF\u83B7\u5F97\u5DEE\u989D\u8BA1\u7B97\uFF0C\u5982\u603B\u4EE3\u6EE150\u4EBA\u5956\u52B1100\uFF0C\u5BF9\u4E0B\u7EA7\u7BA1\u7406\u8BBE\u7F6E\u6EE150\u4EBA\u5956\u52B190\uFF0C\u5219\u4ECD\u53EF\u5F97\u5230<b>10</b>\u7684\u5DEE\u989D"
        },
        dealer_home: {
            dealerId: "\u7ECF\u9500\u5546ID",
            superiorId: "\u4E0A\u7EA7ID",
            level: "\u7EA7\u522B",
            firstRecharge: "\u4F60\u7684\u9996\u5145",
            person: "\u4EBA",
            complaint: "\u6295\u8BC9",
            camReceive: "\u53EF\u9886\u5956",
            received: "\u5DF2\u9886\u5956",
            myLink: "\u6211\u7684\u94FE\u63A5",
            myReview: "\u6211\u7684\u5BA1\u6838",
            reviewNum: "\u5F85\u5BA1\u6838\u6570\u91CF",
            operation: "\u64CD\u4F5C",
            reviewBtn: "\u53BB\u5BA1\u6838",
            reward_setting: "\u5956\u52B1\u8BBE\u7F6E",
            firstRecharge_per_reward: "\u9996\u5145\u6BCF\u4EBA\u5956\u52B1",
            firstRecharge_ext_reward: "\u9996\u5145\u989D\u5916\u5956\u52B1",
            reward_ladder: "\u5956\u52B1\u9636\u68AF",
            check: "\u67E5\u770B",
            reward_sum: "\u5956\u52B1\u7EDF\u8BA1",
            personal_reward: "\u4EBA\u6570\u5956\u52B1",
            ext_reward: "\u989D\u5916\u5956\u52B1",
            total_reward: "\u603B\u5956\u52B1"
        },
        dealer_complaint: {
            title1: "\u6295\u8BC9\u7ECF\u9500\u5546",
            title2: "\u6295\u8BC9\u8BB0\u5F55",
            placeholder: "\u8BF7\u8F93\u5165\u6295\u8BC9\u5185\u5BB9",
            submit: "\u63D0\u4EA4",
            tips: "\u4E3A\u4FDD\u969C\u4EE3\u7406\u7684\u6B63\u5E38\u8FD0\u8425\uFF0C\u53EF\u9488\u5BF9\u65E0\u826F\u7ECF\u9500\u5546\u884C\u4E3A\u8FDB\u884C\u6295\u8BC9\uFF0C\u5E73\u53F0\u5C06\u4E3A\u4F60\u5904\u7406"
        },
        dealer_review: {
            placeholder: "\u8F93\u5165\u4F1A\u5458ID",
            check: "\u67E5\u8BE2",
            contact_setting: "\u8054\u7CFB\u8BBE\u7F6E",
            memberId: "\u4F1A\u5458ID",
            contactInfo: "\u8054\u7CFB\u4FE1\u606F",
            remark: "\u5907\u6CE8",
            applyTime: "\u7533\u8BF7\u65F6\u95F4",
            review: "\u5BA1\u6838"
        },
        dealer_performance: {
            first_person: "\u9996\u5145\u4EBA\u6570",
            time: "\u65F6\u95F4",
            dealer_person: "\u7ECF\u9500\u4EBA\u6570",
            recharge_person: "\u9996\u5145\u4EBA\u6570",
            reward: "\u5956\u52B1\u7D2F\u8BA1"
        },
        dealer_member: {
            placeholder: "\u8F93\u5165\u4F1A\u5458ID",
            check: "\u67E5\u8BE2",
            registerTime: "\u6CE8\u518C\u65F6\u95F4",
            account: "\u4F1A\u5458ID",
            accountRemark: "\u4F1A\u5458\u8D26\u53F7\u5907\u6CE8",
            superiorId: "\u4E0A\u7EA7ID",
            isRecharge: "\u662F\u5426\u5145\u503C",
            dealer: "\u7ECF\u9500\u5546",
            user: "\u666E\u901A\u4F1A\u5458"
        },
        dealer_record: {
            received: "\u5DF2\u9886\u53D6\u4F63\u91D1",
            receive_time: "\u9886\u53D6\u65F6\u95F4",
            received: "\u5DF2\u9886\u53D6"
        },
        dealer_contact_setting: {
            show: "\u5BA2\u670D\u5C55\u793A",
            contactMethod: "\u53EF\u63D0\u4EA4\u8054\u7CFB\u65B9\u5F0F",
            modify: "\u4FEE\u6539",
            tips1: "\u8BF7\u9009\u62E9\u8054\u7CFB\u65B9\u5F0F",
            tips2: "\u81F3\u5C11\u586B\u5199\u4E00\u4E2A\u5BA2\u670D\u4FE1\u606F"
        },
        dealer_ladder: {
            tab1: "\u5145\u503C\u4EBA\u6570\u5956\u52B1",
            tab2: "VIP\u664B\u7EA7\u5956\u52B1",
            currentNum: "\u5F53\u524D\u9996\u5145\u4EBA\u6570",
            levelUpNum: "\u664B\u7EA7\u6B21\u6570",
            receivedReward: "\u5DF2\u9886\u53D6\u4F63\u91D1",
            firstRecharge: "\u9996\u5145\u4EBA\u6570",
            reward: "\u5956\u52B1",
            vipLevel: "VIP\u7B49\u7EA7"
        },
        dealer_join_dialog: {
            title1: "\u8054\u7CFB\u6211\u4EEC",
            title2: "\u7533\u8BF7\u6210\u4E3A\u7ECF\u9500\u5546",
            table1: "\u8054\u7CFB\u8BE6\u60C5",
            table2: "\u5907\u6CE8",
            table3: "\u7533\u8BF7\u65F6\u95F4",
            table4: "\u72B6\u6001",
            table5: "\u64CD\u4F5C",
            btn1: "\u91CD\u65B0\u63D0\u4EA4",
            btn2: "\u67E5\u770B",
            text1: "\u9009\u62E9\u8054\u7CFB\u65B9\u5F0F",
            text2: "\u586B\u5199\u8054\u7CFB\u65B9\u5F0F",
            text3: "\u5907\u6CE8",
            btn3: "\u53D6\u6D88",
            btn4: "\u786E\u5B9A",
            btn5: "\u53D6\u6D88",
            btn6: "\u91CD\u65B0\u63D0\u4EA4",
            tips1: "\u8BF7\u9009\u62E9\u8054\u7CFB\u65B9\u5F0F",
            tips2: "\u8BF7\u586B\u5199\u8054\u7CFB\u4FE1\u606F"
        },
        dealer_review_detail: {
            title: "\u5BA1\u6838\u64CD\u4F5C",
            account: "\u4F1A\u5458\u8D26\u53F7",
            applyTime: "\u7533\u8BF7\u65F6\u95F4",
            contactType: "\u8054\u7CFB\u65B9\u5F0F",
            contactInfo: "\u8054\u7CFB\u4FE1\u606F",
            applyRemark: "\u7533\u8BF7\u5907\u6CE8",
            rechargeReward: "\u9996\u5145\u5956\u52B1",
            person: "\u4EBA",
            extReward: "\u989D\u5916\u5956\u52B1",
            lower_recharge_reward_setting: "\u4E0B\u7EA7\u9996\u5145\u5956\u52B1\u914D\u7F6E",
            lower_recharge_extReward_setting: "\u4E0B\u7EA7\u9996\u5145\u989D\u5916\u5956\u52B1\u914D\u7F6E",
            rechargePerson: "\u5145\u503C\u4EBA\u6570",
            myReward: "\u6211\u7684\u5956\u52B1",
            max_reward: "\u6700\u9AD8\u53EF\u8BBE\u7F6E\u5956\u52B1",
            next_reward_setting: "\u4E0B\u7EA7\u5956\u52B1\u8BBE\u7F6E",
            withdraw_setting: "\u63D0\u73B0\u8BBE\u7F6E",
            can_withdraw: "\u53EF\u4EE5\u63D0\u73B0",
            cannot_withdraw: "\u4E0D\u53EF\u4EE5\u63D0\u73B0",
            edit_setting: "\u7F16\u8F91\u8BBE\u7F6E",
            can_edit: "\u53EF\u4EE5\u7F16\u8F91",
            cannot_edit: "\u4E0D\u53EF\u4EE5\u7F16\u8F91",
            level_name: "\u7EA7\u522B\u540D\u79F0",
            account_remark: "\u4F1A\u5458\u8D26\u53F7\u5907\u6CE8",
            reject: "\u62D2\u7EDD",
            pass: "\u901A\u8FC7",
            tips1: "\u8BF7\u8BBE\u7F6E\u5168\u90E8\u4E0B\u7EA7\u5956\u52B1\u8BBE\u7F6E",
            tips2: "\u8BF7\u8BBE\u7F6E\u4E0B\u7EA7\u9996\u5145\u5956\u52B1\u914D\u7F6E",
            tips3: "\u8BF7\u8BBE\u7F6E\u4E0B\u7EA7\u9996\u5145\u989D\u5916\u5956\u52B1\u914D\u7F6E",
            tips4: "\u8BF7\u8BBE\u7F6E\u7F16\u8F91\u914D\u7F6E",
            tips5: "\u8BF7\u8F93\u5165\u7EA7\u522B\u540D\u79F0",
            tips6: "\u8BF7\u8BBE\u7F6E\u63D0\u73B0\u914D\u7F6E"
        },
        complaint: {
            title: "\u6295\u8BC9",
            site_complaint: "\u7AD9\u70B9\u6295\u8BC9",
            email: "\u90AE\u7BB1",
            tipsTitle: "\u8BF4\u660E",
            tips: "\u4E3A\u4FDD\u969C\u7AD9\u70B9\u7684\u6B63\u5E38\u8FD0\u8425\uFF0C\u53EF\u9488\u5BF9\u65E0\u826F\u7AD9\u70B9\u884C\u4E3A\u8FDB\u884C\u6295\u8BC9\uFF0C\u5E73\u53F0\u5C06\u4E3A\u4F60\u5904\u7406\u3002",
            emailError1: "\u90AE\u7BB1\u4E0D\u80FD\u4E3A\u7A7A",
            emailError2: "\u90AE\u7BB1\u683C\u5F0F\u4E0D\u6B63\u786E",
            placeholderText: "\u8BF7\u8F93\u5165\u7AD9\u70B9\u6295\u8BC9\u5185\u5BB9"
        },
        upload: {
            uploading: "\u4E0A\u4F20\u4E2D...",
            tips1: "\u5355\u4E2A\u6587\u4EF6\u4E0A\u4F20\u5927\u5C0F\u4E0D\u80FD\u8D85\u8FC7",
            tips2: "\u6587\u4EF6\u4E0A\u4F20\u5927\u5C0F\u603B\u5171\u4E0D\u80FD\u8D85\u8FC7",
            tips3: "\u6587\u4EF6\u4E0A\u4F20\u5927\u5C0F\u4E0D\u80FD\u8D85\u8FC7"
        },
        recharge_order_detail: {
            title: "\u5145\u503C",
            tips1: "\u8BF7\u6253\u5F00\u60A8\u7684\u652F\u4ED8\u5E94\u7528\uFF0C\u626B\u63CF\u6216\u590D\u5236\u5E76\u7C98\u8D34\u4E0B\u65B9\u4E8C\u7EF4\u7801\uFF0C\u4EE5\u5B8C\u6210\u8D2D\u4E70\uFF1B",
            tips2: "\u8BE5\u4E8C\u7EF4\u7801\u53EA\u80FD\u652F\u4ED8\u4E00\u6B21\uFF0C\u5982\u9700\u518D\u6B21\u652F\u4ED8\uFF0C\u8BF7\u8FD4\u56DE\u5E76\u91CD\u65B0\u53D1\u8D77\u5145\u503C\uFF1B",
            tips3: "\u652F\u4ED8\u6210\u529F\u540E\uFF0C\u53EF\u8FD4\u56DE\u6E38\u620F\u5927\u5385\u7B49\u5F85\u4E0A\u5206\u54E6\uFF01",
            effectTime: "\u6709\u6548\u65F6\u95F4",
            copyText: "\u590D\u5236\u4E8C\u7EF4\u7801",
            copyAddress: "\u4E8C\u7EF4\u7801\u5730\u5740 ...",
            label1: "\u8BA2\u5355\u72B6\u6001",
            label2: "\u521B\u5EFA\u65F6\u95F4",
            label3: "\u8BA2\u5355\u53F7\u7801",
            label4: "\u5546\u6237\u8BA2\u5355\u53F7",
            waiting: "\u5F85\u652F\u4ED8",
            success: "\u652F\u4ED8\u6210\u529F",
            warning: "\u4E8C\u7EF4\u7801\u5DF2\u5931\u6548",
            tips4: "\u8BF7\u8FD4\u56DE\u5927\u5385\u91CD\u65B0\u4E0B\u5355\uFF0C\u5C06\u572810s\u540E\u5173\u95ED\u5F53\u524D\u9875\u9762",
            tips5: "\u9009\u62E9",
            tips6: "\u7ACB\u5373\u5173\u95ED",
            tips7: "\u6216",
            tips8: "\u67E5\u770B\u8BA2\u5355",
            tips9: "\u5DF2\u6210\u529F\u5230\u8D26",
            tips10: "\u7CFB\u7EDF\u5DF2\u81EA\u52A8\u4E3A\u60A8\u4E0A\u5206\uFF0C",
            tips11: "\u5C06\u572810s\u7ED9\u540E\u5173\u95ED\u5F53\u524D\u9875"
        },
        check_pwd_dialog: {
            title: "Enter PIN",
            text1: "\u5151\u6362\u5BC6\u7801",
            text2: "\u672A\u4E86\u60A8\u8D26\u53F7\u5B89\u5168\uFF0C\u8BF7\u8F93\u5165\u5151\u6362\u5BC6\u7801",
            text3: "\u5FD8\u8BB0\u5BC6\u7801?",
            btnText: "\u786E\u8BA4",
            tips1: "6\u4F4D\u6570\u5B57"
        }
    }, le = {
        home: {
            noData: "Tiada data",
            loadMore: "Tambah lagi",
            moreTipsText1: "Menunjukkan",
            moreTipsText2: "permainan daripada",
            moreTipsText3: "Permainan popular",
            maintain: "Dalam penyelenggaraan",
            all: "Semua",
            maintainText: "Di bawah Maint",
            limitAmountTips: ">Baki anda tidak mencukupi {currency}{balance}; deposit untuk menguasai tempat kejadian!",
            top: "Atas"
        },
        footer: {
            cassino: "Fungsi",
            games: "Permainan",
            support: "Sokongan",
            none: "Ditutup buat sementara waktu",
            funcList: {
                reward: "Bonus",
                rebate: "Rebat",
                vip: "VIP",
                agent: "Ejen",
                event: "Aktiviti",
                task: "Tugasan"
            },
            gameList: {
                hot: "Popular",
                card: "Huruf",
                fish: "Memancing",
                digital: "Slot",
                live: "Kasino Langsung",
                sports: "Sukan",
                recent: "Terkini",
                collect: "Kegemaran"
            },
            supportList: {
                support: "Sokongan dalam talian",
                advise: "Hadiah yang disyorkan",
                faq: "Pusat Bantuan"
            },
            technicalSupport: "Sokongan teknikal"
        },
        new_player: {
            title: "Faedah untuk pemain baru",
            proceed: "Teruskan",
            collect: "Terima",
            collected: "Menerima",
            reward: "Bonus",
            tips1: "Tetingkap semasa tidak akan dipaparkan lagi",
            tips2: "Jangan sekali-kali menggesa (lihat di pusat tugas)",
            collectAll: "Semua diterima",
            tip3: "Tidak layak menerima resit",
            tip4: "Sila ikat akaun pembayaran dahulu"
        },
        search_page: {
            title: "Cari",
            result: "Hasil carian",
            popular: "Popular",
            recent: "Baru-baru ini",
            favorites: "Kegemaran",
            record: "Dapatkan rekod",
            clear: "Kosongkan semua"
        },
        sub_game: {
            search: "Permainan Cari",
            all: "Semua"
        },
        vip_item: {
            accumulated_deposits: "Deposit terkumpul",
            current_stream: "Perolehan semasa",
            relegation_deposits: "Deposit penyingkiran",
            relegation_stream: "Perolehan penyingkiran",
            tips1: "Anda juga memerlukan deposit",
            tips2: "untuk menaik taraf kepada",
            tips3: "untuk meningkatkan kepada",
            maxLevel: "Sudah peringkat tertinggi",
            privilege: "Diberi keistimewaan",
            challenge_game: "Permainan terobosan",
            go: "Pergi lihat",
            unset: "Anda belum menetapkan hari lahir lagi",
            tips: "Petunjuk",
            confirmText: "Beralih ke tetapan",
            cancelText: "Sembang lain kali"
        },
        vip_lucky_wheel: {
            daily_lottery: "Cabutan harian",
            upgrade_vip: "Tingkatkan VIP",
            current: "semasa",
            lottery_draw: "Bilangan cabutan",
            winning_record: "Rekod kemenangan",
            tips1: "Jumlah cabutan telah tamat",
            tips2: "Tahniah kerana mendapat ",
            tips3: "jumlah"
        },
        vip_birthday: {
            title: "Bonus Hari Lahir",
            collect: "Terima",
            collected: "Menerima"
        },
        vip_reward: {
            title: "Ganjaran VIP",
            upgrade: "Naik Level",
            recharge: "Tambah nilai lagi",
            bet: "Bertaruh lagi",
            collect_all: "Dapatkannya dengan satu klik",
            collect_record: "Dapatkan rekod",
            level_list: "Senarai peringkat VIP",
            upgrade_rewards: "Tingkatkan ganjaran",
            relegation_conditions: "Syarat penyingkiran",
            daily_rewards: "Bonus Harian",
            weekly_rewards: "Ganjaran mingguan",
            monthly_rewards: "Ganjaran bulanan",
            privilege: "Keistimewaan VIP",
            rule_description: "Penerangan Peraturan VIP",
            title1: "Tingkatkan peraturan ganjaran",
            text1: "Selepas memenuhi syarat untuk promosi VIP (memenuhi keperluan untuk caj semula dan pengumpulan kod), ahli akan dinaikkan ke tahap VIP yang sepadan dan boleh menerima bonus promosi. Jika berbilang peningkatan dibuat pada satu masa, ahli boleh menerima bonus untuk semua peringkat promosi.",
            title2: "Peraturan ganjaran mingguan",
            text2: "Apabila jumlah caj semula mingguan dan pertaruhan mencapai tahap VIP semasa dan keperluan ganjaran mingguan yang sepadan, ahli boleh menerima gaji mingguan yang sepadan, yang ditetapkan semula pada jam 00:00 setiap hari Isnin.",
            title3: "Peraturan ganjaran bulanan",
            text3: "Apabila caj semula bulanan dan pertaruhan memenuhi keperluan VIP bulan itu, anda boleh menerima gaji bulanan yang sepadan, yang akan ditetapkan semula pada jam 00:00 pada hari pertama setiap bulan.",
            none_reward: "Tiada ganjaran untuk dituntut",
            rule_detail: `1.Standard promosi: Memenuhi keperluan promosi VIP (iaitu, kedua-dua deposit atau pertaruhan sah memenuhi kriteria) untuk menaik taraf ke tahap VIP yang sepadan dan menerima bonus promosi yang sepadan. Jika anda menaik taraf berbilang peringkat secara berturut-turut, anda hanya boleh menerima bonus promosi peringkat semasa. Bonus masa nyata boleh dituntut;
        <br/>2.Bonus Harian: Dengan memenuhi deposit harian tahap semasa dan keperluan pertaruhan yang sah, anda boleh menerima bonus harian yang sepadan. Jika maju secara berturut-turut merentasi pelbagai peringkat, hanya bonus harian tahap semasa boleh diperolehi. Bonus masa nyata boleh dituntut;
        <br/>3.Bonus Mingguan: Dengan memenuhi keperluan deposit dan pertaruhan yang sah untuk tahap semasa setiap minggu, seseorang boleh menerima bonus mingguan yang sepadan. Jika maju secara berturut-turut merentasi pelbagai peringkat, hanya bonus mingguan tahap semasa boleh diperolehi. Bonus masa nyata boleh dituntut;
        <br/>4.Bonus Bulanan: Dengan memenuhi syarat deposit dan pertaruhan yang sah untuk tahap semasa setiap bulan, seseorang boleh menerima bonus gaji bulanan yang sepadan. Jika maju secara berturut-turut merentasi pelbagai peringkat, hanya bonus bulanan tahap semasa boleh diperolehi. Bonus masa nyata boleh dituntut;
        <br/>5.Masa tamat ganjaran: Bonus yang diterima dikekalkan selama %d hari. Jika tidak dituntut secara aktif dalam tempoh ini, ia akan dikreditkan secara automatik ke akaun. Contohnya: jika ganjaran diperoleh pada 1 Januari dan dikekalkan selama %d hari, ganjaran itu akan dikreditkan ke akaun secara automatik pada %d Januari pada 00:00:00.
        <br/>6.Nota Audit: Bonus VIP perlu dipertaruhkan 10 kali (iaitu, diaudit, dimainkan melalui, atau melalui pertaruhan yang sah) untuk layak untuk pengeluaran, Pertaruhan tidak terhad kepada mana-mana platform permainan;
        <br/>7.Penyata Acara: Ciri ini hanya untuk pertaruhan permainan biasa pemilik akaun. Menyewa akaun, pertaruhan bebas risiko (padanan, memberus, kemungkinan rendah), arbitraj berniat jahat, menggunakan pemalam, bot, mengeksploitasi perjanjian, kelemahan, antara muka, kawalan kumpulan atau cara teknikal lain adalah dilarang. Setelah disahkan, platform berhak untuk menamatkan log masuk ahli, menggantung penggunaan laman web ahli, dan merampas bonus dan keuntungan yang tidak wajar tanpa notis terlebih dahulu.
        <br/>8.Penjelasan: Dengan menuntut ganjaran VIP, platform menganggap bahawa ahli bersetuju untuk mematuhi syarat yang sepadan dan peraturan berkaitan. Untuk mengelakkan salah faham dalam tafsiran teks, platform mempunyai hak terakhir untuk mentafsir peristiwa ini.`,
            current_level: "Current Level"
        },
        vip_reward_upgrade: {
            level: "Tingkat",
            reward_conditions: "Syarat ganjaran",
            operate: "Beroperasi",
            recharge: "Tambah nilai",
            bet: "Letak taruhan",
            collected: "Menerima",
            collect: "Terima",
            bonus: "Bonus",
            text1: "Pertaruhan sah setiap hari",
            text2: "Pertaruhan sah mingguan",
            text3: "Pertaruhan sah bulanan",
            text4: "Deposit harian",
            text5: "Deposit mingguan",
            text6: "Deposit bulanan",
            text7: "Deposit untuk promosi",
            text8: "Taruhan untuk promosi",
            text9: "Jumlah had pengeluaran harian",
            text10: "Had kiraan pengeluaran harian",
            text11: "Bilangan transaksi tanpa bayaran setiap hari",
            tips_title: "Petua",
            tips_content_recharge: "Untuk mempromosikan ke peringkat seterusnya, anda perlu mendepositkan jumlah tambahan berdasarkan deposit terkumpul. Contohnya: untuk menaik taraf daripada VIP1 dengan keperluan cas semula 1000 kepada VIP2 dengan keperluan 2000, ahli perlu mengumpul 1000 + 2000 = 3000 untuk menaik taraf kepada VIP2, dan seterusnya.",
            tips_content_bet: "Untuk mempromosikan ke peringkat seterusnya, anda perlu bertaruh jumlah tambahan berdasarkan pertaruhan terkumpul. Sebagai contoh: untuk menaik taraf daripada VIP1 dengan keperluan pertaruhan 1000 kepada VIP2 dengan keperluan 2000, ahli perlu mengumpul 1000 + 2000 = 3000 untuk menaik taraf kepada VIP2, dan seterusnya.",
            unlimited: "Tidak terhad",
            text12: "Deposit bulan lepas",
            text13: "Pertaruhan bulan lepas"
        },
        mine: {
            upgrade: "Naik Level",
            recharge: "Tambah nilai lagi",
            bet: "Bertaruh lagi",
            need_recharge: "Deposit untuk promosi",
            need_bet: "Taruhan untuk promosi",
            account_detail: "Perincian akaun",
            bet_record: "Rekod pertaruhan",
            personal_report: "Laporan individu",
            service_setting: "Tetapan perkhidmatan",
            invite: "Jemput",
            account: "Akaun",
            help_center: "Pusat Bantuan",
            music: "Muzik",
            advise: "Maklum Balas",
            about_us: "Perihal Kami",
            address_manage: "Pentadbiran alamat",
            security_center: "Pusat keselamatan",
            language: "Bahasa",
            exit: "Log keluar",
            tips1: "Adakah anda pasti log keluar daripada akaun semasa?",
            tips: "Petunjuk",
            id: "ID",
            tab_account: "Data peribadi",
            message: "mesej",
            wallet: "Dompet",
            exchange: "Pertukaran",
            deposit: "Membuat deposit",
            income: "Menyimpan",
            login_pwd: "kata laluan login",
            exchange_pwd: "Tebus kata laluan",
            million_monthly: "juta setiap bulan",
            support: "Sokongan",
            search_balance: "Dapatkan semula baki",
            request_label: "Yang tinggal",
            request_recharge: "jumlah untuk deposit"
        },
        advise: {
            message_title: "Pusat Mesej",
            welcome_title: "Perkhidmatan pelanggan profesional full-time sentiasa online untuk membantu anda dengan sebarang soalan.",
            welcome_text: "Perkhidmatan Dalam Talian 24/7",
            customer: "Khidmat pelanggan dalam talian",
            title: "Hadiah-hadiah yang disyorkan",
            faq: "FAQ",
            read: "Telah membaca",
            unread: "Belum dibaca",
            advise_reward: "Cipta",
            my_record: "Catatan saya",
            content_title: "Kandungan Balas Balas",
            content_tips: "(cadangan untuk revisi)",
            entry: "Semua cadangan yang berharga akan dianggap, dan bila diterima, tahap penting akan menentukan hadiah tunai. Sila rasa bebas untuk mengekspresikan diri!",
            annex: "Lampiran",
            annex_tips: "(Mudah untuk diadopsi)",
            upload_tips: "Menyokong gambar atau video, saiznya tidak boleh melebihi 40M",
            advise_title: "Peraturan Balas",
            advise_tips: "Kami telah menetapkan bonus besar untuk mengumpulkan balas balik secara khusus untuk optimize sistem kami dan ciri-ciri untuk pengalaman yang lebih baik untuk and a! Setelah diterima, pahala akan diberikan berdasarkan kepentingan (kecuali yang tidak diterima).",
            submit: "Hantar balas balik",
            replied: "Dijawab",
            feedback: "Kandungan maklum balas",
            reply: "Balas kandungan",
            submit_tips: "Kandungan penyerahan mestilah melebihi 10 patah perkataan",
            bonus: "Bonus",
            contact: "Hubungi Sekarang"
        },
        mine_info: {
            title: "Data peribadi",
            avatar: "Gambar profil",
            useName: "Nama pengguna",
            realName: "Nama sebenar",
            name_tips: "Sila masukkan nama sebenar anda",
            sex: "Jantina",
            man: "Lelaki",
            woman: "perempuan",
            birthday: "Tarikh lahir",
            phone: "Nombor telefon",
            email: "E-mel",
            receive_address: "Alamat penghantaran",
            no_address: "Pada masa ini tiada alamat penghantaran lalai",
            save: "menyimpan",
            choose_date: "Pilih tarikh",
            email_error_tips: "Format e-mel adalah salah",
            cancel: "Batal",
            confirm: "Sahkan",
            bindPhone: "Ikat telefon",
            tips1: "Facebook tidak boleh kosong",
            tips2: "Telegram tidak boleh kosong",
            tips3: "Whatsapp tidak boleh kosong",
            tips4: "Adakah anda benar-benar mahu kembali?",
            tips5: "Perubahan semasa belum disimpan. Jika anda kembali, perubahan tidak akan berkuat kuasa",
            copySuccess: "Success"
        },
        agent: {
            not_have: "tiada",
            extension_course: "Tutorial promosi",
            change: "menggantikan",
            claimable: "Tersedia untuk koleksi",
            direct_subordinate: "Orang bawahan langsung",
            my_superiors: "Atasan saya",
            unlimited_level_difference: "Spread tanpa had (penyelesaian harian)",
            agency_mode: "Mod proksi",
            share: "Kongsi",
            agent: "Ejen",
            my_promotion: "Promosi Saya",
            my_data: "Data saya",
            tutorial: "Tutorial",
            my_performance: "Pencapaian aku",
            tab_commission: "Komisen saya",
            my_member: "Prestasi",
            commission_rate: "Nisbah komisen",
            all_types: "Semua jenis",
            all_data: "Semua data",
            finance: "Kewangan Orang Bawahan",
            wagers: "Taruhan Orang Bawahan",
            stats: "Statistik Orang Bawahan",
            claims: "Tuntutan Orang Bawahan",
            account: "Akaun",
            superior: "Pihak atasan",
            can_receive: "Tersedia untuk dikumpulkan",
            receive: "menerima",
            save: "menyimpan",
            my_link: "Pautan saya",
            commission: "komisen",
            detail: "Butiran",
            total_commission: "Jumlah komisen",
            received: "Menerima",
            unclaimed: "Tidak diterima",
            member: "ahli",
            total_members: "Jumlah ahli",
            direct_members: "ahli langsung",
            other_members: "ahli lain",
            total_income: "jumlah pendapatan",
            direct_income: "pendapatan langsung",
            other_income: "Pendapatan lain",
            bet: "pertaruhan",
            total_effective_bet: "Jumlah pertaruhan berkesan",
            total_bet_number: "Jumlah bilangan pertaruhan",
            total_profit_loss: "Jumlah kerugian dan keuntungan",
            more: "Lagi",
            to: "kepada",
            start_date: "Masa mula",
            end_date: "Masa tamat",
            all: "Semua",
            time: "masa",
            type: "menaip",
            bet_amount: "Jumlah pertaruhan",
            bet_number: "Bilangan petaruh",
            join_time: "Sertai masa",
            personnel: "ahli",
            number: "Tahap",
            effective_bet_unit: "prestasi",
            unit: "(Unid: 10,000)",
            per_commission: "Komisen setiap sepuluh ribu",
            collect_record: "Dapatkan rekod",
            search: "Tanya",
            noData: "Tiada data",
            collected_commission: "Komisen diterima",
            collected_time: "Masa pengumpulan",
            amount: "Jumlah",
            myId: "ID saya",
            share_title1: "",
            share_title2: "Pautan promosi",
            net_profit: "Keuntungan bersih",
            total_net_profit: "Jumlah keuntungan bersih",
            total_discount: "Jumlah diskaun",
            valid_people: "Bilangan orang yang sah",
            valid_text1: "Deposit sah\u2265",
            valid_text2: "\uFF0Ciaitu bilangan orang yang sah",
            deposit_amount: "Jumlah cas semula",
            agent_tier: "Peringkat ejen",
            promotion_conditions: "Syarat promosi<br/>(Prestasi Terkumpul)",
            commission_detail_title: "Butiran komisen",
            commission_detail_endTime: "Tarikh penyelesaian",
            commission_detail_placeholder: "Masukkan ID",
            commission_detail_table1: "ID",
            commission_detail_table2: "Unggul",
            commission_detail_table3: "Data pertaruhan",
            commission_detail_table4: "Komisen",
            commission_detail_label1: "Data langsung",
            commission_detail_label2: "Data lain",
            commission_detail_label3: "Jumlah data",
            commission_detail_label4: "Komisen langsung",
            commission_detail_label5: "Komisen lain",
            commission_detail_label6: "Jumlah komisen",
            my_performance_label1: "Bilangan orang di bawah pengawasan langsung",
            my_performance_label2: "Jumlah pertaruhan langsung",
            my_performance_label3: "Komisen langsung",
            my_performance_label4: "Orang lain",
            my_performance_label5: "Jumlah pertaruhan lain",
            my_performance_label6: "Komisen lain",
            all_data_table1: "Sertai masa",
            all_data_table2: "ID ahli",
            all_data_table3: "Deposit",
            all_data_table4: "Pertaruhan yang sah",
            all_data_table5: "Jumlah kerugian dan keuntungan",
            all_data_label1: "Jumlah cas semula langsung",
            all_data_label2: "Bilangan pendeposit kali pertama langsung",
            all_data_label3: "Jumlah cas semula yang lain",
            all_data_label4: "Bilangan cas semula lain",
            all_data_label5: "Jumlah amaun cas semula",
            all_data_label6: "Jumlah bilangan cas semula",
            direct_finance_table1: "Orang bawahannya",
            direct_finance_table2: "Tambah nilai",
            direct_finance_table3: "Menarik diri",
            direct_finance_table4: "Beza",
            direct_finance_table5: "Seimbang",
            direct_finance_table6: "Kekerapan",
            direct_finance_label1: "Jumlah amaun cas semula",
            direct_finance_label2: "Bilangan orang yang mengecas",
            direct_finance_label3: "Jumlah deposit pertama",
            direct_finance_label4: "Deposit pertama",
            direct_finance_label5: "Jumlah amaun pengeluaran",
            direct_finance_label6: "Bilangan pengeluaran",
            direct_bet_detail: "Butiran pertaruhan",
            direct_bet_table1: "orang bawahannya",
            direct_bet_table2: "Pertaruhan yang sah",
            direct_bet_table3: "Kemenangan dan kekalahan terkumpul",
            direct_bet_table4: "kekerapan",
            direct_bet_label1: "Pertaruhan yang sah secara langsung",
            direct_bet_label2: "Pertaruhan lain yang sah",
            direct_bet_label3: "Jumlah pertaruhan yang sah",
            direct_bet_label4: "Untung dan rugi langsung",
            direct_bet_label5: "Keuntungan dan kerugian lain",
            direct_bet_label6: "Jumlah untung rugi",
            direct_bet_detail1: "Pengeluar",
            direct_bet_detail2: "Nama permainan",
            direct_bet_detail3: "Pertaruhan yang sah",
            direct_bet_detail4: "Untung dan rugi terkumpul",
            direct_bet_detail5: "Jumlah pertaruhan",
            direct_bet_detail6: "Jumlah bilangan pertaruhan",
            direct_bet_detail7: "Jumlah untung rugi",
            direct_data_date: "Tarikh",
            direct_data_table1: "Orang bawahannya",
            direct_data_table2: "Jumlah cas semula",
            direct_data_table3: "Tarikh pendaftaran",
            direct_data_table4: "Pertaruhan yang sah",
            direct_data_table5: "Tarikh log masuk",
            direct_data_table6: "Semasa",
            direct_data_table7: "Negeri",
            direct_data_text1: "Ya",
            direct_data_text2: "Tidak",
            direct_data_text3: "Tidak dibenarkan menerima hadiah",
            direct_data_text4: "Bekukan",
            direct_data_text5: "Biasalah",
            direct_data_text6: "Dalam talian",
            direct_data_text7: "Luar talian",
            direct_data_sum1: "Bilangan orang berdaftar",
            direct_data_sum2: "Bilangan cas semula",
            direct_data_sum3: "Bilangan orang yang membuat deposit pertama",
            direct_data_sum4: "Jumlah cas semula",
            direct_data_sum5: "Pertaruhan yang sah",
            direct_award_table1: "Jumlah Dituntut",
            direct_award_table2: "Aktiviti Dituntut",
            direct_award_table3: "Tugas Dituntut",
            direct_award_table4: "Rebat Dituntut",
            direct_award_table5: "VIP Dituntut",
            direct_award_table6: "Suruhanjaya Agen",
            direct_award_table7: "Pendapatan Faedah",
            my_data_text1: "Tambah ahli langsung",
            my_data_text2: "Bilangan orang yang membuat deposit pertama",
            my_data_text3: "Bilangan cas semula",
            my_data_text4: "Jumlah cas semula",
            my_data_text5: "Prestasi",
            my_data_text6: "Komisen",
            my_data_text7: "Gambaran keseluruhan data",
            my_data_text8: "Pasukan saya",
            my_data_text9: "Jumlah orang",
            my_data_text10: "Bilangan orang bawahan langsung",
            my_data_text11: "Orang lain",
            my_data_text12: "Prestasi saya",
            my_data_text13: "Prestasi keseluruhan",
            my_data_text14: "Prestasi langsung",
            my_data_text15: "Pencapaian lain",
            my_data_text16: "Komisen saya",
            my_data_text17: "Jumlah komisen",
            my_data_text18: "Komisen langsung",
            my_data_text19: "Komisen lain",
            my_data_date1: "semalam",
            my_data_date2: "hari ini",
            my_data_date3: "minggu ini",
            my_data_date4: "minggu lepas",
            my_data_date5: "bulan ini",
            my_data_date6: "bulan lepas",
            performanceDetail: {
                performance: "Menyumbang kepada prestasi",
                winLose: "Untung rugi ahli",
                discount: "Kutipan diskaun"
            },
            commissionDetail: {
                member: "Bilangan penyumbang",
                performance: "Prestasi",
                commission: "Komisen",
                gameType: "Jenis permainan"
            }
        },
        wallet: {
            all: "Semua",
            wallet: "Dompet",
            center_wallet: "dompet tengah",
            one_click_recycling: "Pemulihan satu klik",
            venue_wallet: "Dompet Tempat Permainan",
            balance: "Baki terkini",
            placeholder: "Carian Platform",
            tips: "You can only retrieve the integer multiple of the balance (that is, no decimal point)"
        },
        exchange: {
            exchange: "Pertukaran",
            exchange_record: "Rekod pertukaran",
            audit_record: "Rekod audit",
            account_manage: "Pengurusan akaun",
            account_balance: "Imbangan Akaun",
            withdrawable_balance: "Baki yang ada untuk pengeluaran",
            need_bet: "Need to bet",
            can_withdraw: "to withdraw",
            auditing: "Sedang disemak",
            detailInfo: "Butiran",
            standard_withdrawal: "Pengeluaran Standard",
            tips1: "Sila masukkan amaun tukaran",
            tips2: "Pilih akaun pengeluaran",
            all: "Semua",
            exchange_pwd: "Tebus kata laluan",
            confirm: "Mengesahkan",
            add_account: "Tambahkan akaun baru",
            tips3: "Kata laluan tidak boleh kosong",
            tips4: "kata laluan yang tidak betul",
            accumulate_exchange: "pertukaran terkumpul",
            order_no: "Pesanan No.",
            success: "Berjaya",
            fail: "Kegagalan",
            checking: "Dalam semakan",
            today: "Hari ini",
            yesterday: "Semalam",
            seven_days: "7 hari",
            fifteen_days: "15 hari",
            thirty_days: "30 hari",
            total_waiting_audit: "Jumlah keseluruhan yang akan diaudit",
            audit_detail: "Butiran audit",
            transaction_type: "Jenis Transaksi",
            audit_progress: "Kemajuan audit",
            amount: "Jumlah transaksi",
            audit_multiplier: "Berbilang audit",
            to_be_audit: "Menunggu audit",
            audited: "Diaudit",
            create_time: "Masa yang dicipta",
            exchange_account: "Akaun tukar",
            digital_currency: "Matawang digital",
            add: "Tambah",
            tips5: "Sila masukkan akaun PIX anda",
            tips6: "Sila masukkan 11 digit nombor",
            tips7: "Sila masukkan nombor CPF 11 digit",
            tips8: "Akaun PIX tidak boleh kosong",
            tips9: "Tidak boleh kosong",
            add_digital_currency: "Tambahkan mata wang digital",
            tips10: "Sila masukkan alamat cryptocurrency anda",
            tips11: "Medan alamat tidak boleh kosong",
            tips12: "Pastikan mata wang, protokol dan alamat sepadan, jika tidak, jumlah itu tidak akan dikreditkan.",
            tips13: "Alamat tidak boleh kosong",
            tips14: "Hanya menyokong penambahan satu akaun CPF paling banyak",
            tips15: "Nama tidak boleh kosong",
            tips16: "Sila taip nama anda",
            deleteTips: "Sahkan untuk memadam akaun semasa",
            tips17: "Bilangan akaun yang ditambahkan telah mencapai had atas",
            tips18: "Sila semak nama dan nombor kad dengan teliti, jika tidak, ia tidak akan dikreditkan",
            tips19: "Hanya 1 akaun PIX jenis PIX-CPF boleh ditambah",
            tips20: "Sila semak dengan teliti, jika tidak, ia tidak akan dikreditkan.",
            sendTo: "Dikeluarkan kepada",
            tips21: "Please enter the eleven phone number, starting with 0",
            tips22: "Note: Please ensure that the withdrawal name and withdrawal information are consistent to avoid withdrawal failure.",
            addWalletBtn: "Mengesahkan",
            detail: {
                title: "Butiran pengeluaran",
                type: "Jenis Transaksi",
                withdraw: "Menarik diri",
                methods: "Kaedah pengeluaran",
                fee: "Yuran pengendalian",
                createTime: "Nasa penciptaan",
                orderNo: "Nombor pesanan",
                remark: "Teguran"
            }
        },
        recharge: {
            recharge: "Buat deposit",
            recharge_online: "Caj semula dalam talian",
            digital_currency: "Online Banking Payment",
            recharge_record: "Sejarah deposit",
            recharge_amount: "Deposit amount",
            recharge_tips: "Penerangan aktiviti insentif",
            charge_tipsText: "Deposit mengikut jumlah yang disyorkan untuk menerima bonus yang sepadan. Jumlah bonus bertindan dengan bonus deposit.",
            currency: "Currency",
            terms: "Syarat penggunaan",
            recharge_now: "Tambah nilai segera",
            USDT_rate: "USDT rate",
            tips1: "Sila isikan alamat dompet pembayar dengan betul untuk menerima wang seperti biasa.",
            tips2: "Masukkan alamat wallet pembayar",
            tips3: "Sila masukkan jumlah",
            tips4: "Sila masukkan alamat",
            tips5: "Sila isikan TxId transaksi",
            tips6: "Pesanan telah tamat tempoh, sila serahkan semula",
            submit: "Menyerahkan",
            total_deposit: "Jumlah deposit",
            recharge_detail: "Butiran deposit",
            trade_type: "Jenis Transaksi",
            recharge_type: "Kaedah cas semula",
            recharge_channel: "Caj semula saluran",
            create_time: "Tercipta masa",
            order_no: "Pesanan No.",
            free: "Bebas",
            min: "Minimum",
            max: "Maksimum",
            exchangeRate: "kadar pertukaran",
            addPoint: "tambah titik",
            jump_tips: "Klik Sahkan untuk melompat ke halaman pembayaran",
            recharge_exchange_rate_tipsText: "Klik untuk menukar mata wang pertukaran"
        },
        account: {
            account_detail: "Perincian akaun",
            bet_record: "Rekod pertaruhan",
            personal_report: "Laporan individu",
            all: "Semua",
            time: "Masa",
            transaction_type: "Jenis Transaksi",
            detail: "maklumat terperinci",
            quantity: "kuantiti",
            total_deposits: "jumlah deposit",
            accumulated_withdrawals: "Pengeluaran terkumpul",
            type: "menaip",
            platform: "platform",
            game: "Permainan",
            effective_betting: "Pertaruhan sah",
            profit_loss: "untung dan rugi",
            bet_number: "Bilangan pertaruhan",
            bet_total: "Jumlah pertaruhan",
            total_win_loss: "Keseluruhan menang/kalah"
        },
        login: {
            password_login: "Log masuk kata laluan",
            msg_login: "Log masuk SMS",
            tips1: "Masukkan 6 hingga 16 aksara, huruf/nombor/simbol disokong",
            remember_password: "Ingat kata laluan",
            forget_password: "Terlupa kata laluan",
            login: "Log masuk",
            register: "Daftar akaun",
            other_login_methods: "Kaedah log masuk lain",
            tips2: "Panjang pengguna kurang daripada 4 digit",
            tips3: "Format kata laluan tidak betul",
            telephone: "no telefon",
            enter_password: "Katalaluan",
            again_enter_password: "Sila sahkan kata laluan lagi, sama seperti kata laluan!",
            strength: "Kekuatan",
            register2: "Daftar Akaun",
            register3: "Daftar",
            tips4: "Masukkan 4 hingga 16 aksara, huruf/nombor disokong dan aksara pertama mestilah huruf",
            tips5: "Nombor mudah alih yang dimasukkan adalah salah",
            tips6: "Kod pengesahan yang dimasukkan adalah salah",
            text1: "Saya berumur 18 tahun ke atas, telah membaca dan ",
            agreement: "\u300APerjanjian Pengguna\u300B",
            login_now: "Log masuk segera",
            general_registration: "Pendaftaran biasa",
            mobile_registration: "Daftar melalui telefon bimbit",
            tips7: "Dua kata laluan tidak konsisten",
            tips8: "Sila bersetuju dengan perjanjian itu",
            tips9: "Format kata laluan tidak betul",
            tips10: "Kata laluan yang dimasukkan dua kali tidak konsisten",
            tips11: "nombor telefon tidak betul",
            tips12: "Kod pengesahan tidak betul",
            reset_password: "Memadam kata laluan",
            reset_exchangePwd: "Tukar kata laluan",
            confirm: "Sahkan",
            username: "Akaun Ahli",
            send_code: "hantar",
            code: "Captcha",
            tips13: "Masukkan 6 digit",
            rewardTips: "Bonus pendaftaran",
            agreement_btn: "Saya telah membaca",
            successText: "Pengesahan lulus",
            failText: "Pengesahan gagal, sila cuba lagi",
            sliderText: "Seret gelangsar untuk menyelesaikan teka-teki",
            login_pwd: "Kata laluan login",
            verify_login_pwd: "Sahkan kata laluan log masuk",
            customer_service: "Khidmat Pelanggan"
        },
        side_bar: {
            bet_record: "Sejarah taruhan",
            agency: "Berlakon",
            event_title: "Kenaikan pangkat",
            event: "Aktiviti",
            task: "Tugasan",
            rebate: "Rebat",
            reward: "Bonus",
            history: "Dapatkan rekod",
            fees: "Menyimpan duit",
            dealer: "Peniaga",
            vip: "VIP",
            pending: "Tuntutan",
            agent: "Ejen",
            network: "Jaringan",
            download: "MUAT TURUN APLIKASI",
            customer_service: "Perkhidmatan pelanggan",
            faq: "FAQ",
            about_us: "Tentang Kami",
            closed: "Belum tersedia",
            exchange: "Menarik diri",
            account_manage: "Pengurusan akaun"
        },
        header_menu: {
            recharge: "Muat Semula",
            withdraw: "Menarik diri",
            login: "Log masuk",
            or: " Ataupun ",
            register: "Mendaftar",
            tips: "Dalam permainan"
        },
        common: {
            confirm: "Sahkan",
            cancel: "Batal",
            no_remind: "Tiada peringatan lagi hari ini",
            pls: "Tolonglah",
            add_to: "tambah ke",
            home_screen: "pergi ke skrin utama",
            no_data: "Belum ada data",
            tips: "Pembayang",
            day: "hari",
            hour: "jam",
            minutes: "menit",
            second: "kedua",
            recharge: "Muat Semula",
            exit: "Log keluar",
            refresh: "segarkan semula",
            full_screen: "skrin penuh"
        },
        promotion_event: {
            mixed: "Menyeluruh",
            collect_all: "Terima semua",
            collect_record: "Dapatkan rekod",
            coming: "Sila nantikan",
            end: "telah berakhir",
            collect: "menerima",
            collected: "telah diterima",
            incomplete: "belum siap",
            continuous_login: "Log masuk ",
            day: "hari",
            days: "hari berturut-turut",
            deposit_required: "Perlu tambah nilai",
            bet: "Pertaruhan",
            di: "Hari",
            mysterious_bonus: "Bonus Misteri",
            total_collect: "Diterima dalam jumlah",
            loss: "kerugian semalam",
            relief: "Ganjaran menyelamat hari ini",
            loss_amount: "Jumlah kerugian",
            additional_rewards: "Ganjaran tambahan",
            back: "Kembali",
            link: "Pautan eksklusif",
            quick_share: "Kongsi cepat",
            effective_people: "Orang peringkat rendah yang berkesan",
            request_qty: "Kuantiti yang diperlukan",
            activity_conditions: "Syarat aktiviti",
            effective_qty: "Nombor promosi yang berkesan",
            effective_bind_phone: "Mempromosikan bilangan orang yang terikat dengan telefon mudah alih dengan berkesan",
            effective_recharge: "Jumlah cas semula promoter yang berkesan",
            effective_bet: "Jumlah kod penganjur yang berkesan",
            people: "orang ramai",
            detail: "Butiran",
            promotion_tips_title: "Berapakah bilangan pemain yang dinaikkan pangkat secara berkesan? (memenuhi semua syarat yang dinyatakan di bawah)",
            subordinate_recharge: "Orang bawahan telah terkumpul isi semula",
            subordinate_bet: "Orang bawahan mengumpul taruhan",
            maximum: "Maksimum",
            aforementioned: "Atau yang tersebut di atas",
            more: "Lagi",
            apply: "Mohon diskaun",
            apply_now: "Mohon sekarang",
            apply_placeholder: "Sila masukkan jawapan",
            apply_tips: "Sila isi semua jawapan",
            my_referrals: "Rujukan saya",
            account: "Akaun",
            accumulated_recharge: "Cas semula terkumpul",
            accumulated_bets: "Pertaruhan terkumpul",
            status: "Status",
            efficient: "Cekap",
            invalid: "Tidak sah",
            balance_time: "Bilangan permohonan yang tinggal",
            tips: "Petua",
            tips1: "1. Selepas orang yang dinaikkan pangkat perlu mengikat telefon bimbit mereka, bilangan orang yang akan dinaikkan pangkat akan menjadi nombor yang berkesan;",
            tips2: "2. Selepas kemajuan semasa mencapai bilangan orang yang dinaikkan pangkat, anda boleh menerima baki CPF yang boleh dikeluarkan sekali gus;",
            rewardAmount: "Jumlah ganjaran",
            currentProcess: "Kemajuan semasa",
            bindPhone: "Ikat telefon bimbit",
            receive_success: "Diterima dengan jayanya",
            valid_people: "Bilangan orang yang sah",
            registerTime: "Masa pendaftaran",
            recharge: "Tambah nilai",
            bet: "Tambah mozek",
            request_recharge: "jumlah untuk deposit",
            tips3: "Isi semula {amount} hari ini untuk mendapatkan jumlah tuntutan tertinggi dalam peringkat seterusnya.",
            tips4: "Kenaikan pangkat yang berkesan: Orang bawahan perlu mengecas semula {jumlah}, membuat pertaruhan {bertaruhan} dan mengikat telefon bimbit",
            tips5: "Kenaikan pangkat yang berkesan: Orang bawahan perlu mengecas semula {jumlah}, membuat pertaruhan {bertaruhan}.",
            break_through_text1: "Permainan hari ini",
            break_through_text2: "Bilangan peringkat",
            break_through_text3: "Bilangan orang yang dijemput",
            break_through_text4: "Jumlah ganjaran jemputan",
            break_through_text5: "Jumlah pengekodan untuk menembusi tahap",
            break_through_text6: "Bonus tambahan untuk lulus tahap",
            break_through_text7: "Bilangan tahap dibersihkan hari ini",
            break_through_text8: "Jumlah ganjaran untuk bilangan jemputan hari ini",
            break_through_text9: "Jumlah pengekodan untuk pas hari ini",
            break_through_text10: "Ganjaran tahap hari ini",
            break_through_text11: "Mendapat ganjaran",
            break_through_text12: "Ganjaran untuk dituntut",
            break_through_text13: "IP yang sama",
            balance_relief_fund_text1: "Ahli yang telah mengecas semula",
            balance_relief_fund_text2: "Baki akaun kurang daripada",
            balance_relief_fund_text3: "Perkadaran jumlah cas semula ganjaran",
            balance_relief_fund_text4: "Baki akaun kurang daripada",
            balance_relief_fund_text5: "Jumlah pengekodan mencapai",
            balance_relief_fund_text6: "Perkadaran jumlah pengekodan ganjaran",
            balance_relief_fund_text7: "Pengagihan ganjaran",
            balance_relief_fund_text8: "Sistem akan mengeluarkan ganjaran secara automatik apabila sampai",
            balance_relief_fund_text9: "Ahli yang belum dicas semula",
            balance_relief_fund_text10: "Jumlah ganjaran",
            balance_relief_fund_text11: "Pengiraan ganjaran untuk ahli yang dicas semula: jumlah amaun caj semula x nisbah yang ditetapkan atau amaun ganjaran tetap",
            balance_relief_fund_text12: "Sebagai contoh: Ahli A telah mengecas semula 1000 dan nisbah agihan ganjaran ialah 5%, maka dia boleh mendapat ganjaran: 1000x5%=50",
            balance_relief_fund_text13: "Pengiraan ganjaran untuk ahli yang tidak dicaj semula: jumlah amaun pengekodan x nisbah yang ditetapkan atau amaun ganjaran tetap",
            balance_relief_fund_text14: "Contohnya: Ahli B belum mengecas semula, berkod 500, dan nisbah agihan ganjaran ialah 1.5%, maka dia boleh mendapat ganjaran: 500x1.5%=7.5",
            balance_relief_fund_text15: "Bilangan kali menerima hadiah",
            balance_relief_fund_text16: "Selepas ahli yang telah diisi semula menuntut hadiah, jika ahli tersebut menjadi muflis buat kali kedua, dia perlu menambah nilai semula untuk menuntut hadiah.",
            balance_relief_fund_text17: "Selepas ahli yang belum dicaj semula menuntut hadiah, dia yang muflis buat kali kedua mesti mengumpul semula jumlah kod sebelum dia boleh menuntut hadiah.",
            balance_relief_fund_text18: "Jumlah ganjaran"
        },
        promotion_task: {
            current_PA: "Semasa PA",
            reset_PA: "Masa set semula PA",
            collect_all: "menerima semua",
            collect_record: "Dapatkan rekod",
            next: "berterusan",
            collect: "Terima",
            collected: "Menerima",
            bonus: "Bonus",
            rule_title1: "1\u3001Masa tugas\uFF1A",
            rule_title2: "2\u3001Syarat tugas\uFF1A",
            rule_title3: "3\u3001Kandungan tugasan\uFF1A",
            news_title: "Faedah Pemain Baharu",
            news_rule_text1: "Misi masa terhad (sah dalam masa",
            news_rule_text2: "hari selepas pendaftaran)",
            news_rule_text3: "Lengkapkan tetapan yang berkaitan dan pautan selamat ke akaun kami",
            news_rule_text4: "1.Semua ahli yang baru mendaftar akan menerima sejumlah ganjaran selepas menyelesaikan tugasan di atas. Semakin tinggi kesukaran, semakin tinggi ganjarannya.",
            news_rule_text5: "2.Memandangkan setiap akaun adalah tanpa nama sepenuhnya, jika dicuri, sebarang dana yang hilang akibat kecurian tidak akan dipulihkan. Oleh itu, kami telah melaksanakan proses pengesahan akaun dua langkah, khususnya termasuk e-mel pembayaran, untuk mengesahkan tindakan yang diambil oleh pemilik akaun dan memastikan keselamatan akaun mereka.",
            news_rule_text6: "3.Terima terus jika syarat dipenuhi. Mata boleh dituntut terus pada iOS, Android, H5 dan PC. Dana akan dianggap tidak sah apabila tamat tempoh (jika pengguna tidak menuntutnya, ia akan dianggap sebagai kerugian sukarela).",
            news_rule_text7: "4.Disebabkan bonus tinggi tugas ini, bonus yang diberikan perlu ",
            news_rule_text8: "kali ganda semasa (iaitu semakan, penyertaan atau pertaruhan yang sah) untuk menerima bonus. Penyertaan tidak terhad kepada platform tertentu.",
            news_rule_text9: "5.Tugas ini hanya untuk pemilik akaun bermain seperti biasa. Dilarang sama sekali untuk menggunakan pelan pajakan, menggunakan simulator (program penipuan), robot, pertaruhan yang disengajakan dengan akaun yang berbeza, konfigurasi yang disengajakan, kerjasama, persatuan, perjanjian, mengeksploitasi kelemahan, kawalan kumpulan atau cara teknikal lain untuk mengambil bahagian, jika tidak, ganjaran akan dirampas, dibekukan atau dikeluarkan daripada potongan ganjaran, malah mungkin disenaraihitamkan.",
            news_rule_text10: "6.Untuk mengelakkan perbezaan dalam pemahaman teks, platform akan berhak untuk tafsiran akhir acara ini.",
            daily_title: "pencarian setiap hari",
            weekly_title: "tugas mingguan",
            daily_text1: "Tugas jangka panjang (set semula setiap hari pada pukul 00:00)",
            daily_text2: "Anda boleh mengecas semula dan kod sepenuhnya setiap hari",
            daily_text3: "1.Tugasan berikut boleh dilakukan setiap hari, termasuk caj semula harian, pertaruhan permainan tunggal atau pertaruhan lain. Selepas menyelesaikan tugas, anda boleh mendapat sejumlah ganjaran. Lebih besar kesukaran, lebih besar ganjaran;",
            daily_text4: "2.Jika anda memenuhi syarat, anda boleh mengeluarkan wang secara terus. Jumlah yang berbeza boleh disebut dalam satu jumlah sekali gus. Adalah disyorkan untuk memuat turun versi definisi tinggi apl untuk pengalaman yang lebih menyeronokkan.",
            daily_text5: "3.iOS, Android, H5 dan PC boleh dikumpul secara langsung dan akan menjadi tidak sah apabila tamat tempoh (iaitu, kegagalan untuk mengumpulnya secara aktif akan dianggap sebagai menyerah);",
            daily_text6: "4\u3001Bonus yang diperoleh daripada tugas ini (tidak termasuk bonus utama) mesti mencapai ",
            daily_text7: "kali ganda jumlah pertaruhan semasa (iaitu semakan, pertaruhan atau pertaruhan yang sah) sebelum ia boleh ditarik balik;",
            daily_text8: "5.Tugas ini hanya untuk pemilik akaun bermain seperti biasa. Dilarang sama sekali untuk menggunakan pelan pajakan, menggunakan simulator (program penipuan), robot, pertaruhan yang disengajakan dengan akaun yang berbeza, konfigurasi yang disengajakan, kerjasama, persatuan, perjanjian, mengeksploitasi kelemahan, kawalan kumpulan atau cara teknikal lain untuk mengambil bahagian, jika tidak, ganjaran akan dirampas, dibekukan atau dikeluarkan daripada potongan ganjaran, malah mungkin disenaraihitamkan.",
            daily_text9: "6.Untuk mengelakkan perbezaan dalam pemahaman teks, platform akan menyimpan hak terakhir untuk tafsiran acara ini.",
            weekly_text1: "Tugas jangka panjang (set semula setiap minggu pada pukul 00:00)",
            weekly_text2: "Anda boleh mengecas semula dan kod sepenuhnya setiap minggu",
            weekly_text3: "1.Tugasan berikut boleh dilakukan setiap minggu, termasuk caj semula mingguan, pertaruhan permainan tunggal atau pertaruhan lain. Selepas menyelesaikan tugas, anda boleh mendapat sejumlah ganjaran. Lebih besar kesukaran, lebih besar ganjaran;"
        },
        promotion_rebate: {
            today_effective_betting: "Pertaruhan yang sah hari ini",
            collect_all: "menerima semua",
            collect_record: "Dapatkan rekod",
            effective_betting: "Pertaruhan sah",
            rebate_ratio: "Nisbah rebat",
            can_be_claimed: "Tersedia untuk dikumpulkan",
            next_ratio: "Nisbah yang lebih rendah"
        },
        promotion_fees: {
            deposited: "Didepositkan",
            year_rate: "Annual interest rate",
            settlement_cycle: "Kitaran penyelesaian",
            accumulated_claimed: "Sebanyak yang dikumpul",
            deposit: "Simpanan",
            withdraw: "Keluarkan",
            unclaimed: "Menunggu koleksi",
            withdrawal_of_interest: "Tarik balik faedah",
            tips1_1: "Faedah boleh dikutip selepas pukul",
            tips1_2: "",
            detail: "Butiran",
            rules: "Peraturan",
            tips2: "Anda boleh mengumpulnya selepas kira detik ",
            claim_interest: "Terima faedah",
            total_income: "jumlah pendapatan",
            time: "Masa",
            amount: "Jumlah",
            hour: "Jam",
            type: "menaip",
            quantity: "kuantiti",
            account_balance: "Imbangan Akaun",
            tips3: "Deposit dan pengeluaran tidak akan menyebabkan audit, hanya faedah yang diterima akan diaudit",
            current_time: "Masa kini",
            all: "Semua",
            tips4: "Anggaran masa ketibaan minat",
            min_deposit: "Deposit sekurang-kurangnya setiap masa",
            min_deposit_end: "",
            deposit_balance: "Simpan baki",
            output_value: "Nilai penghasilan",
            tips5: "Sebaik sahaja anda menarik diri, anda akan kehilangan minat untuk tempoh terkini",
            exchange_pwd: "Ekstrak kata laluan",
            forget_pwd: "lupa kata laluan",
            support: "sokongan",
            tips6: "Sekurang-kurangnya keluarkan 1 amaun setiap kali",
            tips7: "Jumlah yang dimasukkan tidak boleh kosong",
            tups8: "Sila masukkan kata laluan penebusan 6 digit",
            rule_title1: "1\u3001Pengenalan pendapatan\uFF1A",
            rule_title2: "2\u3001Kitaran penyelesaian\uFF1A",
            rule_title3: "3\u3001Kadar faedah tahunan\uFF1A",
            rule_title4: "4\u3001Formula pengiraan\uFF1A",
            rule_title5: "5\u3001Contoh\uFF1A",
            rule_title6: "6\u3001Ambang pemindahan\uFF1A",
            rule_title7: "7\u3001Sekatan faedah\uFF1A",
            rule_title8: "8\u3001Masa pengumpulan\uFF1A",
            rule_title9: "9\u3001Semak berbilang\uFF1A",
            rule_title10: "10\u3001Pernyataan acara\uFF1A",
            rule_title11: "11\u3001Penerangan\uFF1A",
            rule_text1: "Amaun yang didepositkan ke dalam kumpulan faedah mesti memenuhi sekurang-kurangnya satu kitaran penuh untuk mengakru faedah.",
            rule_text2: "Jika dipindahkan terlebih dahulu, tiada hasil dikira untuk tempoh tersebut.",
            rule_text3: "Contohnya: jika kitaran penyelesaian semasa ialah",
            rule_text4: "jam, maka amaun yang dipindahkan pada 2023-01-01 00:00:01 akan mengakru faedah dalam tempoh pertama pada ",
            rule_text5: "hari",
            rule_text6: "",
            rule_text7: "Tempoh penyelesaian faedah semasa ialah",
            rule_text8: "jam",
            rule_text9: "Kadar faedah tahunan semasa ialah",
            rule_text10: "Pendapatan faedah = jumlah deposit * kadar faedah tahunan / tempoh penyelesaian;",
            rule_text11: "A mendepositkan 10,000 pada 01-01-2023 00:00:01, dengan kadar faedah tahunan",
            rule_text12: "dan kitaran penyelesaian",
            rule_text13: "am, jadi dia menerima pendapatan faedah pertama pada",
            rule_text14: "",
            rule_text15: "Pengiraan adalah seperti berikut:",
            rule_text16: "Faedah bayaran muka=",
            rule_text17: "Amaun setiap pemindahan mestilah lebih besar daripada atau sama dengan",
            rule_text18: "\uFF0C Tiada had atas untuk jumlah pemindahan. Lebih besar jumlahnya, lebih besar faedahnya;",
            rule_text19: "Tiada had faedah semasa, ingat untuk menerima pendapatan secara tetap atau kerap untuk mengelakkan kehilangan lebih banyak pendapatan!",
            rule_text20: "Pada masa ini, ia dikutip pada hari berikutnya, iaitu, faedah yang dijana pada hari tersebut tidak akan dikutip sehingga 0:00 keesokan harinya;",
            rule_text21: "Berganda semakan semasa ialah",
            rule_text22: "x (keperluan aliran pertaruhan), iaitu faedah yang diterima, dan anda perlu mendapatkan platform yang berkesan untuk pertaruhan tanpa had. Faedah terhad kepada faedah yang anda terima dan prinsipal pindahan masuk. Tiada keperluan semakan;",
            rule_text23: "Syarikat kami melarang perjudian dan pertaruhan biasa, akaun pajakan, pertaruhan bebas risiko (perjudian, pemadanan, menerima pampasan, curahan), timbang tara berniat jahat, penggunaan proses pemalam, robot, perjanjian penggunaan robot, kelemahan, antara muka, kawalan kumpulan atau lain-lain cara teknikal untuk mengambil bahagian.",
            rule_text24: "Selepas siasatan, platform mempunyai hak untuk menamatkan log masuk ahli, menggantung laman web ahli, merampas bonus dan mengharamkan permainan.",
            rule_text25: "Apabila ahli menerima ganjaran faedah, platform ini akan menganggap bahawa ahli bersetuju dan mematuhi syarat yang sepadan dan syarat lain yang berkaitan;"
        },
        records: {
            reward: "Bonus",
            rebate: "Rebat"
        },
        set_exchange_pwd: {
            title: "Kata Laluan Pengeluaran",
            tips: "Ini adalah pengeluaran pertama anda, anda perlu menetapkan kata laluan pengeluaran terlebih dahulu",
            subTitle: "Sediakan Kata Laluan Pengeluaran",
            exchange_pwd: "Tebus kata laluan",
            confirm_pwd: "Sahkan Kata Laluan",
            confirm: "Mengesahkan",
            tips1: "Dua kata laluan tidak konsisten",
            tips2: "Peringatan hangat: Kata laluan penebusan adalah sangat penting. Pastikan ingat dan simpannya. Jangan beritahu sesiapa. Jika berlaku kehilangan, aset tidak akan dipulihkan.",
            tips3: "Panjang kata laluan mestilah 6 digit",
            tips4: "6 digit"
        },
        bottom_menu: {
            index: "Rumah",
            promotion: "Kenaikan pangkat",
            vip: "VIP",
            recharge: "Cas semula",
            me: "Saya",
            exchange: "Pertukaran",
            rebate: "Rebat",
            task: "Tugasan",
            agent: "Ejen"
        },
        lucky_wheel_activity: {
            spin: `MULA
KAN`,
            text1: "Nilai tuah semasa",
            text2: "Pertaruhan diperlukan",
            text3: "untuk mendapatkan",
            text4: "Nilai bertuah",
            silver: "Perak",
            gold: "Emas",
            diamond: "Berlian",
            text5: "{amount} Nilai bertuah",
            tab1: "Pemberitahuan anugerah",
            tab2: "Rekod saya",
            text6: "dapatkan"
        },
        pop_red_envelopes: {
            text1: "Hujan peket merah",
            text2: "BUKA",
            text3: "Tahniah untuk hadiah",
            text4: "Bonus telah dimasukkan ke dalam dompet anda",
            tips1: "Petua",
            tips2: "Selepas ditutup, sampul merah dalam pusingan ini tidak lagi muncul. Apabila secara sukarela meninggalkan pahala."
        },
        message_center: {
            support: "Sokongan",
            news: "Berita",
            notification: "Pemberitahuan",
            marquee: "Marquee",
            feedback: "Maklum Balas"
        },
        finish_register: {
            title: "Peringatan",
            text: "Berjaya mendaftar! Jom main game sekarang~",
            btn: "Deposit Sekarang"
        },
        newbie_bonus: {
            title: "Bonus pemain baru",
            paste: "Tampal",
            placeholder: "Sila masukkan kod penebusan",
            bonus_amount: "Jumlah bonus",
            btn: "Tuntutan Bonus",
            tips: "Tahniah, anda telah memenangi {reward} bonus\uFF01"
        },
        claim: {
            title: "Tuntutan",
            reward: "Bonus",
            active_level: "Tahap aktif",
            time: "Masa",
            name: "Nama",
            source: "Sumber",
            status: "Status",
            claim: "Tuntutan",
            detailTitle: "Sumber ganjaran",
            reward_name: "Nama ganjaran",
            reward_time: "Masa ganjaran",
            amount: "Jumlah",
            point: "Tahap aktif",
            available_time: "Masa yang ada",
            rewards: "Ganjaran",
            claimable_time: "Masa yang boleh dituntut",
            validity_period: "Tempoh sah"
        },
        music: {
            music: "Muzik",
            cycle: "Kitaran",
            shuffle: "Kocok",
            repeat: "Ulang",
            downloaded: "Dimuat turun",
            system_music: "Muzik Sistem",
            my_music: "Muzik saya",
            deleteTips: "Lagu terakhir, yang tidak boleh dipadamkan"
        },
        add_tips_dialog: {
            title1: "Tambahkan pada Skrin Utama",
            subTitle1: '1. Klik ikon "Lagi", kemudian klik "Tambah ke Skrin Utama"',
            subTitle2: '2. Klik "Tambah", kemudian pilih "Tambah"',
            text1: "Kongsi...",
            text2: "Cari di halaman web",
            text3: "Tambahkan pada Skrin Utama",
            text4: "Tapak desktop",
            text5: "Tambahkan pada Skrin Utama",
            text6: "Batal",
            text7: "Tambah",
            title2: "Tambahkan ke skrin utama",
            text8: "Tambahkan pada Nota Pantas",
            text9: "Cari di halaman",
            text10: "Tambahkan ke skrin utama",
            text11: "Penanda buku",
            text12: "Pintasan akan ditambahkan pada skrin utama anda untuk akses pantas ke tapak web ini"
        },
        first_charge_pop: {
            title: "Ganjaran Tambahan Deposit Pertama",
            text1: "Deposit Pertama",
            text2: "Jumlah Ganjaran",
            btn: "Pergi"
        },
        tutorial: {
            text: `
        <h1><strong>Example:</strong></h1>
        <p>Assuming the current commission rate for valid bets between 0-10,000 is 100 for every 10,000 bets
            (1%), and for bets above 10,000 is 300 for every 10,000 bets (3%). A is the first to discover
            the opportunity and immediately recruits B1, B2, and B3; B1 further recruits C1 and C2; B2 has
            no subordinates; B3 recruits the strong C3. On the second day, B1's valid bets are 500, B2's
            valid bets are 3,000, B3's valid bets are 2,000, C1's valid bets are 1,000, C2's valid bets are
            2,000, and C3's valid bets reach 20,000.</p><span>The profit calculation between them is as
            follows:</span>
        <ul>
            <li><strong>1. B1's Commission</strong> (direct contributions from C1 and C2) = (1,000+2,000) *
                1% = <em>30</em></li>
            <li><strong>2. B2's Commission</strong> (no subordinates) = (0+0) * 1% = <em>0</em></li>
            <li><strong>3. B3's Commission</strong> (direct contribution from C3) = 20,000 * 3% =
                <em>600</em></li>
            <li><strong>4. A's Commission</strong> (direct contributions from subordinates B1, B2, and B3,
                and other subordinates C1, C2, and C3) are as follows:<ul>
                    <li><strong>(1) A's Direct Commission</strong> (direct contributions from B1, B2, and
                        B3) = (500+3,000+2,000) * 3% = <em>165</em></li>
                    <li><strong>(2) A's Other Commission</strong> (other contributions from C1, C2) =
                        (1,000+2,000) * 2% = <em>60</em></li>
                    <li><strong>(3) A's Total Commission</strong> (direct + other) = 165 + 60 = <em>225</em>
                    </li>
                </ul>
            </li>
            <li><strong>5. Summary:</strong>
                <ul>
                    <li><strong>(1) Direct Team:</strong> Refers to the direct subordinates recruited by A,
                        i.e., the direct relationship with A, collectively referred to as the direct team.
                    </li>
                    <li><strong>(2) Other Teams:</strong> Refers to the subordinates recruited by A's
                        subordinates, which are beyond the other relationship with A, i.e., subordinates of
                        subordinates, subordinates of subordinates of subordinates, and so on, collectively
                        referred to as other teams; because this agency model can recruit subordinates
                        infinitely, for the sake of explanation, this article only takes a 2-tier structure
                        as an example.</li>
                    <li><strong>(3) Explanation of A:</strong> A's direct performance is 5,500 and another
                        performance is 20,000 (due to the strong performance of C3), with a total
                        performance of 28,500, corresponding to a commission rate of 3%. Since B1's total
                        performance is 3,000, only enjoying a 1% commission, while A's total performance is
                        28500, enjoying a 3% commission rate, there is a tier differential between A and B1,
                        the difference being: 3% - 1% = 2%, this difference is the part contributed by C1
                        and C2 to A, so C1 and C2 contribute to A: (1,000+2,000) * 2% = 60, there is no tier
                        differential between A and B3, so C3 contributes no commission to A.</li>
                    <li><strong>(4) Explanation of B1:</strong> B1 has subordinates C1 and C2, with a direct
                        performance of 3,000, corresponding to a commission rate of 1%.</li>
                    <li><strong>(5) Explanation of B2:</strong> B2 may be lazy and not recruit subordinates,
                        thus no income.</li>
                    <li><strong>(6) Explanation of B3:</strong> Although B3 joined late and belongs to A's
                        subordinate, its subordinate C3 is strong, with a direct performance of 20,000,
                        allowing B3 to directly enjoy a higher commission rate of 3%.</li>
                    <li><strong>(7) Rule Summary:</strong> Regardless of when you join, under whose
                        subordinate, and no matter what level you are in, your income is never affected. You
                        no longer suffer from the losses of others' subordinates, and your recruitment is
                        not restricted. This is a fair and just agency model, and joining late does not mean
                        you will always be at the bottom.</li>
                </ul>
            </li>
        </ul>
        `
        },
        dealer: {
            title: "Peniaga",
            tutorial: "Tutorial",
            home: "Muka depan",
            review: "Semakan",
            performance: "Prestasi saya",
            member: "Ahli saya",
            game: "Data permainan",
            record: "Dapatkan rekod",
            ladder: "Tangga ganjaran"
        },
        dealer_tutorial: {
            title: "Mod merah penuh pertama",
            text1: "Ganjaran deposit pertama anda: 15/orang + ganjaran peringkat tambahan",
            text2: "Had ganjaran tidak boleh melebihi had anda sendiri",
            ruleTitle: "Jumlah tambah nilai anda:",
            ruleText1: "Contohnya, jika ejen am mempunyai ganjaran deposit kali pertama sebanyak 15 setiap orang, dan jika 100 orang dibangunkan untuk mengecas semula, ganjaran caj semula = 100*15=<b>1500</b>, dan tahap yang lebih rendah pengurusan diperuntukkan ganjaran 14 setiap orang, jika pengurus membangunkan 100 orang untuk mengisi semula, perbezaan akan diperolehi 100*(15-14)=100 Jika pengurusan membangunkan pekerja peringkat rendah dan membangunkan 100 orang untuk mengisi semula, ejen am boleh mendapat perbezaan 100*(15-12)=<b>300</b>, dan seterusnya ejen am mendapat Kuota = memiliki 1500 + baki pengurusan 100 + baki pekerja 300 +...",
            ruleText2: "Pengiraan perbezaan ganjaran berperingkat lain: Mengikut bilangan orang dan konfigurasi ganjaran, perbezaan itu masih boleh dikira Contohnya, jika jumlah ejen mencapai 50 orang, ganjaran ialah 100, dan jika pengurusan peringkat bawah menyediakan 50 orang. orang, ganjarannya ialah 90, anda masih boleh mendapat perbezaan <b>10</b>"
        },
        dealer_home: {
            dealerId: "ID peniaga",
            superiorId: "ID Superior",
            level: "Tahap",
            firstRecharge: "Deposit pertama anda",
            person: "orang",
            complaint: "Aduan",
            camReceive: "Boleh terima hadiah",
            received: "Menerima anugerah",
            myLink: "Pautan saya",
            myReview: "Ulasan saya",
            reviewNum: "Kuantiti untuk disemak",
            operation: "Beroperasi",
            reviewBtn: "Untuk mengkaji semula",
            reward_setting: "Tetapan ganjaran",
            firstRecharge_per_reward: "Ganjaran deposit pertama setiap orang",
            firstRecharge_ext_reward: "Ganjaran tambahan untuk deposit pertama",
            reward_ladder: "Tangga ganjaran",
            check: "Semak",
            reward_sum: "Statistik ganjaran",
            personal_reward: "Bilangan orang ganjaran",
            ext_reward: "Ganjaran tambahan",
            total_reward: "Jumlah ganjaran"
        },
        dealer_complaint: {
            title1: "Mengadu kepada peniaga",
            title2: "Rekod aduan",
            placeholder: "Sila masukkan kandungan aduan",
            submit: "Serahkan",
            tips: "Untuk memastikan operasi biasa ejen, anda boleh memfailkan aduan terhadap tingkah laku peniaga yang tidak bertanggungjawab, dan platform akan mengendalikannya untuk anda."
        },
        dealer_review: {
            placeholder: "Masukkan ID ahli",
            check: "Tanya",
            contact_setting: "Tetapan kenalan",
            memberId: "ID ahli",
            contactInfo: "Maklumat perhubungan",
            remark: "Teguran",
            applyTime: "Masa permohonan",
            review: "Semakan"
        },
        dealer_performance: {
            first_person: "Bilangan orang yang membuat deposit pertama",
            time: "Masa",
            dealer_person: "Bilangan peniaga",
            recharge_person: "Bilangan orang yang membuat deposit pertama",
            reward: "Pengumpulan ganjaran"
        },
        dealer_member: {
            placeholder: "Masukkan ID ahli",
            check: "Tanya",
            registerTime: "Masa pendaftaran",
            account: "ID ahli",
            accountRemark: "Catatan akaun ahli",
            superiorId: "ID Superior",
            isRecharge: "Sama ada untuk mengecas semula",
            dealer: "Peniaga",
            user: "Ahli biasa"
        },
        dealer_record: {
            received: "Komisen diterima",
            receive_time: "Masa pengumpulan",
            received: "Menerima"
        },
        dealer_contact_setting: {
            show: "Paparan perkhidmatan pelanggan",
            contactMethod: "Maklumat hubungan boleh diserahkan",
            modify: "Semak semula",
            tips1: "Sila pilih maklumat hubungan",
            tips2: "Isikan sekurang-kurangnya satu maklumat perkhidmatan pelanggan"
        },
        dealer_ladder: {
            currentNum: "Bilangan semasa orang yang membuat deposit pertama",
            tab1: "Ganjaran untuk orang yang mengisi semula",
            tab2: "Ganjaran promosi VIP",
            receivedReward: "Komisen diterima",
            levelUpNum: "Bilangan promosi",
            firstRecharge: "Bilangan orang yang membuat deposit pertama",
            reward: "Anugerah",
            vipLevel: "Tahap VIP"
        },
        dealer_join_dialog: {
            title1: "Hubungi Kami",
            title2: "Mohon untuk menjadi pengedar",
            table1: "Butiran kenalan",
            table2: "Teguran",
            table3: "Masa permohonan",
            table4: "Negeri",
            table5: "Beroperasi",
            btn1: "Serahkan semula",
            btn2: "Semak",
            text1: "Pilih maklumat hubungan",
            text2: "Isikan maklumat hubungan",
            text3: "Teguran",
            btn3: "Batal",
            btn4: "Pasti",
            btn5: "Batal",
            btn6: "Serahkan semula",
            tips1: "Sila pilih maklumat hubungan",
            tips2: "Sila isi maklumat hubungan"
        },
        dealer_review_detail: {
            title: "Semak semula operasi",
            account: "Aakaun ahli",
            applyTime: "Masa permohonan",
            contactType: "Maklumat perhubungan",
            contactInfo: "Kandungan kenalan",
            applyRemark: "Nota permohonan",
            rechargeReward: "Ganjaran deposit pertama",
            person: "orang",
            extReward: "Ganjaran tambahan",
            lower_recharge_reward_setting: "Konfigurasi ganjaran deposit pertama peringkat bawah",
            lower_recharge_extReward_setting: "Konfigurasi bonus tambahan untuk deposit pertama pada tahap yang lebih rendah",
            rechargePerson: "Bilangan orang yang mengecas",
            myReward: "Ganjaran saya",
            max_reward: "Ganjaran maksimum yang boleh ditetapkan",
            next_reward_setting: "Tetapan ganjaran peringkat rendah",
            withdraw_setting: "Tetapan pengeluaran",
            can_withdraw: "Boleh keluarkan wang tunai",
            cannot_withdraw: "Pengeluaran tidak boleh dilakukan",
            edit_setting: "Edit tetapan",
            can_edit: "Boleh edit",
            cannot_edit: "Tidak boleh disunting",
            level_name: "Nama peringkat",
            account_remark: "Catatan akaun ahli",
            reject: "Menolak",
            pass: "Lulus",
            tips1: "Sila tetapkan semua tetapan ganjaran peringkat rendah",
            tips2: "Sila tetapkan konfigurasi ganjaran deposit pertama untuk tahap yang lebih rendah",
            tips3: "Sila tetapkan konfigurasi ganjaran tambahan untuk deposit pertama di peringkat bawah",
            tips4: "Sila tetapkan konfigurasi edit",
            tips5: "Sila masukkan nama peringkat",
            tips6: "Sila tetapkan konfigurasi pengeluaran"
        },
        complaint: {
            title: "Aduan",
            site_complaint: "Aduan tapak",
            email: "E-mel",
            tipsTitle: "Menggambarkan",
            tips: "Untuk memastikan operasi biasa tapak, anda boleh membuat aduan terhadap tingkah laku tapak yang tidak bertanggungjawab dan platform akan mengendalikannya untuk anda.",
            emailError1: "E-mel tidak boleh kosong",
            emailError2: "Format e-mel tidak betul",
            placeholderText: "Sila masukkan kandungan aduan tapak"
        },
        upload: {
            uploading: "memuat naik...",
            tips1: "Saiz muat naik satu fail tidak boleh melebihi",
            tips2: "Jumlah saiz muat naik fail tidak boleh melebihi",
            tips3: "Saiz muat naik fail tidak boleh melebihi"
        },
        recharge_order_detail: {
            title: "Tambah nilai",
            tips1: "Sila buka aplikasi pembayaran anda dan imbas atau salin dan tampal kod QR di bawah untuk melengkapkan pembelian anda;",
            tips2: "Kod QR ini hanya boleh dibayar sekali Jika anda perlu membayar semula, sila kembali dan caj semula;",
            tips3: "Selepas pembayaran berjaya, anda boleh kembali ke lobi permainan dan tunggu mata ditambah!",
            effectTime: "Masa yang berkesan",
            copyText: "Salin kod QR",
            copyAddress: "Alamat kod QR ...",
            label1: "Status pesanan",
            label2: "Masa penciptaan",
            label3: "Nombor pesanan",
            label4: "Nombor pesanan peniaga",
            waiting: "Untuk dibayar",
            success: "Dibayar",
            warning: "Kod QR telah tamat tempoh",
            tips4: "Sila kembali ke lobi untuk membuat pesanan sekali lagi. Halaman semasa akan ditutup dalam masa 10 saat.",
            tips5: "Pilih",
            tips6: " Tutup sekarang ",
            tips7: "atau",
            tips8: " semak pesanan",
            tips9: "Berjaya diterima",
            tips10: "Sistem telah memberikan mata anda secara automatik.",
            tips11: "Halaman semasa akan ditutup dalam masa 10 saat."
        },
        check_pwd_dialog: {
            title: "Enter PIN",
            text1: "Withdrawal Password",
            text2: "For your account safety, please enter the withdrawal password",
            text3: "Forgot password?",
            btnText: "Confirm",
            tips1: "6 digits"
        }
    }, de = {
        home: {
            noData: "tidak ada data data",
            loadMore: "muat lebih banyak",
            moreTipsText1: "sedang ditampilkan",
            moreTipsText2: "Permainan panas keluar",
            moreTipsText3: "",
            maintain: "permainan dalam pemeliharaan",
            all: "semua",
            maintainText: "dalam pemeliharaan",
            limitAmountTips: "saldo anda tidak mencukupi {currency}{balance}, Isi ulang untuk mendominasi adegan!",
            top: "Atas"
        },
        footer: {
            cassino: "kasino",
            games: "game",
            support: "dukungan",
            none: "	belum terbuka",
            funcList: {
                reward: "hadiah",
                rebate: "potongan harga",
                vip: "VIP",
                agent: "kembalikan dana",
                event: "aktivitas",
                task: "tugas"
            },
            gameList: {
                hot: "Populer",
                card: "catur dan kartu",
                fish: "penangkapan ikan",
                digital: "elektronik",
                live: "Video",
                sports: "Pendidikan Jasmani",
                recent: "game belakangan ini",
                collect: "koleksi pribadi"
            },
            supportList: {
                support: "dalam online mendukung",
                advise: "saran ada hadiah",
                faq: "pusat bantuan"
            },
            technicalSupport: "dukungan teknis"
        },
        new_player: {
            title: "keuntungan bagi pemain baru",
            proceed: "proses",
            collect: "mengumpulkan",
            collected: "dikumpulkan",
            reward: "bonus",
            tips1: "jangan tampilkan lagi di sesi ini",
            tips2: "jangan pernah memperingatkan (periksa di pusat tugas)",
            collectAll: "kumpulkan semua",
            tip3: "tidak sesuai menerima permintaan",
            tip4: "silakan ikat metode pembayarannya terlebih dahulu"
        },
        search_page: {
            title: "mencari",
            result: "mencari",
            popular: "populer",
            recent: "belakang game ini",
            favorites: "koleksi pribadi",
            record: "hasil mencari",
            clear: "hapus semua"
        },
        sub_game: {
            search: "mencari",
            all: "semua"
        },
        vip_item: {
            accumulated_deposits: "akumulasi deposit",
            current_stream: "omset saat ini",
            relegation_deposits: "simpan level deposit",
            relegation_stream: "perputaran degradasi",
            tips1: "anda masih butuh",
            tips2: "deposit meningkat level sampai",
            tips3: "perputaran degradasi",
            maxLevel: "sudah adalah paling tinggi level",
            privilege: "hak istimewa",
            challenge_game: "game tantangan level",
            go: "pergi melihat",
            unset: "anda masih belum pengaturan ulang tahun",
            tips: "menampilkan",
            confirmText: "kedepan pengaturan",
            cancelText: "lain kali baru bilang"
        },
        vip_lucky_wheel: {
            daily_lottery: "pengundian setiap hari",
            upgrade_vip: "meningkat VIP",
            current: "omset saat ini",
            lottery_draw: "jumlah undian",
            winning_record: "catatan kemenangan",
            tips1: "pengundian jumlah sudah menggunakan habis",
            tips2: "selamat anda,mendapatkan",
            tips3: "nominal"
        },
        vip_birthday: {
            title: "telur ulang tahun",
            collect: "menerima",
            collected: "sudah menerima"
        },
        vip_reward: {
            title: "hadiah VIP",
            upgrade: "meningkatkan",
            recharge: "lagi isi ulang",
            bet: "taruhan lagi",
            collect_all: "satu tombol menerima",
            collect_record: "catatan menerima",
            level_list: "daftar level vip",
            upgrade_rewards: "hadiah meningkatkan",
            relegation_conditions: "simpan level permintaan",
            daily_rewards: "hadiah setiap hari",
            weekly_rewards: "hadiah setiap minggu",
            monthly_rewards: "hadiah sebulan",
            privilege: "hak istimewa VIP",
            rule_description: "Deskripsi aturan VIP",
            title1: "tingkatkan aturan hadiah",
            text1: "setelah memenuhi ketentuan promosi VIP (memenuhi persyaratan isi ulang dan akumulasi kode), anggota akan dipromosikan ke level VIP yang sesuai dan dapat menerima bonus promosi. jika anda meningkatkan beberapa bonus sekaligus, Anda dapat menerima semua bonus level promosi.",
            title2: "aturan bonus mingguan",
            text2: "ketika isi ulang mingguan dan jumlah taruhan mencapai level VIP saat ini dan persyaratan hadiah mingguan yang sesuai, anggota dapat menerima gaji mingguan yang sesuai, yang disetel ulang pada pukul 00:00 setiap hari Senin.",
            title3: "aturan hadiah bulanan",
            text3: "ketika isi ulang bulanan dan taruhan memenuhi persyaratan VIP bulan itu, Anda dapat menerima gaji bulanan yang sesuai. Gaji bulanan akan disetel ulang pada pukul 00:00 pada hari pertama setiap bulan.",
            rule_detail: "1. kriteria promosi:penuhi ketentuan promosi VIP(artinya deposit atau taruhan sah memenuhi kriteria)anda dapat meningkatkan ke level VIP yang sesuai,dan menerima bonus promosi yang sesuai.jika Anda meningkatkan beberapa level secara terus menerus,anda hanya bisa mendapatkan bonus promosi pada level saat ini,bonus dapat diklaim secara real time;<br/>2. Bonus harian: jika anda memenuhi tingkat setoran harian saat ini dan persyaratan taruhan efektif, anda bisa mendapatkan bonus harian yang sesuai. jika anda maju ke beberapa level berturut-turut, anda hanya akan menerima bonus harian untuk level saat ini. bonus dapat diklaim secara real time;<br/>3. bonus mingguan: jika anda memenuhi tingkat deposit saat ini dan persyaratan taruhan yang valid setiap minggunya, anda bisa mendapatkan bonus mingguan yang sesuai. jika anda naik ke beberapa level berturut-turut, anda hanya dapat menerima bonus mingguan untuk level saat ini. bonus dapat diklaim secara real time;<br/>4. bonus bulanan: jika anda memenuhi tingkat deposit saat ini dan persyaratan taruhan yang valid setiap bulan, anda dapat menerima bonus gaji bulanan yang sesuai. jika anda naik ke beberapa level berturut-turut, anda hanya dapat menerima bonus bulanan untuk level saat ini. bonus dapat diklaim secara real time;<br/>5. masa berlaku hadiah: hadiah yang diterima akan disimpan selama %d hari. jika tidak ada koleksi aktif selama periode ini, maka secara otomatis akan dikreditkan ke akun. misalnya: Jika hadiah diperoleh pada tanggal 1 Januari dan ditahan selama %d hari, hadiah akan otomatis disetorkan ke akun pada pukul 00:00:00 pada %d bulan Januari. <br/>6. catatan audit: bonus VIP harus dipertaruhkan 10 kali (yaitu diaudit, dimainkan, atau melewati taruhan yang sah) agar memenuhi syarat untuk penarikan.taruhan tidak terbatas pada platform permainan apa pun;<br/>7. pernyataan aktivitas: fitur ini hanya berlaku untuk taruhan normal pemilik akun. menyewa akun, taruhan bebas risiko (perjodohan, penyikatan, peluang rendah), arbitrase jahat, penggunaan plug-in, robot, protokol eksploitasi, celah, antarmuka, kontrol grup, dan sarana teknis lainnya dilarang. setelah diverifikasi, platform berhak menghentikan login anggota, menangguhkan penggunaan situs web anggota, menyita bonus, dan keuntungan yang tidak patut tanpa pemberitahuan sebelumnya. <br/>8. catatan: menerima hadiah VIP di platform dianggap sebagai persetujuan anggota untuk mematuhi ketentuan danperaturan terkait. untuk menghindari kesalahpahaman dalam penafsiran teks, platform berhak menafsirkan akhir acara ini.",
            none_reward: "tidak ada bisa menerima hadiah",
            current_level: "Current Level"
        },
        vip_reward_upgrade: {
            level: "level",
            reward_conditions: "persyaratan hadiah",
            operate: "operasi",
            recharge: "isi ulang",
            bet: "taruhan",
            collected: "sudah menerima",
            collect: "menerima",
            bonus: "komisi",
            text1: "taruhan sah perhari",
            text2: "taruhan perminggu",
            text3: "taruhan perbulan",
            text4: "isi ulang harian",
            text5: "isi ulang mingguan",
            text6: "isi ulang bulanan",
            text7: "meningkat perlu deposit",
            text8: "meningkat perlu taruhan",
            text9: "total batas penarikan harian",
            text10: "batas penarikan harian",
            text11: "jumlah transaksi harian bebas biaya",
            tips_title: "petunjuk",
            tips_content_recharge: "untuk meningkatkan ke level berikutnya, anda perlu menyetorkan jumlah tambahan di atas akumulasi deposit anda. Misal: untuk upgrade dari VIP1 dengan syarat isi ulang 1.000 ke VIP2 dengan syarat isi ulang 2.000, anggota harus mengumpulkan 1.000",
            tips_content_bet: "untuk meningkatkan ke level berikutnya, anda perlu menambahkan taruhan tambahan ke akumulasi taruhan anda. Misalnya: untuk meningkatkan dari VIP1 dengan persyaratan taruhan 1.000 ke VIP2 dengan persyaratan taruhan 2.000, anggota harus mengumpulkan 1.000",
            unlimited: "tidak ada batas",
            text12: "bulan kemarin isi ulang",
            text13: "taruhan bulan kemarin"
        },
        mine: {
            upgrade: "meningkat",
            recharge: "isi ulang lagi",
            bet: "taruhan lagi",
            need_recharge: "meningkat perlu isi ulang",
            need_bet: "meningkat perlu taruhan",
            account_detail: "akun detail bahan",
            bet_record: "catatan taruhan",
            personal_report: "laporan pribadi",
            service_setting: "pengaturan pelayanan",
            invite: "mengundang",
            account: "akun",
            help_center: "pusat bantuan",
            music: "musik",
            advise: "masukkan pendapat",
            about_us: "tentang kami",
            address_manage: "manajemen alamat",
            security_center: "pusat keamanan",
            language: "bahasa",
            exit: "keluar",
            tips1: "memastikan keluar akun saat ini",
            tips: "petunjuk",
            id: "ID",
            tab_account: "data data pribadi",
            message: "informasi",
            wallet: "dompet",
            exchange: "penukaran",
            deposit: "deposit",
            income: "simpan dompet",
            login_pwd: "kata sandi login",
            exchange_pwd: "penukaran kata sandi",
            million_monthly: "jutaan perbulan",
            support: "mendukung",
            search_balance: "mengecek saldo",
            request_label: "jarak",
            request_recharge: "nominal isi ulang"
        },
        advise: {
            message_title: "informasi pusat",
            welcome_title: "	layanan pelanggan penuh waktu kapanpun online demi anda menjawab pertanyaan apapun\u3002",
            welcome_text: "sepanjang hari online layanan pelanggan",
            customer: "online layanan pelanggan",
            title: "saran ada hadiah",
            faq: "masalah umum",
            read: "sudah membaca",
            unread: "belum membaca",
            advise_reward: "membuat",
            my_record: "catatan saya",
            content_title: "masukkan isi",
            content_tips: "(masukkan isi kami akan meningkatkan)",
            entry: "pendapat anda sangat berharga bagi kami. setiap saran yang berharga akan dipertimbangkan dan, jika diadopsi, pentingnya hal tersebut akan menentukan imbalan uang tunai. Kami mengundang anda untuk mengirimkan saran anda!",
            annex: "lampiran",
            annex_tips: "(lebih mudah untuk diadopsi)",
            upload_tips: "mendukung gambar atau video, ukurannya tidak melebih 40M",
            advise_title: "aturan bonus",
            advise_tips: "aturan Bonus Kami telah menyiapkan bonus besar untuk mengumpulkan umpan balik, khususnya untuk mengoptimalkan sistem dan fitur kami guna memberi anda pengalaman yang lebih baik! setelah diadopsi, penghargaan akan diberikan berdasarkan kepentingannya (tidak termasuk yang tidak diadopsi).",
            submit: "pengajuan masukkan",
            replied: "sudah membalas",
            feedback: "masukkan isi",
            reply: "balas isi",
            submit_tips: "pengajuan konten harus lebih dari 10 huruf",
            bonus: "bonus",
            contact: "segera hubungi"
        },
        mine_info: {
            title: "informasi pribadi",
            avatar: "foto profil pribadi",
            useName: "nama pengguna",
            realName: "nama asli",
            name_tips: "silahkan masukkan nama asli",
            sex: "kelamin",
            man: "laki laki",
            woman: "perempuan",
            birthday: "tanggal kelahiran",
            phone: "nomopr hp",
            email: "elektronik email",
            receive_address: "alamat penerima",
            no_address: "sementara tidak ada memastikan alamat penerima",
            save: "menyimpan",
            choose_date: "memilih tanggal",
            email_error_tips: "format email tidak benar",
            cancel: "batal",
            confirm: "memastikan",
            bindPhone: "mengikat nomor ponsel",
            tips1: "facebook tidak boleh kosong",
            tips2: "telegram tidak boleh kosong",
            tips3: "whatsapp tidak boleh kosong",
            tips4: "memastikan benar mau keluar?",
            tips5: "perubahan saat ini belum disimpan.jika anda mau pengembalian,mengubah tidak akan berlaku",
            copySuccess: "Success"
        },
        agent: {
            not_have: "tidak ada",
            extension_course: "tutorial promosi",
            change: "mengganti",
            claimable: "bisa menerima",
            direct_subordinate: "tepaty dibawah anggota",
            my_superiors: "atasan saya",
            unlimited_level_difference: "spread tidak terbatas (penyelesaian harian)",
            agency_mode: "mode proksi",
            share: "berbagi",
            agent: "agen",
            my_promotion: "promosi saya",
            my_data: "\u6211\u7684\u6570\u636E",
            tutorial: "tutorial",
            tab_commission: "komisi",
            my_performance: "omset saya",
            my_member: "pertunjukan",
            commission_rate: "tarif komisi",
            all_types: "emua jenis",
            all_data: "semua data data",
            finance: "langsung keuangan",
            wagers: "taruhan langsung",
            stats: "statistik langsung",
            claims: "terima secara langsung",
            account: "akun",
            superior: "atasan",
            can_receive: "bisa menerima",
            receive: "menerima",
            save: "simpan",
            my_link: "link saya",
            commission: "komisi",
            detail: "detail",
            total_commission: "nominal komisi",
            received: "sudah menerima",
            unclaimed: "belum menerima",
            member: "anggota",
            total_members: "jumlah anggota",
            direct_members: "anggota langsung",
            other_members: "anggota lain",
            total_income: "total pendapatan",
            direct_income: "pendapatan langsung",
            other_income: "pendapatan lainnya",
            bet: "taruhan",
            total_effective_bet: "total taruhan efektif",
            total_bet_number: "total taruhan sah",
            total_profit_loss: "total kerugian dan keuntungan",
            more: "lebih banyak",
            to: "ke",
            start_date: "mulai waktu",
            end_date: "waktu selesai",
            all: "semua",
            time: "waktu",
            type: "jenis",
            bet_amount: "nominal taruhan",
            bet_number: "jumlah taruhan",
            join_time: "waktu gabung",
            personnel: "personil",
            number: "urutan nomor",
            effective_bet_unit: "omset",
            unit: "taruhan yang sah : puluhan ribu",
            per_commission: "setiap puluhan ribu komisi",
            collect_record: "catatan menerima",
            search: "memeriksa",
            noData: "sementara tidak ada data data",
            collected_commission: "sudah menerima komisi",
            collected_time: "waktu menerima",
            amount: "nominal",
            myId: "akun saya",
            share_title1: "",
            share_title2: "link promosi",
            net_profit: "laba keuntungan",
            total_net_profit: "laba keuntungan total nominal",
            total_discount: "diskon total nominal",
            valid_people: "jumlah orang yang valid",
            valid_text1: "jumlah orang yang valid\u2265",
            valid_text2: "\uFF0Cjumlah orang yang efektif",
            deposit_amount: "nominal isi ulang",
            agent_tier: "tingkat agen",
            promotion_conditions: "persyaratan promosi",
            commission_detail_title: "detail komisi",
            commission_detail_endTime: "waktu penghitungan",
            commission_detail_placeholder: "masukkan ID anggota",
            commission_detail_table1: "ID anggota",
            commission_detail_table2: "atasan",
            commission_detail_table3: "data data taruhan",
            commission_detail_table4: "komisi",
            commission_detail_label1: "data langsung",
            commission_detail_label2: "data data yang lain",
            commission_detail_label3: "total data data",
            commission_detail_label4: "komisi langsung",
            commission_detail_label5: "komisi yang lain",
            commission_detail_label6: "total komisi",
            my_performance_label1: "jumlah tepat di bawah",
            my_performance_label2: "jumlah taruhan langsung",
            my_performance_label3: "komisi langsung",
            my_performance_label4: "jumlah orang lain",
            my_performance_label5: "jumlah taruhan lainnya",
            my_performance_label6: "komisi lainnya",
            all_data_table1: "waktu gabung",
            all_data_table2: "ID anggota",
            all_data_table3: "menyetorkan",
            all_data_table4: "taruhan sah",
            all_data_table5: "total kerugian dan keuntungan",
            all_data_label1: "jumlah nominal isi ulang langsung",
            all_data_label2: "jumlah deposan langsung top up pertama",
            all_data_label3: "nominal isi ulang lainnya",
            all_data_label4: "jumlah isi ulang lainnya",
            all_data_label5: "total isi ulang nominal",
            all_data_label6: "total jumlah isi ulang",
            direct_finance_table1: "bawahan dia",
            direct_finance_table2: "akun",
            direct_finance_table3: "penarikan",
            direct_finance_table4: "perbedaan setoran dan penarikan",
            direct_finance_table5: "saldo",
            direct_finance_table6: "kali",
            direct_finance_label1: "total isi ulang nominal",
            direct_finance_label2: "jumlah isi ulang",
            direct_finance_label3: "nominal isi ulang pertama",
            direct_finance_label4: "orang deposit pertama kali ",
            direct_finance_label5: "total penarikan nominal",
            direct_finance_label6: "jumlah penarikan",
            direct_bet_detail: "detail taruhan",
            direct_bet_table1: "bawahan dia",
            direct_bet_table2: "taruhan yang sah",
            direct_bet_table3: "kemenangan dan kekalahan kumulatif",
            direct_bet_table4: "kali",
            direct_bet_label1: "taruhan langsung sah",
            direct_bet_label2: "taruhan sah lainnya",
            direct_bet_label3: "total taruhan yang valid",
            direct_bet_label4: "menang atau kalah secara langsung",
            direct_bet_label5: "kemenangan dan kekalahan lainnya",
            direct_bet_label6: "total menang atau kalah ",
            direct_bet_detail1: "pabrikan",
            direct_bet_detail2: "nama permainan",
            direct_bet_detail3: "taruhan yang sah",
            direct_bet_detail4: "keuntungan dan kerugian kumulatif",
            direct_bet_detail5: "total taruhan",
            direct_bet_detail6: "jumlah total taruhan",
            direct_bet_detail7: "jumlah untung dan rugi",
            direct_data_date: "tanggal",
            direct_data_table1: "bawahan dia",
            direct_data_table2: "nominal isi ulang",
            direct_data_table3: "tanggal pendaftaran",
            direct_data_table4: "taruhan yang valid",
            direct_data_table5: "tanggal login",
            direct_data_table6: "saat ini",
            direct_data_table7: "status",
            direct_data_text1: "iya",
            direct_data_text2: "tidak",
            direct_data_text3: "tidak diperbolehkan menerima hadiah",
            direct_data_text4: "membekukan",
            direct_data_text5: "normal",
            direct_data_text6: "Online",
            direct_data_text7: "tidak aktif",
            direct_data_sum1: "jumlah pendaftaran",
            direct_data_sum2: "jumlah pengisian ulang",
            direct_data_sum3: "jumlah orang yang melakukan deposit pertama",
            direct_data_sum4: "nominal isi ulang",
            direct_data_sum5: "taruhan yang valid",
            direct_award_table1: "jumlah yang Diklaim",
            direct_award_table2: "aktivitas diklaim",
            direct_award_table3: "tugas diklaim",
            direct_award_table4: "rabat diklaim",
            direct_award_table5: "klaim VIP",
            direct_award_table6: "komisi agen",
            direct_award_table7: "pendapatan bunga",
            my_data_text1: "tambahkan anggota langsung",
            my_data_text2: "jumlah orang yang melakukan deposit pertama",
            my_data_text3: "jumlah pengisian ulang",
            my_data_text4: "nominal isi ulang",
            my_data_text5: "omset",
            my_data_text6: "komisi",
            my_data_text7: "ikhtisar data",
            my_data_text8: "team saya",
            my_data_text9: "jumlah total orang",
            my_data_text10: "jumlah orang yang berada di bawah pengawasan langsung",
            my_data_text11: "jumlah orang lain",
            my_data_text12: "omset saya",
            my_data_text13: "total omset",
            my_data_text14: "bawahan omset",
            my_data_text15: "omset lain lainnya",
            my_data_text16: "komiis saya",
            my_data_text17: "total komisi",
            my_data_text18: "bawahan komisi",
            my_data_text19: "komisi lain lain",
            my_data_date1: "kemarin",
            my_data_date2: "hari ini",
            my_data_date3: "minggu ini",
            my_data_date4: "minggu lalu",
            my_data_date5: "bulan ini",
            my_data_date6: "bulan lalu",
            performanceDetail: {
                performance: "berkontribusi pada omset",
                winLose: "keuntungan dan kerugian anggota",
                discount: "koleksi diskon"
            },
            commissionDetail: {
                member: "jumlah kontributor",
                performance: "omset",
                commission: "komisi",
                gameType: "jenis permainan"
            }
        },
        wallet: {
            all: "semua",
            wallet: "dompet",
            center_wallet: "dompet pusat",
            one_click_recycling: "satu klik daur ulang",
            venue_wallet: "dompet tempat permainan",
            balance: "saldo akun",
            placeholder: "platform mencari",
            tips: "hanya bisa mencari nominal lipat ganda bilangan bulat"
        },
        exchange: {
            exchange: "penukaran",
            exchange_record: "catatan penukaran",
            audit_record: "catatan audit",
            account_manage: "akun manajemen",
            account_balance: "saldo akun",
            withdrawable_balance: "saldo bisa penarikan",
            need_bet: "masih perlu penarikan",
            can_withdraw: "bisa penarikan",
            auditing: "sedang audit",
            detailInfo: "detail",
            standard_withdrawal: "enarikan standar",
            tips1: "silahkan masukkan nominal penukaran",
            tips2: "silahkan memilih akun penarikan",
            all: "semua",
            exchange_pwd: "penukaran kata sandi",
            confirm: "memastikan",
            add_account: "penambahan akun baru",
            tips3: "kata sandi tidak boleh kosong",
            tips4: "kata sandi salah",
            accumulate_exchange: "akumulasi penukaran",
            order_no: "nomor pesanan",
            success: "berhasil",
            fail: "gagal",
            checking: "sedang di tinjao",
            today: "hari ini",
            yesterday: "kemarin",
            seven_days: "7 hari",
            fifteen_days: "15 hari",
            thirty_days: "30 hari",
            total_waiting_audit: "jumlah total yang di audit",
            audit_detail: "detail audit",
            transaction_type: "jenis transaksi",
            audit_progress: "kemajuan audit",
            amount: "nominal transaksi",
            audit_multiplier: "audit berganda",
            to_be_audit: "menunggu audit",
            audited: "sudah audit",
            create_time: "waktu membuat",
            exchange_account: "penukaran akun",
            digital_currency: "mata uang digital",
            add: "menambahkan",
            tips5: "masukkan akun PIX anda",
            tips6: "silahkan masukkan 11 digit nomor",
            tips7: "masukkan 11 digit nomor dana tabungan anda",
            tips8: "akunPIX tidak boleh kosong",
            tips9: "tidak boleh kosong",
            add_digital_currency: "tambahkan mata uang digital",
            tips10: "silahkan masukkan alamat mata uang kripto",
            tips11: "bidang alamat tidak boleh kosong",
            tips12: "konfirmasi mata uang,pencocokan protokol dan alamat,jika tidak jumlah tersebut tidak akan di kreditkan\u3002",
            tips13: "alamat tidak boleh kosong",
            tips14: "hanya mendukung penambahan paling banyak satu akun CPF",
            tips15: "nama tidak boleh kosong",
            tips16: "silahkan masukkan nama asli",
            deleteTips: "memastikan hapus akun\uFF1F",
            tips17: "akun penambahan jumlah mencapai batas atas",
            tips18: "harap hati-hati memeriksa nama dan nomor kartu, jika tidak maka tidak akan dikreditkan",
            tips19: "hanya 1 akun PIX tipe PIX-CPF yang dapat ditambahkan",
            tips20: "harap periksa dengan teliti, jika tidak maka tidak akan dikreditkan.",
            tips21: "Please enter the eleven phone number, starting with 0",
            tips22: "Note: Please ensure that the withdrawal name and withdrawal information are consistent to avoid withdrawal failure.",
            sendTo: "mengirim ke",
            addWalletBtn: "memastikan",
            detail: {
                title: "detail penarikan",
                type: "jenis transaksi",
                withdraw: "penarikan",
                methods: "cara penarikan",
                fee: "biaya admintrasi",
                createTime: "waktu membuat",
                orderNo: "nomor pesanan",
                remark: "catat"
            }
        },
        recharge: {
            recharge: "tabungan",
            recharge_online: "online isi ulang",
            digital_currency: "Pembayaran perbankan online",
            recharge_record: "catatan tabungan",
            recharge_amount: "nominal tabungan",
            recharge_tips: "hadiah aktivas penjelasan",
            recharge_tipsText: "setor sesuai jumlah yang disarankan dan dapatkan bonus yang sesuai.jumlah bonus bertumpuk dengan bonus deposit\u3002",
            currency: "lei ya er",
            terms: "syarat penggunaan",
            recharge_now: "segera isi ulang",
            USDT_rate: "kurs USDT",
            tips1: "silahkan isi alamat dompet pembayaran dengan benar untuk menerima uang secara normal",
            tips2: "silahkan masukkan alamat dompet pembayaran",
            tips3: "silahkan masukkan nominal",
            tips4: "silahkan masukkan alamat",
            tips5: "silahkan isi transaksi Txld",
            tips6: "pesanan sudah gagal,silahkan ulang pengajuan pesanan",
            submit: "pengajuan",
            total_deposit: "total tabungan",
            recharge_detail: "detail tabungan",
            trade_type: "jenis transaksi",
            recharge_type: "cara isi ulang",
            recharge_channel: "saluran isi ulang",
            create_time: "waktu membuat",
            order_no: "nomor pesanan",
            free: "gratis",
            min: "paling kecil",
            max: "paling besar",
            exchangeRate: "kurs",
            addPoint: "penambahan jumlah",
            jump_tips: "klik konfirmasi untuk melompat ke halaman pembayaran",
            recharge_exchange_rate_tipsText: "klik untuk mengganti mata uang pertukaran"
        },
        account: {
            account_detail: "detail akun data data",
            bet_record: "catatan taruhan",
            personal_report: "laporan pribadi",
            all: "semuanya",
            time: "waktu",
            transaction_type: "jenis transaksi",
            detail: "detail informasi",
            quantity: "jumlah",
            total_deposits: "total tabungan",
            accumulated_withdrawals: "akumulasi penarikan",
            type: "jenis",
            platform: "platform",
            game: "game",
            effective_betting: "taruhan ada sah",
            profit_loss: "laba rugi",
            bet_number: "jumlah taruhan",
            bet_total: "total tyaruhan",
            total_win_loss: "total kemenangan/kerugian"
        },
        login: {
            password_login: "kata sandi login",
            msg_login: "login sms",
            tips1: "masukkan 6 sampai 16 angka sesuai,dukung huruf/angka/simbol",
            remember_password: "mengingat kata sandi",
            forget_password: "lupa kat sandi",
            login: "login",
            register: "daftar akun",
            other_login_methods: "cara login lainnya",
            tips2: "panjang pengguna kurang dari 4 digit",
            tips3: "format kata sandi salah",
            telephone: "nomor ponsel",
            enter_password: "masukkan kata sandi",
            again_enter_password: "sekali lagi masukkan kata sandi",
            strength: "kuat suhu",
            register2: "daftar akun",
            register3: "daftar",
            tips4: "masukkan 4 hingga 16 karakter, huruf/angka didukung, dan karakter pertama harus berupa huruf",
            tips5: "nomor ponsel yang dimasukkan salah",
            tips6: "kode verifikasi yang dimasukkan salah",
            text1: "saya berusia di atas 18 tahun, telah membaca dan menerima",
            agreement: "( Perjanjian Pengguna)",
            login_now: "segera login",
            general_registration: "daftar biasa",
            mobile_registration: "ponsel daftar",
            tips7: "kedua kata sandi tidak konsisten",
            tips8: "mohon setujui perjanjian tersebut",
            tips9: "format kata sandi salah",
            tips10: "kata sandi yang dimasukkan dua kali tidak konsisten",
            tips11: "nomor ponsel tidak benar",
            tips12: "kode verifikasi salah",
            reset_password: "ulang atur kata sandi",
            reset_exchangePwd: "ulang atur penukaran kata sandi",
            confirm: "memastikan",
            username: "nama pengguna",
            send_code: "mengirim kode verifikasi",
            code: "verifikasi",
            tips13: "masukkan 6 digit",
            rewardTips: "hadiah daftar",
            agreement_btn: "saya sudah mengetahui",
            successText: "verfikasi lulus",
            failText: "verifikasi gagal,silahkan ulang kembali",
            sliderText: "seret penggeser untuk menyelesaikan teka-teki",
            login_pwd: "kata sandi login",
            verify_login_pwd: "verfikasi kata sandi login",
            customer_service: "layanan pelanggan"
        },
        side_bar: {
            bet_record: "catatan taruhan",
            agency: "agen",
            event_title: "promosi",
            event: "aktivitas",
            task: "tugas",
            rebate: "potongan harga",
            reward: "hadiah",
            history: "catatan menerima",
            fees: "bank simpanan",
            dealer: "pedagang",
            vip: "VIP",
            pending: "menunggu menerima",
            agent: "agen",
            network: "jaringan",
            download: "install APP",
            customer_service: "layana pelanggan",
            faq: "masalah umum",
            about_us: "tentang kami",
            closed: "belum terbuka",
            exchange: "menarik",
            account_manage: "akun manajemen"
        },
        header_menu: {
            recharge: "isi ulang",
            withdraw: "menarik",
            login: "login",
            or: " Or ",
            register: "daftar",
            tips: "gunakan dalam permainan"
        },
        common: {
            confirm: "memastikan",
            cancel: "batal",
            no_remind: "tidak ada lagi pengingat hari ini",
            pls: "silhakan",
            add_to: "menambahkan sampai",
            home_screen: "tampilan depan",
            no_data: "sementara tidak ada data data",
            tips: "petunjuk",
            day: "langit",
            hour: "jam",
            minutes: "menit",
            second: "detik",
            recharge: "isi ulang",
            exit: "keluar",
            refresh: "perbarui",
            full_screen: "layar penuh"
        },
        promotion_event: {
            mixed: "kursus yang komprehensif",
            collect_all: "menerima semuanya",
            collect_record: "catatan menerima",
            coming: "silahkan menanti",
            end: "sudah selesai",
            collect: "menerima",
            collected: "sudah menerima",
            incomplete: "belum selesai",
            continuous_login: "berturut turut login",
            day: "langit",
            days: "langit",
            deposit_required: "perlu isi ulang",
            bet: "taruhan",
            di: "ke",
            mysterious_bonus: "bonus misteri",
            total_collect: "total menerima",
            loss: "kerugian kemarin",
            relief: "hadiah penyelamatan hari ini",
            loss_amount: "kerugian nominal",
            additional_rewards: "hadiah tambahan",
            back: "pengembalian",
            link: "link promosi anda",
            quick_share: "bagikan dengan cepat",
            effective_people: "ada efisien promosi personil",
            request_qty: "jumlah memerlukan",
            activity_conditions: "persyaratan aktivitas",
            effective_qty: "ada efisien promosi personil",
            effective_bind_phone: "ada efisien promosi jumlah mengikat ponsel",
            effective_recharge: "ada efisien promosi nominal isi ulang",
            effective_bet: "jumlah kode promotor yang efektif",
            people: "orang",
            detail: "detail",
            promotion_tips_title: "berapa banyak pemain yang dipromosikan secara efektif? (penuhi semua ketentuan berikut)",
            subordinate_recharge: "orang yang dipromosikan telah mengumpulkan isi ulang",
            subordinate_bet: "orang yang dipromosikan telah mengumpulkan taruhan",
            maximum: "nilai maksimum",
            aforementioned: "atau disebutkan di atas",
            more: "lebih banyak",
            apply: "pengajuan diskon",
            apply_now: "sekarang pengajuan",
            apply_placeholder: "silahkan masukkan jawaban",
            apply_tips: "silahkan isi semuanya jawaban",
            my_referrals: "rekomendasi saya",
            account: "akun",
            accumulated_recharge: "akumulasi isi ulang",
            accumulated_bets: "akumulasi taruhan",
            status: "status",
            efficient: "ada sah",
            invalid: "tidak sah",
            balance_time: "tersisa pengajuan jumlah",
            tips: "taruhan",
            tips1: "1.setelah orang yang dipromosikan perlu mengikat ponselnya, jumlah orang yang akan dipromosikan akan efektif;",
            tips2: "2.setelah kemajuan saat ini mencapai jumlah orang yang dipromosikan, anda dapat menerima saldo CPF yang dapat ditarik sekaligus;",
            rewardAmount: "hadiah nominal",
            currentProcess: "kemajuan saat ini",
            bindPhone: "mengikat bank",
            receive_success: "berhasil menerima",
            valid_people: "jumlah orang yang sah",
            registerTime: "waktu daftar",
            recharge: "isi ulang",
            bet: "scan kode",
            request_recharge: "jumlah isi ulang",
            tips3: "isi ulang {amount} hari ini untuk mendapatkan jumlah klaim tertinggi di tingkat berikutnya.",
            tips4: "promosi yang efektif: bawahan perlu mengisi ulang {amount}, memasang taruhan {bet}, dan mengikat ponsel mereka",
            tips5: "promosi yang efektif: level yang lebih rendah perlu mengisi ulang {amount} dan bertaruh {bet}.",
            break_through_text1: "pertandingan hari ini",
            break_through_text2: "jumlah level",
            break_through_text3: "jumlah mengundang orang",
            break_through_text4: "jumlah hadiah undangan",
            break_through_text5: "pengkodean total untuk menembus level",
            break_through_text6: "bonus tambahan untuk melewati level",
            break_through_text7: "jumlah level yang diselesaikan hari ini",
            break_through_text8: "jumlah hadiah untuk jumlah undangan hari ini",
            break_through_text9: "total coding untuk pass hari ini",
            break_through_text10: "hadiah level hari ini",
            break_through_text11: "sudah menerima hadiah",
            break_through_text12: "hadiah untuk diklaim",
            break_through_text13: "IP yang sama",
            balance_relief_fund_text1: "anggota yang telah mengisi ulang",
            balance_relief_fund_text2: "saldo akun kurang dari",
            balance_relief_fund_text3: "proporsi jumlah isi ulang hadiah",
            balance_relief_fund_text4: "saldo akun kurang dari",
            balance_relief_fund_text5: "jumlah pengkodean mencapai",
            balance_relief_fund_text6: "proporsi jumlah pengkodean hadiah",
            balance_relief_fund_text7: "distribusi hadiah",
            balance_relief_fund_text8: "sistem akan secara otomatis mengeluarkan hadiah ketika tercapai.",
            balance_relief_fund_text9: "anggota yang belum mengisi ulang",
            balance_relief_fund_text10: "jumlah hadiah",
            balance_relief_fund_text11: "perhitungan hadiah untuk anggota yang diisi ulang: jumlah total isi ulang x rasio yang ditetapkan atau jumlah hadiah tetap",
            balance_relief_fund_text12: "misal: member A sudah isi ulang 1000 dan rasio pembagian rewardnya 5%, maka dia bisa mendapatkan reward: 1000x5%=50",
            balance_relief_fund_text13: "perhitungan imbalan untuk anggota yang tidak diisi ulang: total jumlah pengkodean x rasio yang ditetapkan atau jumlah imbalan tetap",
            balance_relief_fund_text14: "misal: member B belum mengisi ulang, berkode 500, dan rasio pembagian reward 1,5%, maka ia dapat memperoleh reward: 500x1,5%=7,5",
            balance_relief_fund_text15: "berapa kali menerima hadiah",
            balance_relief_fund_text16: "setelah anggota yang diisi ulang mengklaim hadiahnya, kebangkrutan kedua memerlukan pengisian ulang lagi untuk mengklaim hadiah.",
            balance_relief_fund_text17: "setelah member yang belum mengisi ulang mengklaim hadiahnya, maka dia yang bangkrut untuk kedua kalinya harus mengakumulasi kembali hingga batas kode sebelum dia dapat mengklaim hadiahnya.",
            balance_relief_fund_text18: "jumlah hadiah"
        },
        promotion_task: {
            current_PA: "saat ini PA",
            reset_PA: "waktu pengaturan ulang PA",
            collect_all: "satu tombol menerima",
            collect_record: "catatan menerima",
            next: "lanjut",
            collect: "menerima",
            collected: "sudah menerima",
            bonus: "bonus",
            rule_title1: "1.waktu tugas",
            rule_title2: "2.syarat tugas\uFF1A",
            rule_title3: "3.konten tugas\uFF1A",
            news_title: "keuntungan pemain baru",
            news_rule_text1: "batas tugas (setelah daftar",
            news_rule_text2: "berlaku dalam beberapa hari\uFF09",
            news_rule_text3: "selesaikan pengaturan yang relevan dan tautan aman ke akun kami",
            news_rule_text4: "1.semua anggota baru yang menyelesaikan tugas di atas akan menerima sejumlah hadiah setelah menyelesaikan tugas. Semakin tinggi tingkat kesulitannya, semakin tinggi pula hadiahnya.",
            news_rule_text5: "2.karena setiap akun benar-benar anonim, jika dicuri, dana yang hilang karena pencurian tidak akan dikembalikan. Oleh karena itu, kami telah menerapkan proses verifikasi akun dua langkah, khususnya termasuk email pembayaran, untuk memverifikasi tindakan yang diambil oleh pemilik akun dan memastikan keamanan akun mereka.",
            news_rule_text6: "3.terima langsung jika syarat terpenuhi. poin dapat diklaim langsung di iOS, Android, H5, dan PC. dana akan dianggap tidak valid setelah habis masa berlakunya (jika pengguna tidak mengklaimnya, maka akan dianggap kehilangan sukarela).",
            news_rule_text7: "4.karena bonus untuk misi ini relatif tinggi, maka bonus yang diberikan memerlukan",
            news_rule_text8: "kali waktu saat ini (yaitu ulasan, partisipasi, atau taruhan valid) untuk menerima bonus. Partisipasi tidak terbatas pada platform tertentu.\u3002",
            news_rule_text9: "5.tugas ini hanya tersedia untuk permainan normal oleh pemilik akun. Dilarang keras menggunakan rencana sewa, menggunakan simulator (program penipuan), robot, taruhan yang disengaja dengan akun yang berbeda, konfigurasi yang disengaja, kolaborasi, asosiasi, perjanjian, memanfaatkan celah, kontrol kelompok atau cara teknis lainnya untuk berpartisipasi, jika tidak, imbalannya akan berupa disita, dibekukan, atau dikeluarkan dari potongan hadiah, dan bahkan dapat dimasukkan dalam daftar hitam.",
            news_rule_text10: "6.untuk menghindari perbedaan pemahaman teks, platform berhak menafsirkan akhir acara ini.",
            daily_title: "tugas setiap hari",
            weekly_title: "tugas setiap minggu",
            daily_text1: "tugas jangka panjang (setiap hari 00.00 ulang pengaturan)",
            daily_text2: "isi ulang penuh setiap hari,dapat diberi kode",
            daily_text3: "1.tTugas-tugas berikut dapat dilakukan setiap hari, termasuk top-up harian, taruhan satu pertandingan, atau taruhan lainnya. Setelah menyelesaikan tugas, anda bisa mendapatkan sejumlah hadiah. semakin besar kesulitannya, semakin besar pahalanya;",
            daily_text4: "2.jika memenuhi syarat, anda bisa langsung menarik uang. jumlah yang berbeda dapat disebutkan sekaligus. Disarankan untuk mengunduh aplikasi versi definisi tinggi untuk pengalaman yang lebih menyenangkan.",
            daily_text5: "3.iOS, Android, H5, dan PC dapat dikumpulkan secara langsung, dan akan menjadi tidak valid setelah habis masa berlakunya (yaitu, kegagalan mengumpulkannya secara aktif akan dianggap menyerah);",
            daily_text6: "4.bonus yang diperoleh dari tugas ini (tidak termasuk bonus utama) harus mencapai jumlah taruhan saat ini.",
            daily_text7: "ganda (yaitu review, taruhan atau taruhan yang sah)setelah itu baru bisa penarikan;",
            daily_text8: "5.tugas ini hanya tersedia untuk permainan normal oleh pemilik akun. dilarang keras menggunakan rencana sewa, menggunakan simulator (program penipuan), robot, taruhan yang disengaja dengan akun yang berbeda, konfigurasi yang disengaja, kolaborasi, asosiasi, perjanjian, memanfaatkan celah, kontrol kelompok atau cara teknis lainnya untuk berpartisipasi, jika tidak, imbalannya akan berupa disita, dibekukan, atau dikeluarkan dari potongan hadiah, dan bahkan dapat dimasukkan dalam daftar hitam.",
            daily_text9: "6.untuk menghindari perbedaan pemahaman teks, platform berhak menafsirkan akhir acara ini.",
            weekly_text1: "tugas jangka panjang (direset setiap minggu pukul 00:00)",
            weekly_text2: "isi ulang penuh setiap minggu,anda dapat scan kode QR",
            weekly_text3: "1.tugas-tugas berikut dapat dilakukan setiap minggu, termasuk top-up mingguan, taruhan satu pertandingan atau taruhan lainnya. setelah menyelesaikan tugas, anda bisa mendapatkan sejumlah hadiah. semakin besar kesulitannya, semakin besar pahalanya;"
        },
        promotion_rebate: {
            today_effective_betting: "taruhan valid hari ini",
            collect_all: "satu klik menerima",
            collect_record: "catatan menerima",
            effective_betting: "taruhan ada sah",
            rebate_ratio: "rasio rabat",
            can_be_claimed: "bisa menerima",
            next_ratio: "rasio gigi lebih rendah"
        },
        promotion_fees: {
            deposited: "sudah setoran",
            year_rate: "tingkat bunga tahunan",
            settlement_cycle: "penghitungan satu minggu",
            accumulated_claimed: "jumlah keseluruhan sudah menerima",
            deposit: "setor masuk",
            withdraw: "menarik keluar",
            unclaimed: "menunggu menerima",
            withdrawal_of_interest: "menarik bunga",
            tips1_1: "bunga tersedia di",
            tips1_2: "setelah menerima",
            detail: "detail",
            rules: "aturan",
            tips2: "anda dapat menerimanya setelah hitungan mundur selesai",
            claim_interest: "bunga menerima",
            total_income: "total pemasukan",
            time: "waktu",
            amount: "nominal",
            hour: "jam",
            type: "jenis",
            quantity: "jumlah",
            account_balance: "saldo akun",
            tips3: "penyetoran dan penarikan tidak akan mengakibatkan audit, hanya bunga yang diterima yang akan diaudit",
            current_time: "waktu saat ini",
            all: "semua",
            tips4: "perkiraan waktu kedatangan yang diminati",
            min_deposit: "setiap kali paling dikit setoran",
            min_deposit_end: "",
            deposit_balance: "saldo setoran",
            output_value: "nilai keluaran",
            tips5: "sekali anda menarik,anda akan kehilangan belakangan ini satu mingguan informasi",
            exchange_pwd: "kata sandi menarik",
            forget_pwd: "lupa kata sandi",
            support: "mendukung",
            tips6: "tarik setidaknya 1 jumlah setiap kali",
            tips7: "jumlah yang dimasukkan tidak boleh kosong",
            tups8: "silakan masukkan 6 digit kata sandi penukaran",
            rule_title1: "1. pengenalan pendapatan:",
            rule_title2: "2. siklus penyelesaian:",
            rule_title3: "3. suku bunga tahunan:",
            rule_title4: "4. rumus perhitungan:",
            rule_title5: "5. contoh:",
            rule_title6: "6. ambang batas transfer:",
            rule_title7: "7. pembatasan bunga:",
            rule_title8: "8. waktu menerima:",
            rule_title9: "9. tinjau beberapa kali:",
            rule_title10: "10. pernyataan kegiatan:",
            rule_title11: "11. deskripsi:",
            rule_text1: "jumlah yang disetorkan ke kumpulan bunga harus memenuhi setidaknya satu siklus penuh untuk memperoleh bunga.",
            rule_text2: "jika ditransfer lebih awal, pendapatan tidak dihitung untuk periode tersebut.",
            rule_text3: "misalnya: siklus penyelesaian saat ini adalah",
            rule_text4: "jam, maka jumlah transfer akan pada 01-01-2023 00:00:01",
            rule_text5: "langit",
            rule_text6: "minggu pertama Perhitungan bunga\uFF1A",
            rule_text7: "periode penyelesaian bunga saat ini sebagai",
            rule_text8: "jam",
            rule_text9: "tingkat bunga tahunan saat ini",
            rule_text10: "pendapatan bunga = jumlah simpanan * suku bunga tahunan / siklus penyelesaian;",
            rule_text11: "setoran 10.000 pada 01-01-2023 00:00:01, dengan tingkat bunga tahunan sebesar",
            rule_text12: "siklus penyelesaiannya sebagai",
            rule_text13: "jam, oleh karena itu di",
            rule_text14: "dapatkan pendapatan bunga pertama anda",
            rule_text15: "perhitungannya adalah sebagai berikut:",
            rule_text16: "bunga uang muka =",
            rule_text17: "jumlah setiap transfer harus lebih besar atau sama dengan",
            rule_text18: "\uFF0Ctidak ada batasan atas jumlah transfer, semakin besar jumlahnya, semakin besar keuntungannya;",
            rule_text19: "tidak ada batasan bunga saat ini, ingatlah untuk menerima pendapatan secara teratur atau sering untuk menghindari kehilangan lebih banyak pendapatan!",
            rule_text20: "saat ini dikumpulkan pada hari berikutnya, yaitu bunga yang dihasilkan pada hari itu tidak akan dikumpulkan sampai pukul 0:00 keesokan harinya;",
            rule_text21: "Kelipatan ulasan saat ini adalah",
            rule_text22: "kali (persyaratan lalu lintas taruhan), yaitu bunga yang diterima, anda perlu mendapatkan platform yang efektif untuk bertaruh bunga tak terbatas. bunga terbatas pada bunga yang Anda terima dan pokok transfer masuk.",
            rule_text23: "saya memiliki taruhan perjudian normal, tidak ada akun sewa, taruhan bebas risiko (perjudian, pencocokan, kompensasi rendah, penyikatan), arbitrase jahat, penggunaan proses plug-in, robot, protokol penggunaan robot, celah, antarmuka, kontrol grup, atau teknis lainnya berarti berpartisipasi.",
            rule_text24: "setelah diselidiki ternyata benar,platform berhak menghentikan login anggota,berhentikan website member,kehilangan bonus dan profitabilitas yang tidak mencukupi.",
            rule_text25: "ketika anggota menerima imbalan bunga bank,platform ini akan berasumsi bahwa anggota menyetujui dan mematuhi ketentuan yang relevan dan ketentuan lain yang relevan"
        },
        records: {
            reward: "bonus",
            rebate: "potongan harga"
        },
        set_exchange_pwd: {
            title: "kata sandi penukaran",
            tips: "anda adalah pertama penarikan,perlu duluan pengaturan kata sandi penarikan",
            subTitle: "pengaturan penukaran kata sandi",
            exchange_pwd: "kata sandi penukaran",
            confirm_pwd: "memastikan kata sandi",
            confirm: "memastikan",
            tips1: "kata sandi yang dimasukkan dua kali tidak konsisten",
            tips2: "pengingat hangat: kata sandi penukaran sangat penting. pastikan untuk mengingat dan menyimpannya.jangan memberitahu kepada siapapun,jika terjadi kerugian,aset tidak akan dipulihkan.",
            tips3: "panjang kata sandi harus 6 digit",
            tips4: "6 digit"
        },
        bottom_menu: {
            index: "Home",
            promotion: "Promotion",
            vip: "VIP",
            recharge: "Recharge",
            me: "Mine",
            exchange: "Exchange",
            rebate: "Rebate",
            task: "Task",
            agent: "Agent"
        },
        lucky_wheel_activity: {
            spin: "lotere",
            text1: "nilai keberuntungan saat ini",
            text2: "perlu taruhan",
            text3: "baru bisa memperoleh",
            text4: "nilai keberuntungan",
            silver: "perak",
            gold: "emas",
            diamond: "berlian",
            text5: "{amount} nilai keberuntungan",
            tab1: "pemberitahuan pemenang",
            tab2: "catatan saya",
            text6: "mendapatkan"
        },
        pop_red_envelopes: {
            text1: "hujan amplop merah",
            text2: "membuka",
            text3: "selamat atas kemenangannya",
            text4: "bonus telah disetorkan ke dompet anda",
            tips1: "petunjuk",
            tips2: "apakah akan menyerah menerima amplop merah. setelah ditutup, amplop merah tidak akan muncul lagi di babak ini."
        },
        message_center: {
            support: "layanan pelanggan",
            news: "informasi",
            notification: "pemberitahuan",
            marquee: "lampu balap kuda",
            feedback: "hadiah ada saran"
        },
        finish_register: {
            title: "petunjuk",
            text: "daftar berhasil! sekarang mari kita main game~",
            btn: "pergi isi ulang"
        },
        newbie_bonus: {
            title: "bonus pemula",
            paste: "paste",
            placeholder: "silahkan masukkan kode penukaran",
            bonus_amount: "nominal bonus",
            btn: "menerima hadiah",
            tips: "selamat anda,mendapatkan {reward} komisi\uFF01"
        },
        claim: {
            title: "menunggu menerima",
            reward: "bonus",
            active_level: "aktif",
            time: "waktu",
            name: "nama aktivitas",
            source: "sumber",
            status: "status",
            claim: "menerima",
            detailTitle: "aluran hadiah",
            reward_name: "nama hadiah",
            reward_time: "waktu hadiah",
            amount: "nominal",
            point: "aktif",
            available_time: "waktu yang sah",
            rewards: "hadiah",
            claimable_time: "waktu yang tersedia",
            validity_period: "masa berlaku"
        },
        music: {
            music: "musik",
            cycle: "siklus",
            shuffle: "acak",
            repeat: "lagu tunggal",
            downloaded: "sudah download",
            system_music: "sistem musik",
            my_music: "musik saya",
            deleteTips: "ini adalah lagu terakhir, tidak dapat dihapus"
        },
        add_tips_dialog: {
            title1: "tambahkan ke layar utama",
            subTitle1: '1. klik ikon "lainnya", lalu klik "tambahkan ke layar beranda"',
            subTitle2: '2. klik "tambah", lalu pilih "tambah"',
            text1: "membagikan...",
            text2: "temukan di halaman web",
            text3: "tambahkan ke layar utama",
            text4: "situs desktop",
            text5: "tambahkan ke layar utama",
            text6: "batal",
            text7: "menambahkan",
            title2: "tambahkan ke layar utama",
            text8: "tambahkan ke catatan cepat",
            text9: "temukan di halaman",
            text10: "tambahkan ke layar utama",
            text11: "penanda buku",
            text12: "pintasan akan ditambahkan ke layar beranda anda untuk akses cepat ke situs web ini"
        },
        first_charge_pop: {
            title: "hadiah ekstra setoran pertama",
            text1: "setoran pertama",
            text2: "jumlah hadiah",
            btn: "pergi"
        },
        tutorial: {
            text: `
        <h1><strong>contoh:</strong></h1>
        <p>dengan asumsi tingkat komisi saat ini untuk taruhan valid antara 0-10.000 adalah 100 untuk setiap 10.000 taruhan
        (1%), dan untuk taruhan diatas 10.000 adalah 300 untuk setiap 10.000 taruhan (3%). A adalah orang pertama yang menemukan
        peluang dan segera merekrut B1, B2, dan B3; B1 selanjutnya merekrut C1 dan C2; B2 punya
        tidak ada bawahan; B3 merekrut C3 yang kuat. Pada hari kedua, taruhan sah B1 adalah 500, B2
        taruhan sah adalah 3.000, taruhan sah B3 adalah 2.000, taruhan sah C1 adalah 1.000, taruhan sah C2 adalah
        2.000, dan taruhan sah C3 mencapai 20.000.</p><span>Perhitungan keuntungan diantara keduanya adalah sebagai
        berikut:</span>
        <ul>
        <li><kuat>1. Komisi B1</strong> (kontribusi langsung dari C1 dan C2) = (1.000+2.000) *
        1% = <em>30</em></li>
        <li><kuat>2. komisi B2</strong> (tidak ada bawahan) = (0+0) * 1% = <em>0</em></li>
        <li><kuat>3. komisi B3</strong> (kontribusi langsung dari C3) = 20.000 * 3% =
        <em>600</em></li>
        <li><kuat>4. komisi A (kontribusi langsung dari bawahan B1, B2, dan B3,
        dan bawahan lainnya C1, C2, dan C3) adalah sebagai berikut:<ul>
        <li><strong>(1) komisi langsung A</strong> (kontribusi langsung dari B1, B2, dan
        B3) = (500+3.000+2.000) * 3% = <em>165</em></li>
        <li><strong>(2) komisi lain A</strong> (kontribusi lain dari C1, C2) =
        (1.000+2.000) * 2% = <em>60</em></li>
        <li><strong>(3) total komisi A</strong> (langsung + lainnya) = 165 + 60 = <em>225</em></li>
        </ul>
        </li>
        <li><kuat>5. ringkasan:</strong>
        <ul>
        <li><strong>(1) tim langsung:</strong> mengacu pada bawahan langsung yang direkrut oleh A,
        yaitu hubungan langsung dengan A, yang secara kolektif disebut sebagai tim langsung.
        </li>
        <li><strong>(2) tim lain:</strong> mengacu pada bawahan yang direkrut oleh A
        bawahan, yang berada di luar hubungan lain dengan A, yaitu bawahan dari
        bawahan, bawahan dari bawahan dari bawahan, dan seterusnya, secara kolektif
        disebut sebagai tim lain; karena model agensi ini dapat merekrut bawahan
        tanpa batas, demi penjelasan, artikel ini hanya mengambil struktur 2 tingkat
        sebagai contoh.</li>
        <li><strong>(3) penjelasan A:</strong> pertunjukan langsung A adalah 5.500 dan lainnya
        kinerjanya adalah 20.000 (karena kinerja C3 yang kuat), dengan total
        kinerja 28.500, sesuai dengan tingkat komisi 3%. karena total B1
        kinerjanya 3.000, hanya menikmati komisi 1%, sedangkan kinerja total A adalah
        28500, menikmati tingkat komisi 3%, ada perbedaan tingkat antara A dan B1,
        selisihnya adalah: 3% - 1% = 2%, selisih tersebut merupakan bagian yang disumbangkan oleh C1
        dan C2 ke A, jadi C1 dan C2 menyumbang ke A: (1.000+2.000) * 2% = 60, tidak ada tier
        perbedaan antara A dan B3, sehingga C3 tidak memberikan kontribusi komisi kepada A.</li>
        <li><strong>(4) penjelasan B1:</strong> B1 mempunyai bawahan C1 dan C2, dengan hubungan langsung
        kinerja sebesar 3.000, setara dengan tingkat komisi sebesar 1%.</li>
        <li><strong>(5) penjelasan B2:</strong> B2 mungkin malas dan tidak merekrut bawahan,
        jadi tidak ada penghasilan.</li>
        <li><strong>(6) penjelasan B3:</strong> meskipun B3 terlambat bergabung dan termasuk dalam kelompok A
        bawahannya, bawahannya C3 kuat, dengan kinerja langsung 20.000,
        memungkinkan B3 untuk langsung menikmati tingkat komisi yang lebih tinggi sebesar 3%.</li>
        <li><strong>(7) ringkasan aturan:</strong> terlepas dari kapan anda bergabung, di bawah siapa
        bawahan, dan di level mana pun anda berada, penghasilan anda tidak pernah terpengaruh. anda
        tidak lagi menderita karena kehilangan bawahan orang lain, dan perekrutan anda pun demikian
        tidak dibatasi. ini adalah model agensi yang adil dan adil, dan terlambat bergabung tidak berarti
        kamu akan selalu berada di bawah.</li>
        </ul>
        </li>
        </ul>
        `
        },
        dealer: {
            title: "pedagang",
            tutorial: "tutorial",
            home: "halaman depan",
            review: "tinjauan",
            performance: "omset saya",
            member: "anggota saya",
            game: "data game",
            record: "catatan pendapatan",
            ladder: "tangga hadiah"
        },
        dealer_tutorial: {
            title: "mode merah penuh pertama",
            text1: "hadiah deposit pertama anda: 15/orang + hadiah tangga tambahan",
            text2: "batasan hadiah tidak diperbolehkan>batas atas sendiri",
            ruleTitle: "total isi ulang anda:",
            ruleText1: "misalnya, jika agen umum memiliki hadiah deposit pertama kali sebesar 15 per orang, dan jika 100 orang mengembangkan isi ulang, hadiah isi ulang = 100*15=<b>1500</b>, dan hadiah sebesar 14 per orang dialokasikan untuk manajer bawahan, jika manajer mengembangkan 100 orang untuk mengisi ulang, mereka akan mendapat selisih 100*(15-14)=100. jika manajemen mengembangkan karyawan tingkat bawah dan mengembangkan 100 orang untuk mengisi ulang, agen umum bisa mendapat selisih 100*(15-12)=<b>300</b>, dan seterusnya; agen umum mendapat kuota = memiliki 1500 + saldo manajemen 100 + saldo karyawan 300 +...",
            ruleText2: "perhitungan selisih imbalan berjenjang lainnya: berdasarkan jumlah orang dan konfigurasi imbalan, selisihnya masih dapat dihitung, misalnya jika total agen mencapai 50 orang, imbalannya adalah 100, dan jika manajemen tingkat bawah menyiapkan 50 orang. orang-orang, hadiahnya 90, anda masih bisa mendapat selisih <b>10</b>"
        },
        dealer_home: {
            dealerId: "ID dealer",
            superiorId: "ID unggul",
            level: "tingkat",
            firstRecharge: "top up pertama kamu",
            person: "orang",
            complaint: "keluhan",
            camReceive: "dapat menerima hadiah",
            received: "sudah menerima penghargaan",
            myLink: "link saya",
            myReview: "tinajuan saya",
            reviewNum: "jumlah yang akan ditinjau",
            operation: "operasi",
            reviewBtn: "pergi tinjauan",
            reward_setting: "pengaturan bonus",
            firstRecharge_per_reward: "hadiah top up pertama per orang",
            firstRecharge_ext_reward: "hadiah ekstra untuk top up pertama",
            reward_ladder: "tangga hadiah",
            check: "melihat",
            reward_sum: "statistik hadiah",
            personal_reward: "jumlah orang memberi hadiah",
            ext_reward: "bonus tambahan",
            total_reward: "total hadiah"
        },
        dealer_complaint: {
            title1: "mengadu ke dealer",
            title2: "catatan keluhan",
            placeholder: "silakan masukkan konten keluhan",
            submit: "kirim",
            tips: "untuk memastikan pengoperasian normal agen, anda dapat mengajukan keluhan terhadap perilaku dealer yang tidak bermoral, dan platform akan menanganinya untuk anda."
        },
        dealer_review: {
            placeholder: "masukkan ID member",
            check: "mengecek",
            contact_setting: "pengaturan hubungi",
            memberId: "ID member",
            contactInfo: "informasi hubung",
            remark: "catat",
            applyTime: "waktu pengajuan",
            review: "tinjauan"
        },
        dealer_performance: {
            first_person: "jumlah top up pertama",
            time: "waktu",
            dealer_person: "jumlah dealer",
            recharge_person: "jumlah top up pertama",
            reward: "akumulasi hadiah"
        },
        dealer_member: {
            placeholder: "silahkan masukkan ID member",
            check: "mengecek",
            registerTime: "waktu pendaftaran",
            account: "ID member",
            accountRemark: "catat akun member",
            superiorId: "ID atasan",
            isRecharge: "apakah isi ulang",
            dealer: "pedagang",
            user: "anggota biasa"
        },
        dealer_record: {
            received: "sudah menerima komisi",
            receive_time: "waktu menerima",
            received: "sudah menerima"
        },
        dealer_contact_setting: {
            show: "tampilan layanan pelanggan",
            contactMethod: "cara hubungi dapat dikirimkan",
            modify: "ubah",
            tips1: "silahkan memilih cara hubungi",
            tips2: "isi setidaknya satu informasi layanan pelanggan"
        },
        dealer_ladder: {
            tab1: "hadiah jumlah isi ulang",
            tab2: "hadiah promosi VIP",
            currentNum: "jumlah top up pertama saat ini",
            levelUpNum: "jumlah promosi",
            receivedReward: "sudah menerima komisi",
            firstRecharge: "jumlah top up pertama",
            reward: "hadiah",
            vipLevel: "level VIP"
        },
        dealer_join_dialog: {
            title1: "hubungi kami",
            title2: "lamar untuk menjadi dealer",
            table1: "detail hubungi",
            table2: "catat",
            table3: "waktu pengajuan",
            table4: "status",
            table5: "operasi",
            btn1: "ulang pengajun",
            btn2: "memeriksa",
            text1: "memilih cara hubungi",
            text2: "isi cara hubungi",
            text3: "catat",
            btn3: "batal",
            btn4: "memastikan",
            btn5: "batal",
            btn6: "ulang pengajuan",
            tips1: "Silakan memilih cara hubungi",
            tips2: "silakan isi informasi kontak"
        },
        dealer_review_detail: {
            title: "tinjau operasi",
            account: "akun member",
            applyTime: "waktu pengajuan",
            contactType: "cara hubungi",
            contactInfo: "kontak informasi",
            applyRemark: "pengajuan catat",
            rechargeReward: "hadiah top up pertama",
            person: "orang",
            extReward: "hadiah tambahan",
            lower_recharge_reward_setting: "konfigurasi hadiah setoran pertama tingkat rendah",
            lower_recharge_extReward_setting: "konfigurasi bonus tambahan untuk deposit pertama di level yang lebih rendah",
            rechargePerson: "jumlah isi ulang",
            myReward: "hadiah saya",
            max_reward: "hadiah maksimum yang dapat ditetapkan",
            next_reward_setting: "pengaturan hadiah tingkat rendah",
            withdraw_setting: "pengaturan penarikan",
            can_withdraw: "bisa penarikan",
            cannot_withdraw: "tidak bisa penarikan",
            edit_setting: "edit pengaturan",
            can_edit: "bisa di edit",
            cannot_edit: "tidak boleh edit",
            level_name: "nama level",
            account_remark: "komentar akun anggota",
            reject: "menolak",
            pass: "lulus",
            tips1: "silakan atur semua pengaturan hadiah tingkat rendah",
            tips2: "silakan atur konfigurasi hadiah setoran pertama untuk level yang lebih rendah",
            tips3: "silakan atur konfigurasi hadiah tambahan untuk deposit pertama di level yang lebih rendah",
            tips4: "silakan atur konfigurasi edit",
            tips5: "silakan masukkan nama tingkat",
            tips6: "silakan atur konfigurasi penarikan"
        },
        complaint: {
            title: "keluhan",
            site_complaint: "keluhan situs",
            email: "email",
            tipsTitle: "penjelasan",
            tips: "untuk memastikan pengoperasian situs secara normal, anda dapat mengajukan keluhan terhadap perilaku situs yang tidak bermoral dan platform akan menanganinya untuk anda.",
            emailError1: "email tidak boleh kosong",
            emailError2: "format email salah",
            placeholderText: "silakan masukkan konten keluhan situs"
        },
        upload: {
            uploading: "mengunggah...",
            tips1: "ukuran unggahan satu file tidak boleh melebihi",
            tips2: "total ukuran unggahan file tidak boleh melebihi",
            tips3: "ukuran unggahan file tidak boleh melebihi"
        },
        recharge_order_detail: {
            title: "isi ulang ",
            tips1: "silakan buka aplikasi pembayaran anda dan pindai atau salin dan tempel kode QR di bawah ini untuk menyelesaikan pembelian anda;",
            tips2: "kode QR ini hanya dapat dibayar satu kali. Jika anda perlu membayar lagi, silakan kembali dan isi ulang;",
            tips3: "setelah pembayaran berhasil, anda dapat kembali ke lobi permainan dan menunggu poin bertambah!",
            effectTime: "waktu yang sah",
            copyText: "salin kode QR",
            copyAddress: "alamat kode QR...",
            label1: "status pesanan",
            label2: "waktu penciptaan",
            label3: "nomor pesanan",
            label4: "nomor pesanan pedagang",
            waiting: "menunggu pembayaran",
            success: "pembayaran berhasil",
            warning: "kode QR telah kedaluwarsa",
            tips4: "silakan kembali ke lobi untuk melakukan pemesanan lagi. halaman saat ini akan ditutup dalam 10 detik.",
            tips5: "memilih",
            tips6: "tutup sekarang",
            tips7: "atau",
            tips8: "lihat pesanan",
            tips9: "berhasil diterima",
            tips10: "sistem secara otomatis memberi anda poin.",
            tips11: "halaman saat ini akan ditutup setelah 10 detik."
        },
        check_pwd_dialog: {
            title: "Enter PIN",
            text1: "Withdrawal Password",
            text2: "For your account safety, please enter the withdrawal password",
            text3: "Forgot password?",
            btnText: "Confirm",
            tips1: "6 digits"
        }
    }, me = {
        home: {
            noData: "Walang Data",
            loadMore: "Mag -load pa",
            moreTipsText1: "Ipinapakita ang",
            moreTipsText2: "ng",
            moreTipsText3: "Totoong Tao laro,",
            maintain: "Ang mga laro ay nasa ilalim ngpagpapanatili",
            all: "Lahat",
            maintainText: "Ang mga laro ay nasa ilalim ngpagpapanatili",
            limitAmountTips: "Ang iyong balanse ay hindi sapat {currency}{balance}; mabilis na mag-recharge ng kaunting pera upang patayin ang Quartet!",
            top: "Top"
        },
        footer: {
            cassino: "Casino",
            games: "Laro",
            support: "Suporta",
            none: "Pansamantalang sarado",
            funcList: {
                reward: "Upang Makolekta",
                rebate: "Rebate",
                vip: "VIP",
                agent: "Magtaguyod ng Pera",
                event: "Aktibidad",
                task: "Gawain"
            },
            gameList: {
                hot: "Tanyag",
                card: "Baraha",
                fish: "Pangingisda",
                digital: "Elektronik",
                live: "Totoong Tao",
                sports: "Sports",
                recent: "Kamakailan",
                collect: "Mangolekta"
            },
            supportList: {
                support: "Online Service",
                advise: "Award Feedback",
                faq: "Tulong Sa Sentro"
            },
            technicalSupport: "Teknikal na Suporta"
        },
        new_player: {
            title: "newUser benepisyo",
            proceed: "Magpatuloy",
            collect: "mangolekta",
            collected: "nakolekta",
            reward: "Bonus",
            tips1: "Hindi na nag -pop up ngayon",
            tips2: "Huwag kailanman mag -prompt",
            collectAll: "Kolektahin ang Lahat",
            tip3: "Hindi karapat-dapat para sa resibo",
            tip4: "Paki-bind muna ang payment account"
        },
        search_page: {
            title: "Maghanap",
            result: "Maghanap",
            popular: "Tanyag",
            recent: "Kamakailan",
            favorites: "Mangolekta",
            record: "Resulta ng Paghahanap",
            clear: "Tanggalin Lahat"
        },
        sub_game: {
            search: "Maghanap",
            all: "Lahat"
        },
        vip_item: {
            accumulated_deposits: "Mga naipon na deposito",
            current_stream: "Kasalukuyang turnover",
            relegation_deposits: "Deposito ng relegation",
            relegation_stream: "Paglipat ng relegation",
            tips1: "Kailangan mo pa rin ng",
            tips2: "na deposito para mag-upgrade",
            tips3: "turnover para mag-upgrade",
            maxLevel: "Nasa pinakamataas na antas na",
            privilege: "Pribilehiyo",
            challenge_game: "Pambihirang laro",
            go: "Tingnan mo",
            unset: "Hindi ka pa nagse-set ng birthday",
            tips: "Pahiwatig",
            confirmText: "Lumipat sa setting",
            cancelText: "Mag-chat sa susunod"
        },
        vip_lucky_wheel: {
            daily_lottery: "Araw-araw na draw",
            upgrade_vip: "I-upgrade ang VIP",
            current: "Kasalukuyan",
            lottery_draw: "Bilang ng mga draw",
            winning_record: "Record ng panalo",
            tips1: "Ang bilang ng mga draw ay natapos na",
            tips2: "Congratulations sa pagkuha",
            tips3: "halaga"
        },
        vip_birthday: {
            title: "Birthday Bonus",
            collect: "Tumanggap",
            collected: "Natanggap"
        },
        vip_reward: {
            title: "Mga gantimpala sa VIP",
            upgrade: "Upang makamit ang susunod na antas",
            recharge: "Magdeposito ng Karagdagang",
            bet: "Tumaya ng Karagdagang",
            collect_all: "Receive",
            collect_record: "Tala ng Gantimpala",
            level_list: "Paglalarawan ng Mga Panuntunan ng VIP",
            upgrade_rewards: "Bonus",
            relegation_conditions: "Mga Kondisyon sa Pagtatanggal",
            daily_rewards: "Araw-araw na suweldo",
            weekly_rewards: "Lingguhang Suweldo",
            monthly_rewards: "Buwanang Bonus",
            privilege: "Pribilehiyo ng VIP",
            rule_description: "VIP Rules Description",
            title1: "I-upgrade ang mga panuntunan sa gantimpala",
            text1: "Pagkatapos matugunan ang mga kundisyon para sa VIP promotion (natutugunan ang mga kinakailangan para sa recharge at code accumulation), ang mga miyembro ay mapo-promote sa kaukulang antas ng VIP at maaaring makatanggap ng mga bonus sa promosyon. Kung maraming pag-upgrade ang ginawa sa isang pagkakataon, ang mga miyembro ay makakatanggap ng mga bonus para sa lahat ng antas ng promosyon.",
            title2: "Mga panuntunan sa buwanang gantimpala",
            text2: "Kapag ang lingguhang recharge at halaga ng pagtaya ay umabot sa kasalukuyang antas ng VIP at ang kaukulang lingguhang mga kinakailangan sa gantimpala, ang mga miyembro ay maaaring makatanggap ng kaukulang lingguhang suweldo, na na-reset sa 00:00 tuwing Lunes.",
            title3: "Mga panuntunan sa buwanang gantimpala",
            text3: "Kapag ang buwanang recharge at pagtaya ay nakakatugon sa mga kinakailangan ng VIP ng buwang iyon, maaari kang makatanggap ng kaukulang buwanang suweldo, na ire-reset sa 00:00 sa unang araw ng bawat buwan.",
            rule_detail: `1.Pamantayan sa Promosyon: Matugunan ang mga kinakailangan ng promosyon ng VIP (iyon ay, ang recharge o epektibong pagtaya ay maaaring matugunan ang mga kondisyon), maaari kang sumulong sa kaukulang antas ng VIP at makuha ang kaukulang bonus ng promosyon.Ang bonus ay maaaring matanggap sa susunod na araw;<br/>
            2.Pang-araw-araw na suweldo: Kung ang pang-araw-araw na recharge at mga wastong taya ay nakakatugon sa pang-araw-araw na mga kinakailangan sa suweldo ng kasalukuyang antas, maaari kang makakuha ng kaukulang pang-araw-araw na bonus sa suweldo. antas.Ang pang-araw-araw na00:00:00-23:59:59 ay maaaring makolekta\uFF1B<br/>
            3.Lingguhang Salary: Kung ang lingguhang recharge at valid na mga taya ay nakakatugon sa kasalukuyang antas ng lingguhang mga kinakailangan sa suweldo, maaari kang makakuha ng kaukulang lingguhang suweldo na bonus.Available tuwing Lunes 00:00:00-23:59:59\uFF1B<br/>
            4.Buwanang Suweldo: Buwanang muling pag -recharge at epektibong taya upang matugunan ang kasalukuyang antas ng buwanang Lulu, at maaari mong makuha ang kaukulang buwanang premyo na bonus.Buwanang100:00:00-23:59:59 Maaaring makolekta\uFF1B<br/>
            5.Oras ng Pag -expire ng Gantimpala: Long -term Reservation para sa nakuha na mga bonus, kailangan mong manu -manong makatanggap;<br/>
            6.Mga Tagubilin sa Pag -audit: Ang bonus na ibinigay ng VIP ay nangangailangan ng1 dobleng daloy ng tubig (ibig sabihin, coding, o epektibong pagtaya) upang bawiin,Limitado ang coding<br/>
            Chess,Lahat ng Laro,<br/>
            Pangingisda,Lahat ng Laro,<br/>
            elektronik,Lahat ng Laro,<br/>
            Mga Laro sa Blockchain,Lahat ng Laro;<br/>
            7.Pahayag ng aktibidad: Ang function na ito ay limitado sa may-ari ng account para sa normal na pagtaya sa laro. Ipinagbabawal na magrenta ng mga account, walang panganib na pagtaya (pagsusugal, pag-swipe, pag-swipe na mababa ang bayad), malisyosong arbitrage, paggamit ng mga plug-in, mga robot, pagsasamantala sa mga kasunduan, mga butas, mga interface, Paglahok sa pamamagitan ng kontrol ng grupo o iba pang teknikal na paraan, isang beses na-verify, may karapatan ang platform na wakasan ang pag-login ng miyembro, suspindihin ang paggamit ng miyembro ng website, at kumpiskahin ang mga bonus at hindi tamang kita nang walang espesyal na abiso;<br/>
            8.Paliwanag: Kapag ang mga miyembro ay tumatanggap ng mga gantimpala ng VIP, ang platform na ito ay default na pahintulot ng mga miyembro at sumunod sa mga kaugnay na kondisyon tulad ng kaukulang mga kondisyon. Upang maiwasan ang kalabuan sa pag -unawa sa teksto, ang platform na ito ay may pangwakas na karapatan sa interpretasyon ng kaganapang ito.`,
            none_reward: "Walang available na reward para i-claim",
            current_level: "kasalukuyang lebel"
        },
        vip_reward_upgrade: {
            level: "Grado",
            reward_conditions: "Mga kondisyon ng gantimpala",
            operate: "Nagpapatakbo",
            recharge: "Mag-recharge",
            bet: "Maglagay ng taya",
            collected: "Natanggap",
            collect: "Tumanggap",
            bonus: "Bonus",
            text1: "Araw-araw na wastong taya",
            text2: "Lingguhang wastong taya",
            text3: "Mga buwanang wastong taya",
            text4: "Araw-araw na deposito",
            text5: "Lingguhang deposito",
            text6: "Buwanang deposito",
            text7: "Mag-Upgrade At Mag-Recharge",
            text8: "Taya para sa promosyon",
            text9: "Pang-araw-araw na limitasyon sa kabuuang pag-withdraw",
            text10: "Pang-araw-araw na limitasyon sa bilang ng pag-withdraw",
            text11: "Bilang ng mga transaksyong walang bayad bawat araw",
            tips_title: "Mga tip",
            tips_content_recharge: "Para mag-promote sa susunod na level, kailangan mong magdeposito ng karagdagang halaga batay sa accumulative deposit. Halimbawa: para mag-upgrade mula sa VIP1 na may recharge requirement na 1000 hanggang VIP2 na may requirement na 2000, ang miyembro ay kailangang makaipon ng 1000 + 2000 = 3000 para mag-upgrade sa VIP2, at iba pa.",
            tips_content_bet: "Upang mag-promote sa susunod na antas, kailangan mong tumaya ng karagdagang halaga batay sa accumulative bet. Halimbawa: upang mag-upgrade mula sa VIP1 na may kinakailangang taya na 1000 hanggang VIP2 na may kinakailangan na 2000, ang miyembro ay kailangang makaipon ng 1000 + 2000 = 3000 upang mag-upgrade sa VIP2, at iba pa.",
            unlimited: "Walang limitasyon",
            text12: "Deposito noong nakaraang buwan",
            text13: "Tumaya noong nakaraang buwan"
        },
        mine: {
            upgrade: "Level UP",
            recharge: "Mag-recharge ulit",
            bet: "Taya na naman",
            need_recharge: "Mag-upgrade at mag-recharge",
            need_bet: "Avanza e Codifica di Nuovo",
            account_detail: "Statement",
            bet_record: "Record ng Pagtaya",
            personal_report: "Personal na Ulat",
            service_setting: "Pamamahala ng Withdrawal",
            invite: "Magtaguyod ng Pera",
            account: "Account",
            help_center: "Karaniwang Problema",
            music: "Musika",
            advise: "Award Feedback",
            about_us: "Tungkol sa",
            address_manage: "Pangangasiwa ng address",
            security_center: "Sentro ng Seguridad",
            language: "Pumili ng Isang Wika",
            exit: "Ligtas na Umatras",
            tips1: "Umatras ka ba mula sa kasalukuyang account?",
            tips: "Paalala",
            id: "ID",
            tab_account: "Personal na Impormasyon",
            message: "Impormasyon",
            wallet: "Main Wallet",
            exchange: "Withdraw",
            deposit: "Deposit",
            income: "interes",
            login_pwd: "Mag-login ng Password",
            exchange_pwd: "Withdraw Password",
            million_monthly: "milyon buwan-buwa",
            support: "Suporta",
            search_balance: "Kunin ang balanse",
            request_label: "Distansya",
            request_recharge: "Mahina Recharge"
        },
        advise: {
            message_title: "Sentro ng Mensahe",
            welcome_title: "Available ang propesyonal na serbisyo sa customer para sa online na pag-uusap, handang tumulong sa iyo sa anumang mga isyung nararanasan mo.",
            welcome_text: "24/7 na Serbisyo sa Customer",
            customer: "servi\xE7o on-line",
            title: "Award Feedback",
            faq: "FAQ (madalas itanong)",
            read: "Nabasa na",
            unread: "Hindi pa nababasa",
            advise_reward: "Lumikha",
            my_record: "akin",
            content_title: "Nilalaman ng Feedback",
            content_tips: "(Binabanggit mo akong magbago)",
            entry: "Anuman sa iyong mga opinyon ay napakahalaga sa amin, lahat ng mahahalagang opinyon ay tatanggapin, at kapag na-adopt, iba't ibang mga gantimpala sa pera ang ibibigay depende sa kahalagahan, maaari kang malayang magsalita!",
            annex: "May Larawan at Katotohanan",
            annex_tips: "(Mas madaling gamitin)",
            upload_tips: "Suportahan ang mga larawan at pag -upload ng video, ang laki ay hindi dapat lumampas sa 40MB",
            advise_title: "Mga Panuntunan sa Gantimpala",
            advise_tips: "Nag -set up kami ng malaking bonus upang mangolekta ng puna mula sa feedback upang ma -optimize namin ang system at mga pag -andar at magdala sa iyo ng isang mas mahusay na karanasan! Kapag pinagtibay, ibibigay ang mga gantimpala alinsunod sa mahalagang antas (maliban sa hindi pag -ampon)",
            submit: "Isumite ang Feedback",
            replied: "Sumagot",
            feedback: "Nilalaman ng feedback",
            reply: "Tumugon sa nilalaman",
            submit_tips: "Ang nilalaman ng pagsusumite ay dapat na mas mahaba sa 10 salita",
            bonus: "Bonus",
            contact: "Makipag-ugnayan na"
        },
        mine_info: {
            title: "Personal na Impormasyon",
            avatar: "I -set up",
            useName: "Username",
            realName: "Tunay na pangalan",
            name_tips: "Pakilagay ang iyong aktwal na pangalan",
            sex: "Kasarian",
            man: "Lalaki",
            woman: "Babae",
            birthday: "Kaarawan (hindi mababago pagkatapos ng pagtatakda)",
            phone: "Numero ng telepono",
            email: "E-mail",
            receive_address: "Address ng pagpapadala",
            no_address: "Kasalukuyang walang default na address sa pagpapadala",
            save: "I-save",
            choose_date: "Pumili ng petsa",
            email_error_tips: "Mali ang format ng e-mail",
            cancel: "Kanselahin",
            confirm: "Kumpirmahin",
            bindPhone: "Magbigkis ng telepono",
            tips1: "Hindi maaaring walang laman ang Facebook",
            tips2: "Hindi maaaring walang laman ang Telegram",
            tips3: "Hindi maaaring walang laman ang Whatsapp",
            tips4: "Gusto mo ba talagang bumalik?",
            tips5: "Hindi pa nase-save ang mga kasalukuyang pagbabago. Kung babalik ka, hindi magkakabisa ang mga pagbabago",
            copySuccess: "matagumpay na kopyahin"
        },
        agent: {
            not_have: "wala",
            extension_course: "Tutorial ng Promosyon",
            change: "Baguhin",
            claimable: "Magagamit",
            direct_subordinate: "Direkta sa ilalim ng mga subordinates",
            my_superiors: "Ang Aking Auperyor",
            unlimited_level_difference: "Walang -hanggan na pagkakaiba sa antas (Araw na buhol)",
            agency_mode: "Proxy mode",
            share: "Ibahagi",
            agent: "Magtaguyod ng Pera",
            my_promotion: "Promotion Sharing",
            my_data: "My Data",
            tutorial: "Network ng Ahente",
            tab_commission: "Ang Komisyon Ko",
            my_performance: "Pagganap",
            my_member: "Aking Mga Nagawa",
            commission_rate: "Ratio Ng Rebate",
            all_types: "Lahat ng uri",
            all_data: "Lahat ng data",
            finance: "Subordinates' Finance",
            wagers: "Subordinate's Wagers",
            stats: "Subordinate's Stats",
            claims: "Subordinates' Claims",
            account: "Account",
            superior: "Superior ID",
            can_receive: "Nakokolekta",
            receive: "Tumanggap",
            save: "I-click ang Save",
            my_link: "Ang Link Ko",
            commission: "Komisyon",
            detail: "Mga Detalye",
            total_commission: "Kabuuang komisyon",
            received: "Nakolektang Komisyon",
            unclaimed: "Huling Komisyon",
            member: "Pagganap",
            total_members: "Kabuuan",
            direct_members: "Direktang Subordinates",
            other_members: "Iba",
            total_income: "Kabuuang Pagganap",
            direct_income: "Pagganap ng subordinates",
            other_income: "Pagganap ng iba",
            bet: "Mga Pusta ng Subordinate",
            total_effective_bet: "Kabuuang wastong taya",
            total_bet_number: "Kabuuang bilang ng taya",
            total_profit_loss: "Kabuuang Panalo/Talo",
            more: "Higit pa",
            to: "sa",
            start_date: "Oras ng pagsisimula",
            end_date: "Oras ng Pagtatapos",
            all: "Lahat",
            time: "Oras",
            type: "Uri",
            bet_amount: "Ang halaga ng taya",
            bet_number: "Bilang ng mga bettors",
            join_time: "Oras ng pagsali",
            personnel: "miyembro",
            number: "Valid players",
            effective_bet_unit: "Tagumpay",
            unit: "(Unit: 10,000)",
            per_commission: "Halaga ng rebate ng komisyon bawat 10,000",
            collect_record: "Tala ng Gantimpala",
            search: "Magtanong",
            noData: "Walang Data",
            collected_commission: "Nakolektang Komisyon",
            collected_time: "Oras ng koleksyon",
            amount: "Halaga",
            myId: "ID ko",
            share_title1: "",
            share_title2: "Link na pang-promosyon",
            net_profit: "netong kita",
            total_net_profit: "Kabuuang netong kita",
            total_discount: "Kabuuang diskwento",
            valid_people: "Epektibong numero",
            valid_text1: "Wastong deposito\u2265",
            valid_text2: ", na siyang wastong bilang ng mga tao",
            deposit_amount: "Halaga ng deposito",
            agent_tier: "Antas Ng Ahente",
            promotion_conditions: "Mga Kondisyon ng Promosyon (na -promote na maitaguyod upang muling makuha ang mga komisyon)",
            commission_detail_title: "Mga detalye ng komisyon",
            commission_detail_endTime: "Settlement date",
            commission_detail_placeholder: "Petsa ng settlement",
            commission_detail_table1: "Ipasok ang ID ng miyembro",
            commission_detail_table2: "Superior",
            commission_detail_table3: "Data ng pagtaya",
            commission_detail_table4: "Komisyon",
            commission_detail_label1: "Direktang komisyon",
            commission_detail_label2: "Iba pang data",
            commission_detail_label3: "Kabuuang data",
            commission_detail_label4: "Direktang Komisyon",
            commission_detail_label5: "Iba pang komisyon",
            commission_detail_label6: "Kabuuang Komisyon",
            my_performance_label1: "Bilang ng mga tao sa ilalim ng direktang pangangasiwa",
            my_performance_label2: "Direktang halaga ng pagtaya",
            my_performance_label3: "Direktang komisyon",
            my_performance_label4: "ibang tao",
            my_performance_label5: "Iba pang halaga ng pagtaya",
            my_performance_label6: "Iba pang mga komisyon",
            all_data_table1: "Oras ng pagsali",
            all_data_table2: "ID ng Miyembro",
            all_data_table3: "Deposit",
            all_data_table4: "Mabisang Pusta",
            all_data_table5: "Kabuuang Panalo/Talo",
            all_data_label1: "Direktang deposito",
            all_data_label2: "Direktang dami ng unang deposito",
            all_data_label3: "Iba pang deposito",
            all_data_label4: "Iba pang dami ng unang deposito",
            all_data_label5: "Kabuuang recharge",
            all_data_label6: "Kabuuang bilang ng mga first-time na depositors",
            direct_finance_table1: "Ang kanyang mga nasasakupan",
            direct_finance_table2: "Deposito",
            direct_finance_table3: "Mag-withdraw",
            direct_finance_table4: "Pagkakaiba",
            direct_finance_table5: "Balanse",
            direct_finance_table6: "(mga) oras",
            direct_finance_label1: "Kabuuang Deposito",
            direct_finance_label2: "Bilang ng mga deposito",
            direct_finance_label3: "Unang Deposito",
            direct_finance_label4: "Bilang ng mga manlalaro sa unang deposito",
            direct_finance_label5: "Kabuuang withdrawal",
            direct_finance_label6: "Mga oras ng pag-withdraw",
            direct_bet_detail: "Pagtataksil",
            direct_bet_table1: "Ang kanyang mga subordinates",
            direct_bet_table2: "Mabisang Pusta",
            direct_bet_table3: "Kabuuang Panalo/Talo",
            direct_bet_table4: "Platform ng laro",
            direct_bet_label1: "Direktang wastong pagtaya",
            direct_bet_label2: "Iba pang mabisang taya",
            direct_bet_label3: "Kabuuang mabisang pagtaya",
            direct_bet_label4: "Direktang panalo/talo",
            direct_bet_label5: "Iba pang mga panalo/pagkatalo",
            direct_bet_label6: "Kabuuang Panalo/Talo",
            direct_bet_detail1: "Platform ng gaming",
            direct_bet_detail2: "Pangalan ng Laro",
            direct_bet_detail3: "Mabisang Pusta",
            direct_bet_detail4: "Panalo/Talo",
            direct_bet_detail5: "Kabuuang mabisang pagtaya",
            direct_bet_detail6: "Kabuuang order ng tala",
            direct_bet_detail7: "Kabuuang Panalo o Talo",
            direct_data_date: "Petsa",
            direct_data_table1: "Ang kanyang mga subordinates",
            direct_data_table2: "Deposit amount",
            direct_data_table3: "Magrehistro",
            direct_data_table4: "Mabisang Pusta",
            direct_data_table5: "Petsa ng pag-login",
            direct_data_table6: "Kasalukuyan",
            direct_data_table7: "Estado",
            direct_data_text1: "Oo",
            direct_data_text2: "Hindi",
            direct_data_text3: "Hindi pinapayagang tumanggap ng mga premyo",
            direct_data_text4: "I-freeze",
            direct_data_text5: "Normal",
            direct_data_text6: "Online",
            direct_data_text7: "Offline",
            direct_data_sum1: "Bilang ng mga rehistro",
            direct_data_sum2: "Kabuuang bilang ng mga recharge",
            direct_data_sum3: "Bilang ng mga unang singil",
            direct_data_sum4: "Deposit amount",
            direct_data_sum5: "Mabisang Pusta",
            direct_award_table1: "Kabuuang koleksyon",
            direct_award_table2: "Koleksyon ng Kaganapan",
            direct_award_table3: "Koleksyon ng Misyon",
            direct_award_table4: "Pagkolekta ng rebate",
            direct_award_table5: "Koleksyon ng VIP",
            direct_award_table6: "Komisyon ng Ahente",
            direct_award_table7: "Yu'ebao Interes",
            my_data_text1: "Bagong direktang -membership",
            my_data_text2: "Bilang ng mga unang singil",
            my_data_text3: "Bilang ng recharge",
            my_data_text4: "Deposit amount",
            my_data_text5: "Tagumpay",
            my_data_text6: "Komisyon",
            my_data_text7: "Pangkalahatang -ideya ng data",
            my_data_text8: "Ang aking koponan",
            my_data_text9: "Laki ng koponan",
            my_data_text10: "Direkta",
            my_data_text11: "Bilang ng iba",
            my_data_text12: "Aking Mga Nagawa",
            my_data_text13: "Pangkalahatang pagganap",
            my_data_text14: "Direktang pagganap",
            my_data_text15: "Iba pang pagganap",
            my_data_text16: "Ang Komisyon Ko",
            my_data_text17: "Kabuuang Komisyon",
            my_data_text18: "Direktang Komisyon",
            my_data_text19: "Iba pang komisyon",
            my_data_date1: "Kahapon",
            my_data_date2: "Ngayon",
            my_data_date3: "Ngayong linggo",
            my_data_date4: "Nakaraang linggo",
            my_data_date5: "Sa Buwang Ito",
            my_data_date6: "Noong nakaraang Buwan",
            performanceDetail: {
                performance: "Pagganap",
                winLose: "Ang tubo at pagkalugi ng miyembro",
                discount: "Mag-claim ng diskwento"
            },
            commissionDetail: {
                member: "Mga kontribyutor",
                performance: "Pagganap",
                commission: "Komisyon",
                gameType: "Uri ng laro"
            }
        },
        wallet: {
            all: "Lahat",
            wallet: "Kunin ang balanse",
            center_wallet: "gitnang wallet",
            one_click_recycling: "Ibalik",
            venue_wallet: "Game Venue Wallet",
            balance: "Kasalukuyang balanse",
            placeholder: "Paghahanap sa Platform",
            tips: "Makakakuha ka lang ng integer multiple ng natitira (ibig sabihin, walang decimal point"
        },
        exchange: {
            exchange: "Mag-apply para sa withdrawal",
            exchange_record: "Talaan ng mga withdrawal",
            audit_record: "Ulat sa Pag-audit",
            account_manage: "Mga account receivable",
            account_balance: "Balansehin",
            withdrawable_balance: "Ang balanseng magagamit para sa withdrawal",
            need_bet: "Kailangan pa ring tumaya",
            can_withdraw: "Maaalis",
            auditing: "Sinusuri",
            detailInfo: "Mga Detalye",
            standard_withdrawal: "Karaniwang Pag-withdraw",
            tips1: "Mangyaring ipasok ang halaga ng palitan",
            tips2: "Mangyaring pumili muna ng withdrawal account",
            all: "Lahat",
            exchange_pwd: "I-verify Ang Withdrawal Password",
            confirm: "Kumpirmahin ang pag-withdraw",
            add_account: "Magdagdag ng withdrawal account",
            tips3: "Hindi maaaring walang laman ang Withdrawal Password",
            tips4: "maling password",
            accumulate_exchange: "Cululative Withdrawal",
            order_no: "Numero ng Order",
            success: "Magtagumpay",
            fail: "Kabiguan",
            checking: "Sa pagsusuri",
            today: "Ngayong araw",
            yesterday: "Kahapon",
            seven_days: "7 araw",
            fifteen_days: "15 araw",
            thirty_days: "30 araw",
            total_waiting_audit: "Cululative Withdrawal",
            audit_detail: "Mga detalye ng pag-audit",
            transaction_type: "Uri ng Transaksyon",
            audit_progress: "Uri ng Transaksyon",
            amount: "Halaga ng transaksyon",
            audit_multiplier: "I-audit ang marami",
            to_be_audit: "Naghihintay ng audit",
            audited: "Na-audit",
            create_time: "Nilikha ng oras",
            exchange_account: "Mga account receivable",
            digital_currency: "Digital na pera",
            add: "Idagdag Sa",
            tips5: "Mangyaring ipasok ang 11 -digit na numero ng CPF",
            tips6: "Mangyaring ipasok ang 11-digit na numero",
            tips7: "Pakilagay ang 11-digit na CPF number",
            tips8: "Hindi maaaring blangko ang PIX account",
            tips9: "Hindi maaaring walang laman",
            add_digital_currency: "Magdagdag ng digital na pera",
            tips10: "Pakilagay ang iyong cryptocurrency address",
            tips11: "Hindi maaaring blangko ang field ng address",
            tips12: "Siguraduhing magkatugma ang currency, protocol at address, kung hindi, hindi ma-credit ang halaga.",
            tips13: "Hindi maaaring walang laman ang address",
            tips14: "Sinusuportahan lamang ang pagdaragdag ng isang CPF account sa karamihan",
            tips15: "Hindi maaaring walang laman ang pangalan",
            tips16: "Mangyaring i -type ang iyong pangalan",
            deleteTips: "Kumpirmahin na tanggalin ang kasalukuyang account",
            tips17: "Ang bilang ng mga account na idinagdag ay umabot sa pinakamataas na limitasyon",
            tips18: "Mangyaring maingat na suriin ang pangalan at numero ng card, kung hindi, hindi ito ma-credit",
            tips19: "Only 1 PIX account of PIX-CPF type can be added",
            tips20: "Mangyaring suriing mabuti, kung hindi, hindi ito ma-kredito.",
            tips21: "Pakilagay ang labing-isang numero ng telepono, simula sa 0",
            tips22: "Tandaan: Pakitiyak na ang pangalan ng withdrawal at impormasyon sa withdrawal ay pare-pareho upang maiwasan ang pagkabigo sa withdrawal.",
            sendTo: "Inisyu sa",
            addWalletBtn: "Kumpirmahin",
            detail: {
                title: "Mga detalye ng withdrawal",
                type: "Uri ng Transaksyon",
                withdraw: "Mag-withdraw",
                methods: "Paraan ng pag-withdraw",
                fee: "Bayad sa paghawak",
                createTime: "Oras ng paglikha",
                orderNo: "Numero ng order",
                remark: "Puna"
            }
        },
        recharge: {
            recharge: "Deposit",
            recharge_online: "Mag-recharge Online",
            digital_currency: "Pagbabayad sa online banking",
            recharge_record: "Record ng Recharge",
            recharge_amount: "Deposit amount",
            recharge_tips: "Bonus na paliwanag ng kaganapan",
            recharge_tipsText: "Magdeposito ayon sa inirekumendang halaga para makatanggap ng kaukulang bonus. Ang halaga ng bonus ay nakasalansan sa deposit bonus.",
            currency: "BRL",
            terms: "Bonus na paliwanag ng kaganapan",
            recharge_now: "Agad na Muling Magkarga",
            USDT_rate: "rate ng USDT",
            tips1: "Mangyaring punan nang tama ang wallet address ng nagbabayad upang matanggap nang normal ang pera.",
            tips2: "Ilagay ang wallet address ng nagbabayad",
            tips3: "Pakilagay ang halaga",
            tips4: "Mangyaring ipasok ang address",
            tips5: "Mangyaring punan ang TxId ng transaksyon",
            tips6: "Nag-expire na ang order, mangyaring muling isumite ang order",
            submit: "Isumite",
            total_deposit: "Kabuuang Deposito",
            recharge_detail: "Mga Detalye ng Recharge",
            trade_type: "Uri ng Transaksyon",
            recharge_type: "Paraan ng Recharge",
            recharge_channel: "Recharge Channel",
            create_time: "Oras ng Paglikha",
            order_no: "Numero ng Order",
            free: "Libre",
            min: "Minimum",
            max: "ang pinakamataas na",
            exchangeRate: "halaga ng palitan",
            addPoint: "Magdagdag ng punto",
            jump_tips: "I-click ang Kumpirmahin upang tumalon sa pahina ng pagbabayad",
            recharge_exchange_rate_tipsText: "I-click upang ilipat ang exchange currency"
        },
        account: {
            account_detail: "Statement",
            bet_record: "Record ng Pagtaya",
            personal_report: "Personal na Ulat",
            all: "Lahat",
            time: "Oras",
            transaction_type: "Uri ng Transaksyon",
            detail: "detalyadong impormasyon",
            quantity: "dami",
            total_deposits: "Kabuuang Deposito",
            accumulated_withdrawals: "Pinagsama-samang koleksyon",
            type: "uri",
            platform: "plataporma",
            game: "Mga laro",
            effective_betting: "Wastong taya",
            profit_loss: "tubo at lugi",
            bet_number: "Bilang ng taya",
            bet_total: "Kabuuang taya",
            total_win_loss: "Pangkalahatang panalo/talo"
        },
        login: {
            password_login: "Password login",
            msg_login: "SMS login",
            tips1: "Maglagay ng 6 hanggang 16 na character, sinusuportahan ang mga titik/numero/simbolo",
            remember_password: "Tandaan Mo Ako",
            forget_password: "Nakalimutan ang password",
            login: "Login",
            register: "Magrehistro ng account",
            other_login_methods: "Iba pang mga paraan ng pag-login",
            tips2: "Ang haba ng user ay mas mababa sa 4 na digit",
            tips3: "Mali ang format ng password",
            telephone: "numero ng telepono",
            enter_password: "Password",
            again_enter_password: "Pakikumpirma muli ang password, katulad ng password!",
            strength: "Lakas ng Password",
            register2: "Register",
            register3: "Register",
            tips4: "Maglagay ng 4 hanggang 16 na character, ang mga titik/numero ay sinusuportahan, at ang unang character ay dapat na isang titik",
            tips5: "Mali ang inilagay na mobile number",
            tips6: "Mali ang inilagay na verification code",
            text1: "Ako ay higit sa 18 at sumasang-ayon sa",
            agreement: "\u300AKasunduan ng Gumagamit\u300B",
            login_now: "Mag-login Ngayon",
            general_registration: "Normal na pagpaparehistro",
            mobile_registration: "Magrehistro sa pamamagitan ng mobile phone",
            tips7: "Dalawang password ay hindi pare-pareho",
            tips8: "Pakisuri muna ang kahon ng Kasunduan sa Gumagamit",
            tips9: "Mali ang format ng password",
            tips10: "Ang password na ipinasok ng dalawang beses ay hindi pare-pareho",
            tips11: "mali ang numero ng telepono",
            tips12: "Mali ang verification code",
            reset_password: "Baguhin ang Password sa Pag-login",
            reset_exchangePwd: "Baguhin ang Password ng Pag-alis",
            confirm: "Kumpirmahin",
            username: "Account ng miyembro",
            send_code: "ipadala",
            code: "Captcha",
            tips13: "Mangyaring Maglagay ng 6 na digit",
            rewardTips: "Bonus sa pagpaparehistro",
            agreement_btn: "nabasa ko",
            successText: "Lumipas ang pag-verify",
            failText: "Nabigo ang pag-verify, pakisubukang muli",
            sliderText: "I-drag ang slider upang makumpleto ang puzzle",
            login_pwd: "Password sa pag-login",
            verify_login_pwd: "I-verify ang Login Password",
            customer_service: "Serbisyo sa Customer"
        },
        side_bar: {
            bet_record: "Record ng Pagtaya",
            agency: "Magtaguyod ng Pera",
            event_title: "Sentro ng Alok",
            event: "Aktibidad",
            task: "Gawain",
            rebate: "Rebate",
            reward: "Upang Makolekta",
            history: "Tala ng Gantimpala",
            fees: "Interes",
            dealer: "Dealer",
            vip: "VIP",
            pending: "Upang Makolekta",
            agent: "Ahente",
            network: "Network",
            download: "I-download ang App",
            customer_service: "Support",
            faq: "Karaniwang Problema",
            about_us: "Tungkol sa",
            closed: "Hindi pa available",
            exchange: "Withdraw",
            account_manage: "Pamamahala ng Withdrawal"
        },
        header_menu: {
            recharge: "Deposito",
            withdraw: "Mag-withdraw",
            login: "Mag Log In",
            or: " o ",
            register: "Magrehistro",
            tips: "Sa laro"
        },
        common: {
            confirm: "Kumpirmahin",
            cancel: "Kanselahin",
            no_remind: "Wala nang mga paalala ngayon",
            pls: "Pakiusap",
            add_to: "Idagdag sa",
            home_screen: "sa home screen",
            no_data: "Walang mga Tala",
            tips: "Mga tip",
            day: "araw",
            hour: "oras",
            minutes: "minuto",
            second: "pangalawa",
            recharge: "Deposito",
            exit: "Log out",
            refresh: "I-refresh",
            full_screen: "Buong Screen"
        },
        promotion_event: {
            mixed: "Lahat",
            collect_all: "I-claim Lahat",
            collect_record: "Tala ng Gantimpala",
            coming: "Mangyaring manatiling nakatutok",
            end: "natapos",
            collect: "Tumanggap",
            collected: "Buwanang Bonus",
            incomplete: "bawiin",
            continuous_login: "Mag -sign in ",
            day: "Diyos",
            days: "Diyos",
            deposit_required: "Kailangang Mag-recharge ",
            bet: "pagtaya",
            di: "Araw",
            mysterious_bonus: "Misteryo Bonus",
            total_collect: "Natanggap sa kabuuan",
            loss: "Pagkatalo kahapon",
            relief: "Pagkatalo kahapon",
            loss_amount: "Dami ng pagkalugi",
            additional_rewards: "Mga Karagdagang Gantimpala",
            back: "Bumalik",
            link: "Eksklusibong link",
            quick_share: "Mabilis na ibahagi",
            effective_people: "Epektibong mas mababang antas ng mga tao",
            request_qty: "Kinakailangang dami",
            activity_conditions: "Mga kondisyon ng aktibidad",
            effective_qty: "Epektibong numero ng promosyon",
            effective_bind_phone: "Epektibong i-promote ang bilang ng mga taong nakatali sa mga mobile phone",
            effective_recharge: "Epektibong halaga ng recharge ng promoter",
            effective_bet: "Epektibong halaga ng code ng promoter",
            people: "mga tao",
            detail: "Detalye",
            promotion_tips_title: "Ano ang bilang ng mga manlalaro na epektibong na-promote? (Tuparin ang lahat ng mga kundisyon na nakasaad sa ibaba)",
            subordinate_recharge: "Ang nasasakupan ay may naipon na deposito",
            subordinate_bet: "Nakaipon ng taya ang nasasakupan",
            maximum: "Pinakamataas",
            aforementioned: "O ang nabanggit",
            more: "Higit pa",
            apply: "Mag-apply para sa diskwento",
            apply_now: "Mag-apply ngayon",
            apply_placeholder: "Pakilagay ang sagot",
            apply_tips: "Mangyaring punan ang lahat ng mga sagot",
            my_referrals: "Aking Mga Referral",
            account: "Account",
            accumulated_recharge: "Naipon na recharge",
            accumulated_bets: "Mga naipon na taya",
            status: "Katayuan",
            efficient: "Mahusay",
            invalid: "Di-wasto",
            balance_time: "Bilang ng mga application na natitira",
            tips: "Mga tip",
            tips1: "1.Pagkatapos na kailanganin ng mga na-promote na itali ang kanilang mga mobile phone, ang bilang ng mga taong mapo-promote ang magiging epektibong numero;",
            tips2: "2.Matapos maabot ng kasalukuyang pag-unlad ang bilang ng mga taong na-promote, maaari mong matanggap ang na-withdraw na balanseng CPF nang sabay-sabay\uFF1B",
            rewardAmount: "Halaga ng reward",
            currentProcess: "Kasalukuyang pag-unlad",
            bindPhone: "Magbigkis ng mobile phone",
            receive_success: "Matagumpay na natanggap",
            valid_people: "Mga wastong tao",
            registerTime: "Oras ng pagpaparehistro",
            recharge: "Mag-recharge",
            bet: "Nangangailangan ng pagtaya ",
            request_recharge: "Recharge na halaga",
            tips3: "Mag-recharge ng {amount} ngayon para makuha ang pinakamataas na halaga ng claim sa susunod na tier.",
            tips4: "Epektibong promosyon: Ang mga nasasakupan ay kailangang mag-recharge ng {amount}, maglagay ng taya {bet}, at mag-bind ng mobile phone",
            tips5: "Epektibong promosyon: Kailangang mag-recharge ng {amount} ang mga nasasakupan, tumaya nang {bet}.",
            break_through_text1: "Ang laro ngayon",
            break_through_text2: "Bilang ng mga antas",
            break_through_text3: "Bilang ng mga taong inimbitahan",
            break_through_text4: "Halaga ng reward sa imbitasyon",
            break_through_text5: "Kabuuang coding para sa paglabag sa mga antas",
            break_through_text6: "Dagdag na bonus para sa pagpasa sa mga antas",
            break_through_text7: "Bilang ng mga antas na na-clear ngayon",
            break_through_text8: "Halaga ng reward para sa bilang ng mga inimbitahan ngayon",
            break_through_text9: "Kabuuang coding para sa pass ngayong araw",
            break_through_text10: "Level reward ngayon",
            break_through_text11: "Nakatanggap ng mga gantimpala",
            break_through_text12: "Mga reward na dapat i-claim",
            break_through_text13: "Parehong IP",
            balance_relief_fund_text1: "Mga miyembro na nag-recharge",
            balance_relief_fund_text2: "Ang balanse ng account ay mas mababa sa",
            balance_relief_fund_text3: "Ang proporsyon ng halaga ng reward recharge",
            balance_relief_fund_text4: "Ang balanse ng account ay mas mababa sa",
            balance_relief_fund_text5: "Ang halaga ng coding ay umaabot",
            balance_relief_fund_text6: "Proporsyon ng halaga ng reward coding",
            balance_relief_fund_text7: "Pamamahagi ng gantimpala",
            balance_relief_fund_text8: "Ang system ay awtomatikong maglalabas ng mga reward kapag naabot.",
            balance_relief_fund_text9: "Mga miyembrong hindi pa nakapag-recharge",
            balance_relief_fund_text10: "Halaga ng reward",
            balance_relief_fund_text11: "Pagkalkula ng mga reward para sa mga recharged na miyembro: kabuuang halaga ng recharge x set ratio o nakapirming halaga ng reward",
            balance_relief_fund_text12: "Halimbawa: Nag-recharge si Member A ng 1000 at ang ratio ng pamamahagi ng reward ay 5%, pagkatapos ay makukuha niya ang reward: 1000x5%=50",
            balance_relief_fund_text13: "Pagkalkula ng mga reward para sa mga hindi na-recharge na miyembro: kabuuang halaga ng coding x set ratio o nakapirming halaga ng reward",
            balance_relief_fund_text14: "Halimbawa: Ang Member B ay hindi nag-recharge, nag-code ng 500, at ang reward distribution ratio ay 1.5%, pagkatapos ay makukuha niya ang reward: 500x1.5%=7.5",
            balance_relief_fund_text15: "Ang dami ng beses na nakakatanggap ng mga premyo",
            balance_relief_fund_text16: "Pagkatapos ma-claim ng recharged member ang premyo, kung ang miyembro ay nabangkarote sa pangalawang pagkakataon, kailangan niyang mag-top up ulit para ma-claim ang premyo.",
            balance_relief_fund_text17: "Matapos ma-claim ng isang miyembro na hindi pa nakapag-recharge ang premyo, siya na nabangkarote sa pangalawang pagkakataon ay kailangang muling maipon ang halaga ng code bago niya ma-claim ang premyo.",
            balance_relief_fund_text18: "Halaga ng reward"
        },
        promotion_task: {
            current_PA: "Kasalukuyang PA",
            reset_PA: "Oras ng pag-reset ng PA",
            collect_all: "I-claim Lahat",
            collect_record: "Tala ng Gantimpala",
            next: "Pumunta sa",
            collect: "Tumanggap",
            collected: "Natanggap",
            bonus: "Bonus",
            rule_title1: "I.Oras ng misyon:",
            rule_title2: "II.Kondisyon ng gawain:",
            rule_title3: "III.Nilalaman ng gawain:",
            news_title: "Bonus ng bagong manlalaro",
            news_rule_text1: "Limitadong time mission (valid sa loob",
            news_rule_text2: "araw pagkatapos ng pagpaparehistro)",
            news_rule_text3: "Kumpletuhin ang mga setting na nauugnay sa account at seguridad na umiiral",
            news_rule_text4: "1.Ang bawat bagong rehistradong account ay maaaring kumpletuhin ang mga gawain sa itaas. Pagkatapos makumpleto ang mga gawain, isang tiyak na halaga ng mga bonus ang maaaring makuha. Kung mas mataas ang kahirapan, mas maraming mga gantimpala;",
            news_rule_text5: "2.Dahil ang bawat account ay ganap na hindi nagpapakilala, kapag ito ay ninakaw, ang resultang pagkawala ng mga pondo ay hindi na mababawi, kaya't kailangan namin ng may-bisang dalawang-hakbang na pag-verify, lalo na ang pagdaragdag ng address sa pag-withdraw, na napatunayang pinapatakbo ko upang matiyak iyong kaligtasan;",
            news_rule_text6: "3.Maaari mo itong matanggap nang direkta kung matutugunan mo ang mga kundisyon, at maaari mo itong matanggap nang direkta sa anumang dulo ng Android,PC,H5,iOS, at ito ay magiging hindi wasto pagkatapos ng petsa ng pag-expire (iyon ay, kung hindi mo gagawin ang inisyatiba upang matanggap ito, ito ay ituring bilang boluntaryong pagtalikod);",
            news_rule_text7: "4.Dahil ang mga gantimpala na ibinigay ng gawaing ito ay medyo mataas, ang mga bonus na ipinakita ay kailangang",
            news_rule_text8: "beses na turnover (iyon ay, pag-audit, coding o wastong pagtaya) upang mag-withdraw ng pera, at ang coding ay hindi limitado sa platform ng laro;",
            news_rule_text9: "5.Limitado ang gawaing ito sa normal na pagpapatakbo account mismo, at ipinagbabawal na magrenta, gumamit ng mga plug-in, robot, tumaya laban sa iba't ibang account, mutual swiping, arbitrage, interface, protocol, exploit loopholes, group control o iba pang teknikal. ibig sabihin ay lumahok, kung hindi, ito ay kakanselahin o ibabawas sa Gantimpala, pag-freeze, o kahit blacklist;",
            news_rule_text10: "6.Upang maiwasan ang mga pagkakaiba sa pag-unawa sa teksto, inilalaan ng platform ang karapatan ng panghuling interpretasyon ng kaganapang ito.",
            daily_title: "Araw-araw na Misyon",
            weekly_title: "Lingguhang Misyon",
            daily_text1: "Mga pangmatagalang gawain (i-reset araw-araw sa 00:00)",
            daily_text2: "Araw-araw na pagkumpleto ng mga deposito, taya, o pag-audit",
            daily_text3: "1. Ang mga sumusunod na gawain ay maaaring gawin araw-araw, kabilang ang pang-araw-araw na pag-recharge, pagtaya sa solong laro o iba pang pagtaya. Pagkatapos makumpleto ang gawain, maaari kang makakuha ng isang tiyak na halaga ng mga gantimpala. Kung mas malaki ang kahirapan, mas malaki ang gantimpala;",
            daily_text4: "2. Kung natutugunan mo ang mga kundisyon, maaari kang direktang mag-withdraw ng pera. Maaaring mabanggit ang iba't ibang halaga sa isang lump sum. Inirerekomenda na i-download ang high-definition na bersyon ng app para sa mas kasiya-siyang karanasan.",
            daily_text5: "3.Ang iOS, Android, H5, at PC ay maaaring direktang kolektahin at magiging invalid kapag nag-expire (iyon ay, ang hindi aktibong pagkolekta ng mga ito ay ituturing na pagsuko);",
            daily_text6: "4.Ang bonus na nakuha mula sa gawaing ito (hindi kasama ang pangunahing bonus) ay dapat maabot",
            daily_text7: "beses ng kasalukuyang halaga ng pagtaya (i.e. pagsusuri, pagtaya o wastong pagtaya) bago ito ma-withdraw;",
            daily_text8: "5.Ang gawaing ito ay para lamang sa may-ari ng account na maglaro nang normal. Mahigpit na ipinagbabawal ang paggamit ng mga plano sa pagpapaupa, paggamit ng mga simulator (mga mapanlinlang na programa), mga robot, sinadyang pagtaya sa iba't ibang mga account, sinadyang pagsasaayos, pakikipagtulungan, asosasyon, kasunduan, pagsasamantala sa mga butas, kontrol ng grupo o iba pang teknikal na paraan upang lumahok, kung hindi, ang mga gantimpala ay magiging kinumpiska, na-freeze o inalis mula sa mga pagbabawas ng mga gantimpala, at maaaring ma-blacklist pa.",
            daily_text9: "6. Upang maiwasan ang mga pagkakaiba sa pag-unawa sa teksto, irereserba ng platform ang panghuling karapatan ng interpretasyon ng kaganapang ito.",
            weekly_text1: "Mga pangmatagalang gawain (i-reset bawat linggo sa 00:00)",
            weekly_text2: "Lingguhang pagkumpleto ng mga deposito, taya, o pag-audit",
            weekly_text3: "1. Ang mga sumusunod na gawain ay maaaring gawin bawat linggo, kabilang ang lingguhang recharge, single-game na pagtaya o iba pang pagtaya. Pagkatapos makumpleto ang gawain, maaari kang makakuha ng isang tiyak na halaga ng mga gantimpala. Kung mas malaki ang kahirapan, mas malaki ang gantimpala;"
        },
        promotion_rebate: {
            today_effective_betting: "Maaaring makolekta ngayon",
            collect_all: "I-claim Lahat",
            collect_record: "Tala ng Gantimpala",
            effective_betting: "Mga Wastong Taya",
            rebate_ratio: "Rate ng rebate",
            can_be_claimed: "Magagamit para sa pagkolekta",
            next_ratio: "Mas mababang ratio"
        },
        promotion_fees: {
            deposited: "Nakadeposito",
            year_rate: "taunang rate ng interes",
            settlement_cycle: "Settlement cycle ",
            accumulated_claimed: "Kabuuang na-claim",
            deposit: "Ilipat sa",
            withdraw: "Ilipat Sa",
            unclaimed: "Upang Makolekta ",
            withdrawal_of_interest: "Tumanggap",
            tips1_1: "Maaaring mangolekta ng interes pagkalipas ng",
            tips1_2: "",
            detail: "Magtala ng mga detalye",
            rules: "Mga Batas sa Interes",
            tips2: "Maaari mo itong kolektahin pagkatapos makumpleto ang countdown.",
            claim_interest: "Tumanggap ng interes",
            total_income: "Kabuuang Kita",
            time: "Oras",
            amount: "Halaga",
            hour: "Oras",
            type: "Uri",
            quantity: "Halaga",
            account_balance: "Balanse ng Account",
            tips3: "Ang mga paglilipat sa loob at labas ay hindi sasailalim sa pag-verify, ang inaangkin na interes lamang ang kinakailangan",
            current_time: "Kasalukuyang panahon",
            all: "Lahat",
            tips4: "Pagkatapos ng depositong ito, ang unang nabuong interes ay magaganap sa",
            min_deposit: "Minimum na solong halaga ng paglipat",
            min_deposit_end: "integers lang",
            deposit_balance: "Balanse sa deposito",
            output_value: "Halaga ng produksyon",
            tips5: "Kapag nag-withdraw ka, mawawalan ka ng interes para sa pinakahuling panahon",
            exchange_pwd: "Pag-withdraw ng Password",
            forget_pwd: "Nakalimutan ang Password",
            support: "suporta",
            tips6: "Mag-withdraw man lang ng 1 halaga sa bawat pagkakataon",
            tips7: "Ang halagang ipinasok ay hindi maaaring walang laman",
            tups8: "Pakilagay ang 6 na digit na password sa pagkuha",
            rule_title1: "1. Panimula sa kita:",
            rule_title2: "2. Cycle ng pag -areglo: ",
            rule_title3: "3. taunang rate ng interes: ",
            rule_title4: "4. Formula ng Pagkalkula:",
            rule_title5: "5. Halimbawa:",
            rule_title6: "6. Transfer threshold:",
            rule_title7: "7. Hapit ng interes:",
            rule_title8: "8. Makatanggap ng oras: ",
            rule_title9: "9. Maramihang pag-audit:",
            rule_title10: "10. Pahayag ng Kaganapan: ",
            rule_title11: "11. Paliwanag:",
            rule_text1: "Ang halagang idineposito sa kayamanan ng interes ay dapat matugunan ang hindi bababa sa isang kumpletong cycle upang makabuo ng interes.",
            rule_text2: "Kung ito ay ililipat nang maaga, ang kita ay hindi kakalkulahin sa cycle na iyon.",
            rule_text3: "Halimbawa: ang kasalukuyang settlement cycle ay ",
            rule_text4: "na oras, pagkatapos ay 2023-01-01 00:00:01 Ang halagang inilipat ay makakaipon ng interes sa unang cycle sa ",
            rule_text5: "araw",
            rule_text6: "",
            rule_text7: "Ang pag -areglo ng pag -areglo ng kasalukuyang interes ay ",
            rule_text8: "oras",
            rule_text9: "Ang kasalukuyang taunang rate ng interes ay ",
            rule_text10: "Interes ng Interes = Halaga ng Deposit * Taunang Interest Rate / Settlement Cycle;",
            rule_text11: "Ang A ay nagdeposito ng 10,000 sa 2023-01-01 00:00:01, ang taunang rate ng interes ay ",
            rule_text12: " at ang panahon ng pag-aayos ay",
            rule_text13: "na oras, pagkatapos ay makuha ang unang kita ng interes sa ",
            rule_text14: "Kunin ang iyong unang kita sa interes",
            rule_text15: " Ang pagkalkula ay ang mga sumusunod:",
            rule_text16: "Unang interes =",
            rule_text17: "Ang bawat halaga ng paglipat ay dapat na mas malaki kaysa o katumbas ng",
            rule_text18: "\uFF0CWalang mas mataas na limitasyon para sa halaga ng paglipat. Kung mas marami ang paglipat, mas malaki ang kita;",
            rule_text19: "Walang limitasyon sa kasalukuyang rate ng interes Tandaan na regular o madalas na kolektahin ang iyong kita upang maiwasang mawalan ng karagdagang kita;",
            rule_text20: "sa kasalukuyan ito ay nakolekta sa susunod na araw, iyon ay, ang interes na nabuo sa araw na iyon, at hindi ito makokolekta hanggang sa ika -0 ng umaga sa susunod na araw;",
            rule_text21: "Ang kasalukuyang maramihang pag-audit ay",
            rule_text22: " beses (mga kinakailangan sa turnover sa pagtaya), ibig sabihin, kailangang ilagay ang natanggap na interes bago ma-withdraw ang cash.Walang limitasyong wastong platformAng interes na limitado sa interes na natanggap mo ay kinakailangan, at ang punong -guro na inilipat sa paglipat ay walang mga kinakailangan para sa pagsusuri;",
            rule_text23: "Ang pagpapaandar na ito ay limitado sa account. Mayroon akong isang normal na pagtaya sa laro, at ipinagbabawal na magrenta ng isang account, walang panganib na pagtaya (para sa pagsusugal, pagpapares, mababang kabayaran, brushing water), Ang nakakahamak na arbitrasyon, gamit ang mga proseso ng plug -In, mga robot, robot, mga robot ay gumagamit ng mga kasunduan, kahinaan, interface,Kontrol ng pangkat o iba pang mga teknikal na paraan upang lumahok. Kapag ang pagsisiyasat ay totoo, ang platform ay may karapatang wakasan ang pag -login ng mga miyembro, suspindihin ang mga website na gumamit ng mga website, at makumpiska ang mga bonus at hindi tamang kakayahang kumita;",
            rule_text24: "",
            rule_text25: "Kapag natanggap ng isang miyembro ang Yibao reward, ipapalagay ng platform na ang miyembro ay sumasang-ayon at sumusunod sa mga kaukulang kundisyon at iba pang nauugnay na regulasyon Upang maiwasan ang kalabuan sa pag-unawa sa teksto, inilalaan ng platform ang pangwakas karapatang bigyang-kahulugan ang kaganapang ito;"
        },
        records: {
            reward: "Bonus",
            rebate: "Rebate"
        },
        set_exchange_pwd: {
            title: "Withdraw Password",
            tips: "Para sa kaligtasan ng iyong mga pondo, kailangan mo munang magtakda ng withdrawal password!",
            subTitle: "Itakda ang Password sa Pag-atras",
            exchange_pwd: "Bagong pag -alis ng password",
            confirm_pwd: "Kumpirmahin ang withdrawal password",
            confirm: "Kumpirmahin",
            tips1: "Ang mga password ay hindi pare-pareho, mangyaring muling ilagay!",
            tips2: "Tandaan na ang pag -alis ng password ay pinoprotektahan ang iyong mga pondo, napakahalaga, maaari mo lamang malaman ang iyong sarili, na nagiging sanhi ng pagkawala ng kapital",
            tips3: "Dapat na 6 na digit ang haba ng password",
            tips4: "6 puro numero"
        },
        bottom_menu: {
            index: "Home",
            promotion: "Diskwento",
            vip: "VIP",
            recharge: "Deposit",
            me: "Akin",
            exchange: "Withdraw",
            rebate: "Rebate",
            task: "Gawain",
            agent: "Magtaguyod ng Pera"
        },
        lucky_wheel_activity: {
            spin: `DRAW
NOW`,
            text1: "Kasalukuyang Masuwerteng Halaga",
            text2: "Kailangan mo ring tumaya ng ",
            text3: " para makakuha ng ",
            text4: " lucky value",
            silver: "Pilak na Turntable",
            gold: "Golden Turntable",
            diamond: "Diamond Turntable",
            text5: "Masuwerteng halaga {amount}",
            tab1: "Anunsyo ng Parangal",
            tab2: "Ang Tala Ko",
            text6: "ipasok ito"
        },
        pop_red_envelopes: {
            text1: "Ulan ng pulang sobre",
            text2: "Buksan",
            text3: "Binabati kita para sa premyo",
            text4: "Ang bonus ay idineposito sa iyong wallet",
            tips1: "Mga tip",
            tips2: "Pagkatapos isara, hindi na lilitaw ang pulang sobre sa round na ito. Kapag kusang tinalikuran ang gantimpala."
        },
        message_center: {
            support: "Support",
            news: "Anunsyo",
            notification: "Paunawa",
            marquee: "Marquee",
            feedback: "Award Feedback"
        },
        finish_register: {
            title: "Paalala",
            text: "Matagumpay na nakarehistro! Laro tayo ngayon~",
            btn: "Deposito Ngayon"
        },
        newbie_bonus: {
            title: "Bagong Bonus ng Manlalaro",
            paste: "I-paste",
            placeholder: "Pakilagay ang Promo Code",
            bonus_amount: "Halaga ng Lottery",
            btn: "Makatanggap Ng Isang Loterya",
            tips: "Binabati kita, nanalo ka ng {reward} bonus!"
        },
        claim: {
            title: "Claim",
            reward: "Bonus",
            active_level: "Aktibong antas",
            time: "Oras",
            name: "Pangalan",
            source: "Pinagmulan",
            status: "Katayuan",
            claim: "Pumunta sa",
            detailTitle: "Pinagmulan ng gantimpala",
            reward_name: "Pangalan ng gantimpala",
            reward_time: "Oras ng reward",
            amount: "Halaga",
            point: "Aktibong antas",
            available_time: "Magagamit na oras",
            rewards: "Mga gantimpala",
            claimable_time: "Maaangkin na oras",
            validity_period: "Panahon ng bisa"
        },
        music: {
            music: "Musika",
            cycle: "Siklo",
            shuffle: "Random",
            repeat: "Single cycle",
            downloaded: "Na-Download",
            system_music: "Sistema ng Musika",
            my_music: "Ang Aking Musika",
            deleteTips: "Huling kanta, na hindi matatanggal"
        },
        add_tips_dialog: {
            title1: "Idagdag sa Home Screen",
            subTitle1: '1. I-click ang icon na "Higit Pa", pagkatapos ay i-click ang "Idagdag sa Home Screen"',
            subTitle2: '2. I-click ang "Idagdag," pagkatapos ay piliin ang "Idagdag"',
            text1: "Ibahagi...",
            text2: "Hanapin sa webpage",
            text3: "Idagdag sa Home Screen",
            text4: "Desktop site",
            text5: "Idagdag sa Home Screen",
            text6: "Kanselahin",
            text7: "Idagdag",
            title2: "Idagdag sa pangunahing screen",
            text8: "Idagdag sa Quick Notes",
            text9: "Hanapin sa page",
            text10: "Idagdag sa pangunahing screen",
            text11: "Bookmark",
            text12: "Isang shortcut ang idadagdag sa iyong home screen para sa mabilis na pag-access sa website na ito"
        },
        first_charge_pop: {
            title: "Mga Karagdagang Reward Para sa Unang Pagsingil",
            text1: "Unang recharge",
            text2: "Halaga ng Gantimpala",
            btn: "Pumunta sa"
        },
        tutorial: {
            text: `
        <h1><strong>Ang isang halimbawa ay ang sumusunod:</strong></h1><p>Ipagpalagay na ang kasalukuyang epektibong taya mula 0 hanggang 10,000 ay makakatanggap ng komisyon na 100 (ibig sabihin, 1%) para sa bawat 10,000, at ang Ang mga epektibong taya sa itaas ng 10,000 ay makakatanggap ng komisyon na 300 para sa bawat 10,000. (ibig sabihin, 3%), si A ang unang nakatuklas ng mga pagkakataon sa negosyo sa site na ito, at agad na binuo ang B1, B2 at B3. Ang B1 ay higit pang bumuo ng C1 at C2. Ang B2 ay may walang subordinates, at binuo ni B3 ang medyo makapangyarihang C3. Sa ikalawang araw, ang epektibong taya ng B1 ay 500, ang epektibong taya ng B2 ay 3000, ang epektibong taya ng B3 ay 2000, ang epektibong taya ng C1 ay 1000, ang epektibong taya ng C2 ay 2000, at ang epektibong taya ng C3 ay hanggang 20000. </p><span>Kung gayon ang paraan ng pagkalkula ng kita sa pagitan nila ay ang sumusunod: </span><ul><li><strong>1. Komisyon ng B1</strong> (direktang kontribusyon mula sa C1 at C2) = (1000 + 2000) * 1% = <em>30</em></li><li><strong>2. Komisyon ng B2</strong> (walang subordinates) = (0+0) * 1% = <em> 0</em></li><li><strong>3. B3 na komisyon</strong> (direktang kontribusyon mula sa C3) = 20000 * 3% = <em>600</em></li><li> <strong>4. Bilang karagdagan sa mga kontribusyon mula sa mga direktang subordinates na B1, B2 at B3, ang komisyon ni A ay nagmumula rin sa mga kontribusyon mula sa iba pang mga subordinate C1, C2 at C3, tulad ng sumusunod: </strong><ul><li><strong>( 1 )Ang direktang komisyon ni A</strong>(kontribusyon mula sa direktang B1, B2 at B3) = (500+3000+2000) * 3% = <em>165</em></li><li><strong>( 2 )Ang iba pang mga komisyon ni A</strong>(mula sa C1, C2 na mga kontribusyon)=(1000+2000) * 2%= <em>60</em></li><li><strong>(3)Ang kabuuang Komisyon ni A </strong>(direct + other) = 165+60 = <em>225</em></li></ul></li><li>5. Buod: <ul><li>&lt; strong&gt; (1) Direktang pangkat: tumutukoy sa mga nasasakupan na direktang binuo ni A, iyon ay, ang unang antas ng relasyon sa A, na sama-samang tinutukoy bilang direktang pangkat. </li><li><strong>(2) Iba pang mga koponan</strong>: Tumutukoy sa mga binuo ng mga subordinates ng A. Mayroon silang pangalawang antas na relasyon sa A o mas mataas, iyon ay, ang mga subordinates ng mga subordinates , at ang mga subordinates ng mga subordinates.. .etc., na pinagsama-samang tinutukoy bilang iba pang mga koponan, dahil ang modelong ito ng ahensya ay maaaring bumuo ng walang limitasyong mga subordinates, para sa kaginhawahan ng pagpapaliwanag, ang artikulong ito ay kumukuha lamang ng 2-level na istraktura bilang isang halimbawa. </li><li><strong>(3) Paglalarawan ng A</strong>: Ang direktang pagganap ni A ay 5,500 at ang iba pang pagganap ay 20,000 (dahil sa kapangyarihan ng C3). Ang kabuuang pagganap ay 28,500, at ang katumbas na komisyon rate ay 3%. Dahil ang B1 ay may kabuuang pagganap na 3,000 at tinatangkilik lamang ang 1% na rebate, habang ang A ay may kabuuang pagganap na 28,500 at may 3% na rebate ratio, pagkatapos ay magkakaroon ng rebate gap sa pagitan ng A at B1. Ang pagkakaiba ay: 3% -1% =2%, ang pagkakaibang ito ay ang bahaging iniambag ng C1 at C2 sa A, kaya ang C1 at C2 ay nag-ambag sa A: (1000+2000)* 2%=60, walang matinding pagkakaiba sa pagitan ng A at B3, kaya Nag-aambag ang C3 sa A Ang komisyon ng kontribusyon ay 0. </li><li><strong>(4) Paglalarawan ng B1</strong>: Ang B1 ay may mga subordinate na C1 at C2. Dahil ang direktang pagganap ay 3000, ang katumbas na ratio ng rebate ay 1%. </li><li><strong>(5) Pagpapaliwanag ng B2 </strong>: Maaaring tamad si B2 at hindi makikinabang kung hindi niya mapaunlad ang kanyang mga nasasakupan. </li><li><strong>(6) paliwanag ng B3</strong>: Bagama't medyo huli na ang pagsali ni B3 at isang subordinate ng A, ang subordinate na C3 nito ay napakalakas at may direktang pagganap na 20,000, na nagpapahintulot sa B3 na direktang magtamasa ng mas mataas na komisyon. Ang proporsyon ay 3%. </li><li><strong>(7) Buod ng mga alituntunin</strong>: Kahit kailan ka sumali, kung kaninong subordinate ka, anuman ang antas mo, hindi maaapektuhan ang iyong kita, at ikaw ay hindi na nagdurusa sa pagkalugi ng mga nasasakupan ng iba. , hindi pinaghihigpitan ang pag-unlad. Ito ay isang ganap na patas at walang kinikilingan na modelo ng ahensya, at walang sinuman ang palaging nasa ilalim dahil lang sa huli silang sumali. </li></ul></li></ul>
        `
        },
        dealer: {
            title: "Dealer",
            tutorial: "Tutorial",
            home: "Bahay",
            review: "Balik-aral",
            performance: "Ang performance ko",
            member: "Mga miyembro ko",
            game: "Data ng laro",
            record: "Kumuha ng mga tala",
            ladder: "Hagdan ng gantimpala"
        },
        dealer_tutorial: {
            title: "Unang full red mode",
            text1: "Ang iyong unang deposito na reward: 15/tao + karagdagang tier na reward",
            text2: "Ang limitasyon ng reward ay hindi maaaring mas malaki kaysa sa iyong sariling limitasyon",
            ruleTitle: "Ang iyong kabuuang top-up:",
            ruleText1: "Halimbawa, kung ang pangkalahatang ahente ay may first-time na deposito na reward na 15 bawat tao, at kung 100 tao ang binuo para mag-recharge, ang recharge reward = 100*15=<b>1500</b>, at ang mas mababang antas ang management ay inilalaan ng reward na 14 bawat tao, kung ang manager ay bumuo ng 100 tao para mag-recharge, ang pagkakaiba ay makukuha 100*(15-14)=100. Kung ang pamamahala ay bumuo ng mga empleyado sa mababang antas at bumuo ng 100 tao upang muling magkarga, ang pangkalahatang ahente ay makakakuha ng pagkakaiba 100*(15-12)=<b>300</b>, at iba pa; nakukuha ng pangkalahatang ahente Ang quota = sariling 1500 + balanse sa pamamahala 100 + balanse ng empleyado 300 +...",
            ruleText2: "Pagkalkula ng iba pang tier na pagkakaiba sa reward: Ayon sa bilang ng mga tao at configuration ng reward, maaari pa ring kalkulahin ang pagkakaiba. Halimbawa, kung ang kabuuang ahente ay umabot sa 50 tao, ang reward ay 100, at kung ang lower-level na pamamahala ay nag-set up ng 50 tao, ang reward ay 90, maaari ka pa ring makakuha ng <b>10</b> na pagkakaiba."
        },
        dealer_home: {
            dealerId: "Dealer ID",
            superiorId: "Superior ID",
            level: "antas",
            firstRecharge: "Ang iyong unang deposito",
            person: "tao",
            complaint: "Reklamo",
            camReceive: "Matatanggap",
            received: "Natanggap",
            myLink: "Ang link ko",
            myReview: "Ang aking pagsusuri",
            reviewNum: "Dami ng susuriin",
            operation: "Magpatakbo",
            reviewBtn: "Upang suriin",
            reward_setting: "Mga setting ng reward",
            firstRecharge_per_reward: "Gantimpala sa unang deposito bawat tao",
            firstRecharge_ext_reward: "Mga karagdagang reward para sa unang deposito",
            reward_ladder: "Hagdan ng gantimpala",
            check: "Suriin",
            reward_sum: "Mga istatistika ng gantimpala",
            personal_reward: "Bilang ng mga taong gantimpala",
            ext_reward: "Mga karagdagang gantimpala",
            total_reward: "Kabuuang gantimpala"
        },
        dealer_complaint: {
            title1: "Magreklamo sa dealer",
            title2: "Talaan ng reklamo",
            placeholder: "Pakilagay ang nilalaman ng reklamo",
            submit: "Isumite",
            tips: "Upang matiyak ang normal na operasyon ng ahente, maaari kang magsampa ng reklamo laban sa pag-uugali ng mga walang prinsipyong dealer, at hahawakan ito ng platform para sa iyo."
        },
        dealer_review: {
            placeholder: "Ipasok ang ID ng miyembro",
            check: "Magtanong",
            contact_setting: "Mga setting ng contact",
            memberId: "ID ng Miyembro",
            contactInfo: "Impormasyon sa pakikipag-ugnayan",
            remark: "Puna",
            applyTime: "Oras ng aplikasyon",
            review: "Balik-aral"
        },
        dealer_performance: {
            first_person: "Bilang ng mga taong gumagawa ng unang deposito",
            time: "Oras",
            dealer_person: "Bilang ng mga dealers",
            recharge_person: "Bilang ng mga taong gumagawa ng unang deposito",
            reward: "Pagtitipon ng mga gantimpala"
        },
        dealer_member: {
            placeholder: "Ipasok ang ID ng miyembro",
            check: "Magtanong",
            registerTime: "Oras ng pagpaparehistro",
            account: "ID ng Miyembro",
            accountRemark: "Mga komento ng account ng miyembro",
            superiorId: "Superior ID",
            isRecharge: "Kung magrecharge",
            dealer: "Dealer",
            user: "Ordinaryong miyembro"
        },
        dealer_record: {
            received: "Natanggap ang komisyon",
            receive_time: "Oras ng koleksyon",
            received: "Natanggap"
        },
        dealer_contact_setting: {
            show: "Pagpapakita ng serbisyo sa customer",
            contactMethod: "Maaaring isumite ang impormasyon sa pakikipag-ugnayan",
            modify: "Baguhin",
            tips1: "Mangyaring pumili ng impormasyon sa pakikipag-ugnayan",
            tips2: "Punan ang hindi bababa sa isang impormasyon ng serbisyo sa customer"
        },
        dealer_ladder: {
            tab1: "Mga reward para sa mga taong nagrecharge",
            tab2: "Mga gantimpala sa promosyon ng VIP",
            currentNum: "Ang kasalukuyang bilang ng mga taong gumagawa ng unang deposito",
            levelUpNum: "Bilang ng mga promosyon",
            receivedReward: "Natanggap ang komisyon",
            firstRecharge: "Bilang ng mga taong gumagawa ng unang deposito",
            reward: "parangal",
            vipLevel: "antas ng VIP"
        },
        dealer_join_dialog: {
            title1: "Makipag-ugnayan sa amin",
            title2: "Mag-apply para maging dealer",
            table1: "Mga detalye ng contact",
            table2: "Puna",
            table3: "Oras ng aplikasyon",
            table4: "Estado",
            table5: "Magpatakbo",
            btn1: "Muling isumite",
            btn2: "Suriin",
            text1: "Pumili ng impormasyon sa pakikipag-ugnayan",
            text2: "Punan ang impormasyon sa pakikipag-ugnayan",
            text3: "Puna",
            btn3: "Kanselahin",
            btn4: "Kumpirmahin",
            btn5: "Kanselahin",
            btn6: "Muling isumite",
            tips1: "Mangyaring pumili ng impormasyon sa pakikipag-ugnayan",
            tips2: "Mangyaring punan ang impormasyon sa pakikipag-ugnayan"
        },
        dealer_review_detail: {
            title: "Suriin ang mga operasyon",
            account: "Account ng miyembro",
            applyTime: "Oras ng aplikasyon",
            contactType: "Uri ng pakipag-ugnayan",
            contactInfo: "Impormasyon sa pakikipag-ugnayan",
            applyRemark: "Pahayag ng aplikasyon",
            rechargeReward: "Gantimpala sa unang deposito",
            person: "tao",
            extReward: "Mga karagdagang gantimpala",
            lower_recharge_reward_setting: "Configuration ng reward sa unang deposito sa mababang antas",
            lower_recharge_extReward_setting: "Karagdagang bonus configuration para sa unang deposito sa mas mababang antas",
            rechargePerson: "Bilang ng mga taong nagre-recharge",
            myReward: "Aking gantimpala",
            max_reward: "Ang maximum na reward na maaaring itakda",
            next_reward_setting: "Mga setting ng reward na mas mababang antas",
            withdraw_setting: "Mga setting ng withdrawal",
            can_withdraw: "Maaaring mag-withdraw ng pera",
            cannot_withdraw: "Hindi posible ang withdrawal",
            edit_setting: "I-edit ang mga setting",
            can_edit: "Maaaring mag-edit",
            cannot_edit: "Hindi nae-edit",
            level_name: "Pangalan ng antas",
            account_remark: "Mga komento ng account ng miyembro",
            reject: "Tanggihan",
            pass: "Pass",
            tips1: "Pakitakda ang lahat ng mas mababang antas ng mga setting ng reward",
            tips2: "Mangyaring itakda ang configuration ng reward sa unang deposito para sa mas mababang antas",
            tips3: "Mangyaring itakda ang karagdagang configuration ng reward para sa unang deposito sa mas mababang antas",
            tips4: "Mangyaring itakda ang configuration ng pag-edit",
            tips5: "Mangyaring magpasok ng pangalan ng antas",
            tips6: "Mangyaring itakda ang configuration ng withdrawal"
        },
        complaint: {
            title: "Reklamo",
            site_complaint: "Mga reklamo sa site",
            email: "Email",
            tipsTitle: "Ilarawan",
            tips: "Upang matiyak ang normal na operasyon ng site, maaari kang magsampa ng reklamo laban sa walang prinsipyong pag-uugali ng site at ang platform ang hahawak nito para sa iyo.",
            emailError1: "Hindi maaaring walang laman ang email",
            emailError2: "Mali ang format ng email",
            placeholderText: "Mangyaring ipasok ang nilalaman ng reklamo sa site"
        },
        upload: {
            uploading: "ina-upload...",
            tips1: "Ang laki ng pag-upload ng isang file ay hindi maaaring lumampas",
            tips2: "Ang kabuuang laki ng pag-upload ng file ay hindi maaaring lumampas",
            tips3: "Hindi maaaring lumampas ang laki ng pag-upload ng file"
        },
        recharge_order_detail: {
            title: "Deposito",
            tips1: "Mangyaring buksan ang iyong app sa pagbabayad at i-scan o kopyahin at i-paste ang QR code sa ibaba upang makumpleto ang iyong pagbili;",
            tips2: "Isang beses lang mababayaran ang QR code na ito. Kung kailangan mong magbayad muli, mangyaring bumalik at mag-recharge;",
            tips3: "Matapos ang pagbabayad ay matagumpay, maaari kang bumalik sa lobby ng laro at maghintay para sa mga puntos na maidagdag!",
            effectTime: "Epektibong oras",
            copyText: "Kopyahin ang QR code",
            copyAddress: "QR code address...",
            label1: "Katayuan ng Order",
            label2: "Oras ng Paglikha",
            label3: "Numero ng Order",
            label4: "Numero ng order ng merchant",
            waiting: "Para mabayaran",
            success: "Binayaran",
            warning: "Nag-expire na ang QR code",
            tips4: "Mangyaring bumalik sa lobby upang mag-order muli. Ang kasalukuyang pahina ay isasara sa loob ng 10 segundo.",
            tips5: "Pumili",
            tips6: "Isara ngayon",
            tips7: "O kaya",
            tips8: "suriin ang order",
            tips9: "Matagumpay na natanggap",
            tips10: "Ang system ay awtomatikong nagtalaga sa iyo ng mga puntos.",
            tips11: "Ang kasalukuyang pahina ay isasara sa loob ng 10 segundo."
        },
        check_pwd_dialog: {
            title: "Ilagay ang Password",
            text1: "Withdraw Password",
            text2: "Para sa seguridad ng iyong account, mangyaring ipasok ang withdrawal password",
            text3: "Nakalimutan ang password?",
            btnText: "Susunod na Hakbang",
            tips1: "6 puro numero"
        }
    }, ia = _i({
        legacy: !1,
        locale: "en",
        warnHtmlMessage: !1,
        messages: {
            en: oe,
            pt: se,
            "zh-Hans": ya,
            zh: ya,
            "zh-CN": ya,
            ms: le,
            id: de,
            ph: me
        }
    }), {
        t: ra
    } = ia.global, Pt = "0.72rem", Va = "1.24rem", St = 60, At = /^[a-zA-Z][\da-zA-Z]{3,15}$/, yt = /^[\da-zA-Z._\-`~!@#$%^&*]{6,16}$/, ht = /\d{1,15}/, kt = /[a-z]{1,15}/, ft = /[A-Z]{1,15}/, xt = /[._\-`~!@#$%^&*]{1,15}/, pt = /^\d{9,11}$/, bt = /^\d{9,10}$/, _t = /\d{6}/, mt = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(.[a-zA-Z0-9_-]+)+$/, ce = "eJeJylXM", ra("exchange.exchange_account"), ct = {
        0: "/promotion/claim",
        1: "/promotion/rebate",
        2: "/promotion/vip",
        3: "/agent",
        4: "/promotion/event",
        5: "/promotion/task"
    }, wt = {
        0: "/message-center?type=customer-service",
        1: "/message-center?type=advise",
        2: "/message-center?type=customer-service"
    }, ra("side_bar.fees"), ra("side_bar.event"), ra("side_bar.rebate"), ra("side_bar.task");
    let ue;
    ue = [{
        path: "/index",
        name: "index",
        component: () => l(() =>
            import ("./index.2c13aa2a.js").then(async a => (await a.__tla, a)), ["js/index.2c13aa2a.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/swiper.137b1af3.js", "css/swiper.c73a1d56.css", "js/hot_tag.71dc183d.js", "js/bookmark_star_2.d7385625.js", "js/maintenance.1b212141.js", "js/blank.e4277571.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/img_vip.31840ec8.js", "js/clipboard.f53621db.js", "js/xe-utils.0e898ace.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.6e481a7b.css"]),
        meta: {
            bottomMenu: !0,
            headerMenu: !0,
            keepAlive: !0,
            needLogin: !1,
            noHeader: !1,
            depIndex: 0
        }
    }, {
        path: "/me",
        name: "me",
        component: () => l(() =>
            import ("./index.c8e7fd8f.js").then(async a => (await a.__tla, a)), ["js/index.c8e7fd8f.js", "js/@vue.16908cbf.js", "js/img_vip.31840ec8.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.30b109e2.css"]),
        meta: {
            bottomMenu: !0,
            headerMenu: !0,
            keepAlive: !0,
            needLogin: !0,
            noHeader: !1,
            depIndex: 2
        }
    }, {
        path: "/vip",
        name: "vip",
        component: () => l(() =>
            import ("./index.ec99f7a1.js").then(async a => (await a.__tla, a)), ["js/index.ec99f7a1.js", "js/avatar_temp.28806262.js", "js/swiper.137b1af3.js", "js/@vue.16908cbf.js", "css/swiper.c73a1d56.css", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.9d36cd02.css"]),
        meta: {
            bottomMenu: !0,
            headerMenu: !0,
            keepAlive: !1,
            needLogin: !1,
            noHeader: !1,
            depIndex: 100
        }
    }, {
        path: "/limit",
        name: "limit",
        component: () => l(() =>
            import ("./index.9fd745e4.js"), ["js/index.9fd745e4.js", "js/@vue.16908cbf.js", "css/index.8b3ec4eb.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            noHeader: !0,
            depIndex: 100
        }
    }, {
        path: "/promotion",
        name: "promotion",
        component: () => l(() =>
            import ("./index.1f17a1fa.js").then(async a => (await a.__tla, a)), ["js/index.1f17a1fa.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.9740cca8.css"]),
        children: [{
            path: "",
            alias: "/promotion/event",
            name: "event",
            component: () => l(() =>
                import ("./index.9403b552.js").then(async a => (await a.__tla, a)), ["js/index.9403b552.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.74252263.css"]),
            meta: {
                noHeader: !0,
                bottomMenu: !0,
                depIndex: 2
            }
        }, {
            path: "/promotion/task",
            name: "task",
            component: () => l(() =>
                import ("./index.f3fa797f.js").then(async a => (await a.__tla, a)), ["js/index.f3fa797f.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3b32d4de.css"]),
            meta: {
                noHeader: !0,
                bottomMenu: !0,
                needLogin: !1,
                depIndex: 3
            }
        }, {
            path: "/promotion/rebate",
            name: "rebate",
            component: () => l(() =>
                import ("./index.2a448ffc.js").then(async a => (await a.__tla, a)), ["js/index.2a448ffc.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/vue-router.d17f0860.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.15ee0f65.css"]),
            meta: {
                noHeader: !0,
                bottomMenu: !0,
                needLogin: !1,
                depIndex: 4
            }
        }, {
            path: "/promotion/fees",
            name: "fees",
            component: () => l(() =>
                import ("./index.6f3555cf.js").then(async a => (await a.__tla, a)), ["js/index.6f3555cf.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/vue-router.d17f0860.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.d15afbde.css"]),
            meta: {
                noHeader: !0,
                bottomMenu: !0,
                needLogin: !1,
                depIndex: 5
            }
        }, {
            path: "/promotion/records",
            name: "records",
            component: () => l(() =>
                import ("./index.23318e08.js").then(async a => (await a.__tla, a)), ["js/index.23318e08.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@vue.16908cbf.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/blank.e4277571.js", "js/xe-utils.0e898ace.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.43d5db29.css"]),
            meta: {
                noHeader: !0,
                bottomMenu: !0,
                needLogin: !1,
                depIndex: 6
            }
        }, {
            path: "/promotion/claim",
            name: "claim",
            component: () => l(() =>
                import ("./index.5182a546.js").then(async a => (await a.__tla, a)), ["js/index.5182a546.js", "js/blank.e4277571.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.7af01e62.css"]),
            meta: {
                noHeader: !0,
                bottomMenu: !0,
                needLogin: !1,
                depIndex: 2
            }
        }, {
            path: "/promotion/vip",
            name: "vip",
            component: () => l(() =>
                import ("./index.45a4d400.js").then(async a => (await a.__tla, a)), ["js/index.45a4d400.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.891aa8ae.css"]),
            meta: {
                bottomMenu: !0,
                headerMenu: !0,
                keepAlive: !1,
                needLogin: !1,
                noHeader: !1,
                depIndex: 3
            }
        }]
    }, {
        path: "/manufacturer",
        name: "manufacturer",
        component: () => l(() =>
            import ("./index.1a00f80a.js").then(async a => (await a.__tla, a)), ["js/index.1a00f80a.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-router.d17f0860.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.64287623.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            depIndex: 100
        }
    }, {
        path: "/notice",
        name: "notice",
        component: () => l(() =>
            import ("./index.14cb9ade.js").then(async a => (await a.__tla, a)), ["js/index.14cb9ade.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/arrow.cf3e21f9.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.7be4a3df.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/noticeDetail",
        name: "noticeDetail",
        component: () => l(() =>
            import ("./detail.04c9abc4.js").then(async a => (await a.__tla, a)), ["js/detail.04c9abc4.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/detail.804359e8.css", "css/@wangeditor.501cf061.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/mine-info",
        name: "mine-info",
        component: () => l(() =>
            import ("./index.ad2513ba.js").then(async a => (await a.__tla, a)), ["js/index.ad2513ba.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/avatar_temp.28806262.js", "js/img_vip.31840ec8.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.c3a8cad0.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            keepAlive: !0,
            depIndex: 3
        }
    }, {
        path: "/address",
        name: "address",
        component: () => l(() =>
            import ("./index.91b52c10.js").then(async a => (await a.__tla, a)), ["js/index.91b52c10.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.e6360599.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            keepAlive: !0,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/modify-address",
        name: "modifyAddress",
        component: () => l(() =>
            import ("./modify_address.b86f1fd6.js").then(async a => (await a.__tla, a)), ["js/modify_address.b86f1fd6.js", "js/@vue.16908cbf.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/modify_address.8b9eb59f.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/about-us",
        name: "aboutUs",
        component: () => l(() =>
            import ("./about_us.db405099.js").then(async a => (await a.__tla, a)), ["js/about_us.db405099.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/about_us.fda8eae6.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            keepAlive: !0,
            depIndex: 3
        }
    }, {
        path: "/game/:id",
        name: "game",
        component: () => l(() =>
            import ("./index.68fe2a24.js").then(async a => (await a.__tla, a)), ["js/index.68fe2a24.js", "js/@vue.16908cbf.js", "js/bookmark_star_2.d7385625.js", "js/maintenance.1b212141.js", "js/blank.e4277571.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.fcc16159.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            keepAlive: !1,
            needLogin: !0,
            noHeader: !0,
            depIndex: 100
        }
    }, {
        path: "/wallet",
        name: "wallet",
        component: () => l(() =>
            import ("./index.6bb21f2f.js").then(async a => (await a.__tla, a)), ["js/index.6bb21f2f.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/blank.e4277571.js", "js/vuex.7fead168.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.713ebcad.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            keepAlive: !1,
            needLogin: !0,
            depIndex: 3
        }
    }, {
        path: "/account",
        name: "account",
        component: () => l(() =>
            import ("./index.c448a976.js").then(async a => (await a.__tla, a)), ["js/index.c448a976.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.4f6c7a2b.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            keepAlive: !1,
            needLogin: !0,
            depIndex: 3
        }
    }, {
        path: "/set-password",
        name: "setPassword",
        component: () => l(() =>
            import ("./set_password.98d436b0.js").then(async a => (await a.__tla, a)), ["js/set_password.98d436b0.js", "js/dark_tips.0e17d95d.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/@vue.16908cbf.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/set_password.f9decfdc.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/exchange",
        name: "exchange",
        component: () => l(() =>
            import ("./index.df6af35a.js").then(async a => (await a.__tla, a)), ["js/index.df6af35a.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.e1984b23.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            keepAlive: !1,
            depIndex: 3
        }
    }, {
        path: "/recharge",
        name: "recharge",
        component: () => l(() =>
            import ("./index.10f4a4d2.js").then(async a => (await a.__tla, a)), ["js/index.10f4a4d2.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.384d5d5f.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/recharge-record",
        name: "rechargeRecord",
        component: () => l(() =>
            import ("./recharge_record.f7efb2c5.js").then(async a => (await a.__tla, a)), ["js/recharge_record.f7efb2c5.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/blank_record.fc740b4b.js", "js/xe-utils.0e898ace.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/recharge_record.857a8ab8.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/birthday",
        name: "birthday",
        component: () => l(() =>
            import ("./birthday.441d3126.js").then(async a => (await a.__tla, a)), ["js/birthday.441d3126.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/birthday.cba9aa68.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/lucky-wheel",
        name: "LuckyWheel",
        component: () => l(() =>
            import ("./lucky_wheel.0b12c95f.js").then(async a => (await a.__tla, a)), ["js/lucky_wheel.0b12c95f.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/lucky_wheel.9df90c73.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/reward",
        name: "reward",
        component: () => l(() =>
            import ("./index.45a4d400.js").then(async a => (await a.__tla, a)), ["js/index.45a4d400.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.891aa8ae.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/collect-record",
        name: "collectRecord",
        component: () => l(() =>
            import ("./record.84e609c9.js").then(async a => (await a.__tla, a)), ["js/record.84e609c9.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@vue.16908cbf.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/blank.e4277571.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/record.a8fa8abb.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 1
        }
    }, {
        path: "/game-search",
        name: "gameSearch",
        component: () => l(() =>
            import ("./index.1ceba323.js").then(async a => (await a.__tla, a)), ["js/index.1ceba323.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/hot_tag.71dc183d.js", "js/bookmark_star_2.d7385625.js", "js/maintenance.1b212141.js", "js/blank.e4277571.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.fb9e6093.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 1
        }
    }, {
        path: "/sub-game",
        name: "subGame",
        component: () => l(() =>
            import ("./subgame.c5b7121d.js").then(async a => (await a.__tla, a)), ["js/subgame.c5b7121d.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@vue.16908cbf.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/hot_tag.71dc183d.js", "js/bookmark_star_2.d7385625.js", "js/maintenance.1b212141.js", "js/blank.e4277571.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/subgame.e9d93f22.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 1
        }
    }, {
        path: "/goods-list",
        name: "goodsList",
        component: () => l(() =>
            import ("./index.75757144.js").then(async a => (await a.__tla, a)), ["js/index.75757144.js", "js/@vue.16908cbf.js", "js/wheel.64ea9ed7.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.eafa072e.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/goods/:id",
        name: "goods",
        component: () => l(() =>
            import ("./index.1a717502.js").then(async a => (await a.__tla, a)), ["js/index.1a717502.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/wheel.64ea9ed7.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.190eb568.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/order-list",
        name: "orderList",
        component: () => l(() =>
            import ("./order_list.93ea508c.js").then(async a => (await a.__tla, a)), ["js/order_list.93ea508c.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/wheel.64ea9ed7.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/order_list.1ab73ef4.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/order-detail/:id",
        name: "orderDetail",
        component: () => l(() =>
            import ("./order_detail.a7eab420.js").then(async a => (await a.__tla, a)), ["js/order_detail.a7eab420.js", "js/wheel.64ea9ed7.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/order_detail.3bb475d1.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/finished-pay",
        name: "finishedPay",
        component: () => l(() =>
            import ("./finished_pay.088e9d6d.js").then(async a => (await a.__tla, a)), ["js/finished_pay.088e9d6d.js", "js/wheel.64ea9ed7.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/finished_pay.49abb8cb.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/special-promotion",
        name: "specialPromotion",
        component: () => l(() =>
            import ("./index.b6dff2d4.js").then(async a => (await a.__tla, a)), ["js/index.b6dff2d4.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.d651dad6.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/goods-promotion",
        name: "goodsPromotion",
        component: () => l(() =>
            import ("./goods_promotion.cb5f37a2.js").then(async a => (await a.__tla, a)), ["js/goods_promotion.cb5f37a2.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/wheel.64ea9ed7.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/goods_promotion.acf016d7.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/diamond-exchange",
        name: "diamondExchange",
        component: () => l(() =>
            import ("./index.1fb05b85.js").then(async a => (await a.__tla, a)), ["js/index.1fb05b85.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.57da492c.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/diamond-exchange-record",
        name: "diamondExchangeRecord",
        component: () => l(() =>
            import ("./record.c17fb52f.js").then(async a => (await a.__tla, a)), ["js/record.c17fb52f.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/record.dc4ad21a.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/help-center",
        name: "helpCenter",
        component: () => l(() =>
            import ("./index.5bbfa3a2.js").then(async a => (await a.__tla, a)), ["js/index.5bbfa3a2.js", "js/support.52cd5dbc.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3b163b99.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 3
        }
    }, {
        path: "/advise",
        name: "advise",
        component: () => l(() =>
            import ("./advise.1bf5d396.js").then(async a => (await a.__tla, a)), ["js/advise.1bf5d396.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/dark_arrow.3f22666d.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/advise.b74caa77.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/promotion-record",
        name: "promotionRecord",
        component: () => l(() =>
            import ("./collect_record.5ea010f9.js").then(async a => (await a.__tla, a)), ["js/collect_record.5ea010f9.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/blank.e4277571.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/collect_record.16ccec71.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/recharge-activity/:id",
        name: "rechargeActivity",
        component: () => l(() =>
            import ("./recharge_activity.e2dbaf5c.js").then(async a => (await a.__tla, a)), ["js/recharge_activity.e2dbaf5c.js", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/recharge_activity.cc3906f6.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/bet-activity/:id",
        name: "betActivity",
        component: () => l(() =>
            import ("./bet_activity.5566c511.js").then(async a => (await a.__tla, a)), ["js/bet_activity.5566c511.js", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/bet_activity.31d59e59.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/signIn-activity/:id",
        name: "signInActivity",
        component: () => l(() =>
            import ("./sign_in_activity.15785d29.js").then(async a => (await a.__tla, a)), ["js/sign_in_activity.15785d29.js", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/sign_in_activity.d9275018.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/rescue-activity/:id",
        name: "rescueActivity",
        component: () => l(() =>
            import ("./rescue_activity.7ba4a53f.js").then(async a => (await a.__tla, a)), ["js/rescue_activity.7ba4a53f.js", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/rescue_activity.f5fd9321.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/promotion-activity/:id",
        name: "promotionActivity",
        component: () => l(() =>
            import ("./promotion_activity.6d0e8067.js").then(async a => (await a.__tla, a)), ["js/promotion_activity.6d0e8067.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@vue.16908cbf.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/promotion_activity.55ffd8aa.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/red-envelopes-activity/:id",
        name: "redEnvelopesActivity",
        component: () => l(() =>
            import ("./redEnvelopes_activity.5a128285.js").then(async a => (await a.__tla, a)), ["js/redEnvelopes_activity.5a128285.js", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/redEnvelopes_activity.761a2e00.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/lucky-wheel-activity/:id",
        name: "luckyWheelActivity",
        component: () => l(() =>
            import ("./lucky_wheel_activity.392c939c.js").then(async a => (await a.__tla, a)), ["js/lucky_wheel_activity.392c939c.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/blank.e4277571.js", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/lucky_wheel_activity.8fab9c04.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/customize-activity/:id",
        name: "customizeActivity",
        component: () => l(() =>
            import ("./customize_activity.4baa87f2.js").then(async a => (await a.__tla, a)), ["js/customize_activity.4baa87f2.js", "js/@vue.16908cbf.js", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/customize_activity.d1bf9898.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/break-through-activity/:id",
        name: "breakThroughActivity",
        component: () => l(() =>
            import ("./break_through_activity.8113933d.js").then(async a => (await a.__tla, a)), ["js/break_through_activity.8113933d.js", "js/@vue.16908cbf.js", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/break_through_activity.6b8170a2.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/balance-relief-fund-activity/:id",
        name: "balanceReliefFundActivity",
        component: () => l(() =>
            import ("./balance_relief_fund_activity.5964c8d9.js").then(async a => (await a.__tla, a)), ["js/balance_relief_fund_activity.5964c8d9.js", "js/betAndRecharge.31160ca3.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/balance_relief_fund_activity.17257878.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/security-center",
        name: "securityCenter",
        component: () => l(() =>
            import ("./index.e5bb5409.js").then(async a => (await a.__tla, a)), ["js/index.e5bb5409.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/vue-router.d17f0860.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.d17a8e28.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 3
        }
    }, {
        path: "/agent",
        name: "agent",
        component: () => l(() =>
            import ("./index.9b124c79.js").then(async a => (await a.__tla, a)), ["js/index.9b124c79.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.d57064ef.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 3
        }
    }, {
        path: "/agent-record",
        name: "agentRecord",
        component: () => l(() =>
            import ("./collect_record.f381bd62.js").then(async a => (await a.__tla, a)), ["js/collect_record.f381bd62.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/blank.e4277571.js", "js/vuex.7fead168.js", "js/xe-utils.0e898ace.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/collect_record.8ebe97ec.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/exchange-record-detail",
        name: "exchangeRecordDetail",
        component: () => l(() =>
            import ("./exchange_record_detail.fe99d5ee.js").then(async a => (await a.__tla, a)), ["js/exchange_record_detail.fe99d5ee.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/clipboard.f53621db.js", "js/UnionBank.d4b4f5ae.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/exchange_record_detail.76e17d88.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/check-record-detail",
        name: "checkRecordDetail",
        component: () => l(() =>
            import ("./check_detail.bba65194.js").then(async a => (await a.__tla, a)), ["js/check_detail.bba65194.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/check_detail.4a9f7eb9.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/message-center",
        name: "messageCenter",
        component: () => l(() =>
            import ("./index.840dfdb9.js").then(async a => (await a.__tla, a)), ["js/index.840dfdb9.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-router.d17f0860.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.bfd62a14.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 3
        }
    }, {
        path: "/maintain",
        name: "maintain",
        component: () => l(() =>
            import ("./index.fe0916c0.js").then(async a => (await a.__tla, a)), ["js/index.fe0916c0.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.c429618b.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            noHeader: !0,
            depIndex: 100
        }
    }, {
        path: "/promotion/rebate-detail",
        name: "rebateDetail",
        component: () => l(() =>
            import ("./index.e9e514e1.js").then(async a => (await a.__tla, a)), ["js/index.e9e514e1.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/blank.e4277571.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.7bf926f8.css"]),
        meta: {
            bottomMenu: !0,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }, {
        path: "/dealer",
        name: "dealer",
        component: () => l(() =>
            import ("./index.d3ff5289.js").then(async a => (await a.__tla, a)), ["js/index.d3ff5289.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.bdf0f429.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/dealer-tutorial",
        name: "dealerTutorial",
        component: () => l(() =>
            import ("./dealer_tutorial.61295bda.js").then(async a => (await a.__tla, a)), ["js/dealer_tutorial.61295bda.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/dealer_tutorial.53b137f2.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/complaint",
        name: "complaint",
        component: () => l(() =>
            import ("./index.110ea741.js").then(async a => (await a.__tla, a)), ["js/index.110ea741.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/dark_arrow.3f22666d.js", "js/blank.e4277571.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.6eb6876c.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !0,
            depIndex: 100
        }
    }, {
        path: "/:error*",
        name: "404",
        component: () => l(() =>
            import ("./index.f261bf11.js"), ["js/index.f261bf11.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "css/index.fd692215.css"]),
        meta: {
            bottomMenu: !1,
            headerMenu: !1,
            needLogin: !1,
            depIndex: 100
        }
    }], x = ri({
        history: oi(),
        routes: ue
    }), x.beforeEach(async (a, e, t) => {
        a.meta.depIndex > e.meta.depIndex ? s.state.transitionName = "slide-right" : a.meta.depIndex < e.meta.depIndex ? s.state.transitionName = "slide-left" : s.state.transitionName = "slide-right";
        let n = h() && h().agentCode,
            o = h() && h().fb_dynamic_pixel,
            m = h() && h().kwaiPixelBaseCode,
            k = h() && h().tt_pixel,
            g = h() && h().bigoAds_pixel,
            P = h() && h().rand,
            w = h() && h().gtagId,
            f = h() && h().dealerCode,
            R = h() && h().id,
            L = h() && h().channelId,
            Q = h() && h().fbclid,
            Y = h() && h().domain,
            V = h() && h().utm_medium,
            ea = h() && h().utm_source,
            X = h() && h().utm_id,
            Ca = h() && h().utm_content,
            Ta = h() && h().utm_term,
            Ba = h() && h().utm_campaign;
        if (a.meta.needLogin && !N()) return s.state.showLoginDialog = !0, t(e.fullPath); {
            if (a.meta.bottomMenu && globalVBus.$emit("changeMenu", a.name), a.query.agentCode || a.query.fb_dynamic_pixel || a.query.kwaiPixelBaseCode || a.query.dealerCode || a.query.gtagId || a.query.tt_pixel || a.query.bigoAds_pixel || a.query.id || a.query.rand || a.query.channelId || a.query.fbclid || a.query.domain || a.query.utm_medium || a.query.utm_source || a.query.utm_id || a.query.utm_content || a.query.utm_term || a.query.utm_campaign) return t();
            let u = { ...a.query
            };
            return !a.query.id && R && (u = Object.assign(u, {
                id: R
            })), !a.query.agentCode && n && (u = Object.assign(u, {
                agentCode: n
            })), !a.query.dealerCode && f && (u = Object.assign(u, {
                dealerCode: f
            })), !a.query.fb_dynamic_pixel && o && (u = Object.assign(u, {
                fb_dynamic_pixel: o
            })), !a.query.kwaiPixelBaseCode && m && (u = Object.assign(u, {
                kwaiPixelBaseCode: m
            })), !a.query.tt_pixel && k && (u = Object.assign(u, {
                tt_pixel: k
            })), !a.query.bigoAds_pixel && g && (u = Object.assign(u, {
                bigoAds_pixel: g
            })), !a.query.gtagId && w && (u = Object.assign(u, {
                gtagId: w
            })), !a.query.rand && P && (u = Object.assign(u, {
                rand: P
            })), !a.query.channelId && L && (u = Object.assign(u, {
                channelId: L
            })), !a.query.fbclid && Q && (u = Object.assign(u, {
                fbclid: Q
            })), !a.query.domain && Y && (u = Object.assign(u, {
                domain: Y
            })), !a.query.utm_medium && V && (u = Object.assign(u, {
                utm_medium: V
            })), !a.query.utm_source && ea && (u = Object.assign(u, {
                utm_source: ea
            })), !a.query.utm_id && X && (u = Object.assign(u, {
                utm_id: X
            })), !a.query.utm_content && Ca && (u = Object.assign(u, {
                utm_content: Ca
            })), !a.query.utm_term && Ta && (u = Object.assign(u, {
                utm_term: Ta
            })), !a.query.utm_campaign && Ba && (u = Object.assign(u, {
                utm_campaign: Ba
            })), u.agentCode || u.fb_dynamic_pixel || u.kwaiPixelBaseCode || u.gtagId || u.dealerCode || u.tt_pixel || u.bigoAds_pixel || u.id || u.rand || u.channelId || u.fbclid || u.domain || u.utm_medium || u.utm_source || u.utm_id || u.utm_content || u.utm_term || u.utm_campaign ? t({
                path: a.path,
                query: u
            }) : t()
        }
    }), x.afterEach(async (a, e) => {
        if (a.name === "game" ? s.state.inGamePage = !0 : s.state.inGamePage = !1, e.name === "game" && N() && (await s.dispatch("refreshGameBalance", e.params.id), await s.dispatch("getReliefCheck"), s.state.isMobile)) try {
            ln()
        } catch {}
        if (a.path === "/promotion/event" || a.path === "/promotion/task" || a.path === "/promotion/rebate" || a.path === "/promotion/fees" || a.path === "/promotion/records") {
            if (s.state.moduleList.find(t => t.alias == "task") && a.path === "/promotion/task" || s.state.moduleList.find(t => t.alias == "rebate") && a.path === "/promotion/rebate") return;
            setTimeout(() => {
                globalVBus.$emit("changeMenu", "promotion")
            })
        }
    });
    let ca, z;
    ({
        t: ca
    } = ia.global), z = ii({
        state: {
            accountInfo: {},
            balance: {},
            metaConfig: "",
            isApp: !1,
            isAndroid: !1,
            isProgress: !0,
            showLoginDialog: !1,
            loginType: "login",
            area: "",
            moduleList: [],
            decorators: {},
            downloadBar: [],
            sections: {},
            offerTypes: {},
            logos: [],
            festivalStyle: "",
            techSupport: "",
            layoutMode: "",
            modifyAddressInfo: "",
            vipList: [],
            vipOnOffs: [],
            vipDetail: "",
            language: "en",
            scrollTop: 0,
            tableList: [],
            showSideBar: !1,
            network: 0,
            activeTab: 0,
            popNoticeList: [],
            showConfirmDialog: !1,
            showAlertDialog: !1,
            hideNewTaskDialog: !1,
            maintainContent: "",
            isMobile: !1,
            timeZone: "",
            endMs: 0,
            currency: "",
            badge: {},
            showNewbieBonusDialog: !1,
            promotionId: "",
            showMusicList: !1,
            musicInfo: {
                allList: [],
                currentMusic: "",
                downloadList: [],
                cycleType: "cycle",
                playStatus: !1
            },
            agentAd: !1,
            customerConfig: {},
            scatter: {},
            popStep: 1,
            btnLoading: !1,
            showDealerJoinDialog: !1,
            dealerApplyData: "",
            showRechargeDialog: !1,
            showRechargeRecordDialog: !1,
            appDownloadDialog: !1,
            appDownloadInfo: "",
            transitionName: "",
            skinBg: 1,
            eventPageScrollTop: 0,
            inGamePage: !1
        },
        mutations: {
            clearAccountInfo(a) {
                a.accountInfo = {}, a.balance = {}, a.vipDetail = "", globalVBus.$emit("clearMessageNum"), x.push("/index")
            }
        },
        getters: {},
        actions: {
            getMetas: async function(a, e) {
                let t = e || "taskRewardType,coinTradeType,timeType,language,country,gender,currency,vipRewardType,auditStatus,gameVendor,coinTradeType,metaConfig,gameType,incomeTransType,imVendor,imType,verifyStatus";
                await I.get("/user/common/metas", {
                    types: t
                }).then(n => {
                    n && n.status === "OK" && (this.state.metaConfig = n.data)
                })
            },
            getUserInfo: async function() {
                await I.get("/user/user/detail").then(a => {
                    a && a.code === 0 && (this.state.accountInfo = a.data, localStorage.setItem("userInfo", JSON.stringify(a.data)))
                })
            },
            clearUserInfo: async function() {
                localStorage.removeItem("token"), localStorage.removeItem("userInfo"), this.state.accountInfo = {}, this.state.showLoginDialog = !0, this.state.vipDetail = "", x.push("/index")
            },
            getVipList: async function() {
                await I.get("/user/vip/list").then(a => {
                    a.code === 0 && (this.state.vipList = a.data.vips, this.state.vipOnOffs = a.data.vipOnOffs)
                })
            },
            getUserVipDetail: async function() {
                await I.get("/user/vip/user").then(a => {
                    a.code === 0 && (this.state.vipDetail = a.data)
                })
            },
            refreshGameBalance: async function(a, e) {
                await I.post("/game/game/quit", {
                    id: e
                }).then(t => {
                    t.code === 0 && (this.state.balance.coinActiveAmount = t.data.total)
                })
            },
            refreshBalance: async function(a, e) {
                let t = e ? {
                    recycle: 2
                } : "";
                t ? dn(t) : await I.get("/game/game/account", t).then(n => {
                    n && n.code === 0 && (this.state.balance.coinActiveAmount = n.data.total)
                })
            },
            getNoticeList: async function(a) {
                await I.get("/user/msg/popup").then(e => {
                    if (e.code === 0 && e.data) {
                        let t = e.data.list || [],
                            n = localStorage.getItem("noticeList");
                        if (!t) return a.state.popStep = 2;
                        n ? (t.forEach(o => {
                            let m = JSON.parse(n).find(k => k.msgId === o.msgId);
                            if (m) {
                                if (m.updateTime === o.updateTime && m.popUp === 1 && o.popUp === 1) return;
                                this.state.popNoticeList.push({ ...o,
                                    show: !0
                                })
                            } else this.state.popNoticeList.push({ ...o,
                                show: !0
                            })
                        }), this.state.popNoticeList.length || (a.state.popStep = 2)) : this.state.popNoticeList = t.map(o => ({ ...o,
                            show: !0
                        })), localStorage.setItem("noticeList", JSON.stringify(t))
                    } else a.state.popStep = 2
                }).catch(() => {
                    a.state.popStep = 2
                })
            },
            getAppConfig: function() {
                I.get("/user/app/config").then(a => {
                    const {
                        data: e,
                        status: t
                    } = a;
                    if (t === "OK") {
                        const {
                            region: n,
                            timeZone: o
                        } = e;
                        this.state.timeZone = o, n ? x.currentRoute.value.name === "limit" && x.push("/") : x.push("/limit")
                    }
                })
            },
            getBadge: function() {
                N() && I.get("/user/msg/unreadNum").then(a => {
                    a.status === "OK" && (this.state.badge.event = a.data.PROMOTION, this.state.badge.task = a.data.TASK, this.state.badge.message = a.data.MSG, this.state.badge.unclaimed = a.data.UNCLAIMED, this.state.badge.vip = a.data.VIP, this.state.badge.fees = a.data.INCOME_BOX, this.state.badge.dealer = a.data.DEALER)
                })
            },
            logOut: async function() {
                await ae(ca("mine.tips1"), ca("mine.tips"), () => {}, async () => {
                    await I.get("/user/user/logout"), z.state.popStep = 1, localStorage.removeItem("userInfo"), localStorage.removeItem("rechargeOrderNo"), N(null), z.commit("clearAccountInfo"), z.state.vipDetail = {
                        currentAmount: 0,
                        lastMonthAmount: 0,
                        totalRecharge: 0,
                        activeAmount: 0,
                        currentRecharge: 0
                    }, z.state.popNoticeList = [], z.state.balance.coinActiveAmount = 0, z.state.badge = {}, x.push("/index")
                }, {
                    confirmText: ca("common.cancel"),
                    cancelText: ca("common.confirm")
                })
            },
            getReliefCheck: async () => {
                x.currentRoute.value.name !== "game" && N() && await I.get("/user/promotion/reliefCheck").then(a => {
                    a.status === "OK" ? a.data && a.data.pollTime > 0 && setTimeout(() => {
                        z.dispatch("getReliefCheck")
                    }, a.data.pollTime) : setTimeout(() => {
                        z.dispatch("getReliefCheck")
                    }, 5e3)
                })
            }
        }
    }), s = z;
    const Yt = {
            class: "custom-message"
        },
        $t = {
            class: "text"
        },
        Xt = {
            __name: "index",
            props: {
                message: String,
                type: {
                    type: String,
                    default: "info"
                }
            },
            setup(a) {
                const e = a,
                    t = H(!0);
                $e(() => e.message, (o, m) => {
                    o !== m && n()
                });
                const n = () => {
                    t.value = !0, Xe(() => {
                        setTimeout(() => {
                            t.value = !1
                        }, 3e3)
                    })
                };
                return (o, m) => {
                    const k = Qa("svg-icon");
                    return A(), O(tt, {
                        name: "custom-message-fade"
                    }, {
                        default: Oa(() => [at(T("div", Yt, [U(k, {
                            iconClass: e.type
                        }, null, 8, ["iconClass"]), T("span", $t, ba(a.message), 1)], 512), [
                            [et, t.value]
                        ])]),
                        _: 1
                    })
                }
            }
        };
    let ge, pe, qa, Ha, oa;
    ee = (a, e) => {
        const t = a.__vccOpts || a;
        for (const [n, o] of e) t[n] = o;
        return t
    }, ge = ["xlink:href"], pe = {
        __name: "index",
        props: {
            iconClass: {
                type: String,
                required: !0
            },
            className: {
                type: String,
                default: () => ""
            }
        },
        setup(a) {
            const e = a,
                t = ka(() => `#icon-${e.iconClass}`),
                n = ka(() => e.className ? "svg-icon " + e.className : "svg-icon");
            return (o, m) => (A(), F("svg", {
                class: sa(n.value),
                width: "1em",
                height: "1em",
                fill: "currentColor",
                "aria-hidden": "true",
                focusable: "false"
            }, [T("use", {
                "xlink:href": t.value
            }, null, 8, ge)], 2))
        }
    }, qa = ee(pe, [
        ["__scopeId", "data-v-63655f90"]
    ]), Ha = a => {
        a.component("svg-icon", qa)
    }, oa = H([]);
    let an = 0;
    const en = (a, e = "info") => {
            const t = an++,
                n = fa(Xt, {
                    message: a,
                    type: e
                }).use(Ha),
                o = document.createElement("div");
            document.body.appendChild(o), n.mount(o), oa.value.push({
                id: t,
                instance: n
            }), setTimeout(() => {
                tn(t)
            }, 3e3)
        },
        tn = a => {
            const e = oa.value.findIndex(t => t.id === a);
            e !== -1 && (oa.value[e].instance.unmount(), document.body.removeChild(oa.value[e].instance._container), oa.value.splice(e, 1))
        },
        {
            t: v
        } = ia.global;
    ma = function() {
        let a = navigator.userAgent;
        return ["Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"].filter(e => a.includes(e)), s.state.isMobile = !0, s.state.isMobile
    }, aa = function(a, e = "warning", t) {
        ma() ? en(a, e) : di({
            showClose: !0,
            message: a,
            type: e,
            appendTo: t || document.body
        })
    }, ae = function(a, e = v("common.tips"), t, n = () => {}, o = {
        confirmText: v("common.confirm"),
        cancelText: v("common.cancel")
    }) {
        globalVBus.$emit("handleConfirm", a, e, o, t, n)
    }, la = function(a = "", e = {
        btnText: v("common.confirm"),
        confirmFun: () => {},
        showClose: !1
    }) {
        typeof e == "string" ? e = {
            btnText: e,
            confirmFun: () => {},
            showClose: !1
        } : typeof e == "function" && (e = {
            btnText: v("common.confirm"),
            confirmFun: e,
            showClose: !1
        }), globalVBus.$emit("handleAlert", a, e)
    };

    function nn() {
        /iphone|ipod|ipad/i.test(navigator.appVersion) && document.addEventListener("blur", a => {
            a.target.localName === "input" && setTimeout(() => {
                document.body.scrollIntoView(!1)
            }, 200)
        }, !0)
    }
    na = function(a, e = "yyyy-MM-DD") {
        xa(a) !== "date" && (/^-*\d+$/.test(a == null ? void 0 : a.toString()) ? a = new Date(+a) : a = a && new Date(a.toString().replace(/\//g, "-")) || new Date);
        const t = (m, k) => {
                for (let g = 0, P = k - (m + "").length; g < P; g++) m = "0" + m;
                return m + ""
            },
            n = a,
            o = ["\u65E5", "\u4E00", "\u4E8C", "\u4E09", "\u56DB", "\u4E94", "\u516D"];
        return e.replace(/yyyy|YYYY/, n.getFullYear() + "").replace(/yy|YY/, t(n.getFullYear() % 100, 2)).replace(/mm|MM/, t(n.getMonth() + 1, 2)).replace(/m|M/g, n.getMonth() + 1 + "").replace(/dd|DD/, t(n.getDate(), 2)).replace(/d|D/g, n.getDate() + "").replace(/hh|HH/, t(n.getHours(), 2)).replace(/h|H/g, n.getHours() + "").replace(/ii|II/, t(n.getMinutes(), 2)).replace(/i|I/g, n.getMinutes() + "").replace(/ss|SS/, t(n.getSeconds(), 2)).replace(/s|S/g, n.getSeconds() + "").replace(/w/g, n.getDay() + "").replace(/W/g, o[n.getDay()])
    };

    function xa(a) {
        return Object.prototype.toString.call(a).replace(/.*\s|\]/g, "").toLowerCase()
    }
    const _e = a => new Promise(e => {
        const {
            type: t,
            source: n,
            attr: o = {},
            preload: m
        } = a, k = typeof n == "string" ? [n] : n;
        switch (t) {
            case "js":
                Promise.all(k.map(g => new Promise((P, w) => {
                    var R;
                    if (document.querySelector(`script[href='${n}']`)) return P(void 0);
                    const f = document.createElement("script");
                    f.src = g, f.onload = P, f.onerror = w;
                    for (const L in o) f.setAttribute(L, o[L]);
                    (R = document.querySelector("head")) == null || R.appendChild(f)
                }))).then(g => {
                    e(typeof n == "string" ? g[0] : g)
                });
                break;
            case "css":
                Promise.all(k.map(g => new Promise((P, w) => {
                    var R;
                    if (document.querySelector(`link[href='${n}']`)) return P(void 0);
                    const f = document.createElement("link");
                    f.href = g, f.onload = P, f.onerror = w, f.rel = "stylesheet";
                    for (const L in o) f.setAttribute(L, o[L]);
                    (R = document.querySelector("head")) == null || R.appendChild(f)
                }))).then(g => {
                    e(typeof n == "string" ? g[0] : g)
                });
                break;
            case "img":
                Promise.all(k.map(g => new Promise((P, w) => {
                    if (m) {
                        const f = new Image;
                        f.onload = P, f.onerror = w, f.src = g
                    } else {
                        const f = new XMLHttpRequest;
                        f.open("GET", g, !0), f.onreadystatechange = () => {
                            if (f.readyState === 4)
                                if (f.status >= 200 && f.status <= 304) {
                                    const R = new FileReader;
                                    R.onload = L => {
                                        var Q;
                                        P((Q = L.target) == null ? void 0 : Q.result)
                                    }, R.onerror = w, R.readAsDataURL(f.response)
                                } else w(void 0)
                        }, f.responseType = "blob", f.send()
                    }
                }))).then(g => {
                    e(typeof n == "string" ? g[0] : g)
                });
                break
        }
    });
    h = function(a) {
        let e = a || location.href;
        return e.indexOf("#") > -1 ? G.parseUrl(e).hashQuery : G.parseUrl(e).searchQuery
    }, ne = function() {
        return !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)
    }, N = function(a) {
        const e = "token";
        if (a) localStorage.setItem(e, JSON.stringify(a));
        else if (a === null) localStorage.removeItem(e);
        else try {
            return JSON.parse(localStorage.getItem(e))
        } catch {}
        return null
    }, La = function(a, e, t) {
        const n = xa(a);
        if (n !== "object" && n !== "array") return a;
        const o = n === "object" ? {} : [],
            m = Object.keys(a),
            k = Object.values(a);
        for (let g = 0; g < k.length; g++)
            if (n === "object") {
                if (t) {
                    if (typeof e == "string" && m[g] !== e || xa(e) === "regexp" && !e.test(m[g]) || Array.isArray(e) && !e.includes(m[g])) continue
                } else if (typeof e == "string" && m[g] === e || xa(e) === "regexp" && e.test(m[g]) || Array.isArray(e) && e.includes(m[g])) continue;
                o[m[g]] = typeof k[g] == "object" ? La(k[g], e, t) : k[g]
            } else o.push(typeof k[g] == "object" ? La(k[g], e, t) : k[g]);
        return o
    };
    const va = B.enc.Utf8.parse(ce + "uqtUb11w");

    function wa(a, e = "") {
        let t = "";
        const n = B.enc.Utf8.parse(e);
        if (typeof a == "string") {
            const o = B.enc.Utf8.parse(a);
            t = B.AES.encrypt(o, va, {
                iv: n,
                mode: B.mode.CBC,
                padding: B.pad.Pkcs7
            })
        } else if (typeof a == "object") {
            const o = JSON.stringify(a),
                m = B.enc.Utf8.parse(o);
            t = B.AES.encrypt(m, va, {
                iv: n,
                mode: B.mode.CBC,
                padding: B.pad.Pkcs7
            })
        }
        return B.enc.Base64.stringify(t.ciphertext)
    }

    function rn(a, e) {
        let t = B.enc.Utf8.parse(e.substring(4, 20));
        var n = B.AES.decrypt(a, va, {
            iv: t,
            mode: B.mode.CBC,
            padding: B.pad.Pkcs7
        });
        let o = n.toString(B.enc.Utf8).trim();
        if (/^{/.test(o)) return o;
        var m = B.AES.decrypt(o.replace('"', ""), va, {
            iv: t,
            mode: B.mode.CBC,
            padding: B.pad.Pkcs7
        });
        return m.toString(B.enc.Utf8).trim()
    }

    function on(a) {
        return Object.freeze(a), a
    }

    function he() {
        return on(Array.from({
            length: 26
        }).fill(65).map((a, e) => String.fromCharCode(a + e)))
    }
    const be = `0123456789${he().join("").toLowerCase()}${he().join("")}`;

    function sn(a = 24) {
        return Array.from({
            length: a
        }).map(() => be[Math.floor(Math.random() * be.length)]).join("")
    }
    Qt = function(a) {
        const e = [],
            t = parseInt(a / 864e5 + "", 10);
        t && (a -= t * 24 * 60 * 60 * 1e3, e.push(t + v("common.day")));
        const n = parseInt(a / (60 * 60 * 1e3) + "", 10);
        n && (a -= n * 60 * 60 * 1e3, e.push(n + v("common.hour")));
        const o = parseInt(a / (60 * 1e3) + "", 10);
        o && (a -= o * 60 * 1e3, e.push(o + v("common.minutes")));
        const m = parseInt(a / 1e3 + "", 10);
        return (m || +m == 0) && e.push(m + v("common.second")), e.join("")
    }, qt = function(a) {
        if (a < 1e3) return "00:00";
        const e = [];
        let t = parseInt(a / (24 * 60 * 60 * 1e3) + "", 10);
        t && (a -= t * 24 * 60 * 60 * 1e3, e.push(t + "d "));
        let n = parseInt(a / (60 * 60 * 1e3) + "", 10);
        n && (a -= n * 60 * 60 * 1e3, n < 10 && (n = "0" + n), e.push(n + ":"));
        let o = parseInt(a / (60 * 1e3) + "", 10);
        o ? (a -= o * 60 * 1e3, o < 10 && (o = "0" + o), e.push(o + ":")) : e.push("00:");
        let m = parseInt(a / 1e3 + "", 10);
        return (m || +m == 0) && (m < 10 && (m = "0" + m), e.push(m)), e.join("")
    }, ut = function(a) {
        let e;
        switch (Number(a)) {
            case 1:
                e = na(G.getWhatDay(new Date, 0, "first"), "YYYY-MM-DD");
                break;
            case 2:
                e = na(G.getWhatDay(new Date, -1, "first"), "YYYY-MM-DD");
                break;
            case 3:
                e = na(G.getWhatDay(new Date, -6, "first"), "YYYY-MM-DD");
                break;
            case 4:
                e = na(G.getWhatDay(new Date, -14, "first"), "YYYY-MM-DD");
                break;
            case 5:
                e = na(G.getWhatDay(new Date, -29, "first"), "YYYY-MM-DD");
                break
        }
        return e
    }, Ft = function(a) {
        switch (a.redirect) {
            case 0:
                break;
            case 1:
                let e = a.redirectUrl;
                e.indexOf("http") === -1 && (e = "http://" + e), window.open(e, "new");
                break;
            case 2:
                try {
                    let t = JSON.parse(a.redirectUrl),
                        n = {
                            type: t.promotionType,
                            id: t.promotionId,
                            remark: t.promotionUrl
                        };
                    ie(n)
                } catch {}
                break;
            case 3:
                x.push("/promotion/task");
                break;
            case 4:
                x.push("/promotion/rebate");
                break;
            case 5:
                x.push("/agent");
                break;
            case 6:
                x.push("/promotion/vip");
                break;
            case 7:
                x.push("/promotion/fees");
                break
        }
    };

    function ke() {
        let a = 0 - new Date().getTimezoneOffset(),
            e = Math.ceil(a / 60);
        e >= 0 ? e < 10 ? e = "+0" + e : e = "+" + e : e > -10 && (e = "-0" + Math.abs(e));
        let t = a % 60;
        return t == 0 ? e : (t = Math.abs(t) > 10 ? Math.abs(t) : "0" + Math.abs(t), e + ":" + t)
    }
    Bt = function(a, e = !1, t = 2) {
        let n = "" + a;
        if (n = n.replace(/[^\d.]/g, "").replace(/\.{2,}/g, ".").replace(/^\./g, "").replace(".", "$#$").replace(/\./g, "").replace("$#$", "."), n.indexOf(".") < 0 && n !== "") n = parseFloat(n) + "";
        else if (n.indexOf(".") >= 0 && !e) {
            let m = "";
            for (var o = 0; o < t; o++) m += "\\d";
            let k = new RegExp("^()*(\\d+)\\.(" + m + ").*$");
            n = n.replace(k, "$1$2.$3")
        }
        return n
    }, vt = function(...a) {
        let e = new W(a[0]);
        for (let t = 1; t < a.length; t++) e = e.add(new W(a[t]));
        return e.toNumber()
    }, Gt = function(...a) {
        let e = new W(a[0]);
        for (let t = 1; t < a.length; t++) e = e.sub(new W(a[t]));
        return e.toNumber()
    }, It = function(...a) {
        let e = new W(a[0]);
        for (let t = 1; t < a.length; t++) e = e.mul(new W(a[t]));
        return e.toNumber()
    }, Ct = function(...a) {
        let e = new W(a[0]);
        for (let t = 1; t < a.length; t++) e = e.div(new W(a[t]));
        return e.toNumber()
    }, Mt = function(a) {
        return a.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    }, zt = function(a, e = 2) {
        return new W(a).toFixed(e, W.ROUND_DOWN).toString().replace(".", ",")
    }, Lt = function(a) {
        for (var e = a.split(" "), t = 0; t < e.length; t++) e[t] = e[t].slice(0, 1).toUpperCase() + e[t].slice(1).toLowerCase();
        return e.join(" ")
    }, Ot = function(a) {
        if (!s.state.tableList.length) return;
        let e = {},
            t = "",
            n = "";
        switch (Number(a)) {
            case 1:
                s.state.layoutMode === 1 ? (t = "cartas", n = "cartas_active") : s.state.layoutMode === 2 && (t = "cartas_2", n = "cartas_active_green");
                break;
            case 2:
                s.state.layoutMode === 1 ? (t = "pescaria", n = "pescaria_active") : s.state.layoutMode === 2 && (t = "pescaria_2", n = "pescaria_active_green");
                break;
            case 3:
                console.log(112), s.state.layoutMode === 1 ? (t = "slots", n = "slots_active") : s.state.layoutMode === 2 && (t = "slots_2", n = "slots_active_green");
                break;
            case 4:
                console.log(113), s.state.layoutMode === 1 ? (t = "esport", n = "esport_active") : s.state.layoutMode === 2 && (t = "esport_2", n = "esport_active_green");
                break;
            case 5:
                s.state.layoutMode === 1 ? (t = "cassino", n = "cassino_active") : s.state.layoutMode === 2 && (t = "cassino_2", n = "cassino_active_green");
                break;
            case 0:
                s.state.layoutMode === 1 ? (t = "hot", n = "hot_active") : s.state.layoutMode === 2 && (t = "hot_2", n = "hot_active");
                break;
            case 98:
                t = "recent", n = "recent_active";
                break;
            case 99:
                t = "collect", n = "collect_active";
                break;
            default:
                s.state.layoutMode === 1 ? (t = "slots", n = "slots_active") : s.state.layoutMode === "green" && (t = "slots_green", n = "slots_active_green");
                break
        }
        return e[a] = {
            icon: t,
            active: n
        }, e[a]
    }, ja = function() {
        let a = "";
        return s.state.metaConfig.currency.forEach(e => {
            switch (e.value) {
                case "USD":
                    a = "USD";
                    break;
                case "BRL":
                    a = "R$";
                    break;
                case "MYR":
                    a = "RM";
                    break;
                case "PHP":
                    a = "\u20B1";
                    break;
                case "IDR":
                    a = "Rp";
                    break;
                default:
                    a = "USD";
                    break
            }
        }), a
    }, Wt = function() {
        let a = {};
        return s.state.metaConfig.currency.forEach(e => {
            let t = "";
            switch (e.value) {
                case "USD":
                    t = "usd";
                    break;
                case "BRL":
                    t = "brl";
                    break;
                case "PH":
                    text = "php";
                    break;
                case "ID":
                    text = "idr";
                    break;
                case "MYR":
                    t = "myr";
                    break;
                default:
                    t = "usd";
                    break
            }
            a[e.value] = t
        }), new URL("/img/default/" + a[s.state.metaConfig.currency[0].value] + ".png",
            import.meta.url).href
    }, Kt = function(a) {
        let e = {};
        if (s.state.metaConfig) return s.state.metaConfig.country.forEach(t => {
            let n = "";
            switch (t.value) {
                case "USD":
                    n = "usd";
                    break;
                case "BR":
                    a ? n = "br_mine" : n = "br";
                    break;
                case "PH":
                    a ? n = "ph_mine" : n = "ph";
                    break;
                case "ID":
                    a ? n = "idn_mine" : n = "idn";
                    break;
                case "MYR":
                    n = "myr";
                    break;
                default:
                    n = "br";
                    break
            }
            e[t.value] = n
        }), new URL("/img/country/" + e[s.state.metaConfig.country[0].value] + ".png",
            import.meta.url).href
    }, Et = function() {
        if (s.state.metaConfig) return new URL("/img/language/" + s.state.language + ".png",
            import.meta.url).href
    }, dt = function(a) {
        let e = a || document.documentElement;
        document.documentElement.requestFullscreen ? e.requestFullscreen() : document.documentElement.mozRequestFullScreen ? e.mozRequestFullScreen() : document.documentElement.webkitRequestFullScreen ? e.webkitRequestFullScreen() : document.documentElement.msRequestFullscreen && elem.msRequestFullscreen()
    };

    function ln() {
        if (document.fullscreenElement !== null)
            if (document.exitFullscreen) try {
                document.exitFullscreen()
            } catch {} else document.webkitExitFullscreen ? document.webkitExitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen && document.mozCancelFullScreen()
    }
    jt = function(a) {
        return [{
            label: v("footer.funcList.reward"),
            value: 0
        }, {
            label: v("footer.funcList.rebate"),
            value: 1
        }, {
            label: v("footer.funcList.vip"),
            value: 2
        }, {
            label: v("footer.funcList.agent"),
            value: 3
        }, {
            label: v("footer.funcList.event"),
            value: 4
        }, {
            label: v("footer.funcList.task"),
            value: 5
        }].find(e => e.value === a).label
    }, Nt = function(a) {
        return [{
            label: v("footer.gameList.hot"),
            value: 0
        }, {
            label: v("footer.gameList.card"),
            value: 1
        }, {
            label: v("footer.gameList.fish"),
            value: 2
        }, {
            label: v("footer.gameList.digital"),
            value: 3
        }, {
            label: v("footer.gameList.sports"),
            value: 4
        }, {
            label: v("footer.gameList.live"),
            value: 5
        }, {
            label: v("footer.gameList.recent"),
            value: 98
        }, {
            label: v("footer.gameList.collect"),
            value: 99
        }].find(e => e.value === a).label
    }, Vt = function(a) {
        return [{
            label: v("footer.supportList.support"),
            value: 0
        }, {
            label: v("footer.supportList.advise"),
            value: 1
        }, {
            label: v("footer.supportList.faq"),
            value: 2
        }].find(e => e.value === a).label
    }, Ut = function(a) {
        if (!N()) {
            s.state.loginType = "login", s.state.showLoginDialog = !0;
            return
        }
        if (a.maintain === 1) return aa(v("home.maintain"));
        if (a.minEntry > s.state.balance.coinActiveAmount) {
            la(v("home.limitAmountTips", {
                currency: ja(),
                balance: a.minEntry
            }), {
                btnText: v("recharge.recharge_now"),
                confirmFun: () => {
                    s.state.showRechargeDialog = !0
                },
                showClose: !0
            });
            return
        }
        x.push({
            name: "game",
            params: {
                id: a.id
            },
            query: {
                type: a.type,
                vendorId: a.vendor,
                name: a.name
            }
        })
    }, Ht = function(a) {
        const e = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
        let t = a,
            n = 0;
        for (; t >= 1024 && n < e.length - 1;) t /= 1024, n++;
        return t = Math.round(t * 100) / 100, `${t} ${e[n]}`
    }, ie = function(a) {
        console.log(a), a.type === 1 ? x.push({
            name: "rechargeActivity",
            params: {
                id: a.id
            }
        }) : a.type === 2 ? x.push({
            name: "betActivity",
            params: {
                id: a.id
            }
        }) : a.type === 3 ? x.push({
            name: "signInActivity",
            params: {
                id: a.id
            }
        }) : a.type === 4 ? x.push({
            name: "rescueActivity",
            params: {
                id: a.id
            }
        }) : a.type === 7 ? x.push({
            name: "promotionActivity",
            params: {
                id: a.id
            }
        }) : a.type === 6 ? x.push({
            name: "redEnvelopesActivity",
            params: {
                id: a.id
            }
        }) : a.type === 5 ? x.push({
            name: "luckyWheelActivity",
            params: {
                id: a.id
            }
        }) : a.type === 8 ? (s.state.showNewbieBonusDialog = !0, s.state.promotionId = a.id) : a.type === 9 ? a.remark ? window.open(a.remark, "_blank") : x.push({
            name: "customizeActivity",
            params: {
                id: a.id
            }
        }) : a.type === 10 || a.type === 11 ? x.push({
            name: "breakThroughActivity",
            params: {
                id: a.id
            }
        }) : a.type === 12 && x.push({
            name: "balanceReliefFundActivity",
            params: {
                id: a.id
            }
        })
    };
    const dn = G.throttle(function(a) {
        I.get("/game/game/account", a).then(e => {
            e && e.code === 0 && (s.state.balance.coinActiveAmount = e.data.total)
        })
    }, 3e3, {
        leading: !0,
        trailing: !1
    });
    re = function() {
        const a = navigator.userAgent;
        let e = !1;
        return /Chrome\/\d+/.test(a) && (window.chrome || globalThis.chrome) ? (console.log("\u6D4F\u89C8\u5668\u4F7F\u7528\u7684\u662FBlink\u5185\u6838\uFF08\u8C37\u6B4C\u5185\u6838\uFF09"), e = !0) : /AppleWebKit\/\d+/.test(a) && !/Chrome\/\d+/.test(a) && /Safari\/\d+/.test(a) ? (console.log("\u6D4F\u89C8\u5668\u4F7F\u7528\u7684\u662FWebKit\u5185\u6838\uFF08\u82F9\u679C\u5185\u6838\uFF09"), e = !0) : (e = !1, console.log("\u65E0\u6CD5\u786E\u5B9A\u6D4F\u89C8\u5668\u5185\u6838\uFF0C\u6216\u4F7F\u7528\u7684\u662F\u5176\u4ED6\u5185\u6838")), e
    }, da = function() {
        let a = "",
            e = 1;
        switch (s.state.layoutColor) {
            case 1:
                a = "bvlgari";
                break;
            case 2:
                a = "aston_martin";
                break;
            case 3:
                a = "IWC";
                break;
            case 4:
                a = "facebook_green";
                break;
            case 5:
                a = "elsa_schiaparelli";
                break;
            case 6:
                a = "burgundy";
                break;
            case 7:
                a = "tom_ford";
                break;
            case 8:
                a = "versace";
                break;
            case 9:
                a = "SK-Il";
                break;
            case 10:
                a = "dior_blue";
                break;
            case 11:
                a = "facebook_blue";
                break;
            case 12:
                a = "aston_martin";
                break;
            case 13:
                a = "chivas_regal_blue";
                break;
            case 14:
                a = "hermes_orange";
                break;
            case 15:
                a = "usdt_green";
                break;
            case 16:
                a = "patek_philippe_light_brown";
                break;
            case 17:
                a = "louis_vuitton_brown";
                break;
            case 18:
                a = "ebay_purple";
                break;
            case 19:
                a = "corum_blue";
                break;
            case 20:
                a = "twitter_blue";
                break;
            case 21:
                a = "gucci_green_gold";
                break;
            case 22:
                a = "la_mer_green";
                break;
            case 23:
                a = "porsche_yellow_green";
                break;
            case 24:
                a = "bvlgari_brown";
                break;
            case 25:
                a = "prada_black";
                break;
            case 26:
                a = "bottega_veneta_ash";
                break;
            case 27:
                a = "microsoft_red";
                break;
            case 28:
                a = "armani_black_red";
                break;
            case 29:
                a = "roger_dubuis_black_gold";
                break;
            case 30:
                a = "embraer_blue";
                break;
            case 31:
                a = "ferrari_black_yellow";
                break;
            case 32:
                a = "lacoste_green";
                break;
            case 33:
                a = "victoria_secret_red";
                break;
            case 34:
                a = "lancome_peach";
                break;
            case 35:
                a = "anna_sui_purple";
                break;
            case 36:
                a = "bottega_veneta_green";
                break;
            case 37:
                a = "furla_blue";
                break;
            case 38:
                a = "cartier_red";
                break;
            case 39:
                a = "estee_lauder_blue";
                break;
            case 40:
                a = "3CE_red";
                break;
            case 41:
                a = "burberry_brown";
                break;
            case 42:
                a = "bordeaux_red";
                break;
            case 43:
                a = "breguet_ash";
                break;
            case 44:
                a = "hermes_brown_orange";
                break;
            case 45:
                a = "fruitz_rosePink", e = 0;
                break;
            case 46:
                a = "LOccitane_blue", e = 0;
                break;
            case 47:
                a = "burberry_midnight_blue_white", e = 0;
                break;
            case 48:
                a = "valentino_dark_green", e = 0;
                break;
            case 49:
                a = "mcLaren_yellow", e = 0;
                break;
            case 50:
                a = "armani_jet_black", e = 0;
                break;
            case 51:
                a = "corum_gray_blue", e = 0;
                break;
            case 52:
                a = "aston_martin_violet", e = 0;
                break;
            case 53:
                a = "carrera_y_carrera_red", e = 0;
                break;
            case 54:
                a = "porsche_forest_green", e = 0;
                break;
            case 55:
                a = "cartier_wine_red", e = 0;
                break;
            case 56:
                a = "estee_lauder_dark_purple_blue", e = 0;
                break;
            case 57:
                a = "gucci_red", e = 0;
                break;
            case 58:
                a = "parmigiani_fleurier_blue", e = 0;
                break;
            case 59:
                a = "roger_vivier_dark_brown", e = 0;
                break;
            case 60:
                a = "prada_brown", e = 0;
                break;
            case 61:
                a = "bulgari_green", e = 0;
                break;
            case 62:
                a = "lanvin_purple", e = 0;
                break;
            case 63:
                a = "montblanc_blue", e = 0;
                break;
            case 64:
                a = "sergio_rossi_brown", e = 0;
                break;
            case 65:
                a = "blue_nile", e = 0;
                break;
            case 66:
                a = "givenchy_gray_green", e = 0;
                break;
            case 67:
                a = "cartier_blue", e = 0;
                break;
            case 68:
                a = "montblanc_red", e = 0;
                break;
            case 69:
                a = "balenciaga_orange", e = 0;
                break;
            case 70:
                a = "louis_vuitton_gray_blue", e = 0;
                break;
            case 71:
                a = "brunello_cucinelli_dark_brown", e = 0;
                break;
            case 72:
                a = "ralph_lauren_brown", e = 0;
                break;
            case 73:
                a = "swarovski_pink", e = 0;
                break;
            case 74:
                a = "boutallion_green", e = 0;
                break;
            case 75:
                a = "oasis_italiana_yellow", e = 0;
                break;
            case 76:
                a = "ghiso_brown", e = 0;
                break;
            case 77:
                a = "chanel_black", e = 0;
                break;
            case 78:
                a = "lalique_red", e = 0;
                break;
            case 79:
                a = "dior_purple", e = 0;
                break;
            case 80:
                a = "tiffany_dark_blue", e = 0;
                break;
            case 81:
                a = "salvatore_ferragamo_green", e = 0;
                break;
            case 82:
                a = "FENDI_blue", e = 0;
                break;
            case 83:
                a = "chaumet_green", e = 0;
                break;
            case 84:
                a = "van_cleef_red", e = 0;
                break;
            case 85:
                a = "gucci_green", e = 0;
                break;
            case 86:
                a = "chopard_red", e = 0;
                break;
            case 87:
                a = "celine_brown", e = 0;
                break;
            case 88:
                a = "cindy_chao_green", e = 0;
                break;
            case 1001:
                a = "dark_green";
                break;
            case 1002:
                a = "royal_blue";
                break;
            case 1003:
                a = "purple_gold";
                break;
            case 1004:
                a = "rust_red";
                break;
            case 1005:
                a = "coffee_brown";
                break;
            case 1006:
                a = "oil_green";
                break;
            case 1007:
                a = "dark_blue";
                break;
            case 1008:
                a = "emerald_green";
                break;
            default:
                a = "bvlgari";
                break
        }
        if (s.state.skinBg = e, s.state.layoutMode === 1) return "skin1/" + a;
        if (s.state.layoutMode === 2) return "skin2/" + a
    }, Zt = G.throttle(function() {
        I.get("/user/app/download").then(a => {
            a && a.status === "OK" && a.data && (s.state.appDownloadDialog = !0, s.state.appDownloadInfo = a.data)
        })
    }, 3e3, {
        leading: !0,
        trailing: !1
    }), Jt = function(a, e = "main-body") {
        setTimeout(() => {
            var o;
            var t = document.getElementsByClassName(e)[0],
                n = (o = t.getElementsByClassName("van-tab")[a]) == null ? void 0 : o.offsetWidth;
            n && (t.getElementsByClassName("van-tabs__line")[0].style.width = n + "px")
        }, 100)
    }, gt = function(a, e) {
        Array.from(a).forEach(t => {
            let n = t.getAttribute("data-src");
            var o = document.createElement("img");
            o.src = n, o.style.display = "none", document.body.appendChild(o), o.onload = function() {
                t.style.backgroundImage = "url(" + n + ") no-repeat", document.body.removeChild(o), e(n)
            }
        })
    }, Rt = function(a) {
        return new URL("/img/vip/img_tpdl-" + a + ".webp",
            import.meta.url).href
    }, ia.global, window.AUTH_PATH = "";
    const Aa = rt.create({
        withCredentials: !0,
        baseURL: "/api",
        timeout: 6e4,
        headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        }
    });
    Aa.interceptors.request.use(async a => {
        let e = Math.floor(new Date().getTime() / 1e3).toString(),
            t = navigator.userAgent.includes("inAndroid") ? wa(e + "/game/Android/1.0.0/main/" + ke()) : wa(e + "/game/WAP/1.0.0/main/" + ke());
        if (a.headers["App-Id"] = t, localStorage.getItem("language") && (a.headers["Accept-Language"] = localStorage.getItem("language")), N() && (a.headers.Authorization = N()), localStorage.getItem("mid") && (a.headers.Mid = localStorage.getItem("mid")), G.locat().searchQuery.encrypt == 1) {
            const n = sn();
            a.headers.Sign = n, a.method === "get" ? (a.params ? a.params = Object.assign(a.params, {
                encrypt: 1
            }) : a.params = {
                encrypt: 1
            }, a.params = {
                body: wa(JSON.stringify(a.params), n)
            }) : (a.data = Object.assign(a.data, {
                encrypt: 1
            }), a.data = {
                body: wa(JSON.stringify(a.data), n)
            })
        }
        return a
    }, a => {
        Promise.reject(a)
    }), Aa.interceptors.response.use(a => {
        globalVBus.$emit("globalLoading", !1);
        const {
            data: e,
            headers: t
        } = a;
        if (!e) return a;
        let n;
        t.sign ? n = JSON.parse(rn(e, t.sign)) : n = e;
        const {
            msg: o,
            status: m,
            callback: k
        } = n;
        return x.currentRoute.value.name !== "game" && a.config.url === "/game/game/play" ? Promise.resolve(n) : (o && (k && k === "alert" ? a.config.url === "/game/game/play" ? la(o, () => {
            e.code === 423 ? s.state.showRechargeDialog = !0 : x.go(-1)
        }) : la(o) : m !== "maintain" && (m === "OK" ? aa(o, "success") : aa(o))), m === "login" ? (s.dispatch("clearUserInfo"), Promise.reject(n)) : m === "frozen" || m === "blocked" ? Promise.reject(n) : (m === "maintain" && (globalVBus.$emit("globalLoading", !1), s.state.maintainContent = n, x.push("/maintain")), Promise.resolve(n)))
    }, a => {
        globalVBus.$emit("globalLoading", !1), a.response || aa(a.message);
        const {
            response: e
        } = a;
        return e && e.data && e.data.msg ? e.data.callback && e.data.callback === "alert" ? la(e.data.msg) : (console.log(e.data.msg), aa(e.data.msg, "error")) : aa(a.message || a.response.status, "error"), e && e.data
    });
    let fe;
    fe = {
        get: (a, e = null, t = {}) => {
            const n = e;
            return Aa.get(a, {
                params: n,
                ...t
            })
        },
        post: (a, e = null, t = {}) => Aa.post(a, e, t)
    }, I = fe;
    const mn = {
            class: "main-content"
        },
        cn = {
            class: "scroll-wrapper"
        },
        un = {
            key: 0,
            class: "festivalBox"
        },
        gn = T("div", {
            class: "festivalBox-leftImg"
        }, null, -1),
        pn = T("div", {
            class: "festivalBox-rightImg"
        }, null, -1),
        _n = [gn, pn],
        hn = {
            class: "animation"
        },
        bn = {
            key: 0,
            class: "loading-overlay"
        },
        kn = T("div", {
            class: "loading-overlay-box"
        }, [T("span")], -1),
        fn = [kn],
        yn = ["src"],
        xn = {
            __name: "App",
            setup(a) {
                const e = si(),
                    t = li(),
                    {
                        locale: n,
                        t: o
                    } = hi(),
                    m = E(() => l(() =>
                        import ("./index.b6c4e289.js").then(async i => (await i.__tla, i)), ["js/index.b6c4e289.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.0d0e2667.css"])),
                    k = E(() => l(() =>
                        import ("./index.aeb7580c.js"), ["js/index.aeb7580c.js", "js/support.52cd5dbc.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "css/index.1841d5ad.css"])),
                    g = E(() => l(() =>
                        import ("./index.8a47f898.js").then(async i => (await i.__tla, i)), ["js/index.8a47f898.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.15b713ea.css"])),
                    P = E(() => l(() =>
                        import ("./index.a9bedf39.js").then(async i => (await i.__tla, i)), ["js/index.a9bedf39.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/xe-utils.0e898ace.js", "js/clipboard.f53621db.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.da4804e4.css"])),
                    w = E(() => l(() =>
                        import ("./confirm.0c476166.js"), ["js/confirm.0c476166.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "css/confirm.07071eb6.css"])),
                    f = E(() => l(() =>
                        import ("./index.d281d6f5.js").then(async i => (await i.__tla, i)), ["js/index.d281d6f5.js", "js/dark_close.53d49d42.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.2c40481f.css"])),
                    R = E(() => l(() =>
                        import ("./index.3c60ed4e.js"), ["js/index.3c60ed4e.js", "js/@vue.16908cbf.js", "css/index.731700ec.css"])),
                    L = E(() => l(() =>
                        import ("./index.2e9dd502.js").then(async i => (await i.__tla, i)), ["js/index.2e9dd502.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.2c26c85b.css"])),
                    Q = E(() => l(() =>
                        import ("./index.78ee1fca.js").then(async i => (await i.__tla, i)), ["js/index.78ee1fca.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js"])),
                    Y = E(() => l(() =>
                        import ("./footer.dafc9156.js").then(async i => (await i.__tla, i)), ["js/footer.dafc9156.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/footer.913dc7b5.css"])),
                    V = E(() => l(() =>
                        import ("./index.4bb7cd3f.js").then(async i => (await i.__tla, i)), ["js/index.4bb7cd3f.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/vue-router.d17f0860.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.71857509.css"])),
                    ea = E(() => l(() =>
                        import ("./index.0f3c2396.js").then(async i => (await i.__tla, i)), ["js/index.0f3c2396.js", "js/vue-router.d17f0860.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.fa354064.css"])),
                    X = E(() => l(() =>
                        import ("./index.dda6051e.js").then(async i => (await i.__tla, i)), ["js/index.dda6051e.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.7065d599.css"])),
                    Ca = E(() => l(() =>
                        import ("./index.3e12b500.js").then(async i => (await i.__tla, i)), ["js/index.3e12b500.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@vue.16908cbf.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.fc06b595.css"])),
                    Ta = E(() => l(() =>
                        import ("./dealer_join_dialog.28b1736b.js").then(async i => (await i.__tla, i)), ["js/dealer_join_dialog.28b1736b.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@vue.16908cbf.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vuex.7fead168.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/dealer_join_dialog.f19e8a24.css"])),
                    Ba = E(() => l(() =>
                        import ("./index_popup.419c10a0.js").then(async i => (await i.__tla, i)), ["js/index_popup.419c10a0.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index_popup.a6248780.css"])),
                    u = E(() => l(() =>
                        import ("./recharge_record_popup.e07ca08d.js").then(async i => (await i.__tla, i)), ["js/recharge_record_popup.e07ca08d.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vuex.7fead168.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/recharge_record_popup.84d15015.css"])),
                    Cn = E(() => l(() =>
                        import ("./index.309c35d2.js").then(async i => (await i.__tla, i)), ["js/index.309c35d2.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.254016fb.css"])),
                    r = ot(),
                    ta = H(null),
                    Fe = H(!1);
                H(!0);
                const Ue = nt([]),
                    Ra = H(!1),
                    Ea = H(!1),
                    _a = H(null),
                    ha = H(!0),
                    Ga = H(!1);
                nt([]);
                const q = H(null),
                    Wa = H(null);
                let Tn = ka(() => {
                    let i = r.state.logos.find(d => d.alias === "desktopLogo");
                    return i && i.icon
                });
                $e(e, i => {
                    i.meta.bottomMenu ? ta.value && (ta.value.style.paddingBottom = Va) : setTimeout(() => {
                        ta.value && (ta.value.style.paddingBottom = 0)
                    }), setTimeout(() => {
                        ze()
                    })
                }, {
                    deep: !0,
                    immediate: !0
                });
                let Bn = ka(() => (document.documentElement.setAttribute("lang", r.state.language), r.state.language === "pt" ? (Za.use("pt-BR", gi), mi) : r.state.language === "en" ? (Za.use("en-US", lt), st) : r.state.language === "id" ? (Za.use("id-ID", pi), ci) : (Za.use("en-US", lt), st)));
                const Rn = (i, d) => {
                        I.post("/user/user/agentHit", {
                            agentCode: i,
                            agentId: d
                        }).then(b => {
                            b.code === 0 && console.log("\u6709\u9080\u8BF7\u7801\u8FDB\u5165")
                        })
                    },
                    En = () => {
                        const i = h();
                        if (i.channelId ? (localStorage.setItem("channelId", i.channelId), I.post("/trade/channel/report", {
                                channelId: i.channelId,
                                type: 10
                            })) : localStorage.removeItem("channelId"), i.fb_dynamic_pixel && !i.rand) {
                            let d = i.fb_dynamic_pixel;
                            localStorage.setItem("fbPixelId", d), Zn(d)
                        } else localStorage.removeItem("fbPixelId");
                        if (i.kwaiPixelBaseCode) {
                            let d = i.kwaiPixelBaseCode;
                            Ln(d)
                        }
                        if (i.bigoAds_pixel) {
                            let d = i.bigoAds_pixel;
                            Nn(d)
                        }
                        if (i.tt_pixel) {
                            let d = i.tt_pixel;
                            jn(d)
                        }
                        if (i.gtagId) {
                            let d = i.gtagId;
                            Vn(d)
                        }
                        if (i.agentCode ? localStorage.setItem("agentCode", i.agentCode) : localStorage.removeItem("agentCode"), i.id ? localStorage.setItem("agentId", i.id) : localStorage.removeItem("agentId"), i.id || i.agentCode) {
                            let d = i.agentCode ? i.agentCode.split("_")[0] : "",
                                b = i.id ? i.id.split("_")[0] : "";
                            Rn(d, b)
                        }
                        i.type && i.type == 4 && !N() && (r.state.loginType = "register", r.state.showLoginDialog = !0), i.dealerCode ? localStorage.setItem("dealerCode", i.dealerCode) : localStorage.removeItem("dealerCode")
                    },
                    Ke = () => {
                        let i = new Date().getTime(),
                            d = {};
                        const b = h();
                        r.state.inGamePage && (d.s = 1), e.name === "game" && (e.params.id && (d.id = e.params.id), b.vendorId && (d.vendor = b.vendorId)), I.get("/game/game/link", d).then(_ => {
                            if (_ && _.code === 0) {
                                let p = new Date().getTime();
                                r.state.network = p - i
                            }
                        })
                    },
                    Sn = () => {
                        Wa.value && clearInterval(Wa.value), Ke(), Wa.value = setInterval(Ke, 6e4)
                    };
                ai(async () => {
                    const i = localStorage.getItem("language") || "en",
                        d = localStorage.getItem("userInfo");
                    d && (r.state.accountInfo = JSON.parse(d)), n.value = i, r.state.language = i, globalVBus.$on("globalLoading", _ => {
                        Fe.value = _
                    }), globalVBus.$on("finishRegister", () => {
                        console.log("finishRegister"), Ga.value = !0
                    }), Sn(), En(), N() && (await r.dispatch("getUserInfo"), await r.dispatch("refreshBalance"), await r.dispatch("getReliefCheck")), await r.dispatch("getAppConfig"), await r.dispatch("getBadge"), !localStorage.getItem("addDesktop") && re() && (Ra.value = !0), globalVBus.$on("addDesktop", Qe), window.addEventListener("resize", () => {
                        r.state.layoutMode === 1 && (e.meta.bottomMenu && r.state.isMobile ? ta.value.style.paddingBottom = Va : ta.value.style.paddingBottom = 0), ze()
                    }), globalVBus.$on("checkRechargeOrderStatus", Je), localStorage.getItem("rechargeOrderNo") && Je(), globalVBus.$on("reopenRedEnvelopes", () => {
                        ha.value = !0
                    }), qn(), globalVBus.$on("startMusic", Dn), globalVBus.$on("pauseMusic", On), globalVBus.$on("nextMusic", Ja), globalVBus.$on("preMusic", We);
                    const b = document.querySelector("#app .scroll-wrapper");
                    b.style.background = "url('/img/colors/" + da() + "/home_bg.png", "serviceWorker" in navigator && fetch(`/sw-path.json?time=${new Date().getTime()}`).then(_ => _.json()).then(_ => {
                        const p = _.swPath;
                        navigator.serviceWorker.register(p).then(M => {
                            console.log("Service Worker registered:", M)
                        }).catch(M => {
                            console.error("Service Worker registration failed:", M)
                        })
                    }).catch(_ => {
                        console.error("Failed to fetch sw-path.json:", _)
                    })
                });
                const ze = () => {
                        let i = document.querySelectorAll(".childFontSize");
                        i && i.length && Array.from(i).forEach(d => {
                            let b = d.parentNode;
                            const _ = window.getComputedStyle(b).getPropertyValue("font-size");
                            let p = parseFloat(_);
                            d.style.fontSize = p - 3 + "px"
                        })
                    },
                    Dn = () => {
                        q.value.play(), r.state.musicInfo.playStatus = !0, q.value.addEventListener("ended", Ge)
                    },
                    On = () => {
                        q.value.pause(), r.state.musicInfo.playStatus = !1, q.value.removeEventListener("ended", Ge)
                    },
                    Ge = () => {
                        let i = r.state.musicInfo.downloadList.findIndex(d => d.id === r.state.musicInfo.currentMusic.id);
                        if (r.state.musicInfo.cycleType === "cycle") i === r.state.musicInfo.downloadList.length - 1 ? r.state.musicInfo.currentMusic = r.state.musicInfo.downloadList[0] : r.state.musicInfo.currentMusic = r.state.musicInfo.downloadList[i + 1];
                        else if (r.state.musicInfo.cycleType === "random") {
                            let d = Math.floor(Math.random() * r.state.musicInfo.downloadList.length) + 1;
                            if (r.state.musicInfo.downloadList.length > 1 && d - 1 === i) return Ja();
                            r.state.musicInfo.currentMusic = r.state.musicInfo.downloadList[d - 1]
                        }
                        q.value.src = r.state.musicInfo.currentMusic.info.url, r.state.musicInfo.playStatus && q.value.play()
                    },
                    Ja = () => {
                        if (r.state.musicInfo.downloadList.length === 1) return;
                        let i = r.state.musicInfo.downloadList.findIndex(d => d.id === r.state.musicInfo.currentMusic.id);
                        if (r.state.musicInfo.cycleType === "cycle" || r.state.musicInfo.cycleType === "single") i === r.state.musicInfo.downloadList.length - 1 ? r.state.musicInfo.currentMusic = r.state.musicInfo.downloadList[0] : r.state.musicInfo.currentMusic = r.state.musicInfo.downloadList[i + 1];
                        else if (r.state.musicInfo.cycleType === "random") {
                            let d = Math.floor(Math.random() * r.state.musicInfo.downloadList.length) + 1;
                            if (r.state.musicInfo.downloadList.length > 1 && d - 1 === i) return Ja();
                            r.state.musicInfo.currentMusic = r.state.musicInfo.downloadList[d - 1]
                        }
                        q.value.src = r.state.musicInfo.currentMusic.info.url, r.state.musicInfo.playStatus && q.value.play()
                    },
                    We = () => {
                        if (r.state.musicInfo.downloadList.length === 1) return;
                        let i = r.state.musicInfo.downloadList.findIndex(d => d.id === r.state.musicInfo.currentMusic.id);
                        if (r.state.musicInfo.cycleType === "cycle" || r.state.musicInfo.cycleType === "single") i === 0 ? r.state.musicInfo.currentMusic = r.state.musicInfo.downloadList[r.state.musicInfo.downloadList.length - 1] : r.state.musicInfo.currentMusic = r.state.musicInfo.downloadList[i - 1];
                        else if (r.state.musicInfo.cycleType === "random") {
                            let d = Math.floor(Math.random() * r.state.musicInfo.downloadList.length) + 1;
                            if (r.state.musicInfo.downloadList.length > 1 && d - 1 === i) return We();
                            r.state.musicInfo.currentMusic = r.state.musicInfo.downloadList[d - 1]
                        }
                        q.value.src = r.state.musicInfo.currentMusic.info.url, r.state.musicInfo.playStatus && q.value.play()
                    },
                    Je = () => {
                        _a.value && clearInterval(_a.value), N() && (_a.value = setInterval(() => {
                            let i = localStorage.getItem("rechargeOrderNo");
                            if (!i || !N()) return clearInterval(_a.value);
                            I.get("/trade/order/result", {
                                ids: i
                            }).then(d => {
                                if (d.status === "OK") {
                                    const {
                                        data: b
                                    } = d;
                                    let _ = i.split(",");
                                    b && b.length && b.forEach(p => {
                                        if (p.status === 1) {
                                            globalVBus.$emit("orderRechargeSuccess", p.id);
                                            let M = _.findIndex(y => y === p.orderNo);
                                            M !== -1 && _.splice(M, 1);
                                            let C = _.findIndex(y => y == p.id);
                                            C !== -1 && _.splice(C, 1);
                                            let S = p.atFirst === 1 ? "firstPurchase" : "purchase",
                                                Sa = {
                                                    amount: p.amount,
                                                    currency: p.currency
                                                };
                                            window.jsBridge && window.jsBridge.postEvent(S, JSON.stringify(Sa));
                                            try {
                                                const y = h();
                                                if (y.fb_dynamic_pixel && y.rand && y.fbclid && y.domain) {
                                                    let j = y.domain;
                                                    j.indexOf("http") === -1 && (j = "https://" + j);
                                                    let Ye = p.atFirst === 1 ? `${j}/facebook/pixed/sendFBFirstRechatge` : `${j}/facebook/pixed/sendFBRechatge`,
                                                        Fn = y.fb_dynamic_pixel,
                                                        Un = y.rand,
                                                        Kn = y.fbclid,
                                                        zn = y.utm_medium || 1,
                                                        Gn = y.utm_source || 1,
                                                        Wn = y.utm_id || 1,
                                                        Jn = y.utm_content || 1,
                                                        Qn = y.utm_term || 1,
                                                        Yn = y.utm_campaign || 1;
                                                    rt({
                                                        method: "get",
                                                        url: `${Ye}?rand=${Un}&pixed_id=${Fn}&fbclid=${Kn}&utm_medium=${zn}&utm_source=${Gn}&utm_id=${Wn}&utm_content=${Jn}&utm_term=${Qn}&utm_campaign=${Yn}`
                                                    }).then(Ai => {
                                                        console.log("dou peng submit success")
                                                    })
                                                }
                                            } catch {}
                                            try {
                                                const y = h();
                                                if (y.fb_dynamic_pixel && y.channelId) {
                                                    let j = y.channelId;
                                                    I.get("/game/game/report", {
                                                        userid: r.state.accountInfo.id,
                                                        channelid: j,
                                                        paramsType: p.atFirst === 1 ? "firstPurchase" : "purchase"
                                                    }).then(Ye => {
                                                        p.atFirst
                                                    })
                                                }
                                                fbq("track", "Purchase", {
                                                    value: p.amount,
                                                    currency: p.currency,
                                                    userid: r.state.accountInfo.id
                                                }, {
                                                    eventID: p.id
                                                }), p.atFirst === 1 && fbq("trackCustom", "firstPurchase", {}, {
                                                    eventID: p.id
                                                })
                                            } catch {}
                                            try {
                                                const y = h();
                                                if (y.kwaiPixelBaseCode) {
                                                    let j = y.kwaiPixelBaseCode;
                                                    kwaiq.instance(j).track("purchase")
                                                }
                                            } catch {}
                                            try {
                                                ttq.track("CompletePayment")
                                            } catch {}
                                            try {
                                                const y = h();
                                                if (y.bigoAds_pixel) {
                                                    let j = y.bigoAds_pixel;
                                                    bge("event", "ec_purchase", {
                                                        configId: j
                                                    })
                                                }
                                            } catch {}
                                            try {
                                                gtag("event", "purchase")
                                            } catch {}
                                        } else if (p.status === -1) {
                                            let M = _.findIndex(S => S === p.orderNo);
                                            M !== -1 && _.splice(M, 1);
                                            let C = _.findIndex(S => S == p.id);
                                            C !== -1 && _.splice(C, 1)
                                        }
                                    }), _.length ? localStorage.setItem("rechargeOrderNo", _.join(",")) : (clearInterval(_a.value), localStorage.removeItem("rechargeOrderNo"))
                                }
                            })
                        }, 15e3))
                    };
                ei(() => {
                    t.getRoutes().forEach(i => {
                        i.meta.keepAlive && Ue.push(i.name)
                    })
                });
                const Qe = () => {
                        if (Ra.value = !1, I.post("/user/task/shortcut"), ne() && r.state.isMobile) Ea.value = !0;
                        else try {
                            window.deferredPrompt.prompt(), window.deferredPrompt.userChoice.then(i => {
                                i.outcome === "accepted" ? localStorage.setItem("addDesktop", !0) : console.log("User dismissed the A2HS prompt"), window.deferredPrompt = null
                            })
                        } catch {
                            Ea.value = !0
                        }
                    },
                    Zn = i => {
                        (function(d, b, _, p, M, C, S) {
                            d.fbq || (M = d.fbq = function() {
                                M.callMethod ? M.callMethod.apply(M, arguments) : M.queue.push(arguments)
                            }, d._fbq || (d._fbq = M), M.push = M, M.loaded = !0, M.version = "2.0", M.queue = [], C = b.createElement(_), C.async = !0, C.src = p, S = b.getElementsByTagName(_)[0], S.parentNode.insertBefore(C, S))
                        })(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js"), fbq("init", i), console.log("pageView"), fbq("track", "PageView")
                    },
                    Ln = i => {
                        let d = document.querySelector("head");
                        const b = document.createElement("script");
                        b.id = "kwaiq-script-load", b.type = "text/javascript", b.innerHTML = `kwaiq.load(${i});kwaiq.page();kwaiq.instance(${i}).track('contentView')`, d.append(b)
                    },
                    jn = i => {
                        (function(d, b, _) {
                            d.TiktokAnalyticsObject = _;
                            var p = d[_] = d[_] || [];
                            p.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie", "disableCookie"], p.setAndDefer = function(C, S) {
                                C[S] = function() {
                                    C.push([S].concat(Array.prototype.slice.call(arguments, 0)))
                                }
                            };
                            for (var M = 0; M < p.methods.length; M++) p.setAndDefer(p, p.methods[M]);
                            p.instance = function(C) {
                                for (var S = p._i[C] || []; S.length > 0;) p.apply(null, S.shift());
                                return p
                            }, p.load = function(C, S) {
                                var Sa = "https://analytics.tiktok.com/i18n/pixel/events.js";
                                p._i = p._i || {}, p._i[C] = [], p._i[C]._u = Sa, p._t = p._t || {}, p._t[C] = +new Date, p._o = p._o || {}, p._o[C] = S || {};
                                var y = document.createElement("script");
                                y.type = "text/javascript", y.async = !0, y.src = Sa + "?sdkid=" + C + "&lib=" + _;
                                var j = document.getElementsByTagName("script")[0];
                                j.parentNode.insertBefore(y, j)
                            }
                        })(window, document, "ttq"), ttq.load(i), ttq.page()
                    },
                    Nn = i => {
                        if (document.getElementById("bigoAds_pixel")) return;
                        let d = document.querySelector("head");
                        const b = document.createElement("script");
                        b.src = `https://api.imotech.video/ad/events.js?pixel_id=${i}`, b.id = "bigoAds_pixel", b.async = !0, d.append(b)
                    },
                    Vn = i => {
                        if (document.getElementById("gtagId")) return;
                        let d = document.querySelector("head");
                        const b = document.createElement("script");
                        b.src = `https://www.googletagmanager.com/gtag/js?id=${i}`, b.async = !0, b.id = "gtagId", d.append(b), b.onload = () => {
                            window.dataLayer = window.dataLayer || [], window.gtag = function() {
                                dataLayer.push(arguments)
                            }, gtag("js", new Date), gtag("config", i)
                        }
                    },
                    qn = () => {
                        I.get("/user/app/radioList").then(i => {
                            if (i && i.data && i.data.list && i.data.list.length) {
                                if (r.state.musicInfo.allList = i.data.list, r.state.musicInfo.open = !!i.ext.radioShow, localStorage.getItem("myMusicList")) {
                                    let d = JSON.parse(localStorage.getItem("myMusicList"));
                                    r.state.musicInfo.currentMusic = i.data.list.find(b => b.id === d[0]) || i.data.list[0], r.state.musicInfo.downloadList = i.data.list.filter(b => d.includes(b.id))
                                } else r.state.musicInfo.currentMusic = i.data.list[0], r.state.musicInfo.downloadList.push(r.state.musicInfo.allList[0]), localStorage.setItem("myMusicList", JSON.stringify(r.state.musicInfo.downloadList.map(d => d.id)));
                                Xe(() => {
                                    q.value.src = r.state.musicInfo.currentMusic.info.url
                                })
                            }
                        })
                    },
                    Hn = i => {
                        setTimeout(() => {
                            ha.value = !0
                        }, i)
                    };
                return (i, d) => {
                    const b = Qa("router-view");
                    return A(), O(c(ui), {
                        locale: c(Bn)
                    }, {
                        default: Oa(() => [T("div", {
                            class: sa(["main-body", ["festival" + c(r).state.festivalStyle, {
                                festival: c(r).state.festivalStyle
                            }, {
                                isMobile: c(r).state.isMobile
                            }, {
                                skin0: c(r).state.skinBg === 0
                            }]])
                        }, [!c(r).state.isMobile && c(e).name !== "limit" ? (A(), O(c(Q), {
                            key: 0
                        })) : Z("", !0), T("div", mn, [!c(r).state.isMobile && c(r).state.leftNavigations && c(r).state.leftNavigations.entrance && c(e).name !== "limit" ? (A(), O(c(P), {
                            key: 0
                        })) : Z("", !0), T("div", cn, [c(r).state.festivalStyle && !c(r).state.isMobile ? (A(), F("div", un, _n)) : Z("", !0), T("div", {
                            class: sa(["wrapper", {
                                dark: c(r).state.layoutMode === 1
                            }]),
                            ref_key: "wrapper",
                            ref: ta
                        }, [T("div", hn, [T("div", null, [U(b, null, {
                            default: Oa(({
                                Component: _
                            }) => [U(tt, {
                                name: c(r).state.transitionName,
                                appear: !1
                            }, {
                                default: Oa(() => [(A(), O(ti, {
                                    include: Ue
                                }, [(A(), O(ni(_)))], 1032, ["include"]))]),
                                _: 2
                            }, 1032, ["name"])]),
                            _: 1
                        })])])], 2), !c(r).state.isMobile && c(e).name !== "limit" ? (A(), O(c(Y), {
                            key: 1
                        })) : Z("", !0)])]), at(U(c(m), null, null, 512), [
                            [et, c(e).meta.bottomMenu]
                        ]), c(r).state.showLoginDialog && c(e).name !== "limit" ? (A(), O(c(g), {
                            key: 1
                        })) : Z("", !0), c(r).state.isMobile && c(r).state.layoutMode !== 2 && c(r).state.leftNavigations && c(r).state.leftNavigations.entrance ? (A(), O(c(P), {
                            key: 2
                        })) : Z("", !0), U(c(w)), U(c(f))], 2), Fe.value ? (A(), F("div", bn, fn)) : Z("", !0), c(r).state.isProgress && c(r).state.isApp && c(r).state.sections.loading ? (A(), O(c(k), {
                            key: 1
                        })) : Z("", !0), c(ma)() && Ra.value && c(Tn) ? (A(), O(c(R), {
                            key: 2,
                            onCloseAddBtn: d[0] || (d[0] = _ => Ra.value = !1),
                            onOpenAddFlow: Qe
                        })) : Z("", !0), Ea.value && c(e).name !== "limit" ? (A(), O(c(L), {
                            key: 3,
                            onClose: d[1] || (d[1] = _ => Ea.value = !1)
                        })) : Z("", !0), c(r).state.popStep > 2 && (c(e).name === "index" || c(e).name === "promotion") && ha.value ? (A(), O(c(V), {
                            key: 4,
                            value: ha.value,
                            "onUpdate:value": d[2] || (d[2] = _ => ha.value = _),
                            onCheckNextRedEnvelopes: Hn
                        }, null, 8, ["value"])) : Z("", !0), Ga.value ? (A(), O(c(ea), {
                            key: 5,
                            onClose: d[3] || (d[3] = _ => Ga.value = !1)
                        })) : Z("", !0), c(r).state.showNewbieBonusDialog ? (A(), O(c(X), {
                            key: 6,
                            onClose: d[4] || (d[4] = _ => c(r).state.showNewbieBonusDialog = !1)
                        })) : Z("", !0), U(c(Ca), {
                            value: c(r).state.showMusicList,
                            "onUpdate:value": d[5] || (d[5] = _ => c(r).state.showMusicList = _)
                        }, null, 8, ["value"]), U(c(Ta), {
                            value: c(r).state.showDealerJoinDialog,
                            "onUpdate:value": d[6] || (d[6] = _ => c(r).state.showDealerJoinDialog = _)
                        }, null, 8, ["value"]), U(c(Ba)), U(c(u)), U(c(Cn), {
                            value: c(r).state.appDownloadDialog,
                            "onUpdate:value": d[7] || (d[7] = _ => c(r).state.appDownloadDialog = _)
                        }, null, 8, ["value"]), T("audio", {
                            id: "musicAudio",
                            src: c(r).state.musicInfo.currentMusic && c(r).state.musicInfo.currentMusic.info.src,
                            preload: "none",
                            ref_key: "musicRef",
                            ref: q
                        }, "\u60A8\u7684\u6D4F\u89C8\u5668\u4E0D\u652F\u6301\u3002", 8, yn)]),
                        _: 1
                    }, 8, ["locale"])
                }
            }
        },
        Fa = document,
        ye = window;
    var D = Fa.documentElement,
        Pa = navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
        ua = Pa ? Math.min(ye.devicePixelRatio, 3) : 1,
        ua = window.top === window.self ? ua : 1,
        ua = 1,
        Ua = 1 / ua,
        vn = "orientationchange" in window ? "orientationchange" : "resize";
    D.dataset.dpr = ua, D.dataset.device = "mobile";
    const Ka = Fa.createElement("meta");
    Ka.name = "viewport", Ka.content = "initial-scale=" + Ua + ",maximum-scale=" + Ua + ", minimum-scale=" + Ua, D.firstElementChild.appendChild(Ka);
    const xe = function() {
        let a = D.clientWidth;
        if (Pa = navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), a > 450 ? (D.dataset.deviceNodesktop = 1, s.state.isDesktop = !0) : (D.dataset.deviceNodesktop = 0, s.state.isDesktop = !1), Pa && a < 450) D.dataset.deviceOs = "ios", s.state.deviceOs = "ios", D.style.setProperty("--theme-max-width", "467.7661169415292px");
        else if (navigator.userAgent.indexOf("Android") > -1 && a < 450) D.dataset.deviceOs = "android", s.state.deviceOs = "android", D.style.setProperty("--theme-max-width", "467.7661169415292px");
        else if (a === 980 && (Pa || navigator.userAgent.indexOf("Android") > -1)) D.style.setProperty("--theme-max-width", "980px");
        else {
            D.dataset.deviceOs = "windows", D.style.setProperty("--theme-max-width", "516.67px");
            let e = D.clientHeight;
            const t = .56221917;
            D.style.setProperty("--theme-max-width", e * t > 980 ? "980px" : e * t + "px"), D.style.setProperty("--vh", e / 100 + "px")
        }
    };
    xe(), Fa.addEventListener && ye.addEventListener(vn, xe, !1);
    class wn {
        constructor() {
            Da(this, "data", {});
            Da(this, "aliveCache", []);
            Da(this, "_events", {})
        }
        $on(e, t) {
            this._events[e] = this._events[e] || [], this._events[e].push(t)
        }
        $off(e, t) {
            this._events[e] && (this._events[e] = this._events[e].filter(n => n !== t))
        }
        $emit(e, ...t) {
            if (!this._events[e]) return;
            const n = this._events[e];
            if (!Array.isArray(n)) return typeof n != "function" ? void 0 : n(...t);
            n.forEach(o => {
                typeof o == "function" && o(...t)
            })
        }
        $destroy() {
            this._events = {}
        }
        $onOnce(e, t) {
            this._events[e] || (this._events[e] = t)
        }
        $offOnce(e, t) {
            delete this._events[e]
        }
    }
    const An = new wn;
    if (typeof window < "u") {
        let a = function() {
            var e = document.body,
                t = document.getElementById("__svg__icons__dom__");
            t || (t = document.createElementNS("http://www.w3.org/2000/svg", "svg"), t.style.position = "absolute", t.style.width = "0", t.style.height = "0", t.id = "__svg__icons__dom__", t.setAttribute("xmlns", "http://www.w3.org/2000/svg"), t.setAttribute("xmlns:link", "http://www.w3.org/1999/xlink")), t.innerHTML = '<symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 38 38" id="icon-FAQ"><defs><symbol viewBox="0 0 38 38" id="icon-FAQ_a"><g data-name="Group 2561"><path data-name="Op component 1" d="M2331.985 1410.01a19 19 0 1 0 19 19 19.023 19.023 0 0 0-19-19Zm0 34.546a15.546 15.546 0 1 1 15.546-15.546 15.562 15.562 0 0 1-15.546 15.546Z" transform="translate(-2312.984 -1410.01)" /><path data-name="Rectangle 958" transform="translate(17.795 26.093)" d="M0 0h2.62v2.262H0z" /><path data-name="Path 509" d="M2277.244 166.49q-5.788.309-6.005 5.757h2.293q.109-3.906 3.712-4.112a3.088 3.088 0 0 1 3.276 3.083q0 1.544-2.293 3.6-2.4 2.367-2.4 4.112v1.85h2.4v-2.16q-.109-.925 1.747-2.569 2.62-2.365 2.62-4.729-.331-4.627-5.35-4.832Z" transform="translate(-2257.916 -156.844)" /></g></symbol></defs><use xlink:href="#icon-FAQ_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-about_us"><defs><symbol viewBox="0 0 16.013 16" id="icon-about_us_a"><path d="M1921.976-191.375a8.012 8.012 0 0 1 8.006-8 8.012 8.012 0 0 1 8.007 8 8.012 8.012 0 0 1-8.007 8 8.012 8.012 0 0 1-8.006-8Zm1.456 0a6.555 6.555 0 0 0 6.55 6.546 6.556 6.556 0 0 0 6.551-6.546 6.556 6.556 0 0 0-6.551-6.546 6.555 6.555 0 0 0-6.55 6.546Zm5.822 3.879v-4.364a.728.728 0 0 1 .728-.727.728.728 0 0 1 .728.727v4.364a.728.728 0 0 1-.728.727.728.728 0 0 1-.728-.731Zm-.242-7.515a.971.971 0 0 1 .97-.97.971.971 0 0 1 .97.97.971.971 0 0 1-.97.969.971.971 0 0 1-.97-.969Z" transform="translate(-1921.976 199.375)" /></symbol></defs><use xlink:href="#icon-about_us_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-activation"><defs><symbol viewBox="0 0 22.851 24" id="icon-activation_a"><g data-name="Group 2414"><path data-name="Path 512" d="m1819.742 100.806-13.124 11.241a.377.377 0 0 0 .1.636l5.606 2.242-4.769 9.538a.2.2 0 0 0 .314.24l12.883-11.548a.377.377 0 0 0-.12-.633l-5.422-2.013 4.837-9.458a.2.2 0 0 0-.305-.245Z" transform="translate(-1802.601 -100.756)" /><g data-name="Group 2413"><path data-name="Path 513" d="m1836.638 110.7-.734 1.436a.629.629 0 0 0 .159.77 8.83 8.83 0 0 1-5.637 15.63h-.035a.867.867 0 0 0-.585.219l-1.751 1.57a.341.341 0 0 0 .158.588 11.422 11.422 0 0 0 9.053-20.355.42.42 0 0 0-.628.142Z" transform="translate(-1819 -108.184)" /><path data-name="Path 514" d="M1792.582 112.579a8.844 8.844 0 0 1 8.834-8.834c.178 0 .355.006.531.017a.628.628 0 0 0 .45-.147l1.851-1.586a.319.319 0 0 0-.13-.551 11.421 11.421 0 0 0-9.479 20.292.375.375 0 0 0 .559-.131l.772-1.543a.559.559 0 0 0-.144-.683 8.819 8.819 0 0 1-3.244-6.834Z" transform="translate(-1789.99 -101.06)" /></g></g></symbol></defs><use xlink:href="#icon-activation_a" fill="var(--theme-secondary-color-success)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-active_badge"><defs><symbol viewBox="0 0 28 28" id="icon-active_badge_a"><path d="M28 0v17.63A10.37 10.37 0 0 1 17.63 28H0Z" /></symbol></defs><use xlink:href="#icon-active_badge_a" fill="var(--theme-filter-active-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-advise"><defs><symbol viewBox="0 0 16 16" id="icon-advise_a"><path d="M1648.3-137.505a2.8 2.8 0 0 1-2.81-2.778v-9.567a2.8 2.8 0 0 1 2.81-2.778h4.979a.7.7 0 0 1 .7.694.7.7 0 0 1-.7.695h-4.979a1.4 1.4 0 0 0-1.406 1.389v9.567a1.4 1.4 0 0 0 1.406 1.389h9.806a1.4 1.4 0 0 0 1.405-1.389v-5.4a.7.7 0 0 1 .7-.694.7.7 0 0 1 .7.694v5.4a2.8 2.8 0 0 1-2.809 2.778Zm2.331-4.871a.708.708 0 0 1-.167-.694l.834-2.767a.707.707 0 0 1 .174-.293l6.448-6.759a2.082 2.082 0 0 1 2.959 0 2.123 2.123 0 0 1 0 2.981l-6.44 6.752a.691.691 0 0 1-.306.18l-2.814.786a.71.71 0 0 1-.188.025.7.7 0 0 1-.5-.211Zm1.95-2.884-.414 1.375 1.416-.4.449-.471-1.073-.9Zm2.441-.531 4.87-5.11a.709.709 0 0 0 0-.994.694.694 0 0 0-.987 0l-.134.136-4.822 5.063Z" transform="translate(-1645.49 153.505)" /></symbol></defs><use xlink:href="#icon-advise_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-advise_green"><defs><symbol viewBox="0 0 16 16" id="icon-advise_green_a"><path d="M1648.3-137.505a2.8 2.8 0 0 1-2.81-2.778v-9.567a2.8 2.8 0 0 1 2.81-2.778h4.979a.7.7 0 0 1 .7.694.7.7 0 0 1-.7.695h-4.979a1.4 1.4 0 0 0-1.406 1.389v9.567a1.4 1.4 0 0 0 1.406 1.389h9.806a1.4 1.4 0 0 0 1.405-1.389v-5.4a.7.7 0 0 1 .7-.694.7.7 0 0 1 .7.694v5.4a2.8 2.8 0 0 1-2.809 2.778Zm2.331-4.871a.708.708 0 0 1-.167-.694l.834-2.767a.707.707 0 0 1 .174-.293l6.448-6.759a2.082 2.082 0 0 1 2.959 0 2.123 2.123 0 0 1 0 2.981l-6.44 6.752a.691.691 0 0 1-.306.18l-2.814.786a.71.71 0 0 1-.188.025.7.7 0 0 1-.5-.211Zm1.95-2.884-.414 1.375 1.416-.4.449-.471-1.073-.9Zm2.441-.531 4.87-5.11a.709.709 0 0 0 0-.994.694.694 0 0 0-.987 0l-.134.136-4.822 5.063Z" transform="translate(-1645.49 153.505)" /></symbol></defs><use xlink:href="#icon-advise_green_a" fill="#FACF20" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-agent"><defs><symbol viewBox="0 0 15.99 15.725" id="icon-agent_a"><path d="M1563.73 289.233c.33-.241.64-.462.92-.635a2.134 2.134 0 0 1 .6-.281 1.974 1.974 0 0 1 .08.653v9.55a1.358 1.358 0 0 1-.06.492 2.422 2.422 0 0 1-.66-.266c-.21-.107-.41-.227-.64-.356-.08-.047-.16-.1-.25-.144-1.54-1.332-3.25-1.642-6.59-1.685v-5.634c3.42-.077 5.08-.573 6.6-1.694Zm-8.26 8.7h-.44l.7 2.987v.078a.4.4 0 0 0 .4.4h1.34a.393.393 0 0 0 .39-.35l-.62-3.109c-.34 0-.71-.006-1.1-.006Zm3.14.044c2.26.106 3.3.433 4.28 1.3l.05.045.06.034q.135.075.27.156c.23.136.48.28.71.4a3.951 3.951 0 0 0 1.06.4 1.271 1.271 0 0 0 1.23-.395 2.072 2.072 0 0 0 .39-1.387v-3.147a1.6 1.6 0 0 0 0-3.153v-3.25a2.454 2.454 0 0 0-.36-1.474 1.19 1.19 0 0 0-.59-.434 1.413 1.413 0 0 0-.67-.039 3.209 3.209 0 0 0-1.09.461c-.34.207-.69.462-1.02.7-1.3.962-2.76 1.475-6.71 1.481h-1.42a3.083 3.083 0 0 0-2.8 2.8v2.665a2.739 2.739 0 0 0 .91 1.993 3.038 3.038 0 0 0 .68.487l.81 3.47a1.734 1.734 0 0 0 1.73 1.646h1.34a1.735 1.735 0 0 0 1.73-1.732v-.066Zm-3.14-6.152V291h-.67a1.528 1.528 0 0 0-.97.5 1.558 1.558 0 0 0-.5.965v2.665a1.426 1.426 0 0 0 .49 1.023 1.521 1.521 0 0 0 .98.443h.67v-4.776Z" transform="translate(-1552 -287)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-agent_a" fill="#FFAA09" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-agent_detail_arrow"><defs><symbol viewBox="0 0 23 16" id="icon-agent_detail_arrow_a"><path d="m149.827 115.033-11.5-12.639 3.062-3.361 8.438 9.271 8.438-9.271 3.062 3.361Z" transform="translate(-138.327 -99.033)" /></symbol></defs><use xlink:href="#icon-agent_detail_arrow_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-agente"><defs><symbol viewBox="0 0 70 70" id="icon-agente_a"><path data-name="\u8054\u5408 336" d="M-5308-901a11.014 11.014 0 0 1-11-11v-40a11.013 11.013 0 0 1 11-11h18a3 3 0 0 1 3 3 3 3 0 0 1-3 3h-18a5.005 5.005 0 0 0-5 5v40a5.005 5.005 0 0 0 5 5h34a5.005 5.005 0 0 0 5-5v-13.5a3 3 0 0 1 3-3 3 3 0 0 1 3 3v13.5a11.012 11.012 0 0 1-11 11Zm30.417-50.3v-9.411l16.448 16.482-16.448 16.471v-9.416s-16.322-1.811-25.85 11.775c0-.001 3-25.901 25.85-25.901Z" transform="translate(5325 967.714)" /></symbol></defs><use xlink:href="#icon-agente_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-android"><defs><symbol viewBox="0 0 40 40" id="icon-android_a"><g data-name="comm_icon_xz-android" stroke-miterlimit="10" clip-path="url(#comm_icon_xz-android--svgSprite:all_clip-path)"><path d="M18.345 36.881a2.067 2.067 0 0 1-.016-.347V31.248h-3.324v5.312a2.415 2.415 0 0 1-4.789.44 3.107 3.107 0 0 1-.026-.555V31.62c0-.114-.011-.228-.018-.374-.13-.01-.243-.024-.357-.027-.211-.007-.422 0-.634 0a7.505 7.505 0 0 1-1.355-.071 2.508 2.508 0 0 1-2.037-2.5V13.362c0-.076.008-.151.014-.257h21.722c.008.1.021.193.021.283v15.216a2.578 2.578 0 0 1-2.62 2.615h-1.433c-.1 0-.2.015-.326.026-.009.13-.022.242-.022.354v4.894a2.376 2.376 0 0 1-2.113 2.458q-.13.011-.256.011a2.393 2.393 0 0 1-2.431-2.081ZM.026 25.485A2.565 2.565 0 0 1 0 25.023V15.1a2.367 2.367 0 0 1 2.128-2.42A2.4 2.4 0 0 1 4.8 14.713a2.443 2.443 0 0 1 .016.393v9.947a2.4 2.4 0 0 1-2.222 2.436c-.072.007-.143.01-.214.01a2.431 2.431 0 0 1-2.354-2.014Zm28.516-.017a2.286 2.286 0 0 1-.021-.416v-9.947a2.41 2.41 0 0 1 4.781-.466 2.522 2.522 0 0 1 .03.484v9.924a2.4 2.4 0 0 1-2.238 2.443q-.093.007-.185.007a2.428 2.428 0 0 1-2.367-2.029ZM5.773 12.123a9.965 9.965 0 0 1 5.579-8.587L10.07 1.248q-.2-.365-.408-.731c-.1-.185-.123-.371.093-.477.2-.1.355-.013.464.182q.787 1.412 1.581 2.818c.04.073.089.141.144.227a11.92 11.92 0 0 1 9.453.005l.794-1.406c.308-.547.618-1.093.921-1.643a.328.328 0 0 1 .466-.183c.217.106.2.292.094.476L22.115 3.3c-.041.073-.079.148-.134.251A10.045 10.045 0 0 1 27.1 9.48a26.157 26.157 0 0 1 .539 2.643Zm14.982-4.767a.946.946 0 0 0 1.891-.007.939.939 0 0 0-.925-.921h-.011a.937.937 0 0 0-.955.928Zm-10.067-.018a.945.945 0 1 0 .96-.91h-.012a.937.937 0 0 0-.948.91Z" transform="translate(3.333 .667)" /><path d="M20.775 38.963c.084 0 .169-.003.256-.01 1.21-.105 2.111-1.15 2.113-2.459.002-1.631 0-3.263.002-4.894 0-.112.013-.225.022-.354.128-.01.227-.025.326-.026h.624c.27 0 .539 0 .809-.002 1.492-.016 2.62-1.138 2.62-2.616.002-5.072 0-10.144 0-15.216 0-.09-.014-.179-.022-.283H5.801c-.006.106-.015.181-.015.257 0 5.095-.002 10.19.001 15.286 0 1.214.834 2.287 2.038 2.5.441.077.898.074 1.354.07.212-.001.424-.003.634.004.113.003.226.017.357.027.007.145.018.26.018.373.001 1.609 0 3.217.002 4.825 0 .185-.007.375.026.555.232 1.256 1.34 2.063 2.671 1.952 1.165-.096 2.117-1.17 2.118-2.392.002-1.662 0-3.325 0-4.987v-.325h3.323v.322l.001 4.964c0 .115-.003.233.016.347.22 1.273 1.181 2.082 2.43 2.082M2.376 27.5c.071 0 .143-.003.215-.01 1.294-.121 2.221-1.135 2.222-2.436.002-3.316 0-6.632 0-9.947 0-.131.005-.265-.016-.393-.218-1.314-1.293-2.13-2.669-2.033C.933 12.765.003 13.82.001 15.1c-.002 1.653 0 3.307 0 4.961v4.962c.001.154-.003.312.025.462.22 1.175 1.222 2.014 2.35 2.014m28.533-.002c.061 0 .123-.002.185-.007 1.288-.1 2.236-1.131 2.238-2.443.002-1.661 0-3.323 0-4.985 0-1.646.002-3.293 0-4.939 0-.161.001-.327-.03-.484-.259-1.297-1.339-2.081-2.682-1.957-1.19.109-2.099 1.155-2.1 2.423v9.947c0 .139-.003.28.022.416.22 1.191 1.216 2.03 2.367 2.03m-3.266-15.375c-.182-.916-.279-1.804-.54-2.643-.835-2.688-2.646-4.593-5.122-5.933.055-.103.093-.178.134-.25l1.557-2.78c.103-.185.123-.371-.094-.477-.2-.097-.356-.012-.463.183-.303.55-.614 1.096-.922 1.643L21.4 3.272c-3.162-1.305-6.304-1.305-9.453-.005-.054-.086-.103-.154-.143-.227-.53-.938-1.06-1.876-1.585-2.817-.108-.195-.263-.28-.463-.182-.217.106-.196.292-.093.477.135.244.271.487.408.73l1.282 2.288c-3.401 1.907-5.375 4.67-5.579 8.587h21.87m-5.934-5.695h.012a.939.939 0 0 1 .925.921c.002.518-.429.93-.967.925a.927.927 0 0 1-.924-.918c-.004-.513.424-.928.954-.928m-10.073 0h.012c.518.006.945.437.93.94-.015.52-.427.91-.96.906a.933.933 0 0 1-.93-.936.937.937 0 0 1 .948-.91m9.139 33.535c-1.742 0-3.115-1.17-3.416-2.912a2.668 2.668 0 0 1-.03-.475V32.248h-1.324V36.56c-.001.835-.311 1.645-.874 2.28a3.247 3.247 0 0 1-2.484 1.121c-1.708 0-3.112-1.143-3.415-2.78-.045-.245-.043-.471-.043-.653v-4.313h-.003l-.288.002a7.1 7.1 0 0 1-1.247-.088c-1.659-.293-2.863-1.758-2.864-3.483v-1.114a3.457 3.457 0 0 1-2.41.966c-1.624 0-3.026-1.19-3.334-2.83a3.093 3.093 0 0 1-.041-.59v-.053C-1 23.69-1 22.356-1 21.02v-5.923c.003-1.793 1.345-3.293 3.056-3.415.098-.007.196-.01.292-.01.948 0 1.783.33 2.4.903l.025-.505c.11-2.094.7-3.96 1.757-5.549.847-1.273 2.014-2.394 3.475-3.342a5487.255 5487.255 0 0 1-1.219-2.177C8.53.539 8.567.149 8.644-.095c.103-.33.342-.6.67-.762.194-.095.396-.143.6-.143.488 0 .917.268 1.178.736.427.765.864 1.541 1.29 2.297a13.082 13.082 0 0 1 4.282-.74c1.423 0 2.86.248 4.287.74a688.783 688.783 0 0 0 1.288-2.292c.26-.471.69-.741 1.18-.741.204 0 .405.048.597.142.33.16.57.432.674.763.077.246.114.636-.145 1.1l-.748 1.334-.47.84c2.37 1.502 3.959 3.518 4.732 6.004.197.636.307 1.282.414 1.908.047.275.096.56.15.838l.103.515a3.228 3.228 0 0 1 1.802-.758c.122-.011.246-.017.367-.017 1.695 0 3.056 1.115 3.388 2.774.048.245.048.469.048.649v.03c.002 1.244.002 2.489.002 3.733v6.194a3.47 3.47 0 0 1-.9 2.35 3.409 3.409 0 0 1-2.524 1.098 3.362 3.362 0 0 1-2.362-.976v1.082c0 .981-.371 1.892-1.044 2.563-.67.668-1.581 1.042-2.566 1.052l-.513.002h-.279v1.575l-.001 2.7c-.003 1.82-1.304 3.305-3.028 3.453a4 4 0 0 1-.341.015Z" transform="translate(3.333 .667)" /></g></symbol></defs><use xlink:href="#icon-android_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 12.928 22.67" id="icon-arrow"><defs><symbol viewBox="0 0 12.928 22.67" id="icon-arrow_img_scroll_jt--svgSprite:all"><path id="icon-arrow_img_scroll_jt--svgSprite:all_img_scroll_jt" d="M10.806,21.6a.961.961,0,0,1-.7-.256L.259,11.181a.889.889,0,0,1,0-1.242.81.81,0,0,1,.6-.267.824.824,0,0,1,.607.267l9.34,9.6,9.326-9.6a.834.834,0,0,1,.61-.267.818.818,0,0,1,.6.267.882.882,0,0,1,0,1.242L11.5,21.348a1,1,0,0,1-.638.25Z" transform="translate(-9.172 22.097) rotate(-90)" stroke-width="1" /></symbol></defs><use xlink:href="#icon-arrow_img_scroll_jt--svgSprite:all" /><linearGradient id="icon-arrow_id-e96458b6-5ed5-4e91-8d3e-12c809a31a1c" x1="0.5" x2="0.5" y2="1"></linearGradient></symbol><symbol  viewBox="64 64 896 896" fill="currentColor" aria-hidden="true" id="icon-arrow_left"><path d="M724 218.3V141c0-6.7-7.7-10.4-12.9-6.3L260.3 486.8a31.86 31.86 0 0 0 0 50.3l450.8 352.1c5.3 4.1 12.9.4 12.9-6.3v-77.3c0-4.9-2.3-9.6-6.1-12.6l-360-281 360-281.1c3.8-3 6.1-7.7 6.1-12.6z" fill="#005DFE" /></symbol><symbol  viewBox="64 64 896 896" fill="currentColor" aria-hidden="true" id="icon-arrow_left_green"><path d="M724 218.3V141c0-6.7-7.7-10.4-12.9-6.3L260.3 486.8a31.86 31.86 0 0 0 0 50.3l450.8 352.1c5.3 4.1 12.9.4 12.9-6.3v-77.3c0-4.9-2.3-9.6-6.1-12.6l-360-281 360-281.1c3.8-3 6.1-7.7 6.1-12.6z" fill="#FACF20" /></symbol><symbol  viewBox="64 64 896 896" fill="currentColor" aria-hidden="true" id="icon-arrow_right"><path d="M765.7 486.8 314.9 134.7A7.97 7.97 0 0 0 302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 0 0 0-50.4z" fill="#005DFE" /></symbol><symbol  viewBox="64 64 896 896" fill="currentColor" aria-hidden="true" id="icon-arrow_right_green"><path d="M765.7 486.8 314.9 134.7A7.97 7.97 0 0 0 302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 0 0 0-50.4z" fill="#FACF20" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-avatar_selected"><defs><symbol viewBox="0 0 28 28" id="icon-avatar_selected_a"><path d="M28 0v17.63A10.37 10.37 0 0 1 17.63 28H0Z" /></symbol></defs><use xlink:href="#icon-avatar_selected_a" fill="#005DFE" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-avatar_ticked"><defs><symbol viewBox="0 0 20 15" id="icon-avatar_ticked_a"><path d="m1234.22-597.615-6.584-5.628a1.524 1.524 0 0 1-.149-2.141 1.5 1.5 0 0 1 2.128-.15l5.438 4.648 9.417-10.834a1.5 1.5 0 0 1 2.128-.15 1.525 1.525 0 0 1 .149 2.141l-10.4 11.964a1.5 1.5 0 0 1-1.139.522 1.494 1.494 0 0 1-.988-.372Z" transform="translate(-1227.117 612.242)" /></symbol></defs><use xlink:href="#icon-avatar_ticked_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-bank_card"><defs><symbol viewBox="0 0 40 27.611" id="icon-bank_card_a"><g fill-rule="evenodd"><path data-name="Path 520" d="M1977.03-283.677a3.486 3.486 0 0 0-3.461-3.51h-30.807a3.486 3.486 0 0 0-3.461 3.51v3.017h37.729Z" transform="translate(-1939.301 287.188)" /><path data-name="Path 521" d="M1958.38-262.572a11.712 11.712 0 0 1 5.108-9.678H1939.3v15.084a3.486 3.486 0 0 0 3.461 3.511h19.739a11.694 11.694 0 0 1-4.12-8.917Z" transform="translate(-1939.301 280.99)" /><path data-name="Path 522" d="M1985.436-271.42a9.192 9.192 0 0 0-9.192 9.193 9.192 9.192 0 0 0 9.192 9.192 9.193 9.193 0 0 0 9.193-9.192 9.193 9.193 0 0 0-9.193-9.193Zm5.089 9.186a1.025 1.025 0 0 1-1.017 1.032h-3.061v3.1a1.024 1.024 0 0 1-1.017 1.032 1.024 1.024 0 0 1-1.017-1.032v-3.1h-3.042a1.024 1.024 0 0 1-1.017-1.032 1.024 1.024 0 0 1 1.017-1.031h3.042v-3.086a1.024 1.024 0 0 1 1.017-1.031 1.024 1.024 0 0 1 1.017 1.031v3.086h3.061a1.024 1.024 0 0 1 1.017 1.031Z" transform="translate(-1954.629 280.646)" /></g></symbol></defs><use xlink:href="#icon-bank_card_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-banner_arrow_left"><defs><symbol viewBox="0 0 21.999 35.998" id="icon-banner_arrow_left_a"><path d="m2209.279 137.564-17.743-15.773a2.024 2.024 0 0 1-.271-.228 2.009 2.009 0 0 1 0-2.83 2.02 2.02 0 0 1 .274-.23l17.74-15.77a1.992 1.992 0 0 1 2.817 2.816l-16.422 14.6 16.422 14.6a1.992 1.992 0 0 1-2.817 2.817Z" transform="translate(-2190.681 -102.15)" /></symbol></defs><use xlink:href="#icon-banner_arrow_left_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-banner_arrow_right"><defs><symbol viewBox="0 0 12.928 22.67" id="icon-banner_arrow_right_a"><path d="M10.806 21.6a.961.961 0 0 1-.7-.256L.259 11.181a.889.889 0 0 1 0-1.242.81.81 0 0 1 .6-.267.824.824 0 0 1 .607.267l9.34 9.6 9.326-9.6a.834.834 0 0 1 .61-.267.818.818 0 0 1 .6.267.882.882 0 0 1 0 1.242L11.5 21.348a1 1 0 0 1-.638.25Z" transform="rotate(-90 6.463 15.635)" /></symbol></defs><use xlink:href="#icon-banner_arrow_right_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-block_chain"><defs><symbol viewBox="0 0 100 76" id="icon-block_chain_a"><path data-name="Path 18326" d="m-1276.05 1838.938-7.08-4.118a5.916 5.916 0 0 0-.755-.368 18.921 18.921 0 0 0-5.893-9.083 5.9 5.9 0 0 0 .127-1.213v-8.322a5.928 5.928 0 0 0-2.948-5.125l-7.081-4.119a5.927 5.927 0 0 0-5.961 0l-7.08 4.119a5.928 5.928 0 0 0-2.948 5.125v7.98a19 19 0 0 0-7.415 11.013l-7.07 4.112a5.929 5.929 0 0 0-2.948 5.125v8.322a5.927 5.927 0 0 0 2.935 5.117l7.08 4.143a5.93 5.93 0 0 0 5.988 0l7.08-4.143a5.948 5.948 0 0 0 .7-.477 21.7 21.7 0 0 0 6.222.906 21.653 21.653 0 0 0 6.221-.908 5.833 5.833 0 0 0 .7.479l7.081 4.143a5.929 5.929 0 0 0 5.987 0l7.08-4.143a5.926 5.926 0 0 0 2.936-5.117v-8.322a5.929 5.929 0 0 0-2.958-5.126Zm-21.9-16.125c1.012-2.206 3.052-3.435 4.555-2.745 1.136.521 1.64 1.991 1.381 3.629a20.98 20.98 0 0 0-1.092-.662 1.839 1.839 0 0 0-2.605.894l-.016.039a1.847 1.847 0 0 0 .819 2.312c.42.237.824.5 1.219.764a3.08 3.08 0 0 1-3.371 1.012c-1.5-.691-1.898-3.038-.885-5.243Zm-17.075 34.269c-1.5-.69-1.9-3.038-.889-5.243s3.052-3.435 4.554-2.745c1.164.535 1.661 2.063 1.359 3.75a17.236 17.236 0 0 1-1.719-.83 1.86 1.86 0 0 0-2.323.413 1.857 1.857 0 0 0 .508 2.826q.874.486 1.8.892a3.035 3.035 0 0 1-3.286.937Zm24.1.177c-1.081.5-2.438 0-3.492-1.143q.588-.259 1.156-.552a1.856 1.856 0 0 0 .648-2.736 1.868 1.868 0 0 0-2.375-.55q-.492.251-1 .473c-.205-1.577.3-2.974 1.4-3.479 1.5-.69 3.542.539 4.555 2.744s.614 4.553-.89 5.242Zm-5.249-18.32a5.929 5.929 0 0 0-2.947 5.125v8.322a5.918 5.918 0 0 0 .158 1.349 18.043 18.043 0 0 1-4.141.479 18.047 18.047 0 0 1-4.141-.479 5.946 5.946 0 0 0 .159-1.349v-8.322a5.931 5.931 0 0 0-2.948-5.125l-7.08-4.118a5.905 5.905 0 0 0-1.9-.7 15.31 15.31 0 0 1 4.484-6.473 5.917 5.917 0 0 0 1.8 1.627l7.08 4.143a5.93 5.93 0 0 0 5.988 0l7.08-4.143a5.872 5.872 0 0 0 .887-.637 15.266 15.266 0 0 1 3.837 5.649 5.95 5.95 0 0 0-1.23.536Z" transform="translate(1353.104 -1795.786)" /></symbol></defs><use xlink:href="#icon-block_chain_a" fill="#ADB6C4" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-block_chain_active"><defs><symbol viewBox="0 0 100 76" id="icon-block_chain_active_a"><path data-name="Path 18326" d="m-1276.05 1838.938-7.08-4.118a5.916 5.916 0 0 0-.755-.368 18.921 18.921 0 0 0-5.893-9.083 5.9 5.9 0 0 0 .127-1.213v-8.322a5.928 5.928 0 0 0-2.948-5.125l-7.081-4.119a5.927 5.927 0 0 0-5.961 0l-7.08 4.119a5.928 5.928 0 0 0-2.948 5.125v7.98a19 19 0 0 0-7.415 11.013l-7.07 4.112a5.929 5.929 0 0 0-2.948 5.125v8.322a5.927 5.927 0 0 0 2.935 5.117l7.08 4.143a5.93 5.93 0 0 0 5.988 0l7.08-4.143a5.948 5.948 0 0 0 .7-.477 21.7 21.7 0 0 0 6.222.906 21.653 21.653 0 0 0 6.221-.908 5.833 5.833 0 0 0 .7.479l7.081 4.143a5.929 5.929 0 0 0 5.987 0l7.08-4.143a5.926 5.926 0 0 0 2.936-5.117v-8.322a5.929 5.929 0 0 0-2.958-5.126Zm-21.9-16.125c1.012-2.206 3.052-3.435 4.555-2.745 1.136.521 1.64 1.991 1.381 3.629a20.98 20.98 0 0 0-1.092-.662 1.839 1.839 0 0 0-2.605.894l-.016.039a1.847 1.847 0 0 0 .819 2.312c.42.237.824.5 1.219.764a3.08 3.08 0 0 1-3.371 1.012c-1.5-.691-1.898-3.038-.885-5.243Zm-17.075 34.269c-1.5-.69-1.9-3.038-.889-5.243s3.052-3.435 4.554-2.745c1.164.535 1.661 2.063 1.359 3.75a17.236 17.236 0 0 1-1.719-.83 1.86 1.86 0 0 0-2.323.413 1.857 1.857 0 0 0 .508 2.826q.874.486 1.8.892a3.035 3.035 0 0 1-3.286.937Zm24.1.177c-1.081.5-2.438 0-3.492-1.143q.588-.259 1.156-.552a1.856 1.856 0 0 0 .648-2.736 1.868 1.868 0 0 0-2.375-.55q-.492.251-1 .473c-.205-1.577.3-2.974 1.4-3.479 1.5-.69 3.542.539 4.555 2.744s.614 4.553-.89 5.242Zm-5.249-18.32a5.929 5.929 0 0 0-2.947 5.125v8.322a5.918 5.918 0 0 0 .158 1.349 18.043 18.043 0 0 1-4.141.479 18.047 18.047 0 0 1-4.141-.479 5.946 5.946 0 0 0 .159-1.349v-8.322a5.931 5.931 0 0 0-2.948-5.125l-7.08-4.118a5.905 5.905 0 0 0-1.9-.7 15.31 15.31 0 0 1 4.484-6.473 5.917 5.917 0 0 0 1.8 1.627l7.08 4.143a5.93 5.93 0 0 0 5.988 0l7.08-4.143a5.872 5.872 0 0 0 .887-.637 15.266 15.266 0 0 1 3.837 5.649 5.95 5.95 0 0 0-1.23.536Z" transform="translate(1353.104 -1795.786)" /></symbol></defs><use xlink:href="#icon-block_chain_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-brl"><defs><symbol viewBox="0 0 24.002 24.002" id="icon-brl_a"><path d="M-13723 14a11.924 11.924 0 0 1-8.487-3.516A11.924 11.924 0 0 1-13735 2a11.919 11.919 0 0 1 3.516-8.484A11.924 11.924 0 0 1-13723-10a12.013 12.013 0 0 1 12 12 11.925 11.925 0 0 1-3.515 8.487A11.92 11.92 0 0 1-13723 14Zm1.44-9.328a.687.687 0 0 0-.534.286 1.021 1.021 0 0 0-.234.658 1.03 1.03 0 0 0 .1.476.892.892 0 0 0 .338.334 5.252 5.252 0 0 0 1.357.693 6.775 6.775 0 0 0 1.6.345v.81a.876.876 0 0 0 .255.651.889.889 0 0 0 .645.248.89.89 0 0 0 .655-.248.9.9 0 0 0 .244-.651v-.853a4.047 4.047 0 0 0 2.244-1.075 2.782 2.782 0 0 0 .831-2.048 2.481 2.481 0 0 0-.5-1.627 2.96 2.96 0 0 0-1.2-.882 13.009 13.009 0 0 0-1.437-.458v-2.775a2.341 2.341 0 0 1 .4.121 6.811 6.811 0 0 1 1.1.583 2.006 2.006 0 0 0 .4.2 1 1 0 0 0 .307.045.687.687 0 0 0 .534-.286 1.008 1.008 0 0 0 .23-.658 1 1 0 0 0-.1-.465.9.9 0 0 0-.323-.345 5.674 5.674 0 0 0-2.534-1.02V-4.1a.9.9 0 0 0-.244-.655.912.912 0 0 0-.655-.245.9.9 0 0 0-.645.245.855.855 0 0 0-.255.655v.855a4.04 4.04 0 0 0-2.258 1.11 2.862 2.862 0 0 0-.862 2.085 2.486 2.486 0 0 0 .518 1.648 3.083 3.083 0 0 0 1.237.9 13.2 13.2 0 0 0 1.444.469V5.65a4.586 4.586 0 0 1-.642-.141 6.013 6.013 0 0 1-1.312-.593 1.5 1.5 0 0 0-.703-.242Zm-8.131-1.41h1.213a1.385 1.385 0 0 1 .721.172 1.75 1.75 0 0 1 .541.562l1.982 2.94a1.093 1.093 0 0 0 .448.421 1.227 1.227 0 0 0 .555.134 1.226 1.226 0 0 0 .786-.269.841.841 0 0 0 .338-.689 1.125 1.125 0 0 0-.225-.645l-1.141-1.71a3.076 3.076 0 0 0-.683-.758 1.944 1.944 0 0 0-.8-.352 3.266 3.266 0 0 0 1.905-1.065 3.087 3.087 0 0 0 .676-2.027 2.954 2.954 0 0 0-.951-2.361 4.243 4.243 0 0 0-2.812-.817h-3.765a1.1 1.1 0 0 0-.813.283 1.124 1.124 0 0 0-.282.81v8.4a1.146 1.146 0 0 0 .313.855 1.161 1.161 0 0 0 .854.317 1.125 1.125 0 0 0 .835-.317 1.186 1.186 0 0 0 .307-.855V3.265Zm12.492 2.268V3.468a1.968 1.968 0 0 1 .534.324.772.772 0 0 1 .279.614 1.1 1.1 0 0 1-.479.951 1.6 1.6 0 0 1-.333.175Zm-10.286-4.036h-2.237v-2.911h2.237a2.414 2.414 0 0 1 1.454.348 1.311 1.311 0 0 1 .448 1.11 1.311 1.311 0 0 1-.448 1.1 2.388 2.388 0 0 1-1.452.359Zm8.583-.648a1.987 1.987 0 0 1-.589-.365.893.893 0 0 1-.286-.683 1.129 1.129 0 0 1 .49-.958 1.478 1.478 0 0 1 .386-.21V.848Z" transform="translate(13735.002 10)" /></symbol></defs><use xlink:href="#icon-brl_a" fill="var(--theme-secondary-color-finance)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-cartas"><defs><symbol viewBox="0 0 100 76" id="icon-cartas_a"><g data-name="Group 54873"><path data-name="Path 17358" d="M-810.636 1229.836a3.193 3.193 0 0 0 1.885-4.1l-15.155-40.922a3.194 3.194 0 0 0-4.1-1.887l-27.116 10.042a3.194 3.194 0 0 0-1.886 4.1l15.156 40.924a3.192 3.192 0 0 0 4.1 1.885Zm-4.346-6.9c1.751 1.04 3.292 1.05 3.736 2.191a1.437 1.437 0 0 1-1.093 2.055 2.938 2.938 0 0 1-1.077-.171 3.663 3.663 0 0 0 1.323 1.094c-.865.315-.866.312-.866.312l-.866.312a3.652 3.652 0 0 0 .314-1.685 3.19 3.19 0 0 1-.746.84 1.441 1.441 0 0 1-2.157-.885c-.386-1.159.753-2.14 1.432-4.062Zm-35.175-24.316a2.929 2.929 0 0 1-1.076-.172 3.665 3.665 0 0 0 1.322 1.095c-.864.315-.865.312-.865.312l-.865.313a3.652 3.652 0 0 0 .314-1.685 3.233 3.233 0 0 1-.746.84 1.441 1.441 0 0 1-2.157-.885c-.389-1.162.754-2.144 1.433-4.065 1.75 1.04 3.292 1.05 3.736 2.19a1.437 1.437 0 0 1-1.096 2.058Zm23.2 18.222a10.688 10.688 0 0 1-3.9-.622 13.3 13.3 0 0 0 4.8 3.969c-3.136 1.143-3.14 1.131-3.14 1.131s0 .012-3.14 1.133a13.256 13.256 0 0 0 1.139-6.11 11.74 11.74 0 0 1-2.706 3.045c-2.018 1.641-6.414 1.006-7.825-3.209s2.732-7.774 5.194-14.739c6.349 3.771 11.94 3.809 13.551 7.943s-1.374 7.432-3.976 7.459Z" transform="translate(877.129 -1172.209)" /><path data-name="Path 17359" d="m-801.927 1183.366-21.978-1.18a6.259 6.259 0 0 1 .849 1.549l6.176 16.675.146-.143c2.388-2.333 6.069-2.519 8.2.058a6.694 6.694 0 0 1-.478 8.891l-.611.6-2.942 2.24 4.668 12.606a6.422 6.422 0 0 1 .383 1.78 1.539 1.539 0 0 1 1.5.568l.144.174.162-.158a1.449 1.449 0 0 1 2.166.015 1.768 1.768 0 0 1-.127 2.35l-.162.158-1.306.995a6.87 6.87 0 0 0-.961.889 6.908 6.908 0 0 0-.86-.986l-1.073-1.017c-.017.038-.03.08-.048.118a6.345 6.345 0 0 1-3.586 3.322l-.178.066 7.239.39a3.194 3.194 0 0 0 3.36-3.018l2.341-43.576a3.193 3.193 0 0 0-3.024-3.366Z" transform="translate(879.273 -1172.244)" /></g></symbol></defs><use xlink:href="#icon-cartas_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-cartas_2"><use xlink:href="#icon-cartas_2_a" /><defs><symbol viewBox="0 0 100 76" id="icon-cartas_2_a"><path data-name="icon_dtfl_qp_0" d="m19.214 44.515.307-5.581a5 5 0 0 1-.858.422 4.937 4.937 0 0 1-6.493-2.891 4.736 4.736 0 0 1 .066-3.8 4.878 4.878 0 0 1 1.16-1.58 5.052 5.052 0 0 1 1.704-1.019 5.494 5.494 0 0 1 2.223-.221s.135 0 .146-.1a.168.168 0 0 0-.035-.13.177.177 0 0 0-.1-.064 5 5 0 0 1-1.653-1.105 4.822 4.822 0 0 1-1.073-1.646 4.878 4.878 0 0 1 .069-3.852 5.019 5.019 0 0 1 1.158-1.611 5.163 5.163 0 0 1 4.73-1.227l.652-11.63L.864 15.947a1.326 1.326 0 0 0-.745.681 1.264 1.264 0 0 0-.033.992l14.045 36.306a1.284 1.284 0 0 0 .274.431 1.326 1.326 0 0 0 .424.3 1.37 1.37 0 0 0 1.023.031l15.668-5.761-8.672-.455a3.916 3.916 0 0 1-2.648-1.247 3.682 3.682 0 0 1-.977-2.7Zm68.305-30.3L57.316.147a1.589 1.589 0 0 0-1.18-.062 1.547 1.547 0 0 0-.519.3 1.5 1.5 0 0 0-.365.473L35.308 41.441a1.47 1.47 0 0 0-.062 1.154 1.529 1.529 0 0 0 .8.86l30.2 14.089a1.591 1.591 0 0 0 1.185.06 1.558 1.558 0 0 0 .519-.3 1.505 1.505 0 0 0 .36-.471L88.242 16.25a1.47 1.47 0 0 0 .075-1.163 1.5 1.5 0 0 0-.309-.513 1.547 1.547 0 0 0-.491-.356ZM55.42 40.533l-4.2-1.989a17.29 17.29 0 0 0 7.36-4.325 16.372 16.372 0 0 0 1.056 8.308c-4.215-1.952-4.2-1.967-4.2-1.967Zm16.841-5.689a6.586 6.586 0 0 1-10.111 2.614 8.8 8.8 0 0 1-2.164-6.091v.033a9.349 9.349 0 0 1-6.257 2.113 6.3 6.3 0 0 1-4.129-9.377c2.475-4.641 9.371-3.912 17.709-7.426 2.326 8.557 7.191 13.39 4.961 18.134Zm-39.134 5.58 3.264-6.644-6.08-6.091-.608-.712a7.183 7.183 0 0 1 .517-9.74 6.268 6.268 0 0 1 9.167.884l.6.712.685-.65a7.072 7.072 0 0 1 4.338-1.967l6.423-13.078-25.991-1.371a1.476 1.476 0 0 0-.555.077 1.443 1.443 0 0 0-.482.278 1.4 1.4 0 0 0-.336.442 1.357 1.357 0 0 0-.137.526l-2.273 41.553a1.368 1.368 0 0 0 .362 1.006 1.456 1.456 0 0 0 .99.462l14.808.782-2.809-1.312a3.921 3.921 0 0 1-2.042-2.21 3.768 3.768 0 0 1 .157-2.957Z" transform="translate(6 8.999)" /></symbol></defs></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-cartas_active"><defs><symbol viewBox="0 0 100 76" id="icon-cartas_active_a"><g data-name="Group 54873"><path data-name="Path 17358" d="M-810.636 1229.836a3.193 3.193 0 0 0 1.885-4.1l-15.155-40.922a3.194 3.194 0 0 0-4.1-1.887l-27.116 10.042a3.194 3.194 0 0 0-1.886 4.1l15.156 40.924a3.192 3.192 0 0 0 4.1 1.885Zm-4.346-6.9c1.751 1.04 3.292 1.05 3.736 2.191a1.437 1.437 0 0 1-1.093 2.055 2.938 2.938 0 0 1-1.077-.171 3.663 3.663 0 0 0 1.323 1.094c-.865.315-.866.312-.866.312l-.866.312a3.652 3.652 0 0 0 .314-1.685 3.19 3.19 0 0 1-.746.84 1.441 1.441 0 0 1-2.157-.885c-.386-1.159.753-2.14 1.432-4.062Zm-35.175-24.316a2.929 2.929 0 0 1-1.076-.172 3.665 3.665 0 0 0 1.322 1.095c-.864.315-.865.312-.865.312l-.865.313a3.652 3.652 0 0 0 .314-1.685 3.233 3.233 0 0 1-.746.84 1.441 1.441 0 0 1-2.157-.885c-.389-1.162.754-2.144 1.433-4.065 1.75 1.04 3.292 1.05 3.736 2.19a1.437 1.437 0 0 1-1.096 2.058Zm23.2 18.222a10.688 10.688 0 0 1-3.9-.622 13.3 13.3 0 0 0 4.8 3.969c-3.136 1.143-3.14 1.131-3.14 1.131s0 .012-3.14 1.133a13.256 13.256 0 0 0 1.139-6.11 11.74 11.74 0 0 1-2.706 3.045c-2.018 1.641-6.414 1.006-7.825-3.209s2.732-7.774 5.194-14.739c6.349 3.771 11.94 3.809 13.551 7.943s-1.374 7.432-3.976 7.459Z" transform="translate(877.129 -1172.209)" /><path data-name="Path 17359" d="m-801.927 1183.366-21.978-1.18a6.259 6.259 0 0 1 .849 1.549l6.176 16.675.146-.143c2.388-2.333 6.069-2.519 8.2.058a6.694 6.694 0 0 1-.478 8.891l-.611.6-2.942 2.24 4.668 12.606a6.422 6.422 0 0 1 .383 1.78 1.539 1.539 0 0 1 1.5.568l.144.174.162-.158a1.449 1.449 0 0 1 2.166.015 1.768 1.768 0 0 1-.127 2.35l-.162.158-1.306.995a6.87 6.87 0 0 0-.961.889 6.908 6.908 0 0 0-.86-.986l-1.073-1.017c-.017.038-.03.08-.048.118a6.345 6.345 0 0 1-3.586 3.322l-.178.066 7.239.39a3.194 3.194 0 0 0 3.36-3.018l2.341-43.576a3.193 3.193 0 0 0-3.024-3.366Z" transform="translate(879.273 -1172.244)" /></g></symbol></defs><use xlink:href="#icon-cartas_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-cartas_active_green"><defs><symbol viewBox="0 0 40 26.102" id="icon-cartas_active_green_a"><path d="m8.694 20.142.139-2.525a2.262 2.262 0 0 1-.388.191A2.234 2.234 0 0 1 5.507 16.5a2.143 2.143 0 0 1 .03-1.721 2.207 2.207 0 0 1 .525-.715 2.286 2.286 0 0 1 .772-.46 2.486 2.486 0 0 1 1.006-.1s.061 0 .066-.045a.076.076 0 0 0-.016-.059.08.08 0 0 0-.047-.029 2.262 2.262 0 0 1-.748-.5 2.182 2.182 0 0 1-.485-.744 2.207 2.207 0 0 1 .031-1.743 2.271 2.271 0 0 1 .524-.729 2.336 2.336 0 0 1 2.14-.555L9.6 3.837.391 7.216a.6.6 0 0 0-.337.308.572.572 0 0 0-.015.449L6.394 24.4a.581.581 0 0 0 .124.195.6.6 0 0 0 .192.134.62.62 0 0 0 .463.014l7.089-2.605-3.924-.206a1.772 1.772 0 0 1-1.2-.564 1.666 1.666 0 0 1-.442-1.22ZM39.6 6.434 25.934.067A.719.719 0 0 0 25.4.039a.7.7 0 0 0-.235.136.679.679 0 0 0-.165.214l-9.024 18.362a.665.665 0 0 0-.028.522.692.692 0 0 0 .36.389l13.665 6.375a.72.72 0 0 0 .536.027.705.705 0 0 0 .235-.136.681.681 0 0 0 .163-.213l9.02-18.362a.665.665 0 0 0 .034-.526.68.68 0 0 0-.14-.232.7.7 0 0 0-.222-.161ZM25.076 18.34l-1.9-.9a7.823 7.823 0 0 0 3.33-1.957 7.408 7.408 0 0 0 .478 3.759c-1.907-.883-1.9-.89-1.9-.89Zm7.62-2.574a2.98 2.98 0 0 1-4.575 1.183 3.982 3.982 0 0 1-.979-2.756v.013a4.23 4.23 0 0 1-2.831.956 2.851 2.851 0 0 1-1.867-4.241c1.12-2.1 4.24-1.77 8.013-3.36 1.051 3.872 3.25 6.06 2.243 8.205Zm-17.707 2.525 1.477-3.006-2.751-2.756-.275-.322a3.25 3.25 0 0 1 .234-4.407 2.836 2.836 0 0 1 4.148.4l.27.322.31-.294a3.2 3.2 0 0 1 1.963-.89l2.907-5.918L11.512.8a.668.668 0 0 0-.251.035.653.653 0 0 0-.218.126.631.631 0 0 0-.152.2.614.614 0 0 0-.062.238L9.8 20.2a.619.619 0 0 0 .164.455.659.659 0 0 0 .448.209l6.7.354-1.271-.594a1.774 1.774 0 0 1-.924-1 1.705 1.705 0 0 1 .071-1.338Z" /></symbol></defs><use xlink:href="#icon-cartas_active_green_a" fill="#333" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-cartas_green"><defs><symbol viewBox="0 0 40 26.102" id="icon-cartas_green_a"><path d="m8.694 20.142.139-2.525a2.262 2.262 0 0 1-.388.191A2.234 2.234 0 0 1 5.507 16.5a2.143 2.143 0 0 1 .03-1.721 2.207 2.207 0 0 1 .525-.715 2.286 2.286 0 0 1 .772-.46 2.486 2.486 0 0 1 1.006-.1s.061 0 .066-.045a.076.076 0 0 0-.016-.059.08.08 0 0 0-.047-.029 2.262 2.262 0 0 1-.748-.5 2.182 2.182 0 0 1-.485-.744 2.207 2.207 0 0 1 .031-1.743 2.271 2.271 0 0 1 .524-.729 2.336 2.336 0 0 1 2.14-.555L9.6 3.837.391 7.216a.6.6 0 0 0-.337.308.572.572 0 0 0-.015.449L6.394 24.4a.581.581 0 0 0 .124.195.6.6 0 0 0 .192.134.62.62 0 0 0 .463.014l7.089-2.605-3.924-.206a1.772 1.772 0 0 1-1.2-.564 1.666 1.666 0 0 1-.442-1.22ZM39.6 6.434 25.934.067A.719.719 0 0 0 25.4.039a.7.7 0 0 0-.235.136.679.679 0 0 0-.165.214l-9.024 18.362a.665.665 0 0 0-.028.522.692.692 0 0 0 .36.389l13.665 6.375a.72.72 0 0 0 .536.027.705.705 0 0 0 .235-.136.681.681 0 0 0 .163-.213l9.02-18.362a.665.665 0 0 0 .034-.526.68.68 0 0 0-.14-.232.7.7 0 0 0-.222-.161ZM25.076 18.34l-1.9-.9a7.823 7.823 0 0 0 3.33-1.957 7.408 7.408 0 0 0 .478 3.759c-1.907-.883-1.9-.89-1.9-.89Zm7.62-2.574a2.98 2.98 0 0 1-4.575 1.183 3.982 3.982 0 0 1-.979-2.756v.013a4.23 4.23 0 0 1-2.831.956 2.851 2.851 0 0 1-1.867-4.241c1.12-2.1 4.24-1.77 8.013-3.36 1.051 3.872 3.25 6.06 2.243 8.205Zm-17.707 2.525 1.477-3.006-2.751-2.756-.275-.322a3.25 3.25 0 0 1 .234-4.407 2.836 2.836 0 0 1 4.148.4l.27.322.31-.294a3.2 3.2 0 0 1 1.963-.89l2.907-5.918L11.512.8a.668.668 0 0 0-.251.035.653.653 0 0 0-.218.126.631.631 0 0 0-.152.2.614.614 0 0 0-.062.238L9.8 20.2a.619.619 0 0 0 .164.455.659.659 0 0 0 .448.209l6.7.354-1.271-.594a1.774 1.774 0 0 1-.924-1 1.705 1.705 0 0 1 .071-1.338Z" /></symbol></defs><use xlink:href="#icon-cartas_green_a" fill="#ADB6C4" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76.001" id="icon-cassino"><defs><symbol viewBox="0 0 100 76.001" id="icon-cassino_a"><path data-name="Union 225" d="M44.449 74.993a1.615 1.615 0 0 1 .326-.412c1.369-.911.98-1.992.211-2.922A9.517 9.517 0 0 0 42.4 69.7c-.408-.238-.82-.463-1.232-.7.027-.064.055-.133.086-.2l3.949 1.067a8.562 8.562 0 0 0-2.629-2.015 56.313 56.313 0 0 0-8.588-3.532 49.051 49.051 0 0 1-8.586-3.549 30.178 30.178 0 0 1-7.611-5.826A15.611 15.611 0 0 1 14 48.171a13.893 13.893 0 0 1 .779-8.854 22.56 22.56 0 0 1 2.921-5.231c.082-.11.174-.211.262-.321-1.041 7.209 1.506 13.086 6.406 18.161a5.426 5.426 0 0 1 .871-4.1c.092.156.16.22.16.289 0 2.89 1.488 5.038 3.408 7A29.675 29.675 0 0 0 35.8 60.1c.2.11.395.229.586.353.043.023.047.1.115.252a11.166 11.166 0 0 1-1.086-.3 62.653 62.653 0 0 1-7.815-3.578 28.22 28.22 0 0 1-7.117-5.373 29.741 29.741 0 0 1-2.625-3.93.357.357 0 0 0-.234-.188 14.386 14.386 0 0 0 .449 1.4 15.824 15.824 0 0 0 3.682 5.226 25.964 25.964 0 0 0 3.027 2.51 42.751 42.751 0 0 0 8.758 4.718c2.648 1.04 5.332 1.979 7.971 3.037a28.685 28.685 0 0 1 6.389 3.355 6.35 6.35 0 0 1 2 2.093 2.457 2.457 0 0 1-.678 3.3 12.608 12.608 0 0 1-3.678 1.851 2.651 2.651 0 0 1-.893.175c-.061-.001-.13-.001-.202-.008ZM37.5 59.878a32.129 32.129 0 0 1-2.152-3.811 53.223 53.223 0 0 0-3.316-6.793 1.042 1.042 0 0 1-.072-.293c.137-.082.266-.22.41-.238a10.236 10.236 0 0 0 5.383-2.492c.762-.646 1.471-1.356 2.223-2.02a5.3 5.3 0 0 1 .742-.472l.182.11a4.114 4.114 0 0 1-.082.87q-.668 2.226-1.379 4.434c-.631 1.96-1.359 3.888-1.9 5.872a5.241 5.241 0 0 0 1.861 5.978 1.072 1.072 0 0 1 .164.247l-.113.133a5.294 5.294 0 0 1-1.951-1.525ZM22 59.543a30.58 30.58 0 0 1-9.684-6.156 18.005 18.005 0 0 1-5.006-7.833 16.279 16.279 0 0 1-.641-6.293A24.813 24.813 0 0 1 10.861 28a55.038 55.038 0 0 1 7.275-8.817 58.632 58.632 0 0 1 9.594-7.951 33.8 33.8 0 0 1 9.238-4.365 13.164 13.164 0 0 1 5.113-.508c1.611.188 2.473.824 2.711 2.093a3.871 3.871 0 0 1-.119 1.6 3.336 3.336 0 0 1-1.113 1.906 1.474 1.474 0 0 1-.182-.38C43 9.513 41.125 8.79 39.318 9.06a13.589 13.589 0 0 0-4.437 1.6 49.633 49.633 0 0 0-9.977 7.31c-.627.582-1.254 1.163-2 1.864.781.215 1.406.38 2.027.554.33.1.66.206.99.3a3.122 3.122 0 0 0 1.4.188 4.77 4.77 0 0 1 1.781.407.443.443 0 0 1 .225.243 3.918 3.918 0 0 1 .309 2.583c-.316-.124-.555-.206-.779-.307-1.307-.6-2.594-1.232-3.922-1.777-.766-.312-1.594-.458-2.387-.706a1.179 1.179 0 0 0-1.418.49c-1.3 1.681-2.656 3.316-3.908 5.034a34.246 34.246 0 0 0-5.623 11.464c-1.127 4.3-1.078 8.542 1.07 12.568a16.723 16.723 0 0 0 5.465 5.991c1.322.9 2.752 1.644 4.135 2.46.193.11.385.22.572.33l-.045.124c-.267-.08-.536-.136-.796-.237ZM6.025 46.861a19.852 19.852 0 0 1-2.275-7.526 18.116 18.116 0 0 1 1.488-8.561 29.068 29.068 0 0 1 5.775-8.6 46.768 46.768 0 0 1 6.365-5.62c1.467-1.1 3.043-2.056 4.572-3.073.139-.087.293-.142.439-.215l.129.169c-.518.394-1.031.792-1.553 1.177a59.428 59.428 0 0 0-5.75 4.915 40.925 40.925 0 0 0-5.293 6.211 26.675 26.675 0 0 0-3.83 7.951 20.87 20.87 0 0 0-.75 8.171A18 18 0 0 0 7.1 48.12a2.2 2.2 0 0 1 .109.375l-.17.083c-.339-.572-.707-1.131-1.014-1.717Zm22.495-3.953c-.7-.518-1.361-1.09-2.08-1.672a9.348 9.348 0 0 0 1.145-.829c.313-.293.5-.7.809-1a9.317 9.317 0 0 1 1.139-.9 1.658 1.658 0 0 1 1.549-.22 2.24 2.24 0 0 0 1.25.041 2.386 2.386 0 0 1 2.383.582 10.037 10.037 0 0 1 .971.976c.43.444.846.9 1.355 1.438-.17.146-.408.366-.656.568-.6.481-1.189.985-1.822 1.429a2.876 2.876 0 0 1-2.35.563.86.86 0 0 0-.34-.023 3.22 3.22 0 0 1-.75.09 4.4 4.4 0 0 1-2.603-1.043Zm1.355-2.608a5.262 5.262 0 0 0 3.705-.1c-1.154-.046-2.16-.1-3.17-.124h-.01c-.117-.003-.242.1-.525.224Zm12.088 2.656a26.161 26.161 0 0 0 3.6-10.832 5.863 5.863 0 0 1 1.516 2.359 5.806 5.806 0 0 0-.125-3.321c-.25-1.1-.611-2.18-.947-3.339a1.4 1.4 0 0 1 .326.105 11.1 11.1 0 0 1 2.455 2.6 5.623 5.623 0 0 1 .3 6.023 16.548 16.548 0 0 1-6.77 6.426.106.106 0 0 1-.055.012c-.063 0-.158-.025-.3-.035ZM2.646 36.807a13.594 13.594 0 0 1-1.566-5.6 12.265 12.265 0 0 1 1.4-6.06 21.742 21.742 0 0 1 4.43-5.771 44.509 44.509 0 0 1 6.535-5.025A82.3 82.3 0 0 1 21.8 9.7c.314-.161.648-.289.975-.431l.1.2c-.605.353-1.213.7-1.812 1.058a67.647 67.647 0 0 0-9.281 6.683 38.869 38.869 0 0 0-5.795 6.1 18.45 18.45 0 0 0-3.32 6.857 11.561 11.561 0 0 0 .418 6.77l.166.453-.143.078a5.069 5.069 0 0 1-.462-.661Zm47.3-.792c.146-.275.289-.554.439-.825a4.969 4.969 0 0 0-.287-5.437 7.658 7.658 0 0 0-.748-1.191c-.8-.852-1.666-1.649-2.5-2.469-.125-.128-.248-.261-.371-.389l.09-.156a19.125 19.125 0 0 1 1.912.669 7.5 7.5 0 0 1 3.512 2.666 3.857 3.857 0 0 1 .551 2.963 8.9 8.9 0 0 1-2.428 4.246Zm-16.42-.009a5.572 5.572 0 0 1-.566-.426c-.131-.1-.5-.21-.449-.421s.5-.16.654-.128a1.235 1.235 0 0 1 .746.449.643.643 0 0 1 .139.288.3.3 0 0 1-.125.284.252.252 0 0 1-.135.036.55.55 0 0 1-.265-.083Zm-4.1.046a.282.282 0 0 1-.125-.284.552.552 0 0 1 .137-.288 1.226 1.226 0 0 1 .742-.449c.152-.032.615-.083.66.128s-.324.325-.449.421a6.336 6.336 0 0 1-.568.426.563.563 0 0 1-.264.082.245.245 0 0 1-.131-.037ZM37.7 28.5a4.433 4.433 0 0 1-2.217-.673c.307-.161.525-.275.926-.481l-1.027.1c2.1-2.318 5.789-2.528 7.332-.976a14.752 14.752 0 0 0-1.969-.577 8.677 8.677 0 0 0-2.006.046 12.637 12.637 0 0 1 4.113.861 5.069 5.069 0 0 0 2.7.357c-.5.563-1.178.458-2.008.486l.957.229a3.056 3.056 0 0 1-1.676.412 3.131 3.131 0 0 0-1.74.362 1.043 1.043 0 0 1-.709.11 3.147 3.147 0 0 0-2.084.087c-.21-.134-.401-.354-.592-.343Zm-13.256.142a2.465 2.465 0 0 0-1.352.05.166.166 0 0 1-.082 0c-1.178-.211-2.359-.426-3.535-.641-.043-.009-.078-.078-.176-.178.238-.078.445-.142.719-.234-.744-.046-1.465.115-2.16-.563a5.362 5.362 0 0 0 3.377-.525l-.221-.1c1.131-1.516 5.316-1.356 7.063.976-.371-.1-.66-.174-.943-.252l-.033.06c.293.193.588.385.994.646-.811.119-1.324.76-2.1.609a1.6 1.6 0 0 1-.854.22 4.8 4.8 0 0 1-.694-.07Zm-1.828-2.712a7.805 7.805 0 0 0-1.354.614l3.494-.659a2.155 2.155 0 0 0-.822-.141 5.7 5.7 0 0 0-1.315.185Zm29.686.536a12.917 12.917 0 0 0-4.58-2.835c-.445-.188-1.059-.275-1.287-.614s-.051-.93-.027-1.406a16.765 16.765 0 0 0-.732-5.693 2.882 2.882 0 0 1-.137-.953 11.52 11.52 0 0 1 2.871 2.079c.883.77 1.7 1.622 2.652 2.551a13.345 13.345 0 0 0-2.635-3.481c-1.012-1.012-2.115-1.924-3.156-2.854.34-.06.322-.032.639.179.52.353 1.08.646 1.6 1a13.829 13.829 0 0 1 4.664 5.1 11.774 11.774 0 0 1 1.35 5.038c.033.8.023 1.6 0 2.4a4.486 4.486 0 0 1-.2.838 15.77 15.77 0 0 0-1.024-1.35Zm-25.665-1.847a2.693 2.693 0 0 0-2.73-.545A6.73 6.73 0 0 0 21 25.842c-.123.119-.246.238-.379.348-.033.023-.1 0-.252 0a5.448 5.448 0 0 1 4.557-2.84 3.459 3.459 0 0 1 1.678.582 4.126 4.126 0 0 1 1.664 2.368c-.61-.632-1.09-1.191-1.631-1.681Zm13.754-.948a7.138 7.138 0 0 1 2.635 2.144c.045.055.041.146.1.353-.7-.531-1.287-1.012-1.91-1.438a3.688 3.688 0 0 0-3.068-.719 3.5 3.5 0 0 0-1.814 1.237c-.273.32-.518.668-.779 1a3.443 3.443 0 0 1 4.836-2.577Zm-6.119-2.057c.061-.124.289-.174.445-.248.119-.055.279-.06.357-.146a1.289 1.289 0 0 1 1.084-.33h.281a5.422 5.422 0 0 0 1.057-.142c1.049-.279 2.094-.609 3.15-.861a2.611 2.611 0 0 1 1.273-.032 9.919 9.919 0 0 1 3.7 2.2c-.041.064-.08.124-.117.188a6.8 6.8 0 0 1-.684-.3 6.3 6.3 0 0 0-5.568-.137c-1.484.586-2.932 1.282-4.4 1.924-.225.1-.463.178-.756.288a3.3 3.3 0 0 1 .177-2.404ZM3.314 17.405a3.126 3.126 0 0 1-2.107-1.374A7.139 7.139 0 0 1 .063 12.55a19.228 19.228 0 0 1-.038-2.579A1.469 1.469 0 0 1 .139 9.6l.2.014a8.928 8.928 0 0 0 .051 1.049 21.876 21.876 0 0 0 .48 2.7 2.266 2.266 0 0 0 2.884 1.647 13.023 13.023 0 0 0 3.953-1.654c2.734-1.631 5.414-3.353 8.166-4.947a96.191 96.191 0 0 1 9.609-4.837A41.438 41.438 0 0 1 34.973.55 15.407 15.407 0 0 1 40.2.453a6.274 6.274 0 0 1 4.992 3.765 2.38 2.38 0 0 1 .166 1.732 3.145 3.145 0 0 1-.295-.366 6.38 6.38 0 0 0-5.414-3.161 18.779 18.779 0 0 0-7.689 1.191c-2.023.719-4.008 1.562-5.982 2.418a65.927 65.927 0 0 0-8.5 4.516c-2.826 1.754-5.639 3.536-8.482 5.258a22.483 22.483 0 0 1-2.707 1.31 4.828 4.828 0 0 1-1.918.363 8.063 8.063 0 0 1-1.057-.074Zm41.418-5.13c.322-.22.541-.4.779-.536a9.675 9.675 0 0 0 2.4-2.065 3.981 3.981 0 0 0 .99-4.2c-.037-.11-.078-.215-.111-.325s-.055-.215-.123-.49a3.024 3.024 0 0 1 .521.421 5.46 5.46 0 0 1 1.266 3.142 3.022 3.022 0 0 1-1.434 2.688 9.916 9.916 0 0 1-4 1.489h-.012a1.585 1.585 0 0 1-.276-.124Zm1.023-2.9a7.106 7.106 0 0 0 .545-4.117A7.089 7.089 0 0 0 43 .719c-.26-.174-.52-.353-.781-.531L42.328 0a9.391 9.391 0 0 1 .908.385A9.755 9.755 0 0 1 46.465 2.9 4.921 4.921 0 0 1 47.2 8a12.131 12.131 0 0 1-2.3 3.606.77.77 0 0 1-.2.165c-.037.027-.1.018-.146.023.409-.801.862-1.585 1.202-2.418ZM26.5 10.947c.527-.38 1.039-.783 1.584-1.145a41.9 41.9 0 0 1 8.141-4.448 11.016 11.016 0 0 1 4.438-.911 3.937 3.937 0 0 1 2.656 1.063 1.341 1.341 0 0 1 .17.192.739.739 0 0 1 .041.2c-.068.023-.16.092-.207.069a6.461 6.461 0 0 0-3.965-.307 25.282 25.282 0 0 0-5.883 1.869 47.273 47.273 0 0 0-6.359 3.385 3.527 3.527 0 0 1-.518.215Z" transform="translate(22.501)" /></symbol></defs><use xlink:href="#icon-cassino_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-cassino_2"><use xlink:href="#icon-cassino_2_a" /><defs><symbol viewBox="0 0 100 76" id="icon-cassino_2_a"><path data-name="icon_dtfl_zr_0" d="M43.981 21.568c-.044-3.793-2.769-6.281-4.528-8.555l-2.175-2c-1.651-3.006 2.7-7.4 4.347-8.193 2.305.442 3.823 2.707 5.083 4.279a23.8 23.8 0 0 1 3.892 5.639c1.3 3.156 1.784 6.8 2.809 10.2L55.2 27.12a7.106 7.106 0 0 1-1.45 4.1c-.252.3-.663.192-.816.637-.948 2.911-.933 6.758-2.809 8.739A12.7 12.7 0 0 0 57.1 50.967c1.956.7 4.1.126 5.888.727a13 13 0 0 1 6.8 6.648c.663 1.3 3.5 10.46 1 11.742-2.047-1.025-1.211-5.147-1.722-7.735-.48-2.732-2.886-7.514-5.083-8.465a9.439 9.439 0 0 0-4.075-.274c-.866.137-1.7-.124-2.265.274l-.816 1.547-1.36 2.639c-.3 3.823-.6 7.682-.906 11.468l-.544.455-4.617-.455h-8.5l-.272-.181c.464-1.439 3.737-1.85 4.982-2.548a16.713 16.713 0 0 0 7.79-9.572c.316-.853 1.459-2.265 1.269-3.185l-.181-.455c-5.039-1.342-7.612.866-10.96-2.913-.287-.4-.942-.464-1.178-1-.9-2.031.057-5.22-.544-7.645l-.544.181c-1.105 2.4-5.746 6.511-9.784 4.825-2.144-.9-4.17-3.26-6.16-3.914l-.091.091c.024 5.262.234 10.805-2.356 13.654a20.461 20.461 0 0 1-2.265 2.367c-1.326 1.021-3.028 1.308-3.8 2.913a4.663 4.663 0 0 0-.634 2.639c.2.869 3.233 3.291 4.528 3 1.768-.393 2.276-2.265 3.622-3.094l.272.181C27.072 75.377 1.72 75.9.047 66.714a7.161 7.161 0 0 1 3.622-6.553c1.189-.663 2.515-.74 3.713-1.456a9.534 9.534 0 0 0 3.355-5.735c.844-4.144-.972-6.767-1.722-9.375l-.442-4c-.221-.981-1.065-1.861-.816-3.187.418-2.21 3.773-5.331 4.8-8.009 1.22-3.138.506-7.711 1.547-11.013A25.33 25.33 0 0 1 24.522 3.363C28.411.521 35.229-2.06 39.2 2.453a21.721 21.721 0 0 1-4.257 8.193c-1.326.663-3.859-.024-5.344.546a14.556 14.556 0 0 0-6.9 9.831l.272.181 1.722-.091a14.259 14.259 0 0 1 5.344 1.456v.455c-.864 1.065-6.829-2.382-8.244.455a.782.782 0 0 0-.091.637l.091.365c3.247-.128 5.843-.946 7.514 1.456l-.091.455h-1.273c-.312.749-.517 1.423-1.269 1.728-1.781.541-2.21-.738-2.718-1.821h-.091c-.818.221-.192.663 0 1.182l-.272.181c-1.065.455-1.563-.484-2.265-.727v.181C19.681 31.007 22.4 38 23.956 40.042a25.2 25.2 0 0 0 4.982 4c1.211.864 3.377 2.765 5.616 2.367 1.808-.32 3.41-2.418 4.438-3.64 3.784-4.5 6.575-8.759 5.888-16.748h-.272c-.8.716-1.286 2-2.809 1.638l-.091-.181.442-1-.161-.186-.544.181a1.932 1.932 0 0 1-2.99 1.456l-.906-1.547a2.055 2.055 0 0 1-1.269-.091v-.442c1.989-2.431 5.083-1.547 8.425-1.092v-.19c.221-.588-.261-1.326-.544-1.731a14.467 14.467 0 0 0-4.891-.455c-1.167.241-2.27 1.167-3.536 1l-.091-.274c-.15-.407 0-.535.181-.82a18.291 18.291 0 0 1 8.157-.719Zm3.081 4.825a11.862 11.862 0 0 0-1.178 5.826c2.257.97 3.171-1.4 3.894-3.278-.484-1.076-1.529-1.7-2.265-2.548Zm-13.315 7.735 1.547.091a.709.709 0 0 1-.091.637c-1.275.442-3.536 1.224-4.438-.274l.181-.272a5.932 5.932 0 0 0 2.8-.181Zm13.04.82a40.644 40.644 0 0 0 .091 11.833l.362-.181c.221-3.118.972-8.449 0-11.468Zm-12.864 2.639 3.8.365c-.239.793-1.01 1.129-1.631 1.547-3 2.02-2.794 1.523-5.616 0-.884-.473-1.834-.557-2.447-1.275.119-.349 0-.19.272-.365 1.388-.493 4.367.491 5.62-.272ZM4.668 61.8c-2.451 1.948-4.135 4.812-.634 7.19.329-.06.3-.038.442-.181-1.136-2.6.015-4.478.362-6.644.062-.356.12-.199-.17-.365Z" transform="translate(13.96 .996)" fill-rule="evenodd" /></symbol></defs></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76.001" id="icon-cassino_active"><defs><symbol viewBox="0 0 100 76.001" id="icon-cassino_active_a"><path data-name="Union 225" d="M44.449 74.993a1.615 1.615 0 0 1 .326-.412c1.369-.911.98-1.992.211-2.922A9.517 9.517 0 0 0 42.4 69.7c-.408-.238-.82-.463-1.232-.7.027-.064.055-.133.086-.2l3.949 1.067a8.562 8.562 0 0 0-2.629-2.015 56.313 56.313 0 0 0-8.588-3.532 49.051 49.051 0 0 1-8.586-3.549 30.178 30.178 0 0 1-7.611-5.826A15.611 15.611 0 0 1 14 48.171a13.893 13.893 0 0 1 .779-8.854 22.56 22.56 0 0 1 2.921-5.231c.082-.11.174-.211.262-.321-1.041 7.209 1.506 13.086 6.406 18.161a5.426 5.426 0 0 1 .871-4.1c.092.156.16.22.16.289 0 2.89 1.488 5.038 3.408 7A29.675 29.675 0 0 0 35.8 60.1c.2.11.395.229.586.353.043.023.047.1.115.252a11.166 11.166 0 0 1-1.086-.3 62.653 62.653 0 0 1-7.815-3.578 28.22 28.22 0 0 1-7.117-5.373 29.741 29.741 0 0 1-2.625-3.93.357.357 0 0 0-.234-.188 14.386 14.386 0 0 0 .449 1.4 15.824 15.824 0 0 0 3.682 5.226 25.964 25.964 0 0 0 3.027 2.51 42.751 42.751 0 0 0 8.758 4.718c2.648 1.04 5.332 1.979 7.971 3.037a28.685 28.685 0 0 1 6.389 3.355 6.35 6.35 0 0 1 2 2.093 2.457 2.457 0 0 1-.678 3.3 12.608 12.608 0 0 1-3.678 1.851 2.651 2.651 0 0 1-.893.175c-.061-.001-.13-.001-.202-.008ZM37.5 59.878a32.129 32.129 0 0 1-2.152-3.811 53.223 53.223 0 0 0-3.316-6.793 1.042 1.042 0 0 1-.072-.293c.137-.082.266-.22.41-.238a10.236 10.236 0 0 0 5.383-2.492c.762-.646 1.471-1.356 2.223-2.02a5.3 5.3 0 0 1 .742-.472l.182.11a4.114 4.114 0 0 1-.082.87q-.668 2.226-1.379 4.434c-.631 1.96-1.359 3.888-1.9 5.872a5.241 5.241 0 0 0 1.861 5.978 1.072 1.072 0 0 1 .164.247l-.113.133a5.294 5.294 0 0 1-1.951-1.525ZM22 59.543a30.58 30.58 0 0 1-9.684-6.156 18.005 18.005 0 0 1-5.006-7.833 16.279 16.279 0 0 1-.641-6.293A24.813 24.813 0 0 1 10.861 28a55.038 55.038 0 0 1 7.275-8.817 58.632 58.632 0 0 1 9.594-7.951 33.8 33.8 0 0 1 9.238-4.365 13.164 13.164 0 0 1 5.113-.508c1.611.188 2.473.824 2.711 2.093a3.871 3.871 0 0 1-.119 1.6 3.336 3.336 0 0 1-1.113 1.906 1.474 1.474 0 0 1-.182-.38C43 9.513 41.125 8.79 39.318 9.06a13.589 13.589 0 0 0-4.437 1.6 49.633 49.633 0 0 0-9.977 7.31c-.627.582-1.254 1.163-2 1.864.781.215 1.406.38 2.027.554.33.1.66.206.99.3a3.122 3.122 0 0 0 1.4.188 4.77 4.77 0 0 1 1.781.407.443.443 0 0 1 .225.243 3.918 3.918 0 0 1 .309 2.583c-.316-.124-.555-.206-.779-.307-1.307-.6-2.594-1.232-3.922-1.777-.766-.312-1.594-.458-2.387-.706a1.179 1.179 0 0 0-1.418.49c-1.3 1.681-2.656 3.316-3.908 5.034a34.246 34.246 0 0 0-5.623 11.464c-1.127 4.3-1.078 8.542 1.07 12.568a16.723 16.723 0 0 0 5.465 5.991c1.322.9 2.752 1.644 4.135 2.46.193.11.385.22.572.33l-.045.124c-.267-.08-.536-.136-.796-.237ZM6.025 46.861a19.852 19.852 0 0 1-2.275-7.526 18.116 18.116 0 0 1 1.488-8.561 29.068 29.068 0 0 1 5.775-8.6 46.768 46.768 0 0 1 6.365-5.62c1.467-1.1 3.043-2.056 4.572-3.073.139-.087.293-.142.439-.215l.129.169c-.518.394-1.031.792-1.553 1.177a59.428 59.428 0 0 0-5.75 4.915 40.925 40.925 0 0 0-5.293 6.211 26.675 26.675 0 0 0-3.83 7.951 20.87 20.87 0 0 0-.75 8.171A18 18 0 0 0 7.1 48.12a2.2 2.2 0 0 1 .109.375l-.17.083c-.339-.572-.707-1.131-1.014-1.717Zm22.495-3.953c-.7-.518-1.361-1.09-2.08-1.672a9.348 9.348 0 0 0 1.145-.829c.313-.293.5-.7.809-1a9.317 9.317 0 0 1 1.139-.9 1.658 1.658 0 0 1 1.549-.22 2.24 2.24 0 0 0 1.25.041 2.386 2.386 0 0 1 2.383.582 10.037 10.037 0 0 1 .971.976c.43.444.846.9 1.355 1.438-.17.146-.408.366-.656.568-.6.481-1.189.985-1.822 1.429a2.876 2.876 0 0 1-2.35.563.86.86 0 0 0-.34-.023 3.22 3.22 0 0 1-.75.09 4.4 4.4 0 0 1-2.603-1.043Zm1.355-2.608a5.262 5.262 0 0 0 3.705-.1c-1.154-.046-2.16-.1-3.17-.124h-.01c-.117-.003-.242.1-.525.224Zm12.088 2.656a26.161 26.161 0 0 0 3.6-10.832 5.863 5.863 0 0 1 1.516 2.359 5.806 5.806 0 0 0-.125-3.321c-.25-1.1-.611-2.18-.947-3.339a1.4 1.4 0 0 1 .326.105 11.1 11.1 0 0 1 2.455 2.6 5.623 5.623 0 0 1 .3 6.023 16.548 16.548 0 0 1-6.77 6.426.106.106 0 0 1-.055.012c-.063 0-.158-.025-.3-.035ZM2.646 36.807a13.594 13.594 0 0 1-1.566-5.6 12.265 12.265 0 0 1 1.4-6.06 21.742 21.742 0 0 1 4.43-5.771 44.509 44.509 0 0 1 6.535-5.025A82.3 82.3 0 0 1 21.8 9.7c.314-.161.648-.289.975-.431l.1.2c-.605.353-1.213.7-1.812 1.058a67.647 67.647 0 0 0-9.281 6.683 38.869 38.869 0 0 0-5.795 6.1 18.45 18.45 0 0 0-3.32 6.857 11.561 11.561 0 0 0 .418 6.77l.166.453-.143.078a5.069 5.069 0 0 1-.462-.661Zm47.3-.792c.146-.275.289-.554.439-.825a4.969 4.969 0 0 0-.287-5.437 7.658 7.658 0 0 0-.748-1.191c-.8-.852-1.666-1.649-2.5-2.469-.125-.128-.248-.261-.371-.389l.09-.156a19.125 19.125 0 0 1 1.912.669 7.5 7.5 0 0 1 3.512 2.666 3.857 3.857 0 0 1 .551 2.963 8.9 8.9 0 0 1-2.428 4.246Zm-16.42-.009a5.572 5.572 0 0 1-.566-.426c-.131-.1-.5-.21-.449-.421s.5-.16.654-.128a1.235 1.235 0 0 1 .746.449.643.643 0 0 1 .139.288.3.3 0 0 1-.125.284.252.252 0 0 1-.135.036.55.55 0 0 1-.265-.083Zm-4.1.046a.282.282 0 0 1-.125-.284.552.552 0 0 1 .137-.288 1.226 1.226 0 0 1 .742-.449c.152-.032.615-.083.66.128s-.324.325-.449.421a6.336 6.336 0 0 1-.568.426.563.563 0 0 1-.264.082.245.245 0 0 1-.131-.037ZM37.7 28.5a4.433 4.433 0 0 1-2.217-.673c.307-.161.525-.275.926-.481l-1.027.1c2.1-2.318 5.789-2.528 7.332-.976a14.752 14.752 0 0 0-1.969-.577 8.677 8.677 0 0 0-2.006.046 12.637 12.637 0 0 1 4.113.861 5.069 5.069 0 0 0 2.7.357c-.5.563-1.178.458-2.008.486l.957.229a3.056 3.056 0 0 1-1.676.412 3.131 3.131 0 0 0-1.74.362 1.043 1.043 0 0 1-.709.11 3.147 3.147 0 0 0-2.084.087c-.21-.134-.401-.354-.592-.343Zm-13.256.142a2.465 2.465 0 0 0-1.352.05.166.166 0 0 1-.082 0c-1.178-.211-2.359-.426-3.535-.641-.043-.009-.078-.078-.176-.178.238-.078.445-.142.719-.234-.744-.046-1.465.115-2.16-.563a5.362 5.362 0 0 0 3.377-.525l-.221-.1c1.131-1.516 5.316-1.356 7.063.976-.371-.1-.66-.174-.943-.252l-.033.06c.293.193.588.385.994.646-.811.119-1.324.76-2.1.609a1.6 1.6 0 0 1-.854.22 4.8 4.8 0 0 1-.694-.07Zm-1.828-2.712a7.805 7.805 0 0 0-1.354.614l3.494-.659a2.155 2.155 0 0 0-.822-.141 5.7 5.7 0 0 0-1.315.185Zm29.686.536a12.917 12.917 0 0 0-4.58-2.835c-.445-.188-1.059-.275-1.287-.614s-.051-.93-.027-1.406a16.765 16.765 0 0 0-.732-5.693 2.882 2.882 0 0 1-.137-.953 11.52 11.52 0 0 1 2.871 2.079c.883.77 1.7 1.622 2.652 2.551a13.345 13.345 0 0 0-2.635-3.481c-1.012-1.012-2.115-1.924-3.156-2.854.34-.06.322-.032.639.179.52.353 1.08.646 1.6 1a13.829 13.829 0 0 1 4.664 5.1 11.774 11.774 0 0 1 1.35 5.038c.033.8.023 1.6 0 2.4a4.486 4.486 0 0 1-.2.838 15.77 15.77 0 0 0-1.024-1.35Zm-25.665-1.847a2.693 2.693 0 0 0-2.73-.545A6.73 6.73 0 0 0 21 25.842c-.123.119-.246.238-.379.348-.033.023-.1 0-.252 0a5.448 5.448 0 0 1 4.557-2.84 3.459 3.459 0 0 1 1.678.582 4.126 4.126 0 0 1 1.664 2.368c-.61-.632-1.09-1.191-1.631-1.681Zm13.754-.948a7.138 7.138 0 0 1 2.635 2.144c.045.055.041.146.1.353-.7-.531-1.287-1.012-1.91-1.438a3.688 3.688 0 0 0-3.068-.719 3.5 3.5 0 0 0-1.814 1.237c-.273.32-.518.668-.779 1a3.443 3.443 0 0 1 4.836-2.577Zm-6.119-2.057c.061-.124.289-.174.445-.248.119-.055.279-.06.357-.146a1.289 1.289 0 0 1 1.084-.33h.281a5.422 5.422 0 0 0 1.057-.142c1.049-.279 2.094-.609 3.15-.861a2.611 2.611 0 0 1 1.273-.032 9.919 9.919 0 0 1 3.7 2.2c-.041.064-.08.124-.117.188a6.8 6.8 0 0 1-.684-.3 6.3 6.3 0 0 0-5.568-.137c-1.484.586-2.932 1.282-4.4 1.924-.225.1-.463.178-.756.288a3.3 3.3 0 0 1 .177-2.404ZM3.314 17.405a3.126 3.126 0 0 1-2.107-1.374A7.139 7.139 0 0 1 .063 12.55a19.228 19.228 0 0 1-.038-2.579A1.469 1.469 0 0 1 .139 9.6l.2.014a8.928 8.928 0 0 0 .051 1.049 21.876 21.876 0 0 0 .48 2.7 2.266 2.266 0 0 0 2.884 1.647 13.023 13.023 0 0 0 3.953-1.654c2.734-1.631 5.414-3.353 8.166-4.947a96.191 96.191 0 0 1 9.609-4.837A41.438 41.438 0 0 1 34.973.55 15.407 15.407 0 0 1 40.2.453a6.274 6.274 0 0 1 4.992 3.765 2.38 2.38 0 0 1 .166 1.732 3.145 3.145 0 0 1-.295-.366 6.38 6.38 0 0 0-5.414-3.161 18.779 18.779 0 0 0-7.689 1.191c-2.023.719-4.008 1.562-5.982 2.418a65.927 65.927 0 0 0-8.5 4.516c-2.826 1.754-5.639 3.536-8.482 5.258a22.483 22.483 0 0 1-2.707 1.31 4.828 4.828 0 0 1-1.918.363 8.063 8.063 0 0 1-1.057-.074Zm41.418-5.13c.322-.22.541-.4.779-.536a9.675 9.675 0 0 0 2.4-2.065 3.981 3.981 0 0 0 .99-4.2c-.037-.11-.078-.215-.111-.325s-.055-.215-.123-.49a3.024 3.024 0 0 1 .521.421 5.46 5.46 0 0 1 1.266 3.142 3.022 3.022 0 0 1-1.434 2.688 9.916 9.916 0 0 1-4 1.489h-.012a1.585 1.585 0 0 1-.276-.124Zm1.023-2.9a7.106 7.106 0 0 0 .545-4.117A7.089 7.089 0 0 0 43 .719c-.26-.174-.52-.353-.781-.531L42.328 0a9.391 9.391 0 0 1 .908.385A9.755 9.755 0 0 1 46.465 2.9 4.921 4.921 0 0 1 47.2 8a12.131 12.131 0 0 1-2.3 3.606.77.77 0 0 1-.2.165c-.037.027-.1.018-.146.023.409-.801.862-1.585 1.202-2.418ZM26.5 10.947c.527-.38 1.039-.783 1.584-1.145a41.9 41.9 0 0 1 8.141-4.448 11.016 11.016 0 0 1 4.438-.911 3.937 3.937 0 0 1 2.656 1.063 1.341 1.341 0 0 1 .17.192.739.739 0 0 1 .041.2c-.068.023-.16.092-.207.069a6.461 6.461 0 0 0-3.965-.307 25.282 25.282 0 0 0-5.883 1.869 47.273 47.273 0 0 0-6.359 3.385 3.527 3.527 0 0 1-.518.215Z" transform="translate(22.501)" /></symbol></defs><use xlink:href="#icon-cassino_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-cassino_active_green"><defs><symbol viewBox="0 0 32.5 33.123" id="icon-cassino_active_green_a"><path d="M19.922 9.761c-.02-1.716-1.253-2.842-2.049-3.871l-.984-.906c-.747-1.36 1.22-3.349 1.967-3.707 1.043.2 1.73 1.225 2.3 1.936a10.768 10.768 0 0 1 1.762 2.553c.59 1.428.807 3.078 1.271 4.613L25 12.273a3.215 3.215 0 0 1-.656 1.853c-.114.135-.3.087-.369.288-.429 1.317-.422 3.058-1.271 3.954a5.747 5.747 0 0 0 3.156 4.695c.885.317 1.854.057 2.664.329A5.884 5.884 0 0 1 31.6 26.4c.3.588 1.583 4.733.451 5.313-.926-.464-.548-2.329-.779-3.5-.217-1.236-1.306-3.4-2.3-3.83a4.271 4.271 0 0 0-1.844-.124c-.392.062-.77-.056-1.025.124l-.369.7-.615 1.194c-.137 1.73-.273 3.476-.41 5.189l-.246.206-2.09-.206h-3.845l-.123-.082c.21-.651 1.691-.837 2.254-1.153a7.562 7.562 0 0 0 3.525-4.331c.143-.386.66-1.025.574-1.441l-.082-.206c-2.28-.607-3.444.392-4.959-1.318-.13-.181-.426-.21-.533-.453-.405-.919.026-2.362-.246-3.459l-.246.082c-.5 1.086-2.6 2.946-4.427 2.183-.97-.406-1.887-1.475-2.787-1.771l-.041.041c.011 2.381.106 4.889-1.066 6.178a9.258 9.258 0 0 1-1.025 1.071c-.6.462-1.37.592-1.721 1.318a2.11 2.11 0 0 0-.287 1.194c.092.393 1.463 1.489 2.049 1.359.8-.178 1.03-1.025 1.639-1.4l.123.082C12.271 34.108.8 34.346.043 30.188a3.24 3.24 0 0 1 1.639-2.965c.538-.3 1.138-.335 1.68-.659a4.314 4.314 0 0 0 1.518-2.595c.382-1.875-.44-3.062-.779-4.242l-.2-1.812c-.1-.444-.482-.842-.369-1.442.189-1 1.707-2.412 2.172-3.624.552-1.42.229-3.489.7-4.983a11.461 11.461 0 0 1 4.713-6.342c1.76-1.286 4.845-2.454 6.64-.412a9.828 9.828 0 0 1-1.926 3.707c-.6.3-1.746-.011-2.418.247a6.586 6.586 0 0 0-3.123 4.448l.123.082.779-.041a6.452 6.452 0 0 1 2.418.659v.206c-.391.482-3.09-1.078-3.73.206a.354.354 0 0 0-.041.288l.041.165c1.469-.058 2.644-.428 3.4.659l-.041.206h-.574c-.141.339-.234.644-.574.782-.806.245-1-.334-1.23-.824h-.041c-.37.1-.087.3 0 .535l-.123.082c-.482.206-.707-.219-1.025-.329v.082c-.745 1.76.483 4.925 1.189 5.848a11.4 11.4 0 0 0 2.254 1.812c.548.391 1.528 1.251 2.541 1.071.818-.145 1.543-1.094 2.008-1.647 1.712-2.035 2.975-3.963 2.664-7.578h-.123c-.361.324-.582.905-1.271.741l-.041-.082.2-.453-.073-.084-.246.082a.874.874 0 0 1-1.353.659l-.41-.7a.93.93 0 0 1-.574-.041v-.2c.9-1.1 2.3-.7 3.812-.494v-.086c.1-.266-.118-.6-.246-.783a6.546 6.546 0 0 0-2.213-.206c-.528.109-1.027.528-1.6.453l-.041-.124c-.068-.184 0-.242.082-.371a8.276 8.276 0 0 1 3.691-.328Zm1.394 2.183a5.367 5.367 0 0 0-.533 2.636c1.021.439 1.435-.633 1.762-1.483-.219-.487-.692-.77-1.025-1.153Zm-6.025 3.5.7.041a.321.321 0 0 1-.041.288c-.577.2-1.6.554-2.008-.124l.082-.123a2.684 2.684 0 0 0 1.266-.082Zm5.9.371a18.39 18.39 0 0 0 .041 5.354l.164-.082c.1-1.411.44-3.823 0-5.189Zm-5.82 1.194 1.721.165c-.108.359-.457.511-.738.7-1.358.914-1.264.689-2.541 0-.4-.214-.83-.252-1.107-.577.054-.158 0-.086.123-.165.628-.223 1.976.222 2.543-.123ZM2.134 27.964c-1.109.882-1.871 2.178-.287 3.254.149-.027.134-.017.2-.082-.514-1.175.007-2.026.164-3.006.03-.161.054-.09-.077-.166Z" transform="translate(-.012 -.004)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-cassino_active_green_a" fill="#333" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-cassino_green"><defs><symbol viewBox="0 0 32.5 33.123" id="icon-cassino_green_a"><path d="M19.922 9.761c-.02-1.716-1.253-2.842-2.049-3.871l-.984-.906c-.747-1.36 1.22-3.349 1.967-3.707 1.043.2 1.73 1.225 2.3 1.936a10.768 10.768 0 0 1 1.762 2.553c.59 1.428.807 3.078 1.271 4.613L25 12.273a3.215 3.215 0 0 1-.656 1.853c-.114.135-.3.087-.369.288-.429 1.317-.422 3.058-1.271 3.954a5.747 5.747 0 0 0 3.156 4.695c.885.317 1.854.057 2.664.329A5.884 5.884 0 0 1 31.6 26.4c.3.588 1.583 4.733.451 5.313-.926-.464-.548-2.329-.779-3.5-.217-1.236-1.306-3.4-2.3-3.83a4.271 4.271 0 0 0-1.844-.124c-.392.062-.77-.056-1.025.124l-.369.7-.615 1.194c-.137 1.73-.273 3.476-.41 5.189l-.246.206-2.09-.206h-3.845l-.123-.082c.21-.651 1.691-.837 2.254-1.153a7.562 7.562 0 0 0 3.525-4.331c.143-.386.66-1.025.574-1.441l-.082-.206c-2.28-.607-3.444.392-4.959-1.318-.13-.181-.426-.21-.533-.453-.405-.919.026-2.362-.246-3.459l-.246.082c-.5 1.086-2.6 2.946-4.427 2.183-.97-.406-1.887-1.475-2.787-1.771l-.041.041c.011 2.381.106 4.889-1.066 6.178a9.258 9.258 0 0 1-1.025 1.071c-.6.462-1.37.592-1.721 1.318a2.11 2.11 0 0 0-.287 1.194c.092.393 1.463 1.489 2.049 1.359.8-.178 1.03-1.025 1.639-1.4l.123.082C12.271 34.108.8 34.346.043 30.188a3.24 3.24 0 0 1 1.639-2.965c.538-.3 1.138-.335 1.68-.659a4.314 4.314 0 0 0 1.518-2.595c.382-1.875-.44-3.062-.779-4.242l-.2-1.812c-.1-.444-.482-.842-.369-1.442.189-1 1.707-2.412 2.172-3.624.552-1.42.229-3.489.7-4.983a11.461 11.461 0 0 1 4.713-6.342c1.76-1.286 4.845-2.454 6.64-.412a9.828 9.828 0 0 1-1.926 3.707c-.6.3-1.746-.011-2.418.247a6.586 6.586 0 0 0-3.123 4.448l.123.082.779-.041a6.452 6.452 0 0 1 2.418.659v.206c-.391.482-3.09-1.078-3.73.206a.354.354 0 0 0-.041.288l.041.165c1.469-.058 2.644-.428 3.4.659l-.041.206h-.574c-.141.339-.234.644-.574.782-.806.245-1-.334-1.23-.824h-.041c-.37.1-.087.3 0 .535l-.123.082c-.482.206-.707-.219-1.025-.329v.082c-.745 1.76.483 4.925 1.189 5.848a11.4 11.4 0 0 0 2.254 1.812c.548.391 1.528 1.251 2.541 1.071.818-.145 1.543-1.094 2.008-1.647 1.712-2.035 2.975-3.963 2.664-7.578h-.123c-.361.324-.582.905-1.271.741l-.041-.082.2-.453-.073-.084-.246.082a.874.874 0 0 1-1.353.659l-.41-.7a.93.93 0 0 1-.574-.041v-.2c.9-1.1 2.3-.7 3.812-.494v-.086c.1-.266-.118-.6-.246-.783a6.546 6.546 0 0 0-2.213-.206c-.528.109-1.027.528-1.6.453l-.041-.124c-.068-.184 0-.242.082-.371a8.276 8.276 0 0 1 3.691-.328Zm1.394 2.183a5.367 5.367 0 0 0-.533 2.636c1.021.439 1.435-.633 1.762-1.483-.219-.487-.692-.77-1.025-1.153Zm-6.025 3.5.7.041a.321.321 0 0 1-.041.288c-.577.2-1.6.554-2.008-.124l.082-.123a2.684 2.684 0 0 0 1.266-.082Zm5.9.371a18.39 18.39 0 0 0 .041 5.354l.164-.082c.1-1.411.44-3.823 0-5.189Zm-5.82 1.194 1.721.165c-.108.359-.457.511-.738.7-1.358.914-1.264.689-2.541 0-.4-.214-.83-.252-1.107-.577.054-.158 0-.086.123-.165.628-.223 1.976.222 2.543-.123ZM2.134 27.964c-1.109.882-1.871 2.178-.287 3.254.149-.027.134-.017.2-.082-.514-1.175.007-2.026.164-3.006.03-.161.054-.09-.077-.166Z" transform="translate(-.012 -.004)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-cassino_green_a" fill="#ADB6C4" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-close"><defs><symbol viewBox="0 0 16 16" id="icon-close_a"><path data-name="Line 14" d="M14 15a1 1 0 0 1-.707-.293l-14-14a1 1 0 0 1 0-1.414 1 1 0 0 1 1.414 0l14 14A1 1 0 0 1 14 15Z" transform="translate(1 1)" /><path data-name="Line 15" d="M0 15a1 1 0 0 1-.707-.293 1 1 0 0 1 0-1.414l14-14a1 1 0 0 1 1.414 0 1 1 0 0 1 0 1.414l-14 14A1 1 0 0 1 0 15Z" transform="translate(1 1)" /></symbol></defs><use xlink:href="#icon-close_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-collect"><defs><symbol viewBox="0 0 100 76" id="icon-collect_a"><path data-name="Path 18327" d="M26.608 6.486a5 5 0 0 1 9.276 0l3.916 9.733a5 5 0 0 0 4.323 3.122L54.594 20a5 5 0 0 1 2.85 8.861l-7.968 6.515A5 5 0 0 0 47.8 40.5l2.583 9.965a5 5 0 0 1-7.488 5.5l-9-5.62a5 5 0 0 0-5.3 0l-9 5.62a5 5 0 0 1-7.488-5.5l2.585-9.965a5 5 0 0 0-1.675-5.125l-7.969-6.513A5 5 0 0 1 7.9 20l10.467-.66a5 5 0 0 0 4.323-3.122Z" transform="translate(19.808 7.534)" /></symbol></defs><use xlink:href="#icon-collect_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-collect_active"><defs><symbol viewBox="0 0 100 76" id="icon-collect_active_a"><path data-name="Path 18327" d="M26.608 6.486a5 5 0 0 1 9.276 0l3.916 9.733a5 5 0 0 0 4.323 3.122L54.594 20a5 5 0 0 1 2.85 8.861l-7.968 6.515A5 5 0 0 0 47.8 40.5l2.583 9.965a5 5 0 0 1-7.488 5.5l-9-5.62a5 5 0 0 0-5.3 0l-9 5.62a5 5 0 0 1-7.488-5.5l2.585-9.965a5 5 0 0 0-1.675-5.125l-7.969-6.513A5 5 0 0 1 7.9 20l10.467-.66a5 5 0 0 0 4.323-3.122Z" transform="translate(19.808 7.534)" /></symbol></defs><use xlink:href="#icon-collect_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-copy"><defs><symbol viewBox="0 0 20.727 24" id="icon-copy_a"><path d="M1801.586 16.829a1.094 1.094 0 0 1-1.1-1.093V-1.781a1.094 1.094 0 0 1 1.1-1.093 1.094 1.094 0 0 1 1.095 1.093v16.424h13.136a1.093 1.093 0 1 1 0 2.185Zm4.305-4.3a1.1 1.1 0 0 1-1.1-1.093V-6.078a1.094 1.094 0 0 1 1.1-1.093h8.759a1.094 1.094 0 0 1 .773.32l5.474 5.463a1.091 1.091 0 0 1 .321.773v12.054a1.094 1.094 0 0 1-1.1 1.093Zm1.094-2.185h12.044V1.569h-5.474a1.094 1.094 0 0 1-1.095-1.093v-5.462h-5.475Z" transform="translate(-1800.491 7.171)" /></symbol></defs><use xlink:href="#icon-copy_a" fill="#FACF20" /></symbol><symbol  fill="currentColor" viewBox="0 0 200.78 200" id="icon-dealer"><path d="M100.42 63c6.71-6.88 12.64-13.12 18.74-19.18 9-8.94 16.77-8.89 25.71 0q18.82 18.8 37.6 37.65c7.91 7.94 8 16.41.07 24.36q-35.31 35.35-70.78 70.57c-7.07 7-15.38 7.25-22.39.33q-36.24-35.84-72.19-72c-6.54-6.58-6.38-15.52.19-22.19Q37.46 62.26 57.8 42.17c6.76-6.69 15.17-6.72 22.08 0S93.12 55.55 100.42 63Zm34.21 75.64c-3.62-3.23-6.88-6-10-8.94-2.64-2.51-3.34-5.54-.49-8.24s5.74-2 8.28.64c3 3.11 5.89 6.27 8.8 9.38 6-5.24 6.09-6.46 1.16-11.41s-9.63-9.59-14.4-14.43c-4.49-4.57-8.93-9.21-13.25-13.67-13.56 9.08-23.61 6.63-35.51-8.33l13.54-12.4a13.55 13.55 0 0 0-1-1.73Q83 60.69 74.21 51.91c-4.66-4.65-6.07-4.7-10.64-.17Q45.29 70 27 88.23c-4.67 4.66-4.62 6.21.18 11Q61.1 133.2 95 167.13c4.9 4.9 6.41 4.83 11.64-1-2.89-2.66-5.83-5.34-8.74-8s-4.14-6-1.16-9.11c3.25-3.39 6.36-1.35 8.94 1.39s5.24 5.83 7.06 7.86l7.8-5.85c-3.39-3.16-6.44-6-9.45-8.8-2.65-2.5-3.49-5.4-.78-8.24s5.73-2 8.21.57c3 3.1 5.77 6.37 8.68 9.62l7.4-6.88Zm21.31-21.45c6.27-6.32 12.93-13 19.54-19.71 2.34-2.38 2.58-5 .14-7.44-13.36-13.35-26.68-26.74-40.28-39.84-1.19-1.15-5.27-1.28-6.39-.2-11.56 11.13-22.77 22.61-34.11 34 5.58 3.54 8.31 3.31 12.8-1.08 3.31-3.25 6.26-7 10-9.65 1.56-1.13 5.51-1.05 6.81.16s1.09 4.58.78 6.89c-.19 1.36-1.87 2.51-3.24 4.19 11.26 10.82 22.36 21.48 34 32.66Z" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 145 145" id="icon-default_game"><defs><symbol viewBox="0 0 130 130" id="icon-default_game_a"><path data-name="Union 233" d="M62.124-231.134H40.76a1.034 1.034 0 0 1-1.065-1c0-11.3 5.791-20.2 11.236-22.84 3.27-1.585 6.315-5.886 7.927-8.475a32.373 32.373 0 0 1-5.3.377 25.322 25.322 0 0 1-8.1-1.4 9.882 9.882 0 0 0-2.556-.6c-2.21 0-3.2.922-3.2 2.994v3.991a1.034 1.034 0 0 1-1.066 1h-4.272a1.034 1.034 0 0 1-1.066-1v-19.958a1.034 1.034 0 0 1 1.066-1h4.265a1.034 1.034 0 0 1 1.066 1v2.768c2.091-1.566 5.718-3.766 9.594-3.766a14.1 14.1 0 0 1 7.1 2.166 11.386 11.386 0 0 0 5.7 1.827 10.951 10.951 0 0 0 7.686-3.6 1.1 1.1 0 0 1 .776-.383 1.148 1.148 0 0 1 .821.289l2.132 2a.951.951 0 0 1 .311.685.948.948 0 0 1-.284.7c-3.04 3.075-12.508 28.249-12.508 33.254a27.584 27.584 0 0 0 1.962 9.38.957.957 0 0 1 .213.6 1.034 1.034 0 0 1-1.032 1Zm36.053 0h-16.33a.815.815 0 0 1-.813-.813c0-9.228 4.426-16.5 8.583-18.648 2.5-1.292 4.827-4.8 6.059-6.917a23.21 23.21 0 0 1-4.054.308 18.267 18.267 0 0 1-6.194-1.141 7.157 7.157 0 0 0-1.954-.489c-1.69 0-2.444.752-2.444 2.444v3.259a.815.815 0 0 1-.813.813h-3.259a.815.815 0 0 1-.813-.813v-16.3a.815.815 0 0 1 .813-.813h3.263a.815.815 0 0 1 .813.813v2.263c1.6-1.28 4.371-3.075 7.333-3.075a10.29 10.29 0 0 1 5.423 1.769 8.323 8.323 0 0 0 4.354 1.49 8.226 8.226 0 0 0 5.875-2.943.818.818 0 0 1 .593-.312.842.842 0 0 1 .627.236l1.63 1.63a.814.814 0 0 1 .021 1.129c-2.324 2.511-9.561 23.063-9.561 27.15a23.814 23.814 0 0 0 1.5 7.659.813.813 0 0 1 .079.854.813.813 0 0 1-.728.449Zm-76.145 0H5.7a.815.815 0 0 1-.813-.813c0-9.228 4.426-16.5 8.584-18.648 2.5-1.292 4.826-4.8 6.059-6.917a23.222 23.222 0 0 1-4.055.308 18.263 18.263 0 0 1-6.194-1.141 7.169 7.169 0 0 0-1.954-.489c-1.69 0-2.444.752-2.444 2.444v3.259a.816.816 0 0 1-.813.813H.813a.815.815 0 0 1-.813-.816v-16.3a.815.815 0 0 1 .813-.813h3.263a.815.815 0 0 1 .813.813v2.263c1.6-1.28 4.37-3.075 7.333-3.075a10.294 10.294 0 0 1 5.423 1.769A8.321 8.321 0 0 0 22-266.985a8.222 8.222 0 0 0 5.874-2.943.818.818 0 0 1 .593-.312.841.841 0 0 1 .627.236l1.63 1.63a.813.813 0 0 1 .021 1.129c-2.324 2.511-9.56 23.063-9.56 27.15a23.83 23.83 0 0 0 1.5 7.659.81.81 0 0 1 .079.854.812.812 0 0 1-.728.449Zm49.216-55.3a1.007 1.007 0 0 1-.389-1.04l1.22-5.373-4.136-3.627a1.01 1.01 0 0 1-.292-1.069 1.009 1.009 0 0 1 .865-.692l5.472-.5 2.162-5.063a1.008 1.008 0 0 1 .927-.612 1.007 1.007 0 0 1 .923.61l2.162 5.064 5.472.5a1.007 1.007 0 0 1 .866.691 1.008 1.008 0 0 1-.294 1.071l-4.136 3.627 1.219 5.373a1.007 1.007 0 0 1-.39 1.039 1.009 1.009 0 0 1-1.109.05l-4.717-2.821-4.718 2.821a1.008 1.008 0 0 1-.518.143 1.007 1.007 0 0 1-.589-.194Zm-47.045 0a1.007 1.007 0 0 1-.389-1.04l1.22-5.373-4.134-3.629a1.011 1.011 0 0 1-.292-1.069 1.009 1.009 0 0 1 .865-.692l5.472-.5L29.1-303.8a1.007 1.007 0 0 1 .927-.612 1.007 1.007 0 0 1 .927.612l2.162 5.064 5.472.5a1.006 1.006 0 0 1 .866.691 1.009 1.009 0 0 1-.294 1.071l-4.137 3.627 1.22 5.373a1.008 1.008 0 0 1-.391 1.039 1.009 1.009 0 0 1-1.109.05l-4.717-2.821-4.718 2.821a1.008 1.008 0 0 1-.518.143 1.007 1.007 0 0 1-.59-.194Zm21.938-2.7a1.281 1.281 0 0 1-.5-1.323l1.551-6.833-5.262-4.614a1.283 1.283 0 0 1-.375-1.361 1.283 1.283 0 0 1 1.1-.881l6.962-.632 2.751-6.441a1.284 1.284 0 0 1 1.186-.781 1.282 1.282 0 0 1 1.179.778l2.751 6.441 6.961.632a1.281 1.281 0 0 1 1.1.88 1.284 1.284 0 0 1-.374 1.362l-5.262 4.614 1.553 6.834a1.282 1.282 0 0 1-.5 1.322 1.282 1.282 0 0 1-1.411.064l-6-3.589-6 3.589a1.28 1.28 0 0 1-.658.182 1.28 1.28 0 0 1-.753-.247Z" transform="translate(12 337.002)" /></symbol></defs><use xlink:href="#icon-default_game_a" /></symbol><symbol  viewBox="0 0 28 28" fill="currentColor" aria-hidden="true" id="icon-deleteIcon_item"><path d="M14 28a14 14 0 1 1 9.9-4.1A13.907 13.907 0 0 1 14 28Zm0-12.351 4.536 4.537a1.167 1.167 0 1 0 1.65-1.65l-4.537-4.537 4.537-4.537a1.167 1.167 0 1 0-1.65-1.65L14 12.348 9.462 7.812a1.167 1.167 0 1 0-1.65 1.65l4.538 4.537-4.538 4.537a1.167 1.167 0 0 0 1.65 1.65l4.537-4.537Z" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-digital_icon"><defs><symbol viewBox="0 0 32.623 24.781" id="icon-digital_icon_a"><path d="M-125.377 117.777a3.656 3.656 0 0 1-2.579-1.1 3.656 3.656 0 0 1-1.044-2.6V99.836h32.613v14.245a3.656 3.656 0 0 1-1.044 2.6 3.656 3.656 0 0 1-2.579 1.1Zm6.127-6.871v.918a.588.588 0 0 0 .4.557l6.743.016a.283.283 0 0 1 .256.244v1.327a.455.455 0 0 0 .285.423.6.6 0 0 0 .233.047.5.5 0 0 0 .352-.131l4.588-2.961.048-.048a.618.618 0 0 0 .09-.515.7.7 0 0 0-.37-.436l-12.049-.015a.607.607 0 0 0-.576.574Zm4.769-7.274-4.613 2.982a.563.563 0 0 0-.144.535.621.621 0 0 0 .412.458l12.136.008a.615.615 0 0 0 .55-.408h.037v-.992a.607.607 0 0 0-.58-.574h-6.672a.283.283 0 0 1-.256-.243v-1.427a.452.452 0 0 0-.285-.422.573.573 0 0 0-.232-.048.5.5 0 0 0-.353.131ZM-129 96.663A3.659 3.659 0 0 1-125.377 93H-100a3.66 3.66 0 0 1 3.623 3.663Z" transform="translate(129 -93)" /></symbol></defs><use xlink:href="#icon-digital_icon_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="var(--theme-primary-font-color)" aria-hidden="true" viewBox="0 0 20 32.952" id="icon-doubt"><defs><symbol viewBox="0 0 10.363 17.074" id="icon-doubt_a"><path data-name="Rectangle 958" transform="translate(4.086 15.01)" d="M0 0h2.391v2.064H0z" /><path data-name="Path 509" d="M2276.715 166.49q-5.283.282-5.481 5.254h2.093q.1-3.565 3.388-3.753a2.818 2.818 0 0 1 2.99 2.814q0 1.409-2.093 3.284-2.193 2.16-2.192 3.753v1.688h2.192v-1.97q-.1-.844 1.594-2.345 2.391-2.158 2.391-4.316-.297-4.222-4.882-4.409Z" transform="translate(-2271.234 -166.49)" /></symbol></defs><use xlink:href="#icon-doubt_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_aboutUs"><defs><symbol viewBox="0 0 16.013 16" id="icon-down_arrow_aboutUs_a"><path d="M1921.976-191.375a8.012 8.012 0 0 1 8.006-8 8.012 8.012 0 0 1 8.007 8 8.012 8.012 0 0 1-8.007 8 8.012 8.012 0 0 1-8.006-8Zm1.456 0a6.555 6.555 0 0 0 6.55 6.546 6.556 6.556 0 0 0 6.551-6.546 6.556 6.556 0 0 0-6.551-6.546 6.555 6.555 0 0 0-6.55 6.546Zm5.822 3.879v-4.364a.728.728 0 0 1 .728-.727.728.728 0 0 1 .728.727v4.364a.728.728 0 0 1-.728.727.728.728 0 0 1-.728-.731Zm-.242-7.515a.971.971 0 0 1 .97-.97.971.971 0 0 1 .97.97.971.971 0 0 1-.97.969.971.971 0 0 1-.97-.969Z" transform="translate(-1921.976 199.375)" /></symbol></defs><use xlink:href="#icon-down_arrow_aboutUs_a" fill="#04BE02" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 15.998 15.206" id="icon-down_arrow_account"><defs><symbol viewBox="0 0 15.998 15.206" id="icon-down_arrow_account_a"><path data-name="Path 454" d="M7.541 13.467H3.02a.575.575 0 0 1-.577-.577V1.988a.575.575 0 0 1 .577-.577h9.01a.575.575 0 0 1 .577.577v3.046a5.227 5.227 0 0 1 1.443.224V2.02A2.032 2.032 0 0 0 12.03 0H3.02A2.032 2.032 0 0 0 1 2.02v10.9a2.032 2.032 0 0 0 2.02 2.02h5.707a6.483 6.483 0 0 1-1.186-1.473Z" transform="translate(-1)" /><path data-name="Path 455" d="M9.719 5.066H4.46a.746.746 0 0 1-.737-.737.726.726 0 0 1 .737-.737h5.259a.746.746 0 0 1 .737.737.726.726 0 0 1-.737.737Z" transform="translate(-1)" /><path data-name="Path 456" d="M7.317 7.5H4.5a.746.746 0 0 1-.737-.737.726.726 0 0 1 .737-.736h2.817a.737.737 0 1 1 0 1.475Z" transform="translate(-1)" /><path data-name="Path 458" d="M12.48 7.471a3.223 3.223 0 1 1-2.28.929 3.223 3.223 0 0 1 2.28-.929Zm0-1.283A4.509 4.509 0 1 0 15.669 7.5a4.509 4.509 0 0 0-3.189-1.312Z" transform="translate(-1)" /><path data-name="Path 14956" d="M1660.263-721.578c-.935 1.154-1.947 1.54-1.975 2.444a1.043 1.043 0 0 0 1.231 1.164 2.3 2.3 0 0 0 .71-.389 2.7 2.7 0 0 1-.631 1.085c.66.008.66.006.66.006l.66.006a2.729 2.729 0 0 1-.617-1.1 2.108 2.108 0 0 0 .681.394 1.04 1.04 0 0 0 1.247-1.141c-.014-.899-1.048-1.302-1.966-2.469Z" transform="translate(-1648.784 730.129)" stroke-miterlimit="10" /></symbol></defs><use xlink:href="#icon-down_arrow_account_a" fill="#FFAA09" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_advise"><defs><symbol viewBox="0 0 16 16" id="icon-down_arrow_advise_a"><path d="M1648.3-137.505a2.8 2.8 0 0 1-2.81-2.778v-9.567a2.8 2.8 0 0 1 2.81-2.778h4.979a.7.7 0 0 1 .7.694.7.7 0 0 1-.7.695h-4.979a1.4 1.4 0 0 0-1.406 1.389v9.567a1.4 1.4 0 0 0 1.406 1.389h9.806a1.4 1.4 0 0 0 1.405-1.389v-5.4a.7.7 0 0 1 .7-.694.7.7 0 0 1 .7.694v5.4a2.8 2.8 0 0 1-2.809 2.778Zm2.331-4.871a.708.708 0 0 1-.167-.694l.834-2.767a.707.707 0 0 1 .174-.293l6.448-6.759a2.082 2.082 0 0 1 2.959 0 2.123 2.123 0 0 1 0 2.981l-6.44 6.752a.691.691 0 0 1-.306.18l-2.814.786a.71.71 0 0 1-.188.025.7.7 0 0 1-.5-.211Zm1.95-2.884-.414 1.375 1.416-.4.449-.471-1.073-.9Zm2.441-.531 4.87-5.11a.709.709 0 0 0 0-.994.694.694 0 0 0-.987 0l-.134.136-4.822 5.063Z" transform="translate(-1645.49 153.505)" /></symbol></defs><use xlink:href="#icon-down_arrow_advise_a" fill="#005DFE" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_exit"><defs><symbol viewBox="0 0 13 16" id="icon-down_arrow_exit_a"><path data-name="Path 487" d="M1477.954-608.582a.782.782 0 0 0-.354-.657l-2.712-2.783a.746.746 0 0 0-1.074 0 .794.794 0 0 0 0 1.1l1.518 1.558h-5.69a.77.77 0 0 0-.76.78.77.77 0 0 0 .76.78h5.69l-1.518 1.558a.794.794 0 0 0 0 1.1.748.748 0 0 0 .537.228.748.748 0 0 0 .537-.228l2.712-2.783a.782.782 0 0 0 .354-.653Z" transform="translate(-1464.954 616.582)" /><path data-name="Path 488" d="M1468.73-611.054a.736.736 0 0 1-.726.745h-8.504a.736.736 0 0 1-.726-.745v-11.391a.735.735 0 0 1 .726-.745h8.5a.735.735 0 0 1 .726.745v1.191a.77.77 0 0 0 .76.78.77.77 0 0 0 .76-.78v-1.761a1.712 1.712 0 0 0-1.69-1.734h-9.621a1.712 1.712 0 0 0-1.69 1.734v12.532a1.712 1.712 0 0 0 1.69 1.734h9.621a1.712 1.712 0 0 0 1.69-1.734v-1.762a.77.77 0 0 0-.76-.78.77.77 0 0 0-.76.78Z" transform="translate(-1457.25 624.75)" /></symbol></defs><use xlink:href="#icon-down_arrow_exit_a" fill="#EA4E3D" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_info"><defs><symbol viewBox="0 0 57.488 56.043" id="icon-down_arrow_info_a"><g data-name="Group 54342"><path data-name="Union 154" d="M2294 14.26a14.26 14.26 0 1 1 14.26 14.261A14.277 14.277 0 0 1 2294 14.26Zm4.931 0a9.329 9.329 0 1 0 9.33-9.328 9.34 9.34 0 0 0-9.33 9.328Z" transform="translate(-2280.239)" /><path data-name="Union 153" d="M2296.466 24.59a2.468 2.468 0 0 1-2.466-2.466v-3.931A18.178 18.178 0 0 1 2312.193 0H2323a2.466 2.466 0 1 1 0 4.932h-10.812a13.276 13.276 0 0 0-13.262 13.261v1.465H2323a2.466 2.466 0 1 1 0 4.932Z" transform="translate(-2294 31.453)" /><path data-name="Path 14907" d="M240.72 182.216a2.274 2.274 0 0 0 0-3.213l-5.678-5.678a2.274 2.274 0 0 0-3.213 0L218.5 186.651a2.275 2.275 0 0 0-.663 1.509l-.259 5.934a2.27 2.27 0 0 0 2.369 2.367l5.934-.257a2.279 2.279 0 0 0 1.509-.663l13.326-13.326Zm-18.38 7.023-.112 2.577 2.577-.114 11.095-11.091-2.463-2.465-11.1 11.094Zm0 0" transform="translate(-183.897 -140.813)" fill-rule="evenodd" /></g></symbol></defs><use xlink:href="#icon-down_arrow_info_a" fill="#005DFE" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_message"><defs><symbol viewBox="0 0 19 15.488" id="icon-down_arrow_message_a"><path d="M1160.974 1514.174h-14.046a2.48 2.48 0 0 0-2.477 2.477v10.534a2.48 2.48 0 0 0 2.477 2.477h14.046a2.48 2.48 0 0 0 2.477-2.477v-10.534a2.48 2.48 0 0 0-2.477-2.477Zm-4.046 7.744 4.874-4.432v8.864Zm4.046-6.1a.827.827 0 0 1 .182.021l-6.758 6.145a.662.662 0 0 1-.894 0l-6.757-6.145a.822.822 0 0 1 .181-.021Zm-14.874 10.532v-8.864l4.874 4.432Zm.828 1.663a.822.822 0 0 1-.181-.021l5.453-4.959.194.177a2.3 2.3 0 0 0 3.114 0l.194-.177 5.454 4.959a.827.827 0 0 1-.182.021Z" transform="translate(-1144.451 -1514.174)" /></symbol></defs><use xlink:href="#icon-down_arrow_message_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_music"><defs><symbol viewBox="0 0 15 16.109" id="icon-down_arrow_music_a"><path d="M5.845 324.262v8.081a3.1 3.1 0 0 0-1.7-.513 3.139 3.139 0 1 0 3.139 3.143v-5.739l7.281-1.619v2.791a3.1 3.1 0 0 0-1.7-.512A3.139 3.139 0 1 0 16 333.033V322Zm8.755-.289v2.048l-7.311 1.591v-2.044ZM5.758 335a1.645 1.645 0 1 1-.482-1.159A1.644 1.644 0 0 1 5.758 335Zm8.785-1.939a1.645 1.645 0 1 1-.482-1.16 1.643 1.643 0 0 1 .482 1.156Z" transform="translate(-1.004 -322)" /></symbol></defs><use xlink:href="#icon-down_arrow_music_a" fill="#005DFE" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_personal"><defs><symbol viewBox="0 0 16.038 15.396" id="icon-down_arrow_personal_a"><path data-name="Path 466" d="M8.089 106.472H3.021a.58.58 0 0 1-.221-.044.576.576 0 0 1-.313-.312.581.581 0 0 1-.043-.222V94.989a.575.575 0 0 1 .577-.577h9.013a.575.575 0 0 1 .577.577v3.689a5.228 5.228 0 0 1 1.443.257v-3.914A2.033 2.033 0 0 0 12.034 93H3.021A2.033 2.033 0 0 0 1 95.021v10.905a2.032 2.032 0 0 0 2.021 2.021h6.415a6.532 6.532 0 0 1-1.347-1.475Z" transform="translate(-1 -93)" /><path data-name="Path 467" d="M4.5 98.068h5.26a.746.746 0 0 0 .738-.738.726.726 0 0 0-.738-.738H4.5a.746.746 0 0 0-.738.738.726.726 0 0 0 .738.738Z" transform="translate(-1 -93)" /><path data-name="Path 468" d="M8.021 99.768a.746.746 0 0 0-.738-.738H4.46a.746.746 0 0 0-.738.738.726.726 0 0 0 .213.525.732.732 0 0 0 .241.16.747.747 0 0 0 .284.053h2.823a.77.77 0 0 0 .738-.738Z" transform="translate(-1 -93)" /><path data-name="Path 469" d="m16.841 107.273-1.315-1.315a3.692 3.692 0 0 0 .706-2.181 3.817 3.817 0 1 0-3.817 3.817 3.691 3.691 0 0 0 2.181-.706l1.315 1.315a.658.658 0 1 0 .93-.93Zm-4.427-.994a2.506 2.506 0 1 1 1.768-.734 2.5 2.5 0 0 1-1.767.734Z" transform="translate(-1 -93)" /></symbol></defs><use xlink:href="#icon-down_arrow_personal_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 18 15.512" id="icon-down_arrow_record"><defs><symbol viewBox="0 0 18 15.512" id="icon-down_arrow_record_a"><path data-name="Path 460" d="M12.91 49.331a6.09 6.09 0 1 0 4.306 1.784 6.09 6.09 0 0 0-4.306-1.784Zm0 10.632a4.58 4.58 0 1 1 3.212-1.353 4.58 4.58 0 0 1-3.212 1.353Z" transform="translate(-1 -46)" /><path data-name="Path 461" d="M1.942 47.884h9.723a.942.942 0 0 0 .942-.942.92.92 0 0 0-.942-.942H1.942a.942.942 0 1 0 0 1.884Z" transform="translate(-1 -46)" /><path data-name="Path 462" d="M1.942 51.148H6.72A7.906 7.906 0 0 1 8.536 49.3H1.942a.942.942 0 0 0-.942.94.912.912 0 0 0 .942.908Z" transform="translate(-1 -46)" /><path data-name="Path 463" d="M1.942 54.411h3.533a8.339 8.339 0 0 1 .5-1.85H1.942A.942.942 0 0 0 1 53.5a.912.912 0 0 0 .942.908Z" transform="translate(-1 -46)" /><path data-name="Path 464" d="M1.942 57.641h3.8a8.546 8.546 0 0 1-.336-1.85H1.942a.942.942 0 0 0-.942.942.912.912 0 0 0 .942.908Z" transform="translate(-1 -46)" /><path data-name="Path 465" d="M1.942 59.055A.942.942 0 0 0 1 60a.92.92 0 0 0 .942.942H7.8a7.051 7.051 0 0 1-1.45-1.854H1.942Z" transform="translate(-1 -46)" /><path data-name="Path 14955" d="M1661.17-721.578c-1.364 1.684-2.842 2.248-2.882 3.566a1.523 1.523 0 0 0 1.8 1.7 3.361 3.361 0 0 0 1.037-.568 3.95 3.95 0 0 1-.92 1.583c.963.012.963.009.963.009l.963.009a3.981 3.981 0 0 1-.9-1.6 3.074 3.074 0 0 0 .994.575 1.518 1.518 0 0 0 1.82-1.666c-.026-1.318-1.535-1.905-2.875-3.608Z" transform="translate(-1649.287 727.624)" stroke-miterlimit="10" /></symbol></defs><use xlink:href="#icon-down_arrow_record_a" fill="#04BE02" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_safe"><defs><symbol viewBox="0 0 13.372 16" id="icon-down_arrow_safe_a"><path d="M1600.052-103.178c-6.624-2.316-6.522-7.784-6.446-11.777.007-.36.016-.807.016-1.212a.683.683 0 0 1 .679-.686 7.364 7.364 0 0 0 5.5-2.091.672.672 0 0 1 .949 0 7.365 7.365 0 0 0 5.5 2.09.684.684 0 0 1 .68.686c0 .371.008.755.015 1.159v.052c.076 3.993.179 9.462-6.447 11.778a.669.669 0 0 1-.223.038.675.675 0 0 1-.223-.037Zm-5.075-12.321c0 .162-.005.327-.009.495v.075c-.074 3.912-.158 8.347 5.309 10.375 5.466-2.028 5.383-6.463 5.309-10.375v-.063q0-.258-.008-.506a8.413 8.413 0 0 1-5.3-2.026 8.413 8.413 0 0 1-5.301 2.024Zm4.063 6.639-1.51-1.523a.69.69 0 0 1 0-.97.676.676 0 0 1 .961 0l1.03 1.038 2.538-2.561a.674.674 0 0 1 .481-.2.671.671 0 0 1 .48.2.684.684 0 0 1 .2.485.682.682 0 0 1-.2.485l-3.02 3.046a.678.678 0 0 1-.481.2.673.673 0 0 1-.479-.2Z" transform="translate(-1593.59 119.14)" /></symbol></defs><use xlink:href="#icon-down_arrow_safe_a" fill="#04BE02" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_setting"><defs><symbol viewBox="0 0 18.381 13" id="icon-down_arrow_setting_a"><path data-name="Path 470" d="M1.737 150.866a.345.345 0 0 1-.341-.341v-5.057h8.532a5.678 5.678 0 0 1 2.265-1.4H1.4v-1.3a.345.345 0 0 1 .341-.341h11.445a.345.345 0 0 1 .341.341v1.024c.155 0 .279-.031.434-.031a4.852 4.852 0 0 1 .962.093v-1.117A1.736 1.736 0 0 0 13.186 141H1.737A1.735 1.735 0 0 0 0 142.737v7.726a1.733 1.733 0 0 0 1.737 1.737H9a5.466 5.466 0 0 1-.558-1.4h-6.7Z" transform="translate(0 -141)" /><path data-name="Path 471" d="M3.32 148.012h2.264a.721.721 0 0 0 .716-.712.7.7 0 0 0-.051-.275.689.689 0 0 0-.154-.233.708.708 0 0 0-.233-.155.718.718 0 0 0-.275-.051H3.351a.721.721 0 0 0-.714.714.693.693 0 0 0 .046.268.692.692 0 0 0 .37.387.68.68 0 0 0 .267.057Z" transform="translate(0 -141)" /><path data-name="Path 472" d="M14.738 154h-1.489a.885.885 0 0 1-.9-.807l-.093-.589-.031-.031-.558.217a.924.924 0 0 1-1.148-.4l-.745-1.272a.945.945 0 0 1 .217-1.179l.5-.373v-.066l-.465-.372a.881.881 0 0 1-.217-1.179l.745-1.272a.909.909 0 0 1 1.117-.4l.589.217.031-.031.093-.621a.9.9 0 0 1 .9-.775h1.489a.883.883 0 0 1 .9.806l.093.59.031.031.558-.217a.924.924 0 0 1 1.148.4l.745 1.272a.945.945 0 0 1-.217 1.179l-.5.372v.062l.5.373a.953.953 0 0 1 .248 1.179l-.745 1.3a.973.973 0 0 1-1.148.4l-.589-.217-.031.031-.093.62a.967.967 0 0 1-.931.745Zm-1.3-1.148h1.086l.155-1.024.279-.124a2.79 2.79 0 0 0 .4-.248l.248-.186.962.372.559-.962-.807-.62.031-.31v-.466l-.031-.31.807-.621-.559-.961-.962.372-.248-.186a2.79 2.79 0 0 0-.4-.248l-.279-.125-.155-1.023h-1.089l-.155 1.023-.28.125a1.4 1.4 0 0 0-.4.248l-.248.186-.962-.372-.558.961.807.621-.031.31v.5l.031.31-.807.62.558.962.962-.372.248.186a2.791 2.791 0 0 0 .4.248l.279.124Zm3.041-5.647c0 .031.031.031 0 0Zm-2.482 3.351a1.055 1.055 0 1 1 1.055-1.055 1.066 1.066 0 0 1-1.055 1.055Z" transform="translate(0 -141)" /></symbol></defs><use xlink:href="#icon-down_arrow_setting_a" fill="#EA4E3D" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-down_arrow_wallet"><defs><symbol viewBox="0 0 22 18" id="icon-down_arrow_wallet_a"><path d="M3 18a3 3 0 0 1-3-3V3a3 3 0 0 1 3-3h16a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3ZM2 3v12a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-2h-4a4 4 0 1 1 0-8h4V3a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1Zm12 6a2 2 0 0 0 2 2h4V7h-4a2 2 0 0 0-2 2Zm1.367 0a1.067 1.067 0 1 1 1.066 1.063A1.065 1.065 0 0 1 15.368 9Z" /></symbol></defs><use xlink:href="#icon-down_arrow_wallet_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-email"><defs><symbol viewBox="0 0 60 60" id="icon-email_a"><g transform="translate(-1989 242)" clip-path="url(#icon_grzx_xx--svgSprite:all_clip-path)"><path data-name="icon_grzx_xx" d="m1331.54 7840.46-16.191-12.658a3.822 3.822 0 0 0-4.708 0l-16.19 12.659a3.786 3.786 0 0 0-1.456 2.98v23.27a3.8 3.8 0 0 0 3.81 3.79h32.381a3.8 3.8 0 0 0 3.81-3.79v-23.271a3.786 3.786 0 0 0-1.456-2.979Zm-9.744 19.487c-1.5-.985-2.978-2-4.467-3l-2.219-1.517-1.1-.753a1.885 1.885 0 0 0-2.031 0l-1.1.75-2.22 1.518c-1.489 1-2.968 2.011-4.468 3q-4.476 2.986-9.056 5.818 4.264-3.283 8.633-6.422c1.449-1.057 2.917-2.085 4.377-3.126l2.2-1.543.226-.156-13.6-7.116a2.1 2.1 0 0 1-1.125-1.854v-1.853a2.1 2.1 0 0 1 2.1-2.1h30.076a2.1 2.1 0 0 1 2.106 2.1v1.855a2.094 2.094 0 0 1-1.12 1.852l-13.559 7.146.181.126 2.2 1.542c1.459 1.043 2.927 2.07 4.377 3.126q4.369 3.136 8.632 6.424-4.559-2.834-9.039-5.824Z" transform="translate(706.005 -8060.991)" /></g></symbol></defs><use xlink:href="#icon-email_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-email_unread"><defs><symbol viewBox="0 0 60 60" id="icon-email_unread_a"><g transform="translate(-2049 242)" clip-path="url(#icon_grzx_xx2--svgSprite:all_clip-path)"><path data-name="icon_grzx_xx2" d="M1972.19-370h-32.38a3.81 3.81 0 0 0-3.81 3.809v24.285a3.81 3.81 0 0 0 3.81 3.809h32.38a3.81 3.81 0 0 0 3.811-3.811v-24.283a3.81 3.81 0 0 0-3.811-3.809Zm-13.307 16 2.2 1.549c1.459 1.047 2.928 2.08 4.376 3.141q4.369 3.152 8.631 6.456-4.58-2.847-9.052-5.846c-1.5-.988-2.978-2.007-4.468-3.01l-2.22-1.525-.35-.241-.234.163a2.807 2.807 0 0 1-1.53.46 2.81 2.81 0 0 1-1.53-.461l-.233-.163-.351.241-2.219 1.525c-1.49 1-2.968 2.021-4.468 3.01q-4.475 3-9.052 5.847 4.264-3.3 8.631-6.455c1.448-1.061 2.918-2.1 4.377-3.14l2.2-1.55.068-.047-.068-.046-2.2-1.551c-1.459-1.046-2.929-2.08-4.377-3.141q-4.368-3.158-8.631-6.455 4.58 2.848 9.052 5.847c1.5.99 2.979 2.006 4.468 3.01l2.219 1.525.351.241.746.512c.033.021.069.037.106.056a1.856 1.856 0 0 0 .914.241 1.866 1.866 0 0 0 1.016-.3l1.1-.754 2.22-1.526c1.489-1 2.968-2.021 4.467-3.01q4.475-3 9.052-5.845-4.263 3.3-8.631 6.456c-1.448 1.061-2.918 2.094-4.377 3.14l-2.2 1.549-.066.046Z" transform="translate(123 148)" /></g></symbol></defs><use xlink:href="#icon-email_unread_a" fill="#FFF" /></symbol><symbol  viewBox="0 0 28 28" fill="currentColor" aria-hidden="true" id="icon-error"><path d="M14 28a14 14 0 1 1 9.9-4.1A13.907 13.907 0 0 1 14 28Zm0-12.351 4.536 4.537a1.167 1.167 0 1 0 1.65-1.65l-4.537-4.537 4.537-4.537a1.167 1.167 0 1 0-1.65-1.65L14 12.348 9.462 7.812a1.167 1.167 0 1 0-1.65 1.65l4.538 4.537-4.538 4.537a1.167 1.167 0 0 0 1.65 1.65l4.537-4.537Z" fill="#F5222D" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-esport"><defs><symbol viewBox="0 0 100 76" id="icon-esport_a"><path data-name="Union 215" d="M19.1 59.008A30.616 30.616 0 0 1 8.973 8.967a30.59 30.59 0 0 1 43.307 0A30.637 30.637 0 0 1 19.1 59.008ZM28.523 58a23.858 23.858 0 0 1-.557-.274 3.376 3.376 0 0 1-.209-.115l-6.471-1.15A27.6 27.6 0 0 0 28.523 58ZM10.43 45.057c.141.268.3.53.461.812.1.16.191.326.287.492a40.314 40.314 0 0 0 3.982 5.8l12.807 2.288c.127-.153.236-.294.34-.428a279.272 279.272 0 0 0 3.078-4.23l-5.93-10.258a.6.6 0 0 1-.1-.013l-.1-.013a86.206 86.206 0 0 1-10-1.994Zm42.826-8.328-6.48 12.1a26.032 26.032 0 0 1 .8 3.413 26.816 26.816 0 0 0 2.48-2.192 27.459 27.459 0 0 0 7.8-15.85 33.523 33.523 0 0 1-4.6 2.529Zm-20.584-7.95a309.01 309.01 0 0 1-1.84 3.541c-1 1.9-1.932 3.649-2.826 5.317L34.115 48.2a57.759 57.759 0 0 0 9.932-.971l6.186-11.536c-.217-.428-.408-.8-.592-1.144a72.03 72.03 0 0 0-4.291-7.075ZM5.924 21.142c-.076.115-.158.23-.236.345a24.735 24.735 0 0 0-1.84 3.036 27.615 27.615 0 0 0 .863 15.21A19.7 19.7 0 0 0 8.258 42.6l4.793-7.51a52.644 52.644 0 0 1-1.061-10.555L6.021 21ZM35.848 7.528c-1.592.1-3.215.262-4.779.429l-1.121.115c-.1.012-.217.025-.338.051l-3.4 10.232c.328.326.652.652.979.978l1.041 1.042-.064.07.846.946c1.123 1.259 2.287 2.563 3.426 3.854.1.115.2.23.3.358l12.316-1.266.059-.134c.6-1.47 1.219-3 1.789-4.505.313-.825.588-1.694.85-2.537L39.176 7.5a18.16 18.16 0 0 0-1.213-.032 36.856 36.856 0 0 0-2.115.06ZM11.205 11.2c-.309.307-.615.632-.928.965a26.137 26.137 0 0 0-1.254 2.512c-.445 1.022-.848 2.1-1.238 3.138l-.154.409c-.006.019-.014.039-.02.064l6 3.547A60.736 60.736 0 0 1 21.5 17.6c.455-.2.922-.39 1.371-.562q.267-.105.521-.211l3.152-9.491a21.253 21.253 0 0 0-5.049-2.6c-.008-.006-.02-.006-.031-.013A27.168 27.168 0 0 0 11.205 11.2Zm30.6-5.49 8.545 9.625c.25.09.518.186.781.294a30.761 30.761 0 0 1 3.564 1.745A27.472 27.472 0 0 0 41.822 5.535c-.006.057-.011.115-.022.172Z" transform="translate(20.627 8.127)" /></symbol></defs><use xlink:href="#icon-esport_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-esport_2"><use xlink:href="#icon-esport_2_a" /><defs><symbol viewBox="0 0 100 76" id="icon-esport_2_a"><path data-name="icon_dtfl_ty_0" d="M40.141.475a34.066 34.066 0 0 1 23.8 18.231c3.443 7.514 4.014 10.217 3.041 21.3-1.382 12.212-11.291 21.72-20.865 25.861-2.522 1.092-5.455 1.326-8.281 2.226a50.388 50.388 0 0 1-8.387-.106C15.677 67.154 1.181 52.779.206 39.054a65.316 65.316 0 0 1 0-10.069C1.285 15.154 14.45 2.793 27.141.475a50.33 50.33 0 0 1 13 0Zm0 4.027C38.07 5.3 30.6 6.69 30.076 8.422a28.888 28.888 0 0 0 1.571 10.388c3.494 1.8 6.988 3.614 10.482 5.406A44.938 44.938 0 0 0 52.4 20.189c1.406-1.061.4-4.5 0-6.146-.349-1.474-.7-2.968-1.048-4.451-2-2.924-7.344-4.062-11.214-5.088ZM19.8 7.892C16.19 9.66 9.453 15.17 8.384 19.128a19.911 19.911 0 0 0 .42 7.956 24.09 24.09 0 0 0 9.331 1.483c1.719-.442 3.339-2.889 4.4-4.133 1.423-1.666 5.746-4.522 6.29-6.571-.245-1.58-.488-3.18-.734-4.769-.318-1.874-.027-3.463-.838-4.663a51.079 51.079 0 0 0-7.453-.539ZM53.249 22.2c-2.111 1.326-8.248 2.542-9.435 4.345l-1.048 5.934c-.42 2.431-.84 4.9-1.258 7.313.29 1.14 7.49 7.408 8.805 8.584 2.294-.024 8.177-3.191 8.805-4.769l1.048-6.889.944-6.889c-.376-1.505-2.252-2.8-3.145-3.921-1.065-1.323-2.458-3.688-4.716-3.708ZM9 29.834c-1.909 1.215-1.889 3.536-2.72 5.934-.455 1.271-.908 2.555-1.364 3.815-.564 2.8 3.507 10.83 4.926 11.764a15.062 15.062 0 0 0 5.136 1.271 11.841 11.841 0 0 0 4.716.53c.9-1.2 5.18-9.521 4.719-11.34l-3.249-5.936c-.61-1.445-1.426-4.148-2.725-4.875-3.113-.385-6.298-.783-9.439-1.163Zm54.3 3.286a36.211 36.211 0 0 0-1.989 11.446l.42.106.42-.318c.5-1.273 3.026-10.012 1.149-11.236Zm-24.209 8.365c-2.676 1.56-9.808.705-12.266 2.332-1.22.807-1.739 3.167-2.307 4.663-.511 1.448-1.856 3.238-2.21 4.663-.506 2.1 6.111 7.6 7.547 8.162 1.671.65 4.546-.555 6.188-.849 1.865-.334 7.8-.72 8.6-1.8.712-.884 4.2-7.123 3.879-8.478-.27-1.125-8.092-8.626-9.431-8.693Zm3.879 20.136c-3.076 1.213-8.107.345-10.8 1.907v.318l.314.106c2.033 1.377 11.252-.8 12.056-1.8-.139-.407 0-.221-.314-.424Z" transform="translate(15.988 3.946)" fill-rule="evenodd" /></symbol></defs></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-esport_active"><defs><symbol viewBox="0 0 100 76" id="icon-esport_active_a"><path data-name="Union 215" d="M19.1 59.008A30.616 30.616 0 0 1 8.973 8.967a30.59 30.59 0 0 1 43.307 0A30.637 30.637 0 0 1 19.1 59.008ZM28.523 58a23.858 23.858 0 0 1-.557-.274 3.376 3.376 0 0 1-.209-.115l-6.471-1.15A27.6 27.6 0 0 0 28.523 58ZM10.43 45.057c.141.268.3.53.461.812.1.16.191.326.287.492a40.314 40.314 0 0 0 3.982 5.8l12.807 2.288c.127-.153.236-.294.34-.428a279.272 279.272 0 0 0 3.078-4.23l-5.93-10.258a.6.6 0 0 1-.1-.013l-.1-.013a86.206 86.206 0 0 1-10-1.994Zm42.826-8.328-6.48 12.1a26.032 26.032 0 0 1 .8 3.413 26.816 26.816 0 0 0 2.48-2.192 27.459 27.459 0 0 0 7.8-15.85 33.523 33.523 0 0 1-4.6 2.529Zm-20.584-7.95a309.01 309.01 0 0 1-1.84 3.541c-1 1.9-1.932 3.649-2.826 5.317L34.115 48.2a57.759 57.759 0 0 0 9.932-.971l6.186-11.536c-.217-.428-.408-.8-.592-1.144a72.03 72.03 0 0 0-4.291-7.075ZM5.924 21.142c-.076.115-.158.23-.236.345a24.735 24.735 0 0 0-1.84 3.036 27.615 27.615 0 0 0 .863 15.21A19.7 19.7 0 0 0 8.258 42.6l4.793-7.51a52.644 52.644 0 0 1-1.061-10.555L6.021 21ZM35.848 7.528c-1.592.1-3.215.262-4.779.429l-1.121.115c-.1.012-.217.025-.338.051l-3.4 10.232c.328.326.652.652.979.978l1.041 1.042-.064.07.846.946c1.123 1.259 2.287 2.563 3.426 3.854.1.115.2.23.3.358l12.316-1.266.059-.134c.6-1.47 1.219-3 1.789-4.505.313-.825.588-1.694.85-2.537L39.176 7.5a18.16 18.16 0 0 0-1.213-.032 36.856 36.856 0 0 0-2.115.06ZM11.205 11.2c-.309.307-.615.632-.928.965a26.137 26.137 0 0 0-1.254 2.512c-.445 1.022-.848 2.1-1.238 3.138l-.154.409c-.006.019-.014.039-.02.064l6 3.547A60.736 60.736 0 0 1 21.5 17.6c.455-.2.922-.39 1.371-.562q.267-.105.521-.211l3.152-9.491a21.253 21.253 0 0 0-5.049-2.6c-.008-.006-.02-.006-.031-.013A27.168 27.168 0 0 0 11.205 11.2Zm30.6-5.49 8.545 9.625c.25.09.518.186.781.294a30.761 30.761 0 0 1 3.564 1.745A27.472 27.472 0 0 0 41.822 5.535c-.006.057-.011.115-.022.172Z" transform="translate(20.627 8.127)" /></symbol></defs><use xlink:href="#icon-esport_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-esport_active_green"><defs><symbol viewBox="0 0 30.5 30.846" id="icon-esport_active_green_a"><path d="M18.169.244a15.414 15.414 0 0 1 10.767 8.249c1.558 3.4 1.816 4.623 1.376 9.639-.624 5.524-5.107 9.826-9.439 11.7-1.141.494-2.468.6-3.747 1.007a22.8 22.8 0 0 1-3.795-.048C7.1 30.414.541 23.91.1 17.7a29.553 29.553 0 0 1 0-4.556C.588 6.886 6.545 1.293 12.287.244a22.773 22.773 0 0 1 5.882 0Zm0 1.822c-.937.36-4.318.99-4.554 1.774a13.071 13.071 0 0 0 .711 4.7c1.581.815 3.162 1.635 4.743 2.446a20.333 20.333 0 0 0 4.648-1.822c.636-.48.183-2.034 0-2.781l-.474-2.014c-.904-1.323-3.323-1.838-5.074-2.302ZM8.967 3.6C7.332 4.4 4.284 6.893 3.8 8.684a9.009 9.009 0 0 0 .19 3.6 10.9 10.9 0 0 0 4.222.671c.778-.2 1.511-1.307 1.992-1.87.644-.754 2.6-2.046 2.846-2.973l-.332-2.158c-.144-.848-.012-1.567-.379-2.11A23.112 23.112 0 0 0 8.967 3.6ZM24.1 10.075c-.955.6-3.732 1.15-4.269 1.966l-.474 2.685c-.19 1.1-.38 2.216-.569 3.309.131.516 3.389 3.352 3.984 3.884 1.038-.011 3.7-1.444 3.984-2.158l.474-3.117.427-3.117c-.17-.681-1.019-1.269-1.423-1.774-.482-.6-1.112-1.67-2.134-1.678ZM4.081 13.528c-.866.55-.857 1.6-1.233 2.685-.206.575-.411 1.156-.617 1.726-.255 1.266 1.587 4.9 2.229 5.323a6.815 6.815 0 0 0 2.324.575 5.358 5.358 0 0 0 2.134.24c.407-.541 2.344-4.308 2.135-5.131l-1.47-2.686c-.276-.654-.645-1.877-1.233-2.206-1.409-.174-2.85-.354-4.269-.526Zm24.57 1.487a16.384 16.384 0 0 0-.9 5.179l.19.048.19-.144c.227-.576 1.369-4.53.52-5.084ZM17.694 18.8c-1.211.706-4.438.319-5.55 1.055-.552.365-.787 1.433-1.044 2.11-.231.655-.84 1.465-1 2.11-.229.949 2.765 3.439 3.415 3.693.756.294 2.057-.251 2.8-.384.844-.151 3.528-.326 3.889-.815.322-.4 1.9-3.223 1.755-3.836-.12-.509-3.659-3.903-4.265-3.933Zm1.755 9.111c-1.392.549-3.668.156-4.886.863v.144l.142.048c.92.623 5.091-.364 5.455-.815-.063-.184 0-.1-.142-.192Z" transform="translate(-.004 -.049)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-esport_active_green_a" fill="#333" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-esport_green"><defs><symbol viewBox="0 0 30.5 30.846" id="icon-esport_green_a"><path d="M18.169.244a15.414 15.414 0 0 1 10.767 8.249c1.558 3.4 1.816 4.623 1.376 9.639-.624 5.524-5.107 9.826-9.439 11.7-1.141.494-2.468.6-3.747 1.007a22.8 22.8 0 0 1-3.795-.048C7.1 30.414.541 23.91.1 17.7a29.553 29.553 0 0 1 0-4.556C.588 6.886 6.545 1.293 12.287.244a22.773 22.773 0 0 1 5.882 0Zm0 1.822c-.937.36-4.318.99-4.554 1.774a13.071 13.071 0 0 0 .711 4.7c1.581.815 3.162 1.635 4.743 2.446a20.333 20.333 0 0 0 4.648-1.822c.636-.48.183-2.034 0-2.781l-.474-2.014c-.904-1.323-3.323-1.838-5.074-2.302ZM8.967 3.6C7.332 4.4 4.284 6.893 3.8 8.684a9.009 9.009 0 0 0 .19 3.6 10.9 10.9 0 0 0 4.222.671c.778-.2 1.511-1.307 1.992-1.87.644-.754 2.6-2.046 2.846-2.973l-.332-2.158c-.144-.848-.012-1.567-.379-2.11A23.112 23.112 0 0 0 8.967 3.6ZM24.1 10.075c-.955.6-3.732 1.15-4.269 1.966l-.474 2.685c-.19 1.1-.38 2.216-.569 3.309.131.516 3.389 3.352 3.984 3.884 1.038-.011 3.7-1.444 3.984-2.158l.474-3.117.427-3.117c-.17-.681-1.019-1.269-1.423-1.774-.482-.6-1.112-1.67-2.134-1.678ZM4.081 13.528c-.866.55-.857 1.6-1.233 2.685-.206.575-.411 1.156-.617 1.726-.255 1.266 1.587 4.9 2.229 5.323a6.815 6.815 0 0 0 2.324.575 5.358 5.358 0 0 0 2.134.24c.407-.541 2.344-4.308 2.135-5.131l-1.47-2.686c-.276-.654-.645-1.877-1.233-2.206-1.409-.174-2.85-.354-4.269-.526Zm24.57 1.487a16.384 16.384 0 0 0-.9 5.179l.19.048.19-.144c.227-.576 1.369-4.53.52-5.084ZM17.694 18.8c-1.211.706-4.438.319-5.55 1.055-.552.365-.787 1.433-1.044 2.11-.231.655-.84 1.465-1 2.11-.229.949 2.765 3.439 3.415 3.693.756.294 2.057-.251 2.8-.384.844-.151 3.528-.326 3.889-.815.322-.4 1.9-3.223 1.755-3.836-.12-.509-3.659-3.903-4.265-3.933Zm1.755 9.111c-1.392.549-3.668.156-4.886.863v.144l.142.048c.92.623 5.091-.364 5.455-.815-.063-.184 0-.1-.142-.192Z" transform="translate(-.004 -.049)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-esport_green_a" fill="#ADB6C4" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-exchange"><defs><symbol viewBox="0 0 25.293 20" id="icon-exchange_a"><path data-name="\u8DEF\u5F84 5560" d="M7403.417 982.784h1.754c.183 0 .366 0 .548.008.1.005.144-.023.144-.135 0-.478.01-.957.016-1.435a.932.932 0 0 1 .251-.616 1.328 1.328 0 0 1 .449-.338 1.045 1.045 0 0 1 .949.041c.538.309 1.081.614 1.62.927.459.267.919.542 1.378.811.5.291 1.008.569 1.5.871a1.13 1.13 0 0 1 .381 1.449 1.378 1.378 0 0 1-.539.54c-.469.271-.934.553-1.4.824-.365.212-.741.414-1.111.625s-.7.411-1.058.617c-.257.151-.509.323-.775.448a1.09 1.09 0 0 1-1.142-.086 1.108 1.108 0 0 1-.514-.977c.011-.4 0-.795 0-1.192a.346.346 0 0 0-.02-.143.147.147 0 0 0-.1-.082c-.228-.007-.449 0-.677 0-.193 0-.381-.006-.573-.008s-.355 0-.533 0h-.657c-.355.007-.711.022-1.067.027-.158 0-.316-.019-.479-.024-.144 0-.282 0-.42-.006-.188 0-.366 0-.549-.014a7.049 7.049 0 0 1-1.6-.315 12.782 12.782 0 0 1-1.018-.416 6.123 6.123 0 0 1-1.313-.825c-.316-.254-.593-.556-.89-.84a6.3 6.3 0 0 1-.879-1.156 5.6 5.6 0 0 1-.331-.62c-.134-.3-.267-.6-.37-.906a6.774 6.774 0 0 1-.321-1.686 14.142 14.142 0 0 1-.05-.919 3.42 3.42 0 0 1 .05-.508c.055-.319.1-.642.183-.954a10.324 10.324 0 0 1 .336-1 6.978 6.978 0 0 1 .84-1.535 7.51 7.51 0 0 1 1.161-1.285c.242-.206.5-.384.755-.566a2.691 2.691 0 0 1 .46-.274 1.07 1.07 0 0 1 1 1.879 7.581 7.581 0 0 0-.727.513 5.465 5.465 0 0 0-1.012 1.124 5.035 5.035 0 0 0-.589 1.177 6.271 6.271 0 0 0-.231.9 4.382 4.382 0 0 0-.04 1.419 6.466 6.466 0 0 0 .223 1.005 4.033 4.033 0 0 0 .528 1.167 5.33 5.33 0 0 0 1 1.179 5.073 5.073 0 0 0 1.748 1.021 3.965 3.965 0 0 0 1.082.245c.415.022.835.035 1.25.041.471.009.93.003 1.379.003Z" transform="translate(-7394.031 -967.543)" /><path data-name="\u8DEF\u5F84 5561" d="M7706.783 833h-1.912c-.1 0-.144.01-.144.131.01.324 0 .649 0 .974v.438a1.141 1.141 0 0 1-1.521.99 2.781 2.781 0 0 1-.514-.272c-.291-.169-.578-.343-.864-.513-.321-.185-.638-.369-.959-.551-.509-.289-1.022-.573-1.531-.863a18.935 18.935 0 0 1-.657-.391 1.125 1.125 0 0 1-.593-1.078 1.1 1.1 0 0 1 .6-.936c.464-.272.923-.548 1.393-.818.528-.306 1.057-.606 1.586-.912.38-.219.761-.446 1.141-.662a2.447 2.447 0 0 1 .523-.243 1.03 1.03 0 0 1 .672.046 1.068 1.068 0 0 1 .688.772 3.154 3.154 0 0 1 .049.527v1.01c0 .2.024.225.222.224.321 0 .643-.012.959-.012s.642.011.958.011.652-.011.974-.01.652.006.968.02c.277.012.544.03.815.061a4.753 4.753 0 0 1 .559.1c.237.056.474.115.7.19a5.9 5.9 0 0 1 1.21.53c.188.109.381.207.554.332a7.7 7.7 0 0 1 .785.61c.3.28.583.587.859.892a5.021 5.021 0 0 1 .79 1.188 12.251 12.251 0 0 1 .529 1.223 4.507 4.507 0 0 1 .231.918 11.429 11.429 0 0 1 .109 1.3 6.114 6.114 0 0 1-.168 1.581 7.409 7.409 0 0 1-.573 1.631 6.906 6.906 0 0 1-.825 1.327c-.257.315-.548.606-.834.9a5.468 5.468 0 0 1-.52.454 1.05 1.05 0 0 1-1.4-.032 1.01 1.01 0 0 1-.321-1.1 1.061 1.061 0 0 1 .39-.556 5.028 5.028 0 0 0 1.216-1.282 4.443 4.443 0 0 0 .568-1.137c.094-.319.163-.645.247-.969a4.855 4.855 0 0 0 .044-1.392 3.1 3.1 0 0 0-.158-.758 6.952 6.952 0 0 0-.37-1 6.743 6.743 0 0 0-.539-.851 3.873 3.873 0 0 0-.839-.871 5.689 5.689 0 0 0-.806-.533 7.147 7.147 0 0 0-.963-.422 4.527 4.527 0 0 0-.736-.162 3.494 3.494 0 0 0-.528-.048c-.5-.009-1-.008-1.5-.011h-.559Z" transform="translate(-7690.662 -828.251)" /></symbol></defs><use xlink:href="#icon-exchange_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-exit"><defs><symbol viewBox="0 0 13 16" id="icon-exit_a"><path data-name="Path 487" d="M1477.954-608.582a.782.782 0 0 0-.354-.657l-2.712-2.783a.746.746 0 0 0-1.074 0 .794.794 0 0 0 0 1.1l1.518 1.558h-5.69a.77.77 0 0 0-.76.78.77.77 0 0 0 .76.78h5.69l-1.518 1.558a.794.794 0 0 0 0 1.1.748.748 0 0 0 .537.228.748.748 0 0 0 .537-.228l2.712-2.783a.782.782 0 0 0 .354-.653Z" transform="translate(-1464.954 616.582)" /><path data-name="Path 488" d="M1468.73-611.054a.736.736 0 0 1-.726.745h-8.504a.736.736 0 0 1-.726-.745v-11.391a.735.735 0 0 1 .726-.745h8.5a.735.735 0 0 1 .726.745v1.191a.77.77 0 0 0 .76.78.77.77 0 0 0 .76-.78v-1.761a1.712 1.712 0 0 0-1.69-1.734h-9.621a1.712 1.712 0 0 0-1.69 1.734v12.532a1.712 1.712 0 0 0 1.69 1.734h9.621a1.712 1.712 0 0 0 1.69-1.734v-1.762a.77.77 0 0 0-.76-.78.77.77 0 0 0-.76.78Z" transform="translate(-1457.25 624.75)" /></symbol></defs><use xlink:href="#icon-exit_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-expand"><defs><symbol viewBox="0 0 11.996 12.008" id="icon-expand_a"><path d="M18645 17402a.534.534 0 0 1-.389-.141l-5.473-5.65a.5.5 0 0 1 0-.691.453.453 0 0 1 .67 0l5.191 5.34 5.182-5.34a.451.451 0 0 1 .668 0 .485.485 0 0 1 0 .691l-5.467 5.65a.549.549 0 0 1-.354.141Zm0-5.373a.479.479 0 0 1-.389-.15l-5.473-5.641a.5.5 0 0 1 0-.7.463.463 0 0 1 .67 0l5.191 5.34 5.182-5.34a.46.46 0 0 1 .668 0 .492.492 0 0 1 0 .7l-5.467 5.641a.489.489 0 0 1-.342.152Z" transform="translate(-18639 -17389.996)" /></symbol></defs><use xlink:href="#icon-expand_a" fill="var(--theme-text-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 10.363 17.074" id="icon-explain"><defs><symbol viewBox="0 0 10.363 17.074" id="icon-explain_a"><path data-name="Rectangle 958" transform="translate(4.086 15.01)" d="M0 0h2.391v2.064H0z" /><path data-name="Path 509" d="M2276.715 166.49q-5.283.282-5.481 5.254h2.093q.1-3.565 3.388-3.753a2.818 2.818 0 0 1 2.99 2.814q0 1.409-2.093 3.284-2.193 2.16-2.192 3.753v1.688h2.192v-1.97q-.1-.844 1.594-2.345 2.391-2.158 2.391-4.316-.297-4.222-4.882-4.409Z" transform="translate(-2271.234 -166.49)" /></symbol></defs><use xlink:href="#icon-explain_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-fee"><defs><symbol viewBox="0 0 60 60" id="icon-fee_a"><g transform="translate(-2279 241)" clip-path="url(#icon_wd_yeb1--svgSprite:all_clip-path)"><path data-name="Subtraction 42" d="M-7405.837-2220.093h-5.11c-.989 0-1.251-.991-1.555-2.139l-.027-.1-.037-.139-.62-1.954a30.073 30.073 0 0 1-7.694 1 29.924 29.924 0 0 1-6.91-.8l-.336 1.758-.01.045c-.25 1.147-.508 2.334-1.552 2.334h-5.11c-1.19 0-2.035-1.679-2.187-2.379-.053-.218-1.3-5.276-1.922-6.055a16.241 16.241 0 0 0-7.162-4.794 5.68 5.68 0 0 1-3.214-2.1c-.015-.018-1.558-1.9-1.7-5.964-.15-4.311.842-5.946.852-5.961a2.4 2.4 0 0 1 2.013-1.342c.889-.017 1.451-.823 2.68-2.591l.007-.011c.864-1.241 2.046-2.939 3.9-5.178a23.881 23.881 0 0 0-3.5-6.389s0-.006.006-.008a.844.844 0 0 1-.121-.427c0-.565.324-1.089 2.68-1.089a12.57 12.57 0 0 1 6.55 1.982 28.669 28.669 0 0 1 15.036-4.122 28.176 28.176 0 0 1 15.524 4.377 22.708 22.708 0 0 1 9.07 11.446c.717 2.01 1.6 3.265 2.374 3.356a5.057 5.057 0 0 0 .549.037.656.656 0 0 0 .3-.037 1.86 1.86 0 0 1 1.4.6 2.926 2.926 0 0 1 .646 2.247c-.117 1.457-.843 2.259-2.046 2.259h-.852c-.744.351-1.3 1.617-1.994 3.221-1.033 2.375-2.447 5.625-5.378 7.872l-2.3 8.676c-.14 1.067-1.176 2.369-2.25 2.369Zm-6.746-24.287a5.25 5.25 0 0 0-2.065.423 5.455 5.455 0 0 0-3.323 5.066 5.454 5.454 0 0 0 3.323 5.064 5.315 5.315 0 0 0 2.064.416 5.282 5.282 0 0 0 3.8-1.6 5.56 5.56 0 0 0 0-7.76 5.28 5.28 0 0 0-3.799-1.609Zm-15.153 2.33v2.743c0 1.764 3.5 3.2 7.806 3.2h1.074a5.344 5.344 0 0 1-.581-2.755h-.493c-4.37-.001-7.792-1.4-7.806-3.188Zm.03-4v2.743c0 1.764 3.495 3.2 7.791 3.2h.566a5.408 5.408 0 0 1 1.248-2.828 15.3 15.3 0 0 1-1.813.117h-.066a14.636 14.636 0 0 1-5.462-.941c-1.458-.606-2.258-1.419-2.264-2.289Zm0-3.85v2.743c0 1.771 3.495 3.213 7.791 3.213a14.532 14.532 0 0 0 2.873-.221 6.981 6.981 0 0 1 4.453-1.658 1.386 1.386 0 0 0 .508-1.1v-2.917c-.05.834-.881 1.618-2.34 2.206a15.054 15.054 0 0 1-5.452.918 15.118 15.118 0 0 1-5.511-.938c-1.491-.6-2.316-1.398-2.322-2.246Zm-10.116-2.027a2.877 2.877 0 0 0-2.873 2.876 2.875 2.875 0 0 0 2.873 2.871 2.874 2.874 0 0 0 2.871-2.871 2.877 2.877 0 0 0-2.871-2.873Zm17.892-2.413c-4.288 0-7.776 1.436-7.776 3.2 0 1.148 1.49 2.208 3.887 2.769a17.007 17.007 0 0 0 3.9.432 16.988 16.988 0 0 0 3.9-.432c2.4-.575 3.889-1.636 3.889-2.769-.009-1.76-3.504-3.197-7.8-3.197Z" transform="translate(9730.002 2032.53)" /></g></symbol></defs><use xlink:href="#icon-fee_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-footer_arrow_green"><defs><symbol viewBox="0 0 12 7" id="icon-footer_arrow_green_a"><path d="M300.734 37.264A1 1 0 0 0 300 37l-9.973.066a1 1 0 0 0-.731.264.953.953 0 0 0 0 1.387l4.986 4.953c.067.066.2.132.266.2l.067.066a1.045 1.045 0 0 0 1.063-.2l4.987-5.019a1.036 1.036 0 0 0 .069-1.453Z" transform="translate(-289 -37)" /></symbol></defs><use xlink:href="#icon-footer_arrow_green_a" fill="#7DB39E" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-game_arrow_left"><defs><symbol viewBox="0 0 21.999 35.998" id="icon-game_arrow_left_a"><path d="m2209.279 137.564-17.743-15.773a2.024 2.024 0 0 1-.271-.228 2.009 2.009 0 0 1 0-2.83 2.02 2.02 0 0 1 .274-.23l17.74-15.77a1.992 1.992 0 0 1 2.817 2.816l-16.422 14.6 16.422 14.6a1.992 1.992 0 0 1-2.817 2.817Z" transform="translate(-2190.681 -102.15)" /></symbol></defs><use xlink:href="#icon-game_arrow_left_a" fill-opacity=".7" fill="var(--theme-text-color-lighten)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-game_cz"><defs><symbol viewBox="0 0 32.891 26.509" id="icon-game_cz_a"><path data-name="Gradient Overlay" d="M4 26.51a4 4 0 0 1-4-4V4a4 4 0 0 1 4-4h24.892a4 4 0 0 1 4 4v2.76a3.87 3.87 0 0 0-1.509-.3H16.928a3.908 3.908 0 1 0 0 7.817h14.454a3.879 3.879 0 0 0 1.509-.3v8.533a4 4 0 0 1-4 4Zm-.916-5.458v1.739a1 1 0 0 0 2 0v-1.739a1 1 0 1 0-2 0Zm0-5.777v1.738a1 1 0 0 0 2 0v-1.738a1 1 0 1 0-2 0Zm0-5.778v1.739a1 1 0 0 0 2 0V9.5a1 1 0 0 0-2 0Zm0-5.778v1.739a1 1 0 0 0 2 0V3.719a1 1 0 1 0-2 0Zm12.335 6.647a1.885 1.885 0 1 1 1.881 1.87 1.877 1.877 0 0 1-1.882-1.87Z" /></symbol></defs><use xlink:href="#icon-game_cz_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-game_exit"><defs><symbol viewBox="0 0 25.741 27.171" id="icon-game_exit_a"><path data-name="Subtraction 42" d="M21.743 27.173H4a4 4 0 0 1-4-4V4a4 4 0 0 1 4-4h17.743a4 4 0 0 1 4 4v9.111a1.574 1.574 0 0 0-.642-.854l-5.452-5.6a1.494 1.494 0 0 0-2.155 0 1.6 1.6 0 0 0 0 2.219l3.048 3.136H8.527a1.569 1.569 0 0 0 0 3.137h12.015l-3.048 3.137a1.6 1.6 0 0 0 0 2.219 1.5 1.5 0 0 0 2.155 0L25.1 14.9a1.579 1.579 0 0 0 .642-.854v9.123a4 4 0 0 1-3.999 4.004Z" transform="translate(-.002 -.002)" /></symbol></defs><use xlink:href="#icon-game_exit_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-game_full_screen"><defs><symbol viewBox="0 0 23.999 24.001" id="icon-game_full_screen_a"><path d="M1.459 24a1.459 1.459 0 0 1-1.436-1.2l-.007-.057L0 22.541v-7.289a1.463 1.463 0 0 1 1.457-1.463 1.46 1.46 0 0 1 1.437 1.2l.007.052.015.209v3.763l4.422-4.422a1.461 1.461 0 0 1 2.066 2.066l-4.421 4.425h3.768a1.46 1.46 0 0 1 .258 2.9l-.054.005-.208.013Zm14.4 0a1.461 1.461 0 0 1 0-2.922h5.22v-5.22a1.46 1.46 0 0 1 2.92 0v6.682A1.461 1.461 0 0 1 22.541 24Zm6.089-13.788a1.458 1.458 0 0 1-1.436-1.2l-.012-.055-.015-.207V4.987l-4.418 4.422A1.461 1.461 0 0 1 14 7.343l4.424-4.423h-3.767A1.461 1.461 0 0 1 14.4.023h.054L14.661 0h7.288a1.459 1.459 0 0 1 1.436 1.2l.008.058.015.208V8.75a1.461 1.461 0 0 1-1.457 1.462ZM0 8.141v-6.68A1.46 1.46 0 0 1 1.46 0h6.681a1.461 1.461 0 0 1 0 2.922h-5.22v5.219a1.46 1.46 0 1 1-2.921 0Z" /></symbol></defs><use xlink:href="#icon-game_full_screen_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-game_refresh"><defs><symbol viewBox="0 0 24 25.144" id="icon-game_refresh_a"><path d="m1520.314-127.2 5.058-9.146 2.1 3.9a10.844 10.844 0 0 0 4.845-9.038c0-3.028-2-6.031-4-8 3.919 1.639 7.43 5.773 7.43 10.285a10.856 10.856 0 0 1-6.549 9.964l1.977 3.179Zm-8.572-10.858a10.86 10.86 0 0 1 6.548-9.965l-1.976-3.178 10.857 1.142-5.06 9.147-2.095-3.9a10.842 10.842 0 0 0-4.847 9.039c0 3.028 2 6.031 4 8-3.914-1.636-7.426-5.77-7.426-10.282Z" transform="translate(-1511.743 151.198)" /></symbol></defs><use xlink:href="#icon-game_refresh_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-header_account_arrow"><defs><symbol viewBox="0 0 12 7" id="icon-header_account_arrow_a"><path d="M300.734 37.264A1 1 0 0 0 300 37l-9.973.066a1 1 0 0 0-.731.264.953.953 0 0 0 0 1.387l4.986 4.953c.067.066.2.132.266.2l.067.066a1.045 1.045 0 0 0 1.063-.2l4.987-5.019a1.036 1.036 0 0 0 .069-1.453Z" transform="translate(-289 -37)" /></symbol></defs><use xlink:href="#icon-header_account_arrow_a" fill="var(--theme-alt-border)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-header_arrow_left"><defs><symbol viewBox="0 0 21.999 35.998" id="icon-header_arrow_left_a"><path d="m2209.279 137.564-17.743-15.773a2.024 2.024 0 0 1-.271-.228 2.009 2.009 0 0 1 0-2.83 2.02 2.02 0 0 1 .274-.23l17.74-15.77a1.992 1.992 0 0 1 2.817 2.816l-16.422 14.6 16.422 14.6a1.992 1.992 0 0 1-2.817 2.817Z" transform="translate(-2190.681 -102.15)" /></symbol></defs><use xlink:href="#icon-header_arrow_left_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-header_search"><defs><symbol viewBox="0 0 24 24" id="icon-header_search_a"><path d="m1610.592-172.388-6.849-6.64a9.445 9.445 0 0 1-5.266 1.584 9.427 9.427 0 0 1-6.659-2.718 9.154 9.154 0 0 1-2.757-6.561 9.158 9.158 0 0 1 2.757-6.561 9.429 9.429 0 0 1 6.659-2.718 9.427 9.427 0 0 1 6.658 2.718 9.152 9.152 0 0 1 2.758 6.561 9.12 9.12 0 0 1-2 5.715l6.692 6.49a1.438 1.438 0 0 1 .081 2.051 1.476 1.476 0 0 1-1.08.466 1.475 1.475 0 0 1-.994-.387Zm-18.7-14.335a6.546 6.546 0 0 0 6.588 6.488 6.617 6.617 0 0 0 4.056-1.38 1.457 1.457 0 0 1 .234-.333 1.467 1.467 0 0 1 .534-.363 6.412 6.412 0 0 0 1.762-4.413 6.545 6.545 0 0 0-6.586-6.488 6.546 6.546 0 0 0-6.59 6.489Z" transform="translate(-1589.062 196.002)" /></symbol></defs><use xlink:href="#icon-header_search_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-hidden"><defs><symbol viewBox="0 0 26 21.514" id="icon-hidden_a"><path data-name="Path 515" d="m1789.072 314.086-3.3 3.3a14.338 14.338 0 0 0-5.53-1.1 13.585 13.585 0 0 0-13.012 8.88l.069.007-.069.007a12.82 12.82 0 0 0 4.592 6.156l-2.855 2.855 1.412 1.412 20.1-20.1Zm-14.792 11.032a5.935 5.935 0 0 1 8.907-5.148l-1.827 1.828a3.507 3.507 0 0 0-4.456 4.456l-1.825 1.825a5.888 5.888 0 0 1-.8-2.961Z" transform="translate(-1767.233 -314.086)" /><path data-name="Path 516" d="M1793.172 339.617a3.516 3.516 0 0 0 3.514-3.515v-.084l-3.6 3.6c.029-.005.057-.001.086-.001Z" transform="translate(-1780.175 -325.064)" /><path data-name="Path 517" d="M1801.535 330.583a12.792 12.792 0 0 0-3.948-5.668l-3.507 3.507a5.934 5.934 0 0 1-7.668 7.668l-2.594 2.594a14.48 14.48 0 0 0 4.729.794 13.555 13.555 0 0 0 12.988-8.881l-.07-.007Z" transform="translate(-1775.535 -319.507)" /></symbol></defs><use xlink:href="#icon-hidden_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-home_back"><defs><symbol viewBox="0 0 51.213 45.807" id="icon-home_back_a"><path d="M435.08 6315.347h-9.4a1.715 1.715 0 0 1-1.713-1.72v-9.5a5.15 5.15 0 0 0-5.135-5.164 5.15 5.15 0 0 0-5.135 5.164v9.5a1.717 1.717 0 0 1-1.711 1.722h-9.4a3.451 3.451 0 0 1-3.442-3.464v-16.46h-3.264a2.631 2.631 0 0 1-2.261-1.2 2.572 2.572 0 0 1 .414-3.236l21.027-19.937a5.486 5.486 0 0 1 7.554 0l20.956 19.871a2.656 2.656 0 0 1 .826 2.432 2.552 2.552 0 0 1-2.507 2.071h-3.369v16.46a3.449 3.449 0 0 1-3.441 3.466Zm6.212-21.849Z" transform="translate(-393.225 -6269.541)" /></symbol></defs><use xlink:href="#icon-home_back_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-hot"><defs><symbol viewBox="0 0 100 76" id="icon-hot_a"><g data-name="Group 54892"><path data-name="Union 226" d="M9.141 20.7C22.238 11.293 21.418 5.574 15.934 0 41.863 11.133 40.8 34.449 27.3 41.973S21 63.086 21 63.086C-5.414 48.762-3.937 30.113 9.141 20.7Zm15.507 38.288c-1.574-4.145-2.07-9.863 4.578-13.574 8.715-4.859 12.766-10.98 12.367-18.73a26.052 26.052 0 0 0-.937-5.617 33.179 33.179 0 0 1 5.777 10.359 20.581 20.581 0 0 1 .91 4.613 14.3 14.3 0 0 1-.238 4.1A11.051 11.051 0 0 1 45.2 44.52a10.436 10.436 0 0 1-3.484 3.008 71.2 71.2 0 0 1-6.867 3.133c-4.914 2.023-8.465 3.484-10.172 8.328Z" transform="translate(25.127 6.83)" /></g></symbol></defs><use xlink:href="#icon-hot_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-hot_2"><use xlink:href="#icon-hot_2_a" /><defs><symbol viewBox="0 0 100 76" id="icon-hot_2_a"><path data-name="icon_dtfl_rm_0" d="m2427.755 344.3-.327-.091c-9.659-2.69-18.87-9.092-18.266-20.123a21.035 21.035 0 0 1 3.039-9.559 15.587 15.587 0 0 0 1.587-12.242 8.634 8.634 0 0 1 7.2 4.4c8.918-5.479 7.514-14.4 6.233-18.7 16.655 1.72 21.168 11.605 21.706 22.242 4.727-1.074 4.4-7.307 3.757-9.132 12.249 11.714 10.1 25.681 7.413 30.409s-6.768 10.423-14.936 12.142c6.984-8.7 1.828-14.5-2.793-22.242-2.9-4.728-2.9-7.956-2.148-9.886a13.039 13.039 0 0 0-8.274 14.076c-5.588-2.9-2.9-8.918-2.9-8.918-10.86 8.718-8.076 19.355-1.291 27.624Z" transform="translate(-2386.133 -277.999)" /></symbol></defs></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-hot_active"><defs><symbol viewBox="0 0 100 76" id="icon-hot_active_a"><g data-name="Group 54892"><path data-name="Union 226" d="M9.141 20.7C22.238 11.293 21.418 5.574 15.934 0 41.863 11.133 40.8 34.449 27.3 41.973S21 63.086 21 63.086C-5.414 48.762-3.937 30.113 9.141 20.7Zm15.507 38.288c-1.574-4.145-2.07-9.863 4.578-13.574 8.715-4.859 12.766-10.98 12.367-18.73a26.052 26.052 0 0 0-.937-5.617 33.179 33.179 0 0 1 5.777 10.359 20.581 20.581 0 0 1 .91 4.613 14.3 14.3 0 0 1-.238 4.1A11.051 11.051 0 0 1 45.2 44.52a10.436 10.436 0 0 1-3.484 3.008 71.2 71.2 0 0 1-6.867 3.133c-4.914 2.023-8.465 3.484-10.172 8.328Z" transform="translate(25.127 6.83)" /></g></symbol></defs><use xlink:href="#icon-hot_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-id"><defs><symbol viewBox="0 0 22.001 15.665" id="icon-id_a"><path d="M-10951.833-3157.833h-18.333a1.836 1.836 0 0 1-1.834-1.834v-12a1.834 1.834 0 0 1 1.834-1.831h18.333a1.834 1.834 0 0 1 1.834 1.831v12a1.836 1.836 0 0 1-1.834 1.834Zm-13.407-12.51a2.605 2.605 0 0 0-2.616 2.588 2.554 2.554 0 0 0 1.05 2.076c-1.585 1.049-2.8 2-2.905 3.88a.814.814 0 0 0 .216.6.6.6 0 0 0 .431.191h7.647a.6.6 0 0 0 .431-.189.825.825 0 0 0 .219-.6c-.109-1.884-1.326-2.834-2.905-3.88a2.568 2.568 0 0 0 1.05-2.076 2.605 2.605 0 0 0-2.618-2.59Zm7.562 5.667a1.032 1.032 0 0 0-1.03 1.032 1.031 1.031 0 0 0 1.03 1.03h4.813a1.032 1.032 0 0 0 1.032-1.03 1.033 1.033 0 0 0-1.032-1.032Zm0-4.125a1.031 1.031 0 0 0-1.03 1.03 1.033 1.033 0 0 0 1.03 1.033h4.813a1.034 1.034 0 0 0 1.032-1.033 1.032 1.032 0 0 0-1.032-1.03Z" transform="translate(10972 3173.499)" /></symbol></defs><use xlink:href="#icon-id_a" fill="var(--theme-text-color-lighten)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 12.928 22.67" id="icon-img_scroll_jt--svgSprite"><defs><symbol viewBox="0 0 12.928 22.67" id="icon-img_scroll_jt--svgSprite_a"><path d="M10.806 21.6a.961.961 0 0 1-.7-.256L.259 11.181a.889.889 0 0 1 0-1.242.81.81 0 0 1 .6-.267.824.824 0 0 1 .607.267l9.34 9.6 9.326-9.6a.834.834 0 0 1 .61-.267.818.818 0 0 1 .6.267.882.882 0 0 1 0 1.242L11.5 21.348a1 1 0 0 1-.638.25Z" transform="rotate(-90 6.463 15.635)" /></symbol></defs><use xlink:href="#icon-img_scroll_jt--svgSprite_a" /></symbol><symbol class="icon" fill="currentColor" viewBox="0 0 1024 1024"  id="icon-info"><path d="M512 85.333A426.667 426.667 0 1 0 938.667 512 426.667 426.667 0 0 0 512 85.333zm42.667 597.334a42.667 42.667 0 0 1-85.334 0V469.333a42.667 42.667 0 0 1 85.334 0zM512 384a42.667 42.667 0 1 1 42.667-42.667A42.667 42.667 0 0 1 512 384z" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-input_code"><defs><symbol viewBox="0 0 18.013 18.998" id="icon-input_code_a"><path d="m8.587 15.229 1.908-1.987a5.939 5.939 0 0 0 6.725-1.363 6.561 6.561 0 0 0 0-9.013 5.959 5.959 0 0 0-8.42-.238 5.935 5.935 0 0 0-.238.238 6.477 6.477 0 0 0-1.796 4.508 6.59 6.59 0 0 0 .485 2.492l-5.84 6.077a.573.573 0 0 0-.16.355L1 19.117a.574.574 0 0 0 .493.625l2.22.258h.061a.542.542 0 0 0 .377-.154.585.585 0 0 0 .174-.442L4.277 17.9l1.445.051a.522.522 0 0 0 .413-.168.6.6 0 0 0 .16-.428l-.051-1.5 1.449.051a.533.533 0 0 0 .41-.168Zm5.042-11.187a1.692 1.692 0 0 1 2.392-.069q.035.033.069.069a1.86 1.86 0 0 1 0 2.562 1.692 1.692 0 0 1-2.391.071l-.07-.071a1.863 1.863 0 0 1 0-2.562Z" transform="translate(-.999 -1)" /></symbol></defs><use xlink:href="#icon-input_code_a" fill="var(--theme-text-color-lighten)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-input_phone"><defs><symbol viewBox="0 0 13.792 23" id="icon-input_phone_a"><path d="M5622.25 1131.995h-9.2a2.328 2.328 0 0 0-2.3 2.356v18.289a2.328 2.328 0 0 0 2.3 2.355h9.194a2.34 2.34 0 0 0 2.3-2.37v-18.265a2.328 2.328 0 0 0-2.294-2.365Zm-4.6 22.183a1.064 1.064 0 1 1 1.038-1.063 1.05 1.05 0 0 1-1.042 1.062Zm5-3.868a.7.7 0 0 1-.759.785h-8.516a.764.764 0 0 1-.646-.785v-14.8a.774.774 0 0 1 .767-.785h8.388a.775.775 0 0 1 .767.785Z" transform="translate(-5610.75 -1131.995)" /></symbol></defs><use xlink:href="#icon-input_phone_a" fill="var(--theme-primary-color)" /></symbol><symbol  viewBox="0 0 1024 1024" fill="currentColor" aria-hidden="true" class="anticon-spin" id="icon-loading"><path d="M988 548c-19.9 0-36-16.1-36-36 0-59.4-11.6-117-34.6-171.3a440.45 440.45 0 0 0-94.3-139.9 437.71 437.71 0 0 0-139.9-94.3C629 83.6 571.4 72 512 72c-19.9 0-36-16.1-36-36s16.1-36 36-36c69.1 0 136.2 13.5 199.3 40.3C772.3 66 827 103 874 150c47 47 83.9 101.8 109.7 162.7 26.7 63.1 40.2 130.2 40.2 199.3.1 19.9-16 36-35.9 36z" /></symbol><symbol   fill="currentColor" aria-hidden="true" id="icon-lock"><defs><symbol viewBox="0 0 15.117 20" id="icon-lock_a"><path d="M3378.433 1298.491v-1.5a5.966 5.966 0 0 0-5.583-6 5.866 5.866 0 0 0-6.176 5.826v1.666h-.236a1.438 1.438 0 0 0-1.443 1.432v9.635a1.438 1.438 0 0 0 1.443 1.432h12.23a1.438 1.438 0 0 0 1.443-1.432v-9.635a1.438 1.438 0 0 0-1.443-1.432Zm-9.8-1.528a3.919 3.919 0 0 1 7.838 0v1.528h-7.838Zm5.177 10.232a.41.41 0 0 1-.1.323.424.424 0 0 1-.313.139h-1.679a.423.423 0 0 1-.314-.139.412.412 0 0 1-.1-.323l.265-2.364a1.643 1.643 0 0 1-.687-1.34 1.68 1.68 0 0 1 3.359 0 1.643 1.643 0 0 1-.687 1.34Z" transform="translate(-3364.995 -1290.991)" /></symbol></defs><use xlink:href="#icon-lock_a" fill="var(--theme-text-color-lighten)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 40 40" id="icon-mine_account"><defs><symbol viewBox="0 0 40 40" id="icon-mine_account_a"><path data-name="\u8DEF\u5F84 16900" d="M-4094.821-365.073a9.77 9.77 0 0 1-5.87-10.92 9.771 9.771 0 0 1 9.567-7.886 9.767 9.767 0 0 1 6.91 2.843 9.77 9.77 0 0 1 1.248 12.335 9.769 9.769 0 0 1-8.141 4.364 9.751 9.751 0 0 1-3.714-.736Zm-1.244-14.013a6.983 6.983 0 0 0-.925 8.815 6.983 6.983 0 0 0 8.465 2.624 6.984 6.984 0 0 0 4.222-7.793 6.984 6.984 0 0 0-6.822-5.658h-.034a6.986 6.986 0 0 0-4.905 2.013Zm-15.558 14.172a4.405 4.405 0 0 1-4.378-4.377v-23.619a4.4 4.4 0 0 1 4.378-4.377h19.524a4.4 4.4 0 0 1 4.377 4.377v7.017a11.33 11.33 0 0 0-3.127-.486v-6.6a1.243 1.243 0 0 0-.365-.885 1.235 1.235 0 0 0-.885-.364h-19.524a1.239 1.239 0 0 0-.886.364 1.245 1.245 0 0 0-.364.885v23.624a1.247 1.247 0 0 0 .364.885 1.248 1.248 0 0 0 .886.364h9.8a14.055 14.055 0 0 0 2.571 3.193Zm20.479-4.505-1.43-.013a5.854 5.854 0 0 0 1.368-2.351 4.982 4.982 0 0 1-1.539.843 2.259 2.259 0 0 1-1.98-.577 2.257 2.257 0 0 1-.687-1.945c.061-1.959 2.253-2.8 4.279-5.3 1.994 2.529 4.225 3.4 4.26 5.35a2.253 2.253 0 0 1-.717 1.93 2.252 2.252 0 0 1-1.985.543 4.566 4.566 0 0 1-1.476-.853 5.915 5.915 0 0 0 1.337 2.383Zm-11.168-11.617h-6.1a1.616 1.616 0 0 1-1.6-1.6 1.579 1.579 0 0 1 .46-1.135 1.577 1.577 0 0 1 1.137-.46h6.1a1.6 1.6 0 0 1 1.6 1.6 1.6 1.6 0 0 1-1.6 1.6Zm5.205-5.274h-11.4a1.617 1.617 0 0 1-1.6-1.6 1.576 1.576 0 0 1 .461-1.137 1.569 1.569 0 0 1 1.136-.46h11.4a1.617 1.617 0 0 1 1.6 1.6 1.576 1.576 0 0 1-.461 1.136 1.572 1.572 0 0 1-1.113.46Z" transform="translate(4118.666 400.812)" /></symbol></defs><use xlink:href="#icon-mine_account_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 82 71" id="icon-mine_account_green"><defs><symbol viewBox="0 0 82 71" id="icon-mine_account_green_a"><path d="M-1696.094 2671a26.763 26.763 0 0 1-10.547-2.145 26.99 26.99 0 0 1-8.613-5.849 27.213 27.213 0 0 1-5.806-8.676 27.3 27.3 0 0 1-2.129-10.624 27.256 27.256 0 0 1 4.859-15.6 27.384 27.384 0 0 1 9.5-8.5 26.831 26.831 0 0 1 6.066-2.364 27.011 27.011 0 0 1 6.672-.834 26.744 26.744 0 0 1 10.544 2.145 26.99 26.99 0 0 1 8.611 5.85 27.221 27.221 0 0 1 5.806 8.677 27.306 27.306 0 0 1 2.131 10.62 27.3 27.3 0 0 1-2.129 10.627 27.215 27.215 0 0 1-5.807 8.676 27 27 0 0 1-8.612 5.849 26.756 26.756 0 0 1-10.546 2.148Zm-.358-11.326c.018 0 .323.021 5.241.046-2.661-2.328-4.312-6.694-4.9-8.463a16.839 16.839 0 0 0 5.411 3.045 5.575 5.575 0 0 0 1.882.312 7.955 7.955 0 0 0 5.512-2.424 9.036 9.036 0 0 0 2.515-6.7c-.073-4.329-3.322-7.212-7.436-10.861a67.733 67.733 0 0 1-8.19-8.228 69.731 69.731 0 0 1-8.149 8.032c-4.137 3.617-7.4 6.475-7.541 10.844a9.061 9.061 0 0 0 2.469 6.814 7.917 7.917 0 0 0 5.523 2.463 5.524 5.524 0 0 0 1.785-.283 18.457 18.457 0 0 0 5.646-3.01c-.611 1.762-2.324 6.1-5.01 8.378 3.21.039 4.478.048 4.976.048h.266v-.005Zm-21.821 8.392h-27.368c-.074 0-.149 0-.224-.005a4.373 4.373 0 0 1-4.134-4.386v-2.613a4.384 4.384 0 0 1 1.24-3.068 4.316 4.316 0 0 1 3.005-1.321h19.461a33.453 33.453 0 0 0 8.018 11.394Zm-10.111-18.435h-17.37a4.316 4.316 0 0 1-3.005-1.322 4.386 4.386 0 0 1-1.24-3.069v-2.611a4.364 4.364 0 0 1 3.912-4.369c.157-.015.3-.023.446-.023h17.176a33.4 33.4 0 0 0-.459 5.467 33.317 33.317 0 0 0 .541 5.927Zm1.907-18.434h-19.165a4.318 4.318 0 0 1-3.044-1.249 4.381 4.381 0 0 1-1.313-3.029V2624.078a4.38 4.38 0 0 1 1.313-3.029 4.318 4.318 0 0 1 3.044-1.249h26.887a32.969 32.969 0 0 0-7.723 11.4Zm19.805-18.8h-38.765a4.382 4.382 0 0 1-4.363-4.397v-2.612a4.574 4.574 0 0 1 .05-.67 4.4 4.4 0 0 1 1.458-2.652 4.343 4.343 0 0 1 2.854-1.071h47.838a4.38 4.38 0 0 1 4.358 4.393v3.649a3.307 3.307 0 0 1-.462 1.676h-.006c-.912-.065-1.668-.1-2.379-.1a32.424 32.424 0 0 0-10.583 1.774Z" transform="translate(1750.5 -2600.5)" stroke-miterlimit="10" /></symbol></defs><use xlink:href="#icon-mine_account_green_a" fill="#FACF20" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 40 40" id="icon-mine_agent"><defs><symbol viewBox="0 0 40 40" id="icon-mine_agent_a"><path data-name="\u8DEF\u5F84 16891" d="M-413.667-1043a5.289 5.289 0 0 1-5.333-5.231v-23.538a5.289 5.289 0 0 1 5.333-5.231h13.334a1.668 1.668 0 0 1 1.667 1.667 1.668 1.668 0 0 1-1.667 1.667v.015h-13.334a1.983 1.983 0 0 0-2 1.961v23.458a1.984 1.984 0 0 0 2 1.962h24a1.983 1.983 0 0 0 2-1.962v-10.1A1.667 1.667 0 0 1-386-1060a1.666 1.666 0 0 1 1.666 1.666v10.1a5.288 5.288 0 0 1-5.334 5.231Zm9.07-11.7a1.666 1.666 0 0 1-1.626-1.706 16.236 16.236 0 0 1 1.048-4.774 13.806 13.806 0 0 1 4.961-6.68 17.591 17.591 0 0 1 9.423-3.09l-2.055-2.055a1.668 1.668 0 0 1 0-2.357 1.667 1.667 0 0 1 2.357 0l5.185 5.185a1.667 1.667 0 0 1 0 2.357l-5.185 5.185a1.667 1.667 0 0 1-2.357 0 1.667 1.667 0 0 1 0-2.357l2.652-2.652c-8.089.345-10.882 4.807-11.838 7.571l-.012.033a13.14 13.14 0 0 0-.848 3.715 1.668 1.668 0 0 1-1.666 1.627Z" transform="translate(421 1081)" /></symbol></defs><use xlink:href="#icon-mine_agent_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 12.928 22.67" id="icon-mine_arrow_right"><defs><symbol viewBox="0 0 12.928 22.67" id="icon-mine_arrow_right_a"><path d="M10.806 21.6a.961.961 0 0 1-.7-.256L.259 11.181a.889.889 0 0 1 0-1.242.81.81 0 0 1 .6-.267.824.824 0 0 1 .607.267l9.34 9.6 9.326-9.6a.834.834 0 0 1 .61-.267.818.818 0 0 1 .6.267.882.882 0 0 1 0 1.242L11.5 21.348a1 1 0 0 1-.638.25Z" transform="rotate(-90 6.463 15.635)" /></symbol></defs><use xlink:href="#icon-mine_arrow_right_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 40 40" id="icon-mine_bet_record"><defs><symbol viewBox="0 0 40 40" id="icon-mine_bet_record_a"><path data-name="\u8DEF\u5F84 16895" d="M842.159-924.035a9.77 9.77 0 0 1-5.869-10.92 9.77 9.77 0 0 1 9.567-7.886 9.774 9.774 0 0 1 6.91 2.843 9.772 9.772 0 0 1 1.249 12.335 9.771 9.771 0 0 1-8.141 4.364 9.76 9.76 0 0 1-3.716-.736Zm-1.243-14.013a6.981 6.981 0 0 0-.925 8.814 6.984 6.984 0 0 0 8.466 2.624 6.985 6.985 0 0 0 4.222-7.793 6.985 6.985 0 0 0-6.822-5.658h-.035a6.983 6.983 0 0 0-4.906 2.013Zm-2.872 14.15h-15.229a1.816 1.816 0 0 1-1.815-1.813 1.816 1.816 0 0 1 1.815-1.814h12.3a12.316 12.316 0 0 0 2.932 3.626Zm7.813-4.367s0 .005-1.431-.013a5.849 5.849 0 0 0 1.368-2.351 4.984 4.984 0 0 1-1.539.844 2.259 2.259 0 0 1-1.981-.578 2.256 2.256 0 0 1-.686-1.944c.061-1.96 2.253-2.8 4.279-5.3 1.994 2.528 4.225 3.4 4.26 5.351a2.255 2.255 0 0 1-.716 1.93 2.256 2.256 0 0 1-1.985.542 4.565 4.565 0 0 1-1.477-.854 5.916 5.916 0 0 0 1.337 2.384Zm-11.91-2.43h-11.132a1.816 1.816 0 0 1-1.815-1.813 1.817 1.817 0 0 1 1.815-1.814h10.892a12.7 12.7 0 0 0-.04 1 12.392 12.392 0 0 0 .281 2.629Zm.4-6.667h-11.532a1.816 1.816 0 0 1-1.815-1.813 1.817 1.817 0 0 1 1.815-1.815h13.523a12.287 12.287 0 0 0-1.995 3.628Zm5.526-6.667Zm0 0h-17.058a1.816 1.816 0 0 1-1.815-1.812 1.817 1.817 0 0 1 1.815-1.815h24.1a1.784 1.784 0 0 1 1.253.519 1.782 1.782 0 0 1 .518 1.3 1.847 1.847 0 0 1-.06.465 12.419 12.419 0 0 0-2.629-.281 12.328 12.328 0 0 0-6.128 1.626Zm-17.054-6.938A1.817 1.817 0 0 1 821-952.78a1.816 1.816 0 0 1 1.815-1.814h24.1a1.776 1.776 0 0 1 1.25.519 1.782 1.782 0 0 1 .518 1.3 1.816 1.816 0 0 1-1.814 1.814Z" transform="translate(-818.333 959.657)" /></symbol></defs><use xlink:href="#icon-mine_bet_record_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-mine_bet_record_green"><defs><symbol viewBox="0 0 113.999 68.093" id="icon-mine_bet_record_green_a"><path d="M-264.222 2532.093a18.106 18.106 0 0 1-12.885-5.337 18.1 18.1 0 0 1-5.339-12.885 18.1 18.1 0 0 1 5.339-12.884 18.106 18.106 0 0 1 12.885-5.337 18.1 18.1 0 0 1 12.885 5.337 18.1 18.1 0 0 1 5.337 12.884 18.1 18.1 0 0 1-5.336 12.885 18.1 18.1 0 0 1-12.886 5.337Zm.211-7.205c.018 0 .276.014 3.541.031-1.8-1.573-2.915-4.524-3.311-5.719a11.354 11.354 0 0 0 3.658 2.058 3.762 3.762 0 0 0 1.272.211 5.375 5.375 0 0 0 3.724-1.638 6.109 6.109 0 0 0 1.7-4.532c-.049-2.926-2.245-4.875-5.025-7.341a45.781 45.781 0 0 1-5.535-5.562 47.1 47.1 0 0 1-5.509 5.43c-2.8 2.445-5 4.375-5.1 7.328a6.123 6.123 0 0 0 1.668 4.605 5.352 5.352 0 0 0 3.734 1.665 3.734 3.734 0 0 0 1.206-.191 12.423 12.423 0 0 0 3.816-2.034c-.413 1.192-1.573 4.127-3.386 5.663 2.173.027 3.031.032 3.369.032h.173Zm-82.8-1.033a13.281 13.281 0 0 1-3.668-.518 13.09 13.09 0 0 1-6.853-4.674 12.887 12.887 0 0 1-2.663-7.808v-.966l.047-.313c1.224-8.194 3.634-24.313 4-26.674 1.006-6.39 3-11 6.081-14.082 2.95-2.951 6.931-4.528 12.17-4.82h46.635a17.051 17.051 0 0 1 12.146 5.521c2.957 3.216 5.011 7.718 6.1 13.381.179.98.687 4.324 1.469 9.671-.6.2-1.21.42-1.8.669a22.922 22.922 0 0 0-7.31 4.883 22.677 22.677 0 0 0-4.928 7.242 22.478 22.478 0 0 0-1.809 8.871 22.471 22.471 0 0 0 1.809 8.871c.041.1.084.2.127.292a13.147 13.147 0 0 1-7.819-5.532l-7.42-12.034a4.058 4.058 0 0 0-3.451-1.932h-20.863a4.058 4.058 0 0 0-3.392 1.932l-7.5 11.991a13.168 13.168 0 0 1-4.825 4.447 13.323 13.323 0 0 1-6.288 1.582Zm13.581-51.664a13.1 13.1 0 0 0-9.279 3.815 12.85 12.85 0 0 0-3.835 9.2 13.08 13.08 0 0 0 13.121 12.986h.022a13.109 13.109 0 0 0 13.1-13 13.075 13.075 0 0 0-13.12-13Zm37.93 17.012a4.224 4.224 0 0 0-4.239 4.2 4.225 4.225 0 0 0 4.239 4.2 4.226 4.226 0 0 0 4.24-4.2 4.225 4.225 0 0 0-4.245-4.203Zm8.48-8.4a4.225 4.225 0 0 0-4.24 4.2 4.226 4.226 0 0 0 4.24 4.2 4.225 4.225 0 0 0 4.239-4.2 4.225 4.225 0 0 0-4.245-4.203Zm-16.959 0a4.225 4.225 0 0 0-4.239 4.2 4.225 4.225 0 0 0 4.239 4.2 4.226 4.226 0 0 0 4.24-4.2 4.225 4.225 0 0 0-4.245-4.203Zm8.479-8.4a4.225 4.225 0 0 0-4.239 4.2 4.225 4.225 0 0 0 4.239 4.2 4.225 4.225 0 0 0 4.24-4.2 4.225 4.225 0 0 0-4.245-4.203Zm-38.072 20.637a7.81 7.81 0 0 1-7.8-7.8 7.809 7.809 0 0 1 7.8-7.8 7.777 7.777 0 0 1 5.509 2.292 7.773 7.773 0 0 1 2.291 5.508 7.81 7.81 0 0 1-7.805 7.798Z" transform="translate(360 -2464)" /></symbol></defs><use xlink:href="#icon-mine_bet_record_green_a" fill="#FACF20" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 23.001 24.3" id="icon-mine_copy"><defs><symbol viewBox="0 0 23.001 24.3" id="icon-mine_copy_a"><path d="M1.293 23.294A1.294 1.294 0 0 1 0 22V5.175a1.292 1.292 0 0 1 1.293-1.293h15.53a1.292 1.292 0 0 1 1.293 1.293V22a1.293 1.293 0 0 1-1.293 1.3Zm.647-1.941h14.234V5.825H1.94Zm18.116-2.263V1.942H7.441a.972.972 0 0 1 0-1.942h13.588A.978.978 0 0 1 22 .978v18.111a.972.972 0 1 1-1.942 0Z" transform="translate(.5 .5)" stroke-miterlimit="10" /></symbol></defs><use xlink:href="#icon-mine_copy_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-mine_language"><defs><symbol viewBox="0 0 26 26" id="icon-mine_language_a"><path d="M18073 22626a13 13 0 1 1 13-13 13 13 0 0 1-13 13Zm0-2.5c.342 0 1.182-.641 1.971-2.355a19.318 19.318 0 0 0 1.5-6.895h-6.937a19.276 19.276 0 0 0 1.5 6.895c.789 1.715 1.629 2.355 1.975 2.355Zm3.984-.785a10.541 10.541 0 0 0 6.441-8.465h-4.457a20.933 20.933 0 0 1-1.982 8.467Zm-7.973 0a20.922 20.922 0 0 1-1.986-8.463h-4.455a10.538 10.538 0 0 0 6.444 8.463Zm14.414-10.967a10.537 10.537 0 0 0-6.441-8.465 20.9 20.9 0 0 1 1.984 8.465Zm-6.959 0a19.3 19.3 0 0 0-1.5-6.895c-.789-1.715-1.629-2.355-1.971-2.355s-1.186.641-1.975 2.355a19.294 19.294 0 0 0-1.5 6.895Zm-9.441 0a20.922 20.922 0 0 1 1.986-8.463 10.53 10.53 0 0 0-6.441 8.463Z" transform="translate(-18060 -22600)" /></symbol></defs><use xlink:href="#icon-mine_language_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 40 40" id="icon-mine_message"><defs><symbol viewBox="0 0 40 40" id="icon-mine_message_a"><path data-name="\u8DEF\u5F84 16899" d="M15.334 30.667A15.333 15.333 0 0 1 4.491 4.491a15.333 15.333 0 0 1 26.176 10.843 15.193 15.193 0 0 1-3.128 9.282c.692 1.029 1.754 2.938 1.092 4.144a1.289 1.289 0 0 1-1.237.612 8.926 8.926 0 0 1-3.6-1.247 15.263 15.263 0 0 1-8.46 2.542Zm7.893-18a2.76 2.76 0 1 0 2.76 2.76 2.763 2.763 0 0 0-2.76-2.76Zm-7.893 0a2.76 2.76 0 1 0 2.76 2.76 2.763 2.763 0 0 0-2.76-2.76Zm-7.907 0a2.76 2.76 0 1 0 2.76 2.76 2.763 2.763 0 0 0-2.76-2.76Z" transform="translate(4.667 4.667)" /></symbol></defs><use xlink:href="#icon-mine_message_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-mine_music"><defs><symbol viewBox="0 0 15 16.109" id="icon-mine_music_a"><path d="M5.845 324.262v8.081a3.1 3.1 0 0 0-1.7-.513 3.139 3.139 0 1 0 3.139 3.143v-5.739l7.281-1.619v2.791a3.1 3.1 0 0 0-1.7-.512A3.139 3.139 0 1 0 16 333.033V322Zm8.755-.289v2.048l-7.311 1.591v-2.044ZM5.758 335a1.645 1.645 0 1 1-.482-1.159A1.644 1.644 0 0 1 5.758 335Zm8.785-1.939a1.645 1.645 0 1 1-.482-1.16 1.643 1.643 0 0 1 .482 1.156Z" transform="translate(-1.004 -322)" /></symbol></defs><use xlink:href="#icon-mine_music_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 40 40" id="icon-mine_personal_report"><defs><symbol viewBox="0 0 40 40" id="icon-mine_personal_report_a"><g data-name="1"><path data-name="\u8DEF\u5F84 16897" d="m-140.793-894.332-2.207-2.207a9.265 9.265 0 0 1-5.533 1.814 9.272 9.272 0 0 1-6.6-2.734 9.272 9.272 0 0 1-2.734-6.6 9.273 9.273 0 0 1 2.734-6.6 9.272 9.272 0 0 1 6.6-2.734 9.274 9.274 0 0 1 6.6 2.734 9.273 9.273 0 0 1 2.734 6.6 9.263 9.263 0 0 1-1.8 5.507l2.21 2.21a1.422 1.422 0 0 1 .407 1.391 1.42 1.42 0 0 1-1.025 1.025 1.419 1.419 0 0 1-.353.045 1.419 1.419 0 0 1-1.033-.451Zm-14.071-9.726a6.338 6.338 0 0 0 6.331 6.331 6.338 6.338 0 0 0 6.331-6.331 6.338 6.338 0 0 0-6.331-6.331 6.338 6.338 0 0 0-6.331 6.331Zm-13.759 9.431A4.4 4.4 0 0 1-173-899v-23.619a4.4 4.4 0 0 1 4.377-4.381h19.523a4.4 4.4 0 0 1 4.377 4.377v7.016a11.317 11.317 0 0 0-3.127-.485v-6.6a1.245 1.245 0 0 0-.365-.885 1.24 1.24 0 0 0-.886-.364h-19.524a1.241 1.241 0 0 0-.885.364 1.243 1.243 0 0 0-.365.885v23.624a1.245 1.245 0 0 0 .365.885 1.249 1.249 0 0 0 .885.364h9.8a14.05 14.05 0 0 0 2.571 3.193Zm9.311-16.122h-6.1a1.616 1.616 0 0 1-1.6-1.6 1.579 1.579 0 0 1 .461-1.135 1.573 1.573 0 0 1 1.136-.46h6.1a1.6 1.6 0 0 1 1.6 1.6 1.6 1.6 0 0 1-1.6 1.6Zm5.2-5.275h-11.4a1.616 1.616 0 0 1-1.6-1.6 1.573 1.573 0 0 1 .461-1.137 1.57 1.57 0 0 1 1.136-.46h11.4a1.617 1.617 0 0 1 1.6 1.6 1.572 1.572 0 0 1-.461 1.136 1.569 1.569 0 0 1-1.112.46Z" transform="translate(175.666 930.525)" /></g></symbol></defs><use xlink:href="#icon-mine_personal_report_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-mine_personal_report_green"><defs><symbol viewBox="0 0 81.002 79.998" id="icon-mine_personal_report_green_a"><g data-name="icon_wd_grbb"><path data-name="Shape 17" d="M89.715 1105.356a6.682 6.682 0 0 1-6.724-6.639v-57.087a6.682 6.682 0 0 1 6.724-6.638h4.706v2.43a10.034 10.034 0 0 0 10.085 9.958h20.171a10.035 10.035 0 0 0 10.088-9.958v-2.43h4.706a6.682 6.682 0 0 1 6.724 6.638v23.87a23.65 23.65 0 0 0-5.379-.639 23.413 23.413 0 0 0-23.532 23.235 23.036 23.036 0 0 0 7.834 17.259Zm2.6-34.809a3.132 3.132 0 0 0 3.152 3.112h17.027a3.112 3.112 0 1 0 0-6.224H95.465a3.132 3.132 0 0 0-3.152 3.111Zm0-13.774a3.132 3.132 0 0 0 3.152 3.112h29.774a3.112 3.112 0 1 0 0-6.224H95.465a3.132 3.132 0 0 0-3.152 3.111Zm12.192-15.368a4.008 4.008 0 0 1-4.033-3.984v-2.428a4.008 4.008 0 0 1 4.033-3.982h20.171a4.008 4.008 0 0 1 4.036 3.982v2.428a4.008 4.008 0 0 1-4.036 3.984Z" transform="translate(-81.991 -1030.009)" /><path data-name="Shape 17" d="m161.108 1103.907-5.987-5.907a17 17 0 0 0 3.176-9.9 17.485 17.485 0 1 0-17.482 17.259 17.554 17.554 0 0 0 10.029-3.135l5.985 5.91a3.052 3.052 0 0 0 4.279 0 2.961 2.961 0 0 0 0-4.227Zm-20.293-4.527a11.285 11.285 0 1 1 11.429-11.284 11.369 11.369 0 0 1-11.429 11.284Z" transform="translate(-81.991 -1030.009)" /></g><g data-name="Stroke Effect" stroke-linejoin="round" opacity=".01"><path d="m156.829 1108.13-5.985-5.909a17.558 17.558 0 0 1-10.03 3.135A17.261 17.261 0 1 1 158.3 1088.1a17 17 0 0 1-3.175 9.9l5.987 5.911a2.962 2.962 0 0 1 0 4.224 3.051 3.051 0 0 1-4.279 0Zm-27.444-20.03a11.43 11.43 0 1 0 11.43-11.285 11.369 11.369 0 0 0-11.43 11.285Zm-39.67 17.259a6.682 6.682 0 0 1-6.724-6.639v-57.087a6.682 6.682 0 0 1 6.724-6.638h4.706v2.43a10.034 10.034 0 0 0 10.085 9.958h20.171a10.035 10.035 0 0 0 10.088-9.958v-2.43h4.706a6.682 6.682 0 0 1 6.724 6.638v23.867a23.65 23.65 0 0 0-5.379-.639 23.413 23.413 0 0 0-23.532 23.235 23.036 23.036 0 0 0 7.834 17.259Zm2.6-34.809a3.132 3.132 0 0 0 3.152 3.112h17.027a3.112 3.112 0 1 0 0-6.224H95.465a3.132 3.132 0 0 0-3.152 3.108Zm0-13.774a3.132 3.132 0 0 0 3.152 3.112h29.774a3.112 3.112 0 1 0 0-6.224H95.465a3.132 3.132 0 0 0-3.152 3.108Zm12.192-15.368a4.008 4.008 0 0 1-4.033-3.984v-2.428a4.008 4.008 0 0 1 4.033-3.982h20.171a4.008 4.008 0 0 1 4.036 3.982v2.428a4.008 4.008 0 0 1-4.036 3.984Z" transform="translate(-81.991 -1030.009)" /><path d="M158.969 1109.006c.773 0 1.549-.292 2.14-.876a2.962 2.962 0 0 0 0-4.223l-5.988-5.912a16.998 16.998 0 0 0 3.176-9.899c0-9.531-7.827-17.259-17.482-17.259-9.654 0-17.484 7.728-17.484 17.26 0 9.53 7.83 17.259 17.484 17.259 3.735 0 7.186-1.167 10.03-3.135l5.984 5.91a3.036 3.036 0 0 0 2.14.875m-18.154-32.195c6.303 0 11.429 5.063 11.429 11.285s-5.126 11.284-11.43 11.284c-6.304 0-11.43-5.062-11.43-11.284s5.126-11.285 11.43-11.285m-15.698 28.545c-4.794-4.258-7.833-10.407-7.833-17.26 0-12.81 10.558-23.235 23.532-23.235 1.854 0 3.649.236 5.38.64v-23.872c0-3.666-3.012-6.638-6.725-6.638h-4.706v2.43c0 5.49-4.525 9.958-10.088 9.958h-20.17c-5.56 0-10.085-4.468-10.085-9.958v-2.43h-4.706c-3.713 0-6.724 2.972-6.724 6.638v57.087c0 3.668 3.011 6.64 6.724 6.64h35.401m-29.651-37.922h17.027c1.738 0 3.15 1.394 3.15 3.112 0 1.72-1.412 3.113-3.15 3.113H95.465c-1.742 0-3.152-1.394-3.152-3.113 0-1.718 1.41-3.112 3.152-3.112m0-13.773h29.774c1.74 0 3.152 1.394 3.152 3.111 0 1.719-1.413 3.112-3.152 3.112H95.465c-1.742 0-3.152-1.393-3.152-3.112 0-1.717 1.41-3.111 3.152-3.111m29.211-12.257c2.231 0 4.036-1.782 4.036-3.985v-2.428c0-2.199-1.805-3.982-4.036-3.982h-20.17c-2.228 0-4.034 1.783-4.034 3.982v2.428c0 2.203 1.806 3.985 4.033 3.985h20.171m34.293 68.602a4.019 4.019 0 0 1-2.842-1.164l-5.408-5.34a18.528 18.528 0 0 1-9.904 2.854c-2.493 0-4.912-.483-7.19-1.434a18.438 18.438 0 0 1-5.875-3.91 18.19 18.19 0 0 1-3.964-5.804 17.951 17.951 0 0 1-1.455-7.112c0-2.466.49-4.858 1.455-7.112a18.19 18.19 0 0 1 3.964-5.803 18.562 18.562 0 0 1 13.065-5.344c2.493 0 4.912.482 7.19 1.434 2.2.919 4.177 2.234 5.874 3.91a18.187 18.187 0 0 1 3.963 5.804 17.958 17.958 0 0 1 1.455 7.111c0 3.485-.994 6.845-2.881 9.772l5.395 5.327a3.945 3.945 0 0 1 1.182 2.826 3.94 3.94 0 0 1-1.182 2.82 4.015 4.015 0 0 1-2.842 1.165Zm-18.154-32.195c-5.751 0-10.43 4.614-10.43 10.285 0 5.67 4.679 10.284 10.43 10.284 5.75 0 10.429-4.613 10.429-10.284 0-5.67-4.678-10.285-10.43-10.285Zm-15.699 28.545H89.715c-4.26 0-7.724-3.427-7.724-7.64v-57.087c0-4.211 3.465-7.638 7.724-7.638h4.706a1 1 0 0 1 1 1v2.43c0 4.94 4.075 8.958 9.084 8.958h20.171c5.011 0 9.088-4.019 9.088-8.958v-2.43a1 1 0 0 1 1-1h4.706c4.26 0 7.724 3.427 7.724 7.638v23.871a1 1 0 0 1-1.227.974 22.77 22.77 0 0 0-5.152-.613c-12.424 0-22.532 9.975-22.532 22.235 0 6.262 2.732 12.28 7.497 16.512a1 1 0 0 1-.664 1.748Zm-29.651-37.922c-1.187 0-2.152.948-2.152 2.112 0 1.165.965 2.113 2.152 2.113h17.027c1.185 0 2.15-.948 2.15-2.113 0-1.164-.965-2.112-2.15-2.112H95.465Zm0-13.773c-1.187 0-2.152.947-2.152 2.111 0 1.165.965 2.112 2.152 2.112h29.774c1.187 0 2.152-.947 2.152-2.112 0-1.164-.965-2.111-2.152-2.111H95.465Zm29.211-12.257h-20.17c-2.776 0-5.034-2.236-5.034-4.985v-2.428c0-2.747 2.258-4.982 5.033-4.982h20.171c2.777 0 5.036 2.235 5.036 4.982v2.428c0 2.749-2.26 4.985-5.036 4.985Z" transform="translate(-81.991 -1030.009)" /></g></symbol></defs><use xlink:href="#icon-mine_personal_report_green_a" fill="#FACF20" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 40 40" id="icon-mine_profile"><defs><symbol viewBox="0 0 40 40" id="icon-mine_profile_a"><path data-name="\u8DEF\u5F84 16898" d="M-86.526-188.357a7.53 7.53 0 0 1-2.059-1.153.82.82 0 0 1-.309-.555.808.808 0 0 1 .176-.6 1.621 1.621 0 0 0 .137-1.864 1.722 1.722 0 0 0-1.478-.83 1.745 1.745 0 0 0-.25.018.837.837 0 0 1-.123.009.852.852 0 0 1-.839-.7 7.083 7.083 0 0 1 0-2.312.841.841 0 0 1 .839-.7.837.837 0 0 1 .122.008 1.785 1.785 0 0 0 .24.016 1.752 1.752 0 0 0 .859-.224 1.663 1.663 0 0 0 .821-1.125 1.629 1.629 0 0 0-.334-1.342.82.82 0 0 1-.181-.6.819.819 0 0 1 .309-.557 7.656 7.656 0 0 1 2.049-1.156.883.883 0 0 1 .307-.056.855.855 0 0 1 .8.524 1.692 1.692 0 0 0 1.579 1.04h.006a1.7 1.7 0 0 0 1.586-1.049.848.848 0 0 1 .792-.522.872.872 0 0 1 .3.053 7.528 7.528 0 0 1 2.06 1.152.816.816 0 0 1 .311.555.808.808 0 0 1-.176.6 1.609 1.609 0 0 0-.136 1.864v.008a1.716 1.716 0 0 0 1.475.832 1.779 1.779 0 0 0 .252-.018.836.836 0 0 1 .123-.009.85.85 0 0 1 .839.7 7.079 7.079 0 0 1 0 2.311.82.82 0 0 1-.341.538.858.858 0 0 1-.5.16.943.943 0 0 1-.124-.008 1.744 1.744 0 0 0-.244-.017 1.711 1.711 0 0 0-1.475.835 1.615 1.615 0 0 0 .136 1.856.813.813 0 0 1 .179.6.823.823 0 0 1-.313.559 7.608 7.608 0 0 1-2.045 1.151.883.883 0 0 1-.307.055.853.853 0 0 1-.8-.523 1.7 1.7 0 0 0-1.584-1.042 1.7 1.7 0 0 0-1.586 1.044.838.838 0 0 1-.447.452.853.853 0 0 1-.347.073.854.854 0 0 1-.299-.051Zm-.456-6.838a3.136 3.136 0 0 0 3.132 3.132 3.136 3.136 0 0 0 3.132-3.132 3.135 3.135 0 0 0-3.132-3.131 3.135 3.135 0 0 0-3.132 3.126Zm-15.572 5.725c-2.909-.847-4.447-2.062-4.447-3.517a8.2 8.2 0 0 1 4.22-7.5 14.968 14.968 0 0 1 4.579-1.687 27.6 27.6 0 0 1 5.608-.527c.877 0 1.74.037 2.565.11a9.562 9.562 0 0 0-3.742 7.617 9.579 9.579 0 0 0 2.656 6.638c-.55.018-1.1.026-1.627.026a36.786 36.786 0 0 1-9.811-1.16Zm5.18-17.233a7.154 7.154 0 0 1-2.11-5.093 7.155 7.155 0 0 1 2.11-5.093A7.154 7.154 0 0 1-92.28-219a7.155 7.155 0 0 1 5.093 2.11 7.155 7.155 0 0 1 2.11 5.093 7.154 7.154 0 0 1-2.11 5.093 7.155 7.155 0 0 1-5.093 2.11 7.154 7.154 0 0 1-5.094-2.106Z" transform="translate(111.667 223.651)" /></symbol></defs><use xlink:href="#icon-mine_profile_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 40 40" id="icon-mine_service_setting"><defs><symbol viewBox="0 0 40 40" id="icon-mine_service_setting_a"><g data-name="1"><path data-name="\u8DEF\u5F84 16896" d="m843.8-759.441-.2-1.259-.066-.066-1.193.464a1.976 1.976 0 0 1-2.455-.856l-1.593-2.72a2.02 2.02 0 0 1 .464-2.521l1.069-.8v-.141l-.994-.8a1.884 1.884 0 0 1-.464-2.521l1.593-2.72a1.944 1.944 0 0 1 2.389-.856l1.259.464.067-.067.2-1.328a1.924 1.924 0 0 1 1.925-1.657h3.184a1.888 1.888 0 0 1 1.924 1.723l.2 1.262.066.067 1.193-.464a1.976 1.976 0 0 1 2.455.856l1.593 2.72a2.021 2.021 0 0 1-.464 2.521l-1.069.8v.133l1.069.8a2.038 2.038 0 0 1 .53 2.521l-1.593 2.78a2.081 2.081 0 0 1-2.455.855l-1.259-.464-.066.067-.2 1.325a2.067 2.067 0 0 1-1.991 1.593l-.008.015h-3.225a1.892 1.892 0 0 1-1.885-1.726Zm.536-3.641a5.986 5.986 0 0 0 .856.53l.6.265.34 2.117h2.322l.332-2.189.6-.265a5.985 5.985 0 0 0 .855-.53l.53-.4 2.057.8 1.2-2.057-1.726-1.325.066-.663v-1l-.066-.663 1.726-1.328-1.2-2.055-2.057.8-.53-.4a5.98 5.98 0 0 0-.855-.53l-.6-.268-.332-2.187h-2.334l-.331 2.187-.6.268a2.992 2.992 0 0 0-.856.53l-.53.4-2.057-.8-1.193 2.055 1.726 1.328-.066.663v1.069l.066.663-1.726 1.325 1.193 2.057 2.057-.8Zm8.3-9.163c-.007.066.064.066-.007-.001Zm-16.724 8.531H825.87a3.845 3.845 0 0 1-2.737-1.134 3.9 3.9 0 0 1-1.133-2.747v-17.257a3.855 3.855 0 0 1 1.135-2.746 3.857 3.857 0 0 1 2.741-1.135h25.582a3.854 3.854 0 0 1 2.74 1.135 3.854 3.854 0 0 1 1.135 2.746v8.606a11.98 11.98 0 0 0-3.119-2v-.5h-1.357a12.02 12.02 0 0 0-3.486-.514 12.023 12.023 0 0 0-3.486.514h-18.766v11.3a.773.773 0 0 0 .761.761l9.5-.093a11.991 11.991 0 0 0 .524 3.073Zm-10.016-21.829a.766.766 0 0 0-.762.761v2.9h27.079v-2.9a.775.775 0 0 0-.762-.761h-25.562Zm19.177 18.208a2.256 2.256 0 0 1 2.256-2.256 2.256 2.256 0 0 1 2.256 2.256 2.279 2.279 0 0 1-2.256 2.256 2.256 2.256 0 0 1-2.263-2.257Zm-16.225-5.581a1.4 1.4 0 0 1-.55-.118 1.434 1.434 0 0 1-.762-.8 1.412 1.412 0 0 1-.095-.552 1.493 1.493 0 0 1 1.471-1.471h4.625a1.474 1.474 0 0 1 .548.106 1.462 1.462 0 0 1 .479.319 1.411 1.411 0 0 1 .317.48 1.445 1.445 0 0 1 .106.567 1.493 1.493 0 0 1-1.475 1.467Z" transform="translate(-819.333 794.065)" /></g></symbol></defs><use xlink:href="#icon-mine_service_setting_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-mine_service_setting_green"><defs><symbol viewBox="0 0 99.999 70" id="icon-mine_service_setting_green_a"><g data-name="icon_wd_txgl"><path data-name="Shape 19" d="M10.479 62.171A10.492 10.492 0 0 1 0 51.668V24.637h64.922a26.6 26.6 0 0 0-9.639 37.533ZM7.543 34.447a3.633 3.633 0 0 0 3.631 3.635h10.372a3.635 3.635 0 0 0 0-7.271H11.174a3.634 3.634 0 0 0-3.631 3.636ZM0 17.368V10.5A10.491 10.491 0 0 1 10.479 0h63.632a10.49 10.49 0 0 1 10.48 10.5v6.867Z" transform="translate(1 1)" /><path data-name="Shape 19" d="m698.32 1088.092-3.734-2.926a15.325 15.325 0 0 0 .089-1.537 14.974 14.974 0 0 0-.089-1.537l3.74-2.927a1.838 1.838 0 0 0 .44-2.337l-3.883-6.733a1.8 1.8 0 0 0-2.246-.808l-4.409 1.772a15.176 15.176 0 0 0-2.648-1.539l-.672-4.682a1.8 1.8 0 0 0-1.793-1.56h-7.792a1.8 1.8 0 0 0-1.791 1.546l-.671 4.7a15.512 15.512 0 0 0-2.643 1.538l-4.417-1.778a1.835 1.835 0 0 0-2.231.8l-3.89 6.741a1.829 1.829 0 0 0 .441 2.349l3.736 2.924a13.541 13.541 0 0 0 0 3.072l-3.74 2.928a1.833 1.833 0 0 0-.439 2.337l3.883 6.732a1.8 1.8 0 0 0 2.249.81l4.4-1.772a15.3 15.3 0 0 0 2.646 1.538l.671 4.681a1.8 1.8 0 0 0 1.8 1.564h7.788a1.8 1.8 0 0 0 1.793-1.547l.674-4.7a15.551 15.551 0 0 0 2.639-1.541l4.421 1.778a1.829 1.829 0 0 0 .666.126 1.787 1.787 0 0 0 1.565-.919l3.9-6.769a1.832 1.832 0 0 0-.453-2.324Zm-19.1 5.708a10.168 10.168 0 1 1 10.152-10.169 10.158 10.158 0 0 1-10.154 10.169Z" transform="translate(-600.006 -1034.986)" /></g><g data-name="Stroke Effect" stroke-linejoin="round" opacity=".01"><path d="M74.324 68a1.8 1.8 0 0 1-1.8-1.565l-.671-4.683a15.29 15.29 0 0 1-2.646-1.539l-4.4 1.773a1.8 1.8 0 0 1-2.249-.809l-3.882-6.734a1.835 1.835 0 0 1 .439-2.338l3.739-2.929a13.568 13.568 0 0 1 0-3.073l-3.736-2.925a1.83 1.83 0 0 1-.441-2.351l3.889-6.743a1.835 1.835 0 0 1 2.231-.8l4.417 1.779a15.562 15.562 0 0 1 2.642-1.539l.671-4.7a1.8 1.8 0 0 1 1.793-1.544h7.791a1.8 1.8 0 0 1 1.789 1.56l.671 4.684a15.1 15.1 0 0 1 2.648 1.54l4.409-1.773a1.8 1.8 0 0 1 2.246.808l3.882 6.735a1.839 1.839 0 0 1-.439 2.338L93.581 46.1a15.178 15.178 0 0 1 .089 1.538c0 .558-.044 1.086-.089 1.537l3.733 2.925a1.833 1.833 0 0 1 .454 2.324l-3.9 6.771a1.785 1.785 0 0 1-1.565.919 1.824 1.824 0 0 1-.665-.125l-4.421-1.779a15.57 15.57 0 0 1-2.638 1.54l-.675 4.7A1.8 1.8 0 0 1 82.111 68Zm-6.259-20.361a10.15 10.15 0 1 0 10.148-10.17 10.16 10.16 0 0 0-10.148 10.17Zm-57.586 14.53A10.492 10.492 0 0 1 0 51.666V24.637h64.923a26.6 26.6 0 0 0-9.639 37.532ZM7.543 34.446a3.633 3.633 0 0 0 3.631 3.634h10.372a3.635 3.635 0 0 0 0-7.271H11.174a3.634 3.634 0 0 0-3.631 3.637ZM0 17.368V10.5A10.491 10.491 0 0 1 10.479 0h63.633a10.49 10.49 0 0 1 10.481 10.5v6.867Z" transform="translate(1 1)" /><path d="M82.111 68c.914 0 1.684-.672 1.792-1.547l.675-4.7a15.57 15.57 0 0 0 2.638-1.541l4.421 1.779c.214.083.435.125.665.125.656 0 1.26-.36 1.565-.92l3.901-6.77a1.833 1.833 0 0 0-.454-2.325l-3.733-2.927c.045-.45.089-.978.089-1.536s-.043-1.087-.09-1.538l3.74-2.928c.691-.55.883-1.526.44-2.338L93.876 34.1c-.417-.76-1.325-1.151-2.246-.809l-4.409 1.773a15.104 15.104 0 0 0-2.647-1.54l-.672-4.684c-.108-.888-.88-1.56-1.792-1.56H74.32c-.912 0-1.681.672-1.792 1.546l-.671 4.702c-.888.4-1.758.909-2.642 1.54l-4.417-1.78c-.829-.321-1.817.04-2.231.796l-3.89 6.743a1.83 1.83 0 0 0 .441 2.35l3.736 2.926a14.78 14.78 0 0 0-.087 1.536c0 .468.028.964.087 1.537l-3.74 2.929c-.693.552-.883 1.526-.438 2.338l3.882 6.734c.417.758 1.314 1.153 2.249.81l4.404-1.773a15.29 15.29 0 0 0 2.646 1.538l.671 4.683c.11.893.88 1.565 1.796 1.565h7.787m-3.898-30.532c5.608 0 10.151 4.554 10.151 10.17 0 5.618-4.543 10.173-10.151 10.173-5.606 0-10.148-4.555-10.148-10.172 0-5.617 4.542-10.17 10.148-10.17m-22.93 24.7c-2.598-4.117-4.127-8.975-4.127-14.196 0-10.036 5.569-18.788 13.767-23.336H0v27.03c0 5.8 4.692 10.502 10.479 10.502h44.805m-44.11-31.36h10.372a3.63 3.63 0 0 1 3.625 3.637 3.63 3.63 0 0 1-3.625 3.634H11.174a3.633 3.633 0 0 1-3.63-3.634 3.634 3.634 0 0 1 3.63-3.636m73.419-13.442v-6.867C84.593 4.702 79.903 0 74.112 0H10.479C4.692 0 0 4.702 0 10.5v6.868h84.593M82.11 69h-7.787c-1.414 0-2.61-1.045-2.787-2.431l-.594-4.143a16.367 16.367 0 0 1-1.86-1.083l-3.903 1.57a2.971 2.971 0 0 1-1.056.198 2.79 2.79 0 0 1-2.437-1.442l-3.878-6.727a.988.988 0 0 1-.01-.019c-.674-1.23-.382-2.745.694-3.6l.005-.005 3.312-2.594a14.522 14.522 0 0 1-.043-1.085c0-.343.014-.7.043-1.084l-3.308-2.59-.007-.005a2.835 2.835 0 0 1-.682-3.636l3.883-6.731c.478-.865 1.444-1.422 2.465-1.422a2.75 2.75 0 0 1 1.01.19l3.918 1.577a16.452 16.452 0 0 1 1.854-1.084l.594-4.163c.179-1.375 1.374-2.411 2.783-2.411h7.791c1.415 0 2.61 1.043 2.784 2.428l.593 4.142c.636.314 1.259.677 1.863 1.084l3.907-1.57.025-.01a2.94 2.94 0 0 1 1.026-.188 2.79 2.79 0 0 1 2.44 1.442l3.877 6.727a.943.943 0 0 1 .01.02c.673 1.23.381 2.743-.692 3.6a.952.952 0 0 1-.007.005l-3.311 2.592c.025.327.044.696.044 1.086 0 .385-.019.75-.045 1.085l3.306 2.591.006.005a2.835 2.835 0 0 1 .698 3.606l-3.896 6.761a2.773 2.773 0 0 1-2.437 1.43 2.833 2.833 0 0 1-1.038-.198l-3.921-1.577c-.619.416-1.23.774-1.851 1.084l-.598 4.161C84.72 67.963 83.524 69 82.111 69Zm-3.898-30.532c-5.044 0-9.148 4.114-9.148 9.17 0 5.058 4.104 9.173 9.148 9.173 5.046 0 9.151-4.115 9.151-9.172s-4.105-9.17-9.151-9.17Zm-22.93 24.7H10.48C4.149 63.169-1 58.009-1 51.667v-27.03a1 1 0 0 1 1-1h64.923a1 1 0 0 1 .485 1.875c-8.174 4.535-13.252 13.142-13.252 22.462a25.57 25.57 0 0 0 3.974 13.662 1 1 0 0 1-.846 1.534ZM11.175 31.81a2.636 2.636 0 0 0 0 5.27h10.372a2.633 2.633 0 0 0 2.625-2.634 2.634 2.634 0 0 0-2.625-2.636H11.174Zm73.419-13.442H0a1 1 0 0 1-1-1v-6.867C-1 4.159 4.15-1 10.479-1h63.633c3.068 0 5.951 1.197 8.12 3.37a11.436 11.436 0 0 1 3.36 8.13v6.868a1 1 0 0 1-1 1Z" transform="translate(1 1)" /></g></symbol></defs><use xlink:href="#icon-mine_service_setting_green_a" fill="#FACF20" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 40 40" id="icon-mine_support"><defs><symbol viewBox="0 0 40 40" id="icon-mine_support_a"><path d="M16.151 30.015a2.721 2.721 0 0 1-2.469-1.515h-2.4a4.541 4.541 0 0 1-4.643-4.421v-.735H6.2a1.365 1.365 0 0 1-1.4-1.329V11.878c0-.016.011-.027.019-.04A12.419 12.419 0 0 1 17.328 0a12.419 12.419 0 0 1 12.514 11.836.08.08 0 0 1 .019.042v10.131a1.363 1.363 0 0 1-1.4 1.329H23.9a1.363 1.363 0 0 1-1.395-1.329v-8.89a1.363 1.363 0 0 1 1.395-1.33h2.578a9.165 9.165 0 0 0-18.3 0h2.578a1.363 1.363 0 0 1 1.4 1.329v8.89a1.363 1.363 0 0 1-1.4 1.329H8.879v.74a2.354 2.354 0 0 0 2.406 2.291h2.382a2.728 2.728 0 0 1 2.485-1.541h2.364a2.595 2.595 0 1 1 0 5.186Zm15.488-9.423v-6.058a.508.508 0 0 1 .6-.493 2.923 2.923 0 0 1 2.426 2.826v1.391a2.923 2.923 0 0 1-2.426 2.826.5.5 0 0 1-.1.009.51.51 0 0 1-.506-.5Zm-29.215.493A2.923 2.923 0 0 1 0 18.259v-1.39a2.923 2.923 0 0 1 2.426-2.827.508.508 0 0 1 .6.493v6.058a.506.506 0 0 1-.6.493Z" transform="translate(2.667 4.992)" /></symbol></defs><use xlink:href="#icon-mine_support_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 40 40" id="icon-mine_wallet"><defs><symbol viewBox="0 0 40 40" id="icon-mine_wallet_a"><path data-name="\u8DEF\u5F84 16934" d="m-1186.158 7208.472-5.187-5.2a16.939 16.939 0 0 1-10.649 3.746 17.007 17.007 0 0 1-17.006-17.011 17.008 17.008 0 0 1 17.006-17.007 17.008 17.008 0 0 1 17.007 17.008 16.937 16.937 0 0 1-3.744 10.646l5.191 5.209a1.849 1.849 0 0 1-.005 2.615 1.841 1.841 0 0 1-1.3.539 1.84 1.84 0 0 1-1.313-.545Zm-25.242-27.872a13.222 13.222 0 0 0-3.9 9.412 13.223 13.223 0 0 0 3.9 9.411 13.219 13.219 0 0 0 9.41 3.9 13.224 13.224 0 0 0 9.412-3.9 13.223 13.223 0 0 0 3.9-9.411 13.222 13.222 0 0 0-3.9-9.412 13.222 13.222 0 0 0-9.412-3.9 13.217 13.217 0 0 0-9.41 3.9Zm4.243 15.323c-1.387-.555-2.176-1.294-2.222-2.086v-1.6a6.509 6.509 0 0 0 1.725 1 15.451 15.451 0 0 0 5.67.972 15.453 15.453 0 0 0 5.669-.972 6.525 6.525 0 0 0 1.723-1v1.601c-.048.792-.839 1.533-2.226 2.086a14.4 14.4 0 0 1-5.166.86 14.406 14.406 0 0 1-5.177-.866Zm0-3.748c-1.387-.555-2.176-1.294-2.222-2.085v-1.6a6.5 6.5 0 0 0 1.725 1 15.462 15.462 0 0 0 5.67.972 15.463 15.463 0 0 0 5.669-.972 6.512 6.512 0 0 0 1.723-1V7190.094c-.048.791-.839 1.532-2.226 2.085a14.4 14.4 0 0 1-5.166.86 14.406 14.406 0 0 1-5.177-.869Zm-2.226-5.915c0-1.669 3.312-3.021 7.395-3.021s7.392 1.352 7.392 3.021-3.31 3.022-7.392 3.022-7.399-1.357-7.399-3.027Z" transform="translate(1220 -7171.008)" /></symbol></defs><use xlink:href="#icon-mine_wallet_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-mix_icon"><defs><symbol viewBox="0 0 100 76" id="icon-mix_icon_a"><path data-name="icon_dtfl_zh_0" d="M4.745 56.926A4.745 4.745 0 0 1 0 52.181V36.307a4.745 4.745 0 0 1 4.745-4.745h15.867a4.745 4.745 0 0 1 4.745 4.745v15.874a4.745 4.745 0 0 1-4.745 4.745Zm40.555-.264s0 .017-5.156-.041a18.975 18.975 0 0 0 5.218-7.907 18.957 18.957 0 0 0 5.1 7.982c-5.158 0-5.158-.03-5.158-.03Zm5.23-6.362a10.157 10.157 0 0 1-5.115-5.2v.039a10.166 10.166 0 0 1-5.2 5.126 7.173 7.173 0 0 1-8.68-7.618c.195-5.912 7.421-8.436 14.009-15.99C52.016 34.3 59.206 36.938 59.3 42.831a7.333 7.333 0 0 1-7.115 7.732 5.164 5.164 0 0 1-1.668-.261ZM36.688 25.361a4.745 4.745 0 0 1-4.743-4.743V4.745A4.745 4.745 0 0 1 36.688 0h15.865A4.745 4.745 0 0 1 57.3 4.745v15.874a4.745 4.745 0 0 1-4.745 4.745Zm-31.945 0A4.745 4.745 0 0 1 0 20.619V4.745A4.745 4.745 0 0 1 4.745 0h15.867a4.745 4.745 0 0 1 4.745 4.745v15.874a4.745 4.745 0 0 1-4.745 4.745Z" transform="translate(20 10)" stroke-miterlimit="10" /></symbol></defs><use xlink:href="#icon-mix_icon_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-mix_icon_active"><defs><symbol viewBox="0 0 27.703 26.587" id="icon-mix_icon_active_a"><path d="M2.216 26.587A2.216 2.216 0 0 1 0 24.371v-7.414a2.216 2.216 0 0 1 2.216-2.216h7.411a2.216 2.216 0 0 1 2.216 2.216v7.414a2.216 2.216 0 0 1-2.216 2.216Zm18.943-.123s0 .008-2.408-.019a8.862 8.862 0 0 0 2.437-3.693 8.854 8.854 0 0 0 2.381 3.728c-2.409 0-2.409-.014-2.409-.014Zm2.441-2.971a4.744 4.744 0 0 1-2.389-2.427v.018a4.748 4.748 0 0 1-2.427 2.394 3.35 3.35 0 0 1-4.054-3.558c.091-2.761 3.466-3.94 6.543-7.468 3.021 3.567 6.379 4.8 6.425 7.552a3.425 3.425 0 0 1-3.323 3.611 2.412 2.412 0 0 1-.779-.122Zm-6.465-11.648A2.216 2.216 0 0 1 14.92 9.63V2.216A2.216 2.216 0 0 1 17.135 0h7.41a2.216 2.216 0 0 1 2.216 2.216V9.63a2.216 2.216 0 0 1-2.216 2.216Zm-14.92 0A2.216 2.216 0 0 1 0 9.63V2.216A2.216 2.216 0 0 1 2.216 0h7.411a2.216 2.216 0 0 1 2.216 2.216V9.63a2.216 2.216 0 0 1-2.216 2.216Z" /></symbol></defs><use xlink:href="#icon-mix_icon_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-mix_icon_green"><defs><symbol viewBox="0 0 27.703 26.587" id="icon-mix_icon_green_a"><path d="M2.216 26.587A2.216 2.216 0 0 1 0 24.371v-7.414a2.216 2.216 0 0 1 2.216-2.216h7.411a2.216 2.216 0 0 1 2.216 2.216v7.414a2.216 2.216 0 0 1-2.216 2.216Zm18.943-.123s0 .008-2.408-.019a8.862 8.862 0 0 0 2.437-3.693 8.854 8.854 0 0 0 2.381 3.728c-2.409 0-2.409-.014-2.409-.014Zm2.441-2.971a4.744 4.744 0 0 1-2.389-2.427v.018a4.748 4.748 0 0 1-2.427 2.394 3.35 3.35 0 0 1-4.054-3.558c.091-2.761 3.466-3.94 6.543-7.468 3.021 3.567 6.379 4.8 6.425 7.552a3.425 3.425 0 0 1-3.323 3.611 2.412 2.412 0 0 1-.779-.122Zm-6.465-11.648A2.216 2.216 0 0 1 14.92 9.63V2.216A2.216 2.216 0 0 1 17.135 0h7.41a2.216 2.216 0 0 1 2.216 2.216V9.63a2.216 2.216 0 0 1-2.216 2.216Zm-14.92 0A2.216 2.216 0 0 1 0 9.63V2.216A2.216 2.216 0 0 1 2.216 0h7.411a2.216 2.216 0 0 1 2.216 2.216V9.63a2.216 2.216 0 0 1-2.216 2.216Z" /></symbol></defs><use xlink:href="#icon-mix_icon_green_a" fill="#333" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_cycle"><defs><symbol viewBox="0 0 51 50.092" id="icon-music_cycle_a"><path data-name="Union 23" d="M15 51.277 3.015 44.384a2 2 0 0 1 0-3.468L15 34.024a2 2 0 0 1 3 1.733V40h26a3 3 0 0 0 3-3v-7a3 3 0 1 1 6 0v7a9.01 9.01 0 0 1-9 9H18v3.543a2 2 0 0 1-3 1.733ZM2 23v-7a9.01 9.01 0 0 1 9-9h26v6H11a3 3 0 0 0-3 3v7a3 3 0 1 1-6 0Zm35-5.756V3.457a2 2 0 0 1 3-1.733l11.985 6.893a2 2 0 0 1 0 3.467L40 18.976a2 2 0 0 1-3-1.733Z" transform="translate(-2 -1.454)" /></symbol></defs><use xlink:href="#icon-music_cycle_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_delete"><defs><symbol viewBox="0 0 21.351 24" id="icon-music_delete_a"><path data-name="Path 503" d="M1966.49 59.525c.1-.085.12-.114.141-.116 1.694-.211 1.694-.21 1.694 1.456v11.46c0 2.576-1.283 3.844-3.877 3.844-3.343 0-6.685.007-10.028 0a3.29 3.29 0 0 1-3.528-3.463c-.025-4.3-.007-8.6-.006-12.893 0-.1.019-.207.035-.376h1.8v12.95c0 1.486.47 1.954 1.952 1.955h10.027c1.277 0 1.787-.492 1.789-1.77q.011-6.128 0-12.256Z" transform="translate(-1948.928 -52.171)" /><path data-name="Path 504" d="M1962.479 44.734h3.736c.623 0 1.234.078 1.22.89-.012.767-.567.919-1.217.918q-9.5-.005-19 0c-.632 0-1.139-.163-1.137-.9s.5-.917 1.135-.914h3.791c.019-.313.033-.567.05-.821a2.086 2.086 0 0 1 2.251-2.146c2.279-.016 4.558-.007 6.837 0a2.084 2.084 0 0 1 2.331 2.291c.008.184.003.367.003.682Zm-9.559-.065h7.689c.149-1.093.123-1.127-.851-1.128h-5.959c-.988 0-.988.002-.879 1.128Z" transform="translate(-1946.084 -41.758)" /><path data-name="Path 505" d="M1964.983 67.255v-4.456c0-.552.143-1.01.74-1.162.641-.164 1.084.264 1.092 1.088.015 1.644.005 3.289.005 4.933 0 1.379.009 2.758 0 4.138-.007.786-.369 1.225-.969 1.185-.743-.05-.86-.587-.861-1.19q-.008-2.268-.007-4.536Z" transform="translate(-1957.294 -53.53)" /><path data-name="Path 506" d="M1977.18 67.343v4.453c0 .8-.333 1.236-.932 1.2-.745-.039-.857-.56-.856-1.176.007-3 0-5.99 0-8.985 0-.81.325-1.232.929-1.2.746.038.864.553.859 1.172-.007 1.514 0 3.025 0 4.536Z" transform="translate(-1963.469 -53.55)" /></symbol></defs><use xlink:href="#icon-music_delete_a" fill="#EA4E3D" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_disabled_delete"><defs><symbol viewBox="0 0 21.351 24" id="icon-music_disabled_delete_a"><path data-name="Path 503" d="M1966.49 59.525c.1-.085.12-.114.141-.116 1.694-.211 1.694-.21 1.694 1.456v11.46c0 2.576-1.283 3.844-3.877 3.844-3.343 0-6.685.007-10.028 0a3.29 3.29 0 0 1-3.528-3.463c-.025-4.3-.007-8.6-.006-12.893 0-.1.019-.207.035-.376h1.8v12.95c0 1.486.47 1.954 1.952 1.955h10.027c1.277 0 1.787-.492 1.789-1.77q.011-6.128 0-12.256Z" transform="translate(-1948.928 -52.171)" /><path data-name="Path 504" d="M1962.479 44.734h3.736c.623 0 1.234.078 1.22.89-.012.767-.567.919-1.217.918q-9.5-.005-19 0c-.632 0-1.139-.163-1.137-.9s.5-.917 1.135-.914h3.791c.019-.313.033-.567.05-.821a2.086 2.086 0 0 1 2.251-2.146c2.279-.016 4.558-.007 6.837 0a2.084 2.084 0 0 1 2.331 2.291c.008.184.003.367.003.682Zm-9.559-.065h7.689c.149-1.093.123-1.127-.851-1.128h-5.959c-.988 0-.988.002-.879 1.128Z" transform="translate(-1946.084 -41.758)" /><path data-name="Path 505" d="M1964.983 67.255v-4.456c0-.552.143-1.01.74-1.162.641-.164 1.084.264 1.092 1.088.015 1.644.005 3.289.005 4.933 0 1.379.009 2.758 0 4.138-.007.786-.369 1.225-.969 1.185-.743-.05-.86-.587-.861-1.19q-.008-2.268-.007-4.536Z" transform="translate(-1957.294 -53.53)" /><path data-name="Path 506" d="M1977.18 67.343v4.453c0 .8-.333 1.236-.932 1.2-.745-.039-.857-.56-.856-1.176.007-3 0-5.99 0-8.985 0-.81.325-1.232.929-1.2.746.038.864.553.859 1.172-.007 1.514 0 3.025 0 4.536Z" transform="translate(-1963.469 -53.55)" /></symbol></defs><use xlink:href="#icon-music_disabled_delete_a" fill="var(--theme-text-color-lighten)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_download"><defs><symbol viewBox="0 0 12.748 15" id="icon-music_download_a"><path data-name="Path 510" d="m2516.976-1372.709 2.316 2.413a.4.4 0 0 0 .573 0l2.315-2.413 1.958-2.04a.4.4 0 0 0-.286-.672h-3.371v-5.481a.9.9 0 0 0-.9-.9.9.9 0 0 0-.9.9v5.481h-3.381a.4.4 0 0 0-.286.672Z" transform="translate(-2513.204 1381.804)" /><path data-name="Path 511" d="M2520.95-1338.054h-10.775a.986.986 0 0 0-.986.986.986.986 0 0 0 .986.986h10.775a.986.986 0 0 0 .986-.986.986.986 0 0 0-.986-.986Z" transform="translate(-2509.188 1351.081)" /></symbol></defs><use xlink:href="#icon-music_download_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_list"><defs><symbol viewBox="0 0 53.999 43.199" id="icon-music_list_a"><path data-name="Color Overlay" d="M29.454 33.381a9.818 9.818 0 0 1 14.719-8.505V5.9A5.891 5.891 0 0 1 50.064.008h1.293Q51.446 0 51.545 0a2.455 2.455 0 1 1 0 4.909h-.1v.067a2.945 2.945 0 0 0-2.362 2.886V32.4h-.04q.048.484.049.982a9.818 9.818 0 1 1-19.636 0Zm4.909 0a4.909 4.909 0 1 0 4.909-4.909 4.909 4.909 0 0 0-4.909 4.909ZM2.945 38.447a2.945 2.945 0 1 1 0-5.891h17.732a2.945 2.945 0 1 1 0 5.891Zm0-12.891a2.945 2.945 0 1 1 0-5.891h21.6a2.945 2.945 0 0 1 0 5.891Zm0-12.881a2.945 2.945 0 1 1 0-5.891h32.4a2.945 2.945 0 0 1 0 5.891Z" /></symbol></defs><use xlink:href="#icon-music_list_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_logo"><defs><symbol viewBox="0 0 15.5 18" id="icon-music_logo_a"><path d="M-4207 15.25a2.75 2.75 0 0 1 2.75-2.75 2.737 2.737 0 0 1 1.25.3V1.485L-4191.5 0v4.646l-.005 7.9c0 .066.007.133.007.2a2.75 2.75 0 0 1-2.75 2.75 2.75 2.75 0 0 1-2.75-2.75 2.75 2.75 0 0 1 2.75-2.75 2.738 2.738 0 0 1 1.25.3v-5.45l-8.5 1.133V15.249a2.75 2.75 0 0 1-2.75 2.75A2.75 2.75 0 0 1-4207 15.25Z" transform="translate(4207)" /></symbol></defs><use xlink:href="#icon-music_logo_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 20 17.595" id="icon-music_mute"><defs><symbol viewBox="0 0 32 28.152" id="icon-music_mute_a"><path data-name="Op component 1" d="m4428.977 3735.1-2.257-1.367-.005.008c-.582.774.534 2.325 1.936 1.649.112-.1.223-.2.327-.29Zm0 0" transform="translate(-4404.581 -3714.563)" /><path data-name="Op component 2" d="m4413.664 3721.878-27.992-24.932a1.136 1.136 0 0 0-1.508 1.7l27.992 24.935a1.136 1.136 0 0 0 1.508-1.7Zm-5.261-18.737a10.839 10.839 0 0 1 1.4 13.947l2.42 2.156a14.1 14.1 0 0 0-1.415-18.042.262.262 0 0 1-.091-.284v-.008a1.673 1.673 0 0 0-2.31 0 1.563 1.563 0 0 0 0 2.232Zm0 0" transform="translate(-4382.831 -3695.709)" /><path data-name="Op component 3" d="m4410.587 3719.033-2.432-2.166c-.167.2-.3.421-.48.614-.1.1-.195.2-.293.292a1.551 1.551 0 0 0-.457 1.04l1.816 1.616a1.639 1.639 0 0 0 .95-.422c.32-.314.617-.642.9-.975Zm-10.565-9.414-9.9-8.813-.515.374h-2.479l12.889 11.481Zm5.067 5.916a8.268 8.268 0 0 0 .682-.8l-2.4-2.137a4.706 4.706 0 0 1-.478.6c-.033.036-.061.062-.095.1a1.506 1.506 0 0 0-.418 1.458l1.342 1.2a1.618 1.618 0 0 0 1.367-.422Zm-19.468-14.355h-1.221a2.541 2.541 0 0 0-2.593 2.488v10.178a2.564 2.564 0 0 0 2.593 2.506h5.207l8.342 6.072c1.146.845 2.068.38 2.068-1.006v-7.411Zm14.4 7.094v-12.146c0-1.385-.923-1.855-2.066-1.016l-7 5.088Zm2.774-1.677a4.681 4.681 0 0 1 1.071 5.1l2.48 2.211a7.694 7.694 0 0 0-1-9.305 1.686 1.686 0 0 0-.26-.233v-.009a1.653 1.653 0 0 0-2.293 0 1.531 1.531 0 0 0-.064 2.169Zm0 0" transform="translate(-4381.811 -3694.694)" /></symbol></defs><use xlink:href="#icon-music_mute_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_next"><defs><symbol viewBox="0 0 33.9 33" id="icon-music_next_a"><path data-name="comm_nav_xys" d="M28.076 32.412 6.6 18.95V29.7a3.3 3.3 0 1 1-6.6 0V3.3a3.3 3.3 0 1 1 6.6 0v10.61L27.966.814a3.925 3.925 0 0 1 5.23.8 3.335 3.335 0 0 1 .7 2.034V29.5a3.627 3.627 0 0 1-3.744 3.5 3.93 3.93 0 0 1-2.076-.588Z" transform="rotate(180 16.95 16.5)" /></symbol></defs><use xlink:href="#icon-music_next_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_notice"><defs><symbol viewBox="0 0 32 25.679" id="icon-music_notice_a"><path data-name="Op component 1" d="M4404.9 3548.991a1.7 1.7 0 0 0-2.242.16 1.934 1.934 0 0 0-.16 2.24 5.032 5.032 0 0 1 0 7.362 1.7 1.7 0 0 0 2.4 2.4 8.743 8.743 0 0 0 2.562-6.082 8.1 8.1 0 0 0-2.562-6.081Zm-8.325-6.4-7.525 5.6h-4.8a1.859 1.859 0 0 0-1.6.64 2.847 2.847 0 0 0-.64 1.6v9.283a2.325 2.325 0 0 0 2.4 2.24h4.8l7.525 5.6c1.12.8 1.921.32 1.921-.96v-23.047c-.16-1.28-.961-1.6-2.081-.96Zm0 0" transform="translate(-4382.006 -3542.268)" /><path data-name="Op component 2" d="M4433.974 3546a1.946 1.946 0 0 0-2.562 0 1.6 1.6 0 0 0 0 2.4 11.78 11.78 0 0 1 3.682 8.322 11.328 11.328 0 0 1-3.842 8.322 1.74 1.74 0 0 0 0 2.4 1.948 1.948 0 0 0 2.562 0 14.254 14.254 0 0 0 .16-21.446Zm0 0" transform="translate(-4406.756 -3543.918)" /></symbol></defs><use xlink:href="#icon-music_notice_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_pause"><defs><symbol viewBox="0 0 47.999 68.999" id="icon-music_pause_a"><path d="M36 69a6 6 0 0 1-6-6V6a6 6 0 0 1 6-6h6a6 6 0 0 1 6 6v57a6 6 0 0 1-6 6ZM6 69a6 6 0 0 1-6-6V6a6 6 0 0 1 6-6h6a6 6 0 0 1 6 6v57a6 6 0 0 1-6 6Z" transform="translate(0 -.001)" /></symbol></defs><use xlink:href="#icon-music_pause_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_pre"><defs><symbol viewBox="0 0 33.9 33" id="icon-music_pre_a"><path d="M28.076.588 6.6 14.05V3.3a3.3 3.3 0 1 0-6.6 0v26.4a3.3 3.3 0 1 0 6.6 0V19.09l21.366 13.1a3.925 3.925 0 0 0 5.23-.8 3.335 3.335 0 0 0 .7-2.034V3.5A3.627 3.627 0 0 0 30.152 0a3.93 3.93 0 0 0-2.076.588Z" /></symbol></defs><use xlink:href="#icon-music_pre_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_random"><defs><symbol viewBox="0 0 50.673 44.334" id="icon-music_random_a"><path data-name="comm_icon_sj" d="M1985.687 2675.964c-2.6 0-9.086 6.433-13.824 10.993-7.183 6.915-13.968 13.637-19.4 13.637h-3.341a2.464 2.464 0 1 1 0-4.927h3.341c3.431 0 10.378-6.878 15.961-12.251 6.793-6.54 12.661-12.378 17.262-12.378h3.185l-3.379-3.269a2.345 2.345 0 0 1 0-3.384 2.481 2.481 0 0 1 3.5-.007l7.612 7.567a2.452 2.452 0 0 1 0 3.48l-7.612 7.562a2.458 2.458 0 0 1-3.5-.039 2.509 2.509 0 0 1 0-3.527l3.383-3.456Zm3.3 12.669a2.479 2.479 0 0 0-3.492 0 2.568 2.568 0 0 0 0 3.576l3.383 3.455h-3.189c-2.027 0-5.421-2.991-8.783-6.124a2.476 2.476 0 0 0-3.491.068 2.541 2.541 0 0 0 .116 3.551c5.121 4.774 8.578 7.432 12.159 7.432h3.189l-3.379 3.265a2.4 2.4 0 0 0 0 3.431 2.48 2.48 0 0 0 3.492-.03l7.613-7.571a2.464 2.464 0 0 0 0-3.489Zm-39.859-12.669h3.341c2.605 0 6.486 3.3 9.578 6.1a2.522 2.522 0 0 0 1.662.687 2.438 2.438 0 0 0 1.83-.782 2.553 2.553 0 0 0-.171-3.564c-4.83-4.369-8.875-7.367-12.9-7.367h-3.338a2.463 2.463 0 1 0 0 4.927Zm0 0" transform="translate(-1946.651 -2663.66)" /></symbol></defs><use xlink:href="#icon-music_random_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_single"><defs><symbol viewBox="0 0 49.001 40.098" id="icon-music_single_a"><path data-name="Union 175" d="m-9325.054-993.2-11.152-6.789a2 2 0 0 1 0-3.417l11.152-6.791a2 2 0 0 1 3.042 1.708v4.291h16.6a11.916 11.916 0 0 0 11.9-11.9 11.916 11.916 0 0 0-11.9-11.9h-15.194a11.916 11.916 0 0 0-11.9 11.9 11.881 11.881 0 0 0 .536 3.536 2.5 2.5 0 0 1-1.643 3.131 2.5 2.5 0 0 1-3.131-1.643 16.872 16.872 0 0 1-.764-5.024 16.766 16.766 0 0 1 1.331-6.58 16.83 16.83 0 0 1 3.621-5.373 16.814 16.814 0 0 1 5.371-3.621 16.816 16.816 0 0 1 6.58-1.329h15.194a16.816 16.816 0 0 1 6.58 1.329 16.814 16.814 0 0 1 5.371 3.621 16.836 16.836 0 0 1 3.623 5.373 16.816 16.816 0 0 1 1.329 6.58 16.813 16.813 0 0 1-1.329 6.578 16.835 16.835 0 0 1-3.623 5.373 16.812 16.812 0 0 1-5.371 3.621 16.774 16.774 0 0 1-6.58 1.329h-16.6v4.291a2 2 0 0 1-2 2 1.98 1.98 0 0 1-1.043-.294Zm11.44-13.847v-14.3l-3.625 3.152v-3.5l3.625-3.15h3.25v17.8Z" transform="translate(9337.514 1033)" /></symbol></defs><use xlink:href="#icon-music_single_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_start"><defs><symbol viewBox="0 0 57.821 59.999" id="icon-music_start_a"><path d="M4057.836 6103.072a5.424 5.424 0 0 1-1.437 1.277l-43.632 25.732a8.26 8.26 0 0 1-10.382-1.459 5.792 5.792 0 0 1-1.4-3.723v-47.234c0-3.525 3.33-6.383 7.439-6.383a8.355 8.355 0 0 1 4.126 1.07l43.679 23.834a4.552 4.552 0 0 1 1.607 6.886Z" transform="translate(-4000.988 -6071.283)" /></symbol></defs><use xlink:href="#icon-music_start_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-music_ticked"><defs><symbol viewBox="0 0 20 15" id="icon-music_ticked_a"><path d="m1234.22-597.615-6.584-5.628a1.524 1.524 0 0 1-.149-2.141 1.5 1.5 0 0 1 2.128-.15l5.438 4.648 9.417-10.834a1.5 1.5 0 0 1 2.128-.15 1.525 1.525 0 0 1 .149 2.141l-10.4 11.964a1.5 1.5 0 0 1-1.139.522 1.494 1.494 0 0 1-.988-.372Z" transform="translate(-1227.117 612.242)" /></symbol></defs><use xlink:href="#icon-music_ticked_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-my_info"><defs><symbol viewBox="0 0 57.488 56.043" id="icon-my_info_a"><g data-name="Group 54342"><path data-name="Union 154" d="M2294 14.26a14.26 14.26 0 1 1 14.26 14.261A14.277 14.277 0 0 1 2294 14.26Zm4.931 0a9.329 9.329 0 1 0 9.33-9.328 9.34 9.34 0 0 0-9.33 9.328Z" transform="translate(-2280.239)" /><path data-name="Union 153" d="M2296.466 24.59a2.468 2.468 0 0 1-2.466-2.466v-3.931A18.178 18.178 0 0 1 2312.193 0H2323a2.466 2.466 0 1 1 0 4.932h-10.812a13.276 13.276 0 0 0-13.262 13.261v1.465H2323a2.466 2.466 0 1 1 0 4.932Z" transform="translate(-2294 31.453)" /><path data-name="Path 14907" d="M240.72 182.216a2.274 2.274 0 0 0 0-3.213l-5.678-5.678a2.274 2.274 0 0 0-3.213 0L218.5 186.651a2.275 2.275 0 0 0-.663 1.509l-.259 5.934a2.27 2.27 0 0 0 2.369 2.367l5.934-.257a2.279 2.279 0 0 0 1.509-.663l13.326-13.326Zm-18.38 7.023-.112 2.577 2.577-.114 11.095-11.091-2.463-2.465-11.1 11.094Zm0 0" transform="translate(-183.897 -140.813)" fill-rule="evenodd" /></g></symbol></defs><use xlink:href="#icon-my_info_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-my_info_green"><defs><symbol viewBox="0 0 57.488 56.043" id="icon-my_info_green_a"><g data-name="Group 54342"><path data-name="Union 154" d="M2294 14.26a14.26 14.26 0 1 1 14.26 14.261A14.277 14.277 0 0 1 2294 14.26Zm4.931 0a9.329 9.329 0 1 0 9.33-9.328 9.34 9.34 0 0 0-9.33 9.328Z" transform="translate(-2280.239)" /><path data-name="Union 153" d="M2296.466 24.59a2.468 2.468 0 0 1-2.466-2.466v-3.931A18.178 18.178 0 0 1 2312.193 0H2323a2.466 2.466 0 1 1 0 4.932h-10.812a13.276 13.276 0 0 0-13.262 13.261v1.465H2323a2.466 2.466 0 1 1 0 4.932Z" transform="translate(-2294 31.453)" /><path data-name="Path 14907" d="M240.72 182.216a2.274 2.274 0 0 0 0-3.213l-5.678-5.678a2.274 2.274 0 0 0-3.213 0L218.5 186.651a2.275 2.275 0 0 0-.663 1.509l-.259 5.934a2.27 2.27 0 0 0 2.369 2.367l5.934-.257a2.279 2.279 0 0 0 1.509-.663l13.326-13.326Zm-18.38 7.023-.112 2.577 2.577-.114 11.095-11.091-2.463-2.465-11.1 11.094Zm0 0" transform="translate(-183.897 -140.813)" fill-rule="evenodd" /></g></symbol></defs><use xlink:href="#icon-my_info_green_a" fill="#FACF20" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 33.4 33.4" id="icon-nav_about"><defs><symbol viewBox="0 0 33.4 33.4" id="icon-nav_about_a"><g data-name="Mask Group 187" clip-path="url(#icon_sy_zc_gywm--svgSprite:all_clip-path)" transform="translate(-29.5 -199)"><path d="M.552 19.417v-9.99a1.665 1.665 0 1 1 3.329 0v9.99a1.665 1.665 0 1 1-3.329 0ZM0 2.219a2.217 2.217 0 1 1 2.217 2.219A2.218 2.218 0 0 1 0 2.219Z" transform="translate(43.981 205.16)" stroke-miterlimit="10" /></g></symbol></defs><use xlink:href="#icon-nav_about_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-nav_customer"><defs><symbol viewBox="0 0 33.429 33.428" id="icon-nav_customer_a"><g data-name="Mask Group 189" clip-path="url(#icon_sy_zc_kf--svgSprite:all_clip-path)"><path d="M11.278 20.959A1.9 1.9 0 0 1 9.554 19.9H7.877a3.171 3.171 0 0 1-3.242-3.087V16.3h-.308a.953.953 0 0 1-.975-.928V8.294c0-.011.008-.019.013-.028A8.672 8.672 0 0 1 12.1 0a8.672 8.672 0 0 1 8.738 8.265.056.056 0 0 1 .013.029v7.074a.952.952 0 0 1-.975.928h-3.185a.952.952 0 0 1-.974-.928V9.16a.952.952 0 0 1 .974-.928h1.8a6.4 6.4 0 0 0-12.78 0h1.8a.952.952 0 0 1 .975.928v6.208a.952.952 0 0 1-.975.928H6.2v.517a1.644 1.644 0 0 0 1.68 1.6h1.663a1.905 1.905 0 0 1 1.735-1.076h1.651a1.812 1.812 0 1 1 0 3.621Zm10.815-6.58v-4.23a.355.355 0 0 1 .42-.344 2.041 2.041 0 0 1 1.694 1.973v.971a2.041 2.041 0 0 1-1.694 1.973.351.351 0 0 1-.067.006.356.356 0 0 1-.353-.349Zm-20.4.344A2.041 2.041 0 0 1 0 12.75v-.971a2.041 2.041 0 0 1 1.694-1.974.355.355 0 0 1 .42.344v4.23a.353.353 0 0 1-.42.344Z" transform="translate(4.61 6.234)" /></g></symbol></defs><use xlink:href="#icon-nav_customer_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-nav_download"><defs><symbol viewBox="0 0 33.429 33.428" id="icon-nav_download_a"><g data-name="Mask Group 190" clip-path="url(#icon_sy_zc_xz--svgSprite:all_clip-path)"><path d="m2032.081 134.116 2.957 2.745a.551.551 0 0 0 .732 0l2.957-2.745 2.5-2.32a.448.448 0 0 0-.366-.764h-2.652v-6.664a.7.7 0 0 0-.7-.7h-4.21a.7.7 0 0 0-.7.7v6.664h-2.646a.448.448 0 0 0-.366.764Zm10.336 5.337h-14.033a1.052 1.052 0 1 0 0 2.1h14.033a1.052 1.052 0 1 0 0-2.1Z" transform="translate(-2018.686 -116.174)" fill-rule="evenodd" /></g></symbol></defs><use xlink:href="#icon-nav_download_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 33.429 33.428" id="icon-nav_faq"><defs><symbol viewBox="0 0 33.429 33.428" id="icon-nav_faq_a"><g data-name="Mask Group 188" clip-path="url(#icon_sy_zc_cjwt--svgSprite:all_clip-path)"><path data-name="Union 135" d="M0 5.347a5.817 5.817 0 0 1 2.307-4.1A7.03 7.03 0 0 1 6.58 0a6.924 6.924 0 0 1 4.883 1.624A4.736 4.736 0 0 1 13 5.273a4.953 4.953 0 0 1-.745 2.649 10.96 10.96 0 0 1-2.234 2.429A6.973 6.973 0 0 0 8 12.7a6.782 6.782 0 0 0-.366 2.5h-2.58v-.6a7.41 7.41 0 0 1 .546-3.113 8.951 8.951 0 0 1 1.749-2.258 10.333 10.333 0 0 0 1.88-2.295 3.478 3.478 0 0 0 .4-1.66A2.574 2.574 0 0 0 8.7 3.162 3.21 3.21 0 0 0 6.6 2.5a3.079 3.079 0 0 0-2.49 1.074 4.3 4.3 0 0 0-.891 2.515Zm4.553 12.28h3.552V21H4.553Z" transform="translate(9.474 5.717)" stroke-miterlimit="10" /></g></symbol></defs><use xlink:href="#icon-nav_faq_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-nav_language"><defs><symbol viewBox="0 0 26 26" id="icon-nav_language_a"><path d="M18073 22626a13 13 0 1 1 13-13 13 13 0 0 1-13 13Zm0-2.5c.342 0 1.182-.641 1.971-2.355a19.318 19.318 0 0 0 1.5-6.895h-6.937a19.276 19.276 0 0 0 1.5 6.895c.789 1.715 1.629 2.355 1.975 2.355Zm3.984-.785a10.541 10.541 0 0 0 6.441-8.465h-4.457a20.933 20.933 0 0 1-1.982 8.467Zm-7.973 0a20.922 20.922 0 0 1-1.986-8.463h-4.455a10.538 10.538 0 0 0 6.444 8.463Zm14.414-10.967a10.537 10.537 0 0 0-6.441-8.465 20.9 20.9 0 0 1 1.984 8.465Zm-6.959 0a19.3 19.3 0 0 0-1.5-6.895c-.789-1.715-1.629-2.355-1.971-2.355s-1.186.641-1.975 2.355a19.294 19.294 0 0 0-1.5 6.895Zm-9.441 0a20.922 20.922 0 0 1 1.986-8.463 10.53 10.53 0 0 0-6.441 8.463Z" transform="translate(-18060 -22600)" /></symbol></defs><use xlink:href="#icon-nav_language_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-nav_record"><defs><symbol viewBox="0 0 60 64.609" id="icon-nav_record_a"><path d="M-5600.436-1395.588v-2.023c3.267 1.892 8.893 2.023 10.37 2.023s7.112-.131 10.381-2.023v2.023c0 1.767-4.644 3.2-10.381 3.2s-10.37-1.433-10.37-3.2Zm-17.565-3.195v-3.615c3.515 1.879 9.579 2.023 11.184 2.023.677 0 2.2-.031 3.986-.21v4.773a34.741 34.741 0 0 1-3.986.224c-6.183 0-11.183-1.436-11.183-3.194Zm41.19 1.779v-11.453l-.051.03c-.292-1.63-1.77-2.89-4.395-3.748a26.879 26.879 0 0 0-8.006-1.083 32.793 32.793 0 0 0-3.873.221 3.221 3.221 0 0 0 .359-1.5v-14.536c-.184-3.848-6.735-4.884-10.625-5.159V-1451a6.007 6.007 0 0 1 6-6h33.4a6.007 6.007 0 0 1 6 6v48a6.007 6.007 0 0 1-6 6Zm-9.808-29.284a1.918 1.918 0 0 0 1.916 1.915h17.73a1.917 1.917 0 0 0 1.915-1.915 1.918 1.918 0 0 0-1.915-1.916h-17.73a1.919 1.919 0 0 0-1.915 1.917Zm-9.729-10.218a1.918 1.918 0 0 0 1.916 1.916h27.458a1.918 1.918 0 0 0 1.915-1.916 1.918 1.918 0 0 0-1.915-1.916h-27.458a1.918 1.918 0 0 0-1.915 1.917Zm0-10.216a1.917 1.917 0 0 0 1.916 1.915h27.458a1.917 1.917 0 0 0 1.915-1.915 1.917 1.917 0 0 0-1.915-1.916h-27.458a1.917 1.917 0 0 0-1.915 1.916Zm-4.089 45.544v-2.023c3.267 1.891 8.893 2.023 10.37 2.023s7.112-.132 10.381-2.023v2.023c0 1.767-4.644 3.2-10.381 3.2s-10.369-1.433-10.369-3.2Zm-17.565-4.788v-3.619c3.515 1.879 9.579 2.023 11.184 2.023a40.954 40.954 0 0 0 4.162-.226 3.121 3.121 0 0 0-.113.485l-.063-.049v4.352a33.822 33.822 0 0 1-3.986.228c-6.182.001-11.182-1.439-11.182-3.194Zm17.843-1c0-1.786 4.718-3.25 10.535-3.25s10.545 1.464 10.545 3.25-4.718 3.239-10.545 3.239-10.534-1.451-10.534-3.237Zm-17.843-6.178v-3.626c3.526 1.891 9.579 2.027 11.184 2.027s7.658-.137 11.171-2.027v3.626c0 1.755-5 3.188-11.171 3.188s-11.182-1.431-11.182-3.187Zm0-7.191v-3.622c3.526 1.893 9.579 2.026 11.184 2.026s7.658-.133 11.171-2.026v3.622c0 1.767-5 3.2-11.171 3.2s-11.182-1.432-11.182-3.198Zm0-7.711c0-1.786 5.09-3.247 11.356-3.247s11.348 1.461 11.348 3.247-5.088 3.237-11.348 3.237-11.354-1.446-11.354-3.235Z" transform="translate(5618 1457)" /></symbol></defs><use xlink:href="#icon-nav_record_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-online_icon"><defs><symbol viewBox="0 0 31.979 33.88" id="icon-online_icon_a"><path d="M17.456 33.88H3.492A3.485 3.485 0 0 1 0 30.41V3.47A3.485 3.485 0 0 1 3.492 0h13.975a3.486 3.486 0 0 1 3.481 3.484v12.781a10.035 10.035 0 0 0-2.255 1.066V5.183a1.161 1.161 0 0 0-1.164-1.156h-14a1.161 1.161 0 0 0-1.165 1.156V27.6a1.136 1.136 0 0 0 .982 1.157h11.12a9.961 9.961 0 0 0 3.622 5.057 3.457 3.457 0 0 1-.632.066Zm-6.674-3.708a1.247 1.247 0 1 0 1.255 1.247 1.247 1.247 0 0 0-1.255-1.247ZM24.1 33.614a7.831 7.831 0 1 1 7.879-7.831 7.831 7.831 0 0 1-7.879 7.831Zm-.159-3.321 1.45.012a6.019 6.019 0 0 1-1.357-2.4 4.6 4.6 0 0 0 1.5.866 2.287 2.287 0 0 0 2.742-2.509c-.023-1.233-.923-2.054-2.063-3.092a19 19 0 0 1-2.268-2.343 19.557 19.557 0 0 1-2.255 2.286c-1.145 1.029-2.049 1.842-2.086 3.085a2.292 2.292 0 0 0 2.711 2.56 5.013 5.013 0 0 0 1.562-.855 5.972 5.972 0 0 1-1.385 2.385c.869.011 1.227.013 1.373.013h.08Z" /></symbol></defs><use xlink:href="#icon-online_icon_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" id="icon-password_hidden"><defs><symbol viewBox="0 0 26 21.514" id="icon-password_hidden_a"><path data-name="Path 515" d="m1789.072 314.086-3.3 3.3a14.338 14.338 0 0 0-5.53-1.1 13.585 13.585 0 0 0-13.012 8.88l.069.007-.069.007a12.82 12.82 0 0 0 4.592 6.156l-2.855 2.855 1.412 1.412 20.1-20.1Zm-14.792 11.032a5.935 5.935 0 0 1 8.907-5.148l-1.827 1.828a3.507 3.507 0 0 0-4.456 4.456l-1.825 1.825a5.888 5.888 0 0 1-.8-2.961Z" transform="translate(-1767.233 -314.086)" /><path data-name="Path 516" d="M1793.172 339.617a3.516 3.516 0 0 0 3.514-3.515v-.084l-3.6 3.6c.029-.005.057-.001.086-.001Z" transform="translate(-1780.175 -325.064)" /><path data-name="Path 517" d="M1801.535 330.583a12.792 12.792 0 0 0-3.948-5.668l-3.507 3.507a5.934 5.934 0 0 1-7.668 7.668l-2.594 2.594a14.48 14.48 0 0 0 4.729.794 13.555 13.555 0 0 0 12.988-8.881l-.07-.007Z" transform="translate(-1775.535 -319.507)" /></symbol></defs><use xlink:href="#icon-password_hidden_a" fill="var(--theme-color-line)" /></symbol><symbol   fill="currentColor" aria-hidden="true" id="icon-password_visible"><defs><symbol viewBox="0 0 26 17.776" id="icon-password_visible_a"><path d="M1858.15 327.364a13.956 13.956 0 0 0-26 0l.069.007-.069.007a13.955 13.955 0 0 0 26 0l-.07-.007Zm-13.007 5.9a5.946 5.946 0 1 1 5.947-5.947 5.947 5.947 0 0 1-5.947 5.949Zm0-9.457a3.515 3.515 0 1 0 3.515 3.515 3.516 3.516 0 0 0-3.512-3.513Z" transform="translate(-1832.15 -318.484)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-password_visible_a" fill="#005DFE" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-pescaria"><defs><symbol viewBox="0 0 100 76" id="icon-pescaria_a"><path data-name="Subtraction 59" d="m41.6 74-.005-.007c-2.108-2.971-4.322-7.012-2.719-11.932a2.1 2.1 0 0 0-.819-2.662c-4.47-3.386-6-8.144-4.556-14.142a11.947 11.947 0 0 1 2.682-4.522c2.333-2.747 5.652-4.693 10.148-5.947 1.6-.445 3.251-.786 4.851-1.116 1.5-.308 3.042-.627 4.538-1.03a12.741 12.741 0 0 0 4.028-1.942 2.425 2.425 0 0 0 1.063-1.957 2.378 2.378 0 0 0-1.04-1.921 13.36 13.36 0 0 0-3.5-1.59l-.545-.189a4.93 4.93 0 0 0-1.494-.183c-.283-.008-.574-.016-.891-.041a5.178 5.178 0 0 1 3.872-2.56 18.106 18.106 0 0 1 2.977-.277 7.965 7.965 0 0 1 6.889 3.283 1.793 1.793 0 0 0 1.2.468.586.586 0 0 0 .316-.07c3.867-2.573 6.427-5.22 8.057-8.332a.608.608 0 0 0 .022-.309 5.828 5.828 0 0 1-.013-.377 20.728 20.728 0 0 1-1.132-.392 10.148 10.148 0 0 0-2.624-.705c-1.3-.1-2.625-.252-3.9-.4a66.94 66.94 0 0 0-7.386-.55 27.139 27.139 0 0 0-3.5.212c-.45.058-.908.11-1.352.16-2.416.274-4.91.557-7.14 1.951-2.894 1.8-4.438 3.8-5.006 6.454a3.58 3.58 0 0 1-.369.879l-.031.058a.526.526 0 0 1-.231.167c-.065.034-.138.071-.22.122-1.269-1.033-.9-2.4-.566-3.609l.024-.089a10.928 10.928 0 0 1 1.109-2.41c.2-.358.408-.729.6-1.111-1.639.1-2.825 1.229-3.621 3.459a23.506 23.506 0 0 0-.856 3.545 69.58 69.58 0 0 1-.387 1.934c-1.886-2.148-1.251-4.016-.636-5.823a10.605 10.605 0 0 0 .565-2.129c-2.83 1.654-3.211 4.351-3.614 7.206-.071.5-.144 1.018-.231 1.524a3.029 3.029 0 0 1-1.693-2.722 6.186 6.186 0 0 0-.283-1.21c-3.339 2.106-6.153 6.509-7.341 11.491a23.961 23.961 0 0 0 2.82 17.957 31.8 31.8 0 0 0-.651-.627 14.9 14.9 0 0 1-1.369-1.415c-.959-1.181-1.708-1.864-2.7-1.864a5.347 5.347 0 0 0-2.327.763c-.443.227-.871.482-1.368.777-.246.147-.505.3-.79.466a8.917 8.917 0 0 1 1.745-5.723c1.013-1.387 1.526-2.65.739-4.3a3.99 3.99 0 0 1-.261-1.554 8.14 8.14 0 0 0-.066-.883c-.065-.432-.16-.863-.252-1.28a36.605 36.605 0 0 1-.132-.618c-.144.014-.264.018-.361.022-.158.005-.254.009-.278.052-.82 1.455-2.072 1.57-3.503 1.57H17.16A67.971 67.971 0 0 0 .289 40.142L0 39.776c.414-.407.828-.829 1.228-1.238.872-.89 1.772-1.809 2.735-2.623a62.634 62.634 0 0 1 18.406-11.047 4.6 4.6 0 0 0 2.573-2.433 25.26 25.26 0 0 1 9.995-10.909 14.661 14.661 0 0 0 1.291-.871c.2-.147.408-.3.623-.446a1.613 1.613 0 0 0-1.264-.575 3.64 3.64 0 0 0-1.748.592l-.062.037A21.894 21.894 0 0 0 32.484.09h.092c.438 0 .888-.021 1.323-.042.464-.025.944-.048 1.413-.048a8.818 8.818 0 0 1 1.617.128 42.165 42.165 0 0 1 16 6.127 9.036 9.036 0 0 0 4.589 1.483 51.247 51.247 0 0 1 21.907 7.026 3.3 3.3 0 0 1 .722.644c.116.125.236.254.368.38-2.8 6.51-7.587 11.41-14.628 14.983-1.7.86-3.456 1.67-5.156 2.452-1.659.764-3.372 1.553-5.027 2.387-.751.378-1.09.683-1.134 1.021-.046.354.226.755.939 1.384a24 24 0 0 1 7.435 11.857 28.764 28.764 0 0 1 .751 5.421c.047.63.1 1.281.157 1.916a2.316 2.316 0 0 1-.473 1.359 12.815 12.815 0 0 0-4.955-5.353c-4.467-3.079-9.83-6.466-15.736-8.234a.26.26 0 0 1-.171-.139c-.113-.237.077-.706.278-1.2.239-.588.485-1.2.274-1.51a.611.611 0 0 0-.547-.211 3.111 3.111 0 0 0-.72.107 6.824 6.824 0 0 0-3.745 2.606 16.77 16.77 0 0 0 1.06 1.439c1.05 1.325 2.136 2.694 1.788 4.708-.4-.2-.771-.4-1.133-.6a13.241 13.241 0 0 0-2.272-1.068 2.532 2.532 0 0 0-.754-.134 1 1 0 0 0-.789.314 1.738 1.738 0 0 0-.25 1.38 8.917 8.917 0 0 0 3.825 6.1 1.875 1.875 0 0 0 1.152.408 4.079 4.079 0 0 0 1.6-.473c.109-.049.217-.1.326-.144a16.93 16.93 0 0 1 6.658-1.431 16.687 16.687 0 0 1 7.605 1.921c.065.034.111.1.2.229.06.085.134.19.244.33a17.748 17.748 0 0 0-11.151 5.093c-3.354 3.339-4.848 7.03-4.569 11.282Zm14.637-63.823c-.092 0-.147.066-.183.221a1.617 1.617 0 0 0 .13.676l.028.084a2.7 2.7 0 0 0 .748 1.217 4.28 4.28 0 0 0 2.633 1.075 1.828 1.828 0 0 0 1.308-.475.831.831 0 0 0 .262-.788.491.491 0 0 0-.04-.113 1.194 1.194 0 0 0-.726-.48l-3.77-1.294a3.144 3.144 0 0 1-.153-.058.732.732 0 0 0-.237-.065Z" transform="translate(10 1.001)" /></symbol></defs><use xlink:href="#icon-pescaria_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-pescaria_2"><use xlink:href="#icon-pescaria_2_a" /><defs><symbol viewBox="0 0 100 76" id="icon-pescaria_2_a"><path data-name="icon_dtfl_by_0" d="M13.225.064a25.065 25.065 0 0 1 14.706 4.6l4.232 3.958h6.666c7.139 1.388 12.869 2.542 17.986 5.561a16.394 16.394 0 0 1 4.761 3.094c.979 1.244-.641 2.539-1.269 3.209-1.494 1.593-5.594 5.879-8.04 5.775l-.422-2.354c-1.253-2.066-6.188-3.757-9.311-3.85-1.6-.044-4.219-.592-5.083.32 1.828 2.027 6.851 1.311 9.1 4.279.608.707 1.854 2.047.846 3.315-1.505 2.92-13.784 2.995-15.34 5.669-.179.221-.164.221-.221.641h.221c1.207.411 3.251-.442 4.02.32.972 1.01.2 7.236-.422 8.129l-.634-.106c-1.658-.72-6.46-5.7-8.146-5.24a6.938 6.938 0 0 0-2.652 3.423c-3.238 6.354.935 11.6 5.5 14.439.9.559 5.746 3.768 6.031 1.819-.694-1.3-2.186-1.83-2.327-3.636A19.946 19.946 0 0 1 42.63 43.7c1.07-.621 2.889-1.9 4.444-1.5v.641c-3.45 2.63-8.725 9.647-6.453 16.258.61 1.768 4.526 6.239 4.126 7.273A17.548 17.548 0 0 1 34.7 61.454l-1.693-2.674a43.586 43.586 0 0 0-8.142-1.613 3.768 3.768 0 0 0-.846 2.139l-.634.106a10.909 10.909 0 0 1-3.494-4.912c-.362-.758-.278-1.8-.953-2.245l-.528-.108-1.165 1.5c-1.64.595-7.939-5.7-8.675-6.851-4.486-6.97-1.77-14.425 2.856-19.144l-.106-.852c-.3-.705-1.768-2.119-2.752-1.711-2.544 1.255-4.177 4.891-5.713 7.165h-.316l-.108-.1c-.057-4.033 2.626-6.462 3.808-9.411C5.116 20.036 1.414 19.548 0 17.176a1.134 1.134 0 0 1 .634-.641l4.228-.108a49.245 49.245 0 0 1 14.808 2.354c1.163.391 2.338.785 3.492 1.176l9.327-2.245c2.6-.48 5.525.088 7.293-1.176H40l-.106-.429a38.234 38.234 0 0 0-12.273.429c-1.468.3-3.284 1.39-5.083.961l-4.027-1.711-2.855-.535-.106-.221c.046-.751.276-.758.528-1.176a53.755 53.755 0 0 0 7.722-3.423L23.7 10c-1.958 0-3.835.524-5.291.32-.8-.924-.643-2.418-1.165-3.744A17.681 17.681 0 0 0 12.8.808l.106-.316Zm33.432 12.3-.422.535a4.139 4.139 0 0 0 .846 1.819 2.942 2.942 0 0 0 3.28-.32 1.39 1.39 0 0 0-.318-.964 14.434 14.434 0 0 0-3.386-1.07Z" transform="translate(19 4.937)" fill-rule="evenodd" /></symbol></defs></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-pescaria_active"><defs><symbol viewBox="0 0 100 76" id="icon-pescaria_active_a"><path data-name="Subtraction 59" d="m41.6 74-.005-.007c-2.108-2.971-4.322-7.012-2.719-11.932a2.1 2.1 0 0 0-.819-2.662c-4.47-3.386-6-8.144-4.556-14.142a11.947 11.947 0 0 1 2.682-4.522c2.333-2.747 5.652-4.693 10.148-5.947 1.6-.445 3.251-.786 4.851-1.116 1.5-.308 3.042-.627 4.538-1.03a12.741 12.741 0 0 0 4.028-1.942 2.425 2.425 0 0 0 1.063-1.957 2.378 2.378 0 0 0-1.04-1.921 13.36 13.36 0 0 0-3.5-1.59l-.545-.189a4.93 4.93 0 0 0-1.494-.183c-.283-.008-.574-.016-.891-.041a5.178 5.178 0 0 1 3.872-2.56 18.106 18.106 0 0 1 2.977-.277 7.965 7.965 0 0 1 6.889 3.283 1.793 1.793 0 0 0 1.2.468.586.586 0 0 0 .316-.07c3.867-2.573 6.427-5.22 8.057-8.332a.608.608 0 0 0 .022-.309 5.828 5.828 0 0 1-.013-.377 20.728 20.728 0 0 1-1.132-.392 10.148 10.148 0 0 0-2.624-.705c-1.3-.1-2.625-.252-3.9-.4a66.94 66.94 0 0 0-7.386-.55 27.139 27.139 0 0 0-3.5.212c-.45.058-.908.11-1.352.16-2.416.274-4.91.557-7.14 1.951-2.894 1.8-4.438 3.8-5.006 6.454a3.58 3.58 0 0 1-.369.879l-.031.058a.526.526 0 0 1-.231.167c-.065.034-.138.071-.22.122-1.269-1.033-.9-2.4-.566-3.609l.024-.089a10.928 10.928 0 0 1 1.109-2.41c.2-.358.408-.729.6-1.111-1.639.1-2.825 1.229-3.621 3.459a23.506 23.506 0 0 0-.856 3.545 69.58 69.58 0 0 1-.387 1.934c-1.886-2.148-1.251-4.016-.636-5.823a10.605 10.605 0 0 0 .565-2.129c-2.83 1.654-3.211 4.351-3.614 7.206-.071.5-.144 1.018-.231 1.524a3.029 3.029 0 0 1-1.693-2.722 6.186 6.186 0 0 0-.283-1.21c-3.339 2.106-6.153 6.509-7.341 11.491a23.961 23.961 0 0 0 2.82 17.957 31.8 31.8 0 0 0-.651-.627 14.9 14.9 0 0 1-1.369-1.415c-.959-1.181-1.708-1.864-2.7-1.864a5.347 5.347 0 0 0-2.327.763c-.443.227-.871.482-1.368.777-.246.147-.505.3-.79.466a8.917 8.917 0 0 1 1.745-5.723c1.013-1.387 1.526-2.65.739-4.3a3.99 3.99 0 0 1-.261-1.554 8.14 8.14 0 0 0-.066-.883c-.065-.432-.16-.863-.252-1.28a36.605 36.605 0 0 1-.132-.618c-.144.014-.264.018-.361.022-.158.005-.254.009-.278.052-.82 1.455-2.072 1.57-3.503 1.57H17.16A67.971 67.971 0 0 0 .289 40.142L0 39.776c.414-.407.828-.829 1.228-1.238.872-.89 1.772-1.809 2.735-2.623a62.634 62.634 0 0 1 18.406-11.047 4.6 4.6 0 0 0 2.573-2.433 25.26 25.26 0 0 1 9.995-10.909 14.661 14.661 0 0 0 1.291-.871c.2-.147.408-.3.623-.446a1.613 1.613 0 0 0-1.264-.575 3.64 3.64 0 0 0-1.748.592l-.062.037A21.894 21.894 0 0 0 32.484.09h.092c.438 0 .888-.021 1.323-.042.464-.025.944-.048 1.413-.048a8.818 8.818 0 0 1 1.617.128 42.165 42.165 0 0 1 16 6.127 9.036 9.036 0 0 0 4.589 1.483 51.247 51.247 0 0 1 21.907 7.026 3.3 3.3 0 0 1 .722.644c.116.125.236.254.368.38-2.8 6.51-7.587 11.41-14.628 14.983-1.7.86-3.456 1.67-5.156 2.452-1.659.764-3.372 1.553-5.027 2.387-.751.378-1.09.683-1.134 1.021-.046.354.226.755.939 1.384a24 24 0 0 1 7.435 11.857 28.764 28.764 0 0 1 .751 5.421c.047.63.1 1.281.157 1.916a2.316 2.316 0 0 1-.473 1.359 12.815 12.815 0 0 0-4.955-5.353c-4.467-3.079-9.83-6.466-15.736-8.234a.26.26 0 0 1-.171-.139c-.113-.237.077-.706.278-1.2.239-.588.485-1.2.274-1.51a.611.611 0 0 0-.547-.211 3.111 3.111 0 0 0-.72.107 6.824 6.824 0 0 0-3.745 2.606 16.77 16.77 0 0 0 1.06 1.439c1.05 1.325 2.136 2.694 1.788 4.708-.4-.2-.771-.4-1.133-.6a13.241 13.241 0 0 0-2.272-1.068 2.532 2.532 0 0 0-.754-.134 1 1 0 0 0-.789.314 1.738 1.738 0 0 0-.25 1.38 8.917 8.917 0 0 0 3.825 6.1 1.875 1.875 0 0 0 1.152.408 4.079 4.079 0 0 0 1.6-.473c.109-.049.217-.1.326-.144a16.93 16.93 0 0 1 6.658-1.431 16.687 16.687 0 0 1 7.605 1.921c.065.034.111.1.2.229.06.085.134.19.244.33a17.748 17.748 0 0 0-11.151 5.093c-3.354 3.339-4.848 7.03-4.569 11.282Zm14.637-63.823c-.092 0-.147.066-.183.221a1.617 1.617 0 0 0 .13.676l.028.084a2.7 2.7 0 0 0 .748 1.217 4.28 4.28 0 0 0 2.633 1.075 1.828 1.828 0 0 0 1.308-.475.831.831 0 0 0 .262-.788.491.491 0 0 0-.04-.113 1.194 1.194 0 0 0-.726-.48l-3.77-1.294a3.144 3.144 0 0 1-.153-.058.732.732 0 0 0-.237-.065Z" transform="translate(10 1.001)" /></symbol></defs><use xlink:href="#icon-pescaria_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-pescaria_active_green"><defs><symbol viewBox="0 0 28 30.004" id="icon-pescaria_active_green_a"><path d="M5.984.063a11.341 11.341 0 0 1 6.654 2.081l1.915 1.791h3.016c3.23.628 5.823 1.15 8.138 2.516a7.418 7.418 0 0 1 2.154 1.4c.443.563-.29 1.149-.574 1.452-.676.721-2.531 2.66-3.638 2.613l-.191-1.065c-.567-.935-2.8-1.7-4.213-1.742-.722-.02-1.909-.268-2.3.145.827.917 3.1.593 4.117 1.936.275.32.839.926.383 1.5-.681 1.321-6.237 1.355-6.941 2.565-.081.1-.074.1-.1.29h.1c.546.186 1.471-.2 1.819.145.44.457.092 3.274-.191 3.678l-.287-.048c-.75-.326-2.923-2.581-3.686-2.371a3.139 3.139 0 0 0-1.2 1.549c-1.465 2.875.423 5.247 2.489 6.533.406.253 2.6 1.705 2.729.823-.314-.589-.989-.828-1.053-1.645a9.025 9.025 0 0 1 4.165-4.4c.484-.281 1.307-.859 2.011-.677v.29c-1.561 1.19-3.948 4.365-2.92 7.356.276.8 2.048 2.823 1.867 3.291A7.94 7.94 0 0 1 15.7 27.84l-.766-1.21a19.721 19.721 0 0 0-3.684-.73 1.705 1.705 0 0 0-.383.968l-.287.048A4.936 4.936 0 0 1 9 24.695c-.164-.343-.126-.816-.431-1.016l-.239-.049-.527.678c-.742.269-3.592-2.579-3.925-3.1-2.03-3.154-.8-6.527 1.292-8.662l-.048-.387c-.134-.319-.8-.959-1.245-.774-1.151.568-1.89 2.213-2.585 3.242h-.143l-.049-.046c-.026-1.825 1.188-2.924 1.723-4.258C2.315 9.1.64 8.879 0 7.806a.513.513 0 0 1 .287-.29L2.2 7.467a22.282 22.282 0 0 1 6.7 1.065c.526.177 1.058.355 1.58.532l4.22-1.016c1.177-.217 2.5.04 3.3-.532h.1l-.048-.194a17.3 17.3 0 0 0-5.553.194c-.664.136-1.486.629-2.3.435l-1.822-.774-1.292-.242-.048-.1c.021-.34.125-.343.239-.532a24.323 24.323 0 0 0 3.495-1.549l-.048-.194c-.886 0-1.735.237-2.394.145-.363-.418-.291-1.094-.527-1.694A8 8 0 0 0 5.792.4L5.84.257Zm15.127 5.565-.191.242a1.873 1.873 0 0 0 .383.823 1.331 1.331 0 0 0 1.484-.145.629.629 0 0 0-.144-.436 6.531 6.531 0 0 0-1.532-.484Z" transform="translate(0 -.063)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-pescaria_active_green_a" fill="#333" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-pescaria_green"><defs><symbol viewBox="0 0 28 30.004" id="icon-pescaria_green_a"><path d="M5.984.063a11.341 11.341 0 0 1 6.654 2.081l1.915 1.791h3.016c3.23.628 5.823 1.15 8.138 2.516a7.418 7.418 0 0 1 2.154 1.4c.443.563-.29 1.149-.574 1.452-.676.721-2.531 2.66-3.638 2.613l-.191-1.065c-.567-.935-2.8-1.7-4.213-1.742-.722-.02-1.909-.268-2.3.145.827.917 3.1.593 4.117 1.936.275.32.839.926.383 1.5-.681 1.321-6.237 1.355-6.941 2.565-.081.1-.074.1-.1.29h.1c.546.186 1.471-.2 1.819.145.44.457.092 3.274-.191 3.678l-.287-.048c-.75-.326-2.923-2.581-3.686-2.371a3.139 3.139 0 0 0-1.2 1.549c-1.465 2.875.423 5.247 2.489 6.533.406.253 2.6 1.705 2.729.823-.314-.589-.989-.828-1.053-1.645a9.025 9.025 0 0 1 4.165-4.4c.484-.281 1.307-.859 2.011-.677v.29c-1.561 1.19-3.948 4.365-2.92 7.356.276.8 2.048 2.823 1.867 3.291A7.94 7.94 0 0 1 15.7 27.84l-.766-1.21a19.721 19.721 0 0 0-3.684-.73 1.705 1.705 0 0 0-.383.968l-.287.048A4.936 4.936 0 0 1 9 24.695c-.164-.343-.126-.816-.431-1.016l-.239-.049-.527.678c-.742.269-3.592-2.579-3.925-3.1-2.03-3.154-.8-6.527 1.292-8.662l-.048-.387c-.134-.319-.8-.959-1.245-.774-1.151.568-1.89 2.213-2.585 3.242h-.143l-.049-.046c-.026-1.825 1.188-2.924 1.723-4.258C2.315 9.1.64 8.879 0 7.806a.513.513 0 0 1 .287-.29L2.2 7.467a22.282 22.282 0 0 1 6.7 1.065c.526.177 1.058.355 1.58.532l4.22-1.016c1.177-.217 2.5.04 3.3-.532h.1l-.048-.194a17.3 17.3 0 0 0-5.553.194c-.664.136-1.486.629-2.3.435l-1.822-.774-1.292-.242-.048-.1c.021-.34.125-.343.239-.532a24.323 24.323 0 0 0 3.495-1.549l-.048-.194c-.886 0-1.735.237-2.394.145-.363-.418-.291-1.094-.527-1.694A8 8 0 0 0 5.792.4L5.84.257Zm15.127 5.565-.191.242a1.873 1.873 0 0 0 .383.823 1.331 1.331 0 0 0 1.484-.145.629.629 0 0 0-.144-.436 6.531 6.531 0 0 0-1.532-.484Z" transform="translate(0 -.063)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-pescaria_green_a" fill="#ADB6C4" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-pix_account"><defs><symbol viewBox="0 0 30 29.987" id="icon-pix_account_a"><path d="M11.726 28.609q-2.758-2.755-5.518-5.518c-.027-.028-.059-.05-.087-.075l.014-.041h.861a4.261 4.261 0 0 0 3.041-1.263c1.494-1.479 2.974-2.97 4.46-4.455a.861.861 0 0 1 1.365 0l4.4 4.4a4.245 4.245 0 0 0 2.811 1.283c.259.016.518 0 .776 0 0 .016.007.034.011.05-.031.034-.059.071-.092.1l-5.578 5.575a4.36 4.36 0 0 1-2.781 1.29q-.226.019-.451.02a4.435 4.435 0 0 1-3.231-1.372zm-7.239-7.233c-1.04-1.052-2.09-2.092-3.136-3.138a4.563 4.563 0 0 1-.034-6.452c1.1-1.122 2.224-2.227 3.334-3.341a.259.259 0 0 1 .29-.1.96.96 0 0 0 .282.011h1.7a3.049 3.049 0 0 1 2.23.928c1.476 1.472 2.963 2.935 4.419 4.426a2.231 2.231 0 0 0 3.214 0c1.461-1.488 2.946-2.952 4.42-4.428a3.114 3.114 0 0 1 2.23-.923h.586c.311 0 .623.007.932-.011a.592.592 0 0 1 .507.216c1.047 1.06 2.1 2.11 3.157 3.163a4.464 4.464 0 0 1 1.348 2.856c.011.132.025.265.029.344a4.569 4.569 0 0 1-1.33 3.273q-1.622 1.63-3.254 3.256a.476.476 0 0 1-.405.171c-.332-.02-.666-.018-1-.014h-.519a3.184 3.184 0 0 1-2.32-.959c-1.446-1.456-2.9-2.9-4.347-4.355a2.23 2.23 0 0 0-1.666-.713 2.121 2.121 0 0 0-1.528.636q-2.217 2.219-4.435 4.435a3.115 3.115 0 0 1-2.33.964c-.591-.007-1.18-.029-1.766.011h-.061a.708.708 0 0 1-.545-.256zm10.038-8.627c-1.491-1.488-2.978-2.984-4.472-4.467a4.263 4.263 0 0 0-3.071-1.274h-.845l-.02-.048c.061-.055.127-.105.186-.164q2.742-2.741 5.487-5.481a4.365 4.365 0 0 1 2.792-1.3 4.44 4.44 0 0 1 3.659 1.338c1.845 1.835 3.678 3.679 5.521 5.518.034.034.075.064.114.1l-.015.05h-.437a4.322 4.322 0 0 0-2.505.766 4.489 4.489 0 0 0-.641.531q-2.224 2.206-4.439 4.431a.837.837 0 0 1-1.312 0z" transform="translate(.002 .006)" style="fill:#00bdae" /></symbol></defs><use xlink:href="#icon-pix_account_a" fill="#55657E" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 23 16.739" id="icon-pix_cpf"><defs><symbol viewBox="0 0 23 16.739" id="icon-pix_cpf_a"><path d="M20.062 15.739H1.938A1.939 1.939 0 0 1 0 13.8V1.938A1.939 1.939 0 0 1 1.938 0h18.124A1.939 1.939 0 0 1 22 1.938V13.8a1.939 1.939 0 0 1-1.938 1.938Zm-3.483-12.48a2.578 2.578 0 0 0-2.588 2.559A2.532 2.532 0 0 0 15.03 7.87c-1.566 1.035-2.77 1.973-2.871 3.835a.806.806 0 0 0 .214.588.592.592 0 0 0 .427.189h7.56a.592.592 0 0 0 .427-.189.8.8 0 0 0 .213-.587c-.106-1.865-1.309-2.8-2.871-3.835a2.535 2.535 0 0 0 1.038-2.053 2.578 2.578 0 0 0-2.588-2.559ZM2.809 5.515a1.78 1.78 0 0 0-.953.253 1.648 1.648 0 0 0-.63.733 2.619 2.619 0 0 0-.22 1.1v.262a2.309 2.309 0 0 0 .477 1.54 1.642 1.642 0 0 0 1.317.564 1.834 1.834 0 0 0 1.227-.4 1.516 1.516 0 0 0 .513-1.1h-.892a.843.843 0 0 1-.234.582.887.887 0 0 1-.616.188.755.755 0 0 1-.675-.326 1.9 1.9 0 0 1-.214-1.023v-.331a1.793 1.793 0 0 1 .228-.992.768.768 0 0 1 .673-.319.865.865 0 0 1 .61.188.916.916 0 0 1 .234.61h.89a1.643 1.643 0 0 0-.527-1.126 1.773 1.773 0 0 0-1.207-.4Zm6.24.057v4.335h.891V8.133h1.711v-.718h-1.71V6.3h1.934v-.728Zm-3.924 0v4.335h.89V8.378H6.8a1.83 1.83 0 0 0 1.207-.365 1.241 1.241 0 0 0 .435-1.005 1.417 1.417 0 0 0-.2-.75 1.328 1.328 0 0 0-.57-.508 1.956 1.956 0 0 0-.861-.179Zm1.688 2.087h-.8V6.3h.821a.7.7 0 0 1 .517.2.724.724 0 0 1 .186.517.613.613 0 0 1-.186.477.781.781 0 0 1-.539.168Z" transform="translate(.5 .5)" stroke-linejoin="round" /></symbol></defs><use xlink:href="#icon-pix_cpf_a" fill="var(--theme-text-color-lighten)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-pix_name"><defs><symbol viewBox="0 0 22.001 15.665" id="icon-pix_name_a"><path d="M-10951.833-3157.833h-18.333a1.836 1.836 0 0 1-1.834-1.834v-12a1.834 1.834 0 0 1 1.834-1.831h18.333a1.834 1.834 0 0 1 1.834 1.831v12a1.836 1.836 0 0 1-1.834 1.834Zm-13.407-12.51a2.605 2.605 0 0 0-2.616 2.588 2.554 2.554 0 0 0 1.05 2.076c-1.585 1.049-2.8 2-2.905 3.88a.814.814 0 0 0 .216.6.6.6 0 0 0 .431.191h7.647a.6.6 0 0 0 .431-.189.825.825 0 0 0 .219-.6c-.109-1.884-1.326-2.834-2.905-3.88a2.568 2.568 0 0 0 1.05-2.076 2.605 2.605 0 0 0-2.618-2.59Zm7.562 5.667a1.032 1.032 0 0 0-1.03 1.032 1.031 1.031 0 0 0 1.03 1.03h4.813a1.032 1.032 0 0 0 1.032-1.03 1.033 1.033 0 0 0-1.032-1.032Zm0-4.125a1.031 1.031 0 0 0-1.03 1.03 1.033 1.033 0 0 0 1.03 1.033h4.813a1.034 1.034 0 0 0 1.032-1.033 1.032 1.032 0 0 0-1.032-1.03Z" transform="translate(10972 3173.499)" /></symbol></defs><use xlink:href="#icon-pix_name_a" fill="var(--theme-text-color-lighten)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-pix_type"><defs><symbol viewBox="0 0 20.001 20" id="icon-pix_type_a"><path d="M2.451 20.894A1.46 1.46 0 0 1 1 19.427v-.064a9.627 9.627 0 0 1 4.8-7.725 7.557 7.557 0 0 0 10.41 0A9.624 9.624 0 0 1 21 19.363a1.458 1.458 0 0 1-1.383 1.529h-.065ZM5.584 6.333a5.415 5.415 0 1 1 5.468 5.334H11a5.375 5.375 0 0 1-5.416-5.334Z" transform="translate(-1 -.894)" /></symbol></defs><use xlink:href="#icon-pix_type_a" fill="var(--theme-text-color-lighten)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-play"><defs><symbol viewBox="0 0 20.598 25.074" id="icon-play_a"><path d="M10.829 2.807a2 2 0 0 1 3.417 0l8.979 14.751a2 2 0 0 1-1.708 3.04H3.559a2 2 0 0 1-1.708-3.04Z" transform="rotate(90 10.299 10.299)" /></symbol></defs><use xlink:href="#icon-play_a" fill="var(--theme-primary-font-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-play_agent"><defs><symbol viewBox="0 0 23.999 24.001" id="icon-play_agent_a"><path d="M-7245 1351a12 12 0 0 1 12-12 12 12 0 0 1 12 12 12 12 0 0 1-12 12 12 12 0 0 1-12-12Zm2 0a10.011 10.011 0 0 0 10 10 10.011 10.011 0 0 0 10-10 10.01 10.01 0 0 0-10-10 10.011 10.011 0 0 0-10 10Zm7.99 3.573-.082-7.435a.5.5 0 0 1 .754-.435l6.4 3.789a.5.5 0 0 1-.005.864l-6.313 3.644a.5.5 0 0 1-.25.068.5.5 0 0 1-.504-.495Z" transform="translate(7245 -1339)" /></symbol></defs><use xlink:href="#icon-play_agent_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-pwd_hidden"><defs><symbol viewBox="0 0 26 21.514" id="icon-pwd_hidden_a"><path data-name="Path 515" d="m1789.072 314.086-3.3 3.3a14.338 14.338 0 0 0-5.53-1.1 13.585 13.585 0 0 0-13.012 8.88l.069.007-.069.007a12.82 12.82 0 0 0 4.592 6.156l-2.855 2.855 1.412 1.412 20.1-20.1Zm-14.792 11.032a5.935 5.935 0 0 1 8.907-5.148l-1.827 1.828a3.507 3.507 0 0 0-4.456 4.456l-1.825 1.825a5.888 5.888 0 0 1-.8-2.961Z" transform="translate(-1767.233 -314.086)" /><path data-name="Path 516" d="M1793.172 339.617a3.516 3.516 0 0 0 3.514-3.515v-.084l-3.6 3.6c.029-.005.057-.001.086-.001Z" transform="translate(-1780.175 -325.064)" /><path data-name="Path 517" d="M1801.535 330.583a12.792 12.792 0 0 0-3.948-5.668l-3.507 3.507a5.934 5.934 0 0 1-7.668 7.668l-2.594 2.594a14.48 14.48 0 0 0 4.729.794 13.555 13.555 0 0 0 12.988-8.881l-.07-.007Z" transform="translate(-1775.535 -319.507)" /></symbol></defs><use xlink:href="#icon-pwd_hidden_a" fill="var(--theme-color-line)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-pwd_visible"><defs><symbol viewBox="0 0 26 17.776" id="icon-pwd_visible_a"><path d="M1858.15 327.364a13.956 13.956 0 0 0-26 0l.069.007-.069.007a13.955 13.955 0 0 0 26 0l-.07-.007Zm-13.007 5.9a5.946 5.946 0 1 1 5.947-5.947 5.947 5.947 0 0 1-5.947 5.949Zm0-9.457a3.515 3.515 0 1 0 3.515 3.515 3.516 3.516 0 0 0-3.512-3.513Z" transform="translate(-1832.15 -318.484)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-pwd_visible_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-recent"><defs><symbol viewBox="0 0 100 76" id="icon-recent_a"><path data-name="Union 199" d="M5.1 41.576a3.452 3.452 0 0 1 2.174-4.832l.117-.035a3.492 3.492 0 0 1 4.067 1.863 21.9 21.9 0 1 0 1.306-21.582l2.836-.25a3.516 3.516 0 0 1 .618 7L4.753 24.75c-.1.009-.205.013-.31.013a3.517 3.517 0 0 1-3.5-3.2l-.93-10.6a3.516 3.516 0 0 1 7-.616l.2 2.287A28.9 28.9 0 1 1 5.1 41.576Zm32.869-2.536L27.9 33.819A3.516 3.516 0 0 1 26 30.7V19.643a3.516 3.516 0 0 1 7.031 0v8.92L41.2 32.8a3.514 3.514 0 0 1-3.235 6.239Z" transform="translate(21.039 10)" /></symbol></defs><use xlink:href="#icon-recent_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-recent_active"><defs><symbol viewBox="0 0 100 76" id="icon-recent_active_a"><path data-name="Union 199" d="M5.1 41.576a3.452 3.452 0 0 1 2.174-4.832l.117-.035a3.492 3.492 0 0 1 4.067 1.863 21.9 21.9 0 1 0 1.306-21.582l2.836-.25a3.516 3.516 0 0 1 .618 7L4.753 24.75c-.1.009-.205.013-.31.013a3.517 3.517 0 0 1-3.5-3.2l-.93-10.6a3.516 3.516 0 0 1 7-.616l.2 2.287A28.9 28.9 0 1 1 5.1 41.576Zm32.869-2.536L27.9 33.819A3.516 3.516 0 0 1 26 30.7V19.643a3.516 3.516 0 0 1 7.031 0v8.92L41.2 32.8a3.514 3.514 0 0 1-3.235 6.239Z" transform="translate(21.039 10)" /></symbol></defs><use xlink:href="#icon-recent_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-recharge"><defs><symbol viewBox="0 0 60 60" id="icon-recharge_a"><g transform="translate(-2120 242)" clip-path="url(#icon_wd_cz1--svgSprite:all_clip-path)"><path d="M6 46a6.007 6.007 0 0 1-6-6V6a6.007 6.007 0 0 1 6-6h45a6.007 6.007 0 0 1 6 6v5.731a6.737 6.737 0 0 0-2.625-.527h-25.03a6.782 6.782 0 1 0 0 13.565h25.03A6.743 6.743 0 0 0 57 24.243V40a6.006 6.006 0 0 1-6 6Zm-.656-10.314v4.706a.891.891 0 0 0 1.781 0v-4.706a.891.891 0 1 0-1.781 0Zm0-10.026v4.706a.891.891 0 1 0 1.781 0V25.66a.891.891 0 0 0-1.781 0Zm0-10.025v4.7a.891.891 0 1 0 1.781 0v-4.7a.891.891 0 1 0-1.781 0Zm0-10.026v4.706a.891.891 0 0 0 1.781 0V5.609a.891.891 0 1 0-1.781 0Zm21.375 12.378a3.266 3.266 0 1 1 3.265 3.244 3.266 3.266 0 0 1-3.265-3.244Z" transform="translate(2122 -235)" /></g></symbol></defs><use xlink:href="#icon-recharge_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-refresh-2"><defs><symbol viewBox="0 0 27.675 28" id="icon-refresh-2_a"><path d="m0 18.972 9.548-.161-2.393 3.418a10.746 10.746 0 1 0-4.056-8.4c0 .306.013.617.04.921H.057c-.021-.3-.03-.612-.03-.921a13.827 13.827 0 0 1 26.559-5.386 13.824 13.824 0 0 1-21.2 16.313L3.113 28Z" /></symbol></defs><use xlink:href="#icon-refresh-2_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-refresh"><defs><symbol viewBox="0 0 24 25.144" id="icon-refresh_a"><path d="m1520.314-127.2 5.058-9.146 2.1 3.9a10.844 10.844 0 0 0 4.845-9.038c0-3.028-2-6.031-4-8 3.919 1.639 7.43 5.773 7.43 10.285a10.856 10.856 0 0 1-6.549 9.964l1.977 3.179Zm-8.572-10.858a10.86 10.86 0 0 1 6.548-9.965l-1.976-3.178 10.857 1.142-5.06 9.147-2.095-3.9a10.842 10.842 0 0 0-4.847 9.039c0 3.028 2 6.031 4 8-3.914-1.636-7.426-5.77-7.426-10.282Z" transform="translate(-1511.743 151.198)" /></symbol></defs><use xlink:href="#icon-refresh_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" id="icon-register_account"><defs><symbol viewBox="0 0 20.001 20" id="icon-register_account_a"><path d="M2.451 20.894A1.46 1.46 0 0 1 1 19.427v-.064a9.627 9.627 0 0 1 4.8-7.725 7.557 7.557 0 0 0 10.41 0A9.624 9.624 0 0 1 21 19.363a1.458 1.458 0 0 1-1.383 1.529h-.065ZM5.584 6.333a5.415 5.415 0 1 1 5.468 5.334H11a5.375 5.375 0 0 1-5.416-5.334Z" transform="translate(-1 -.894)" /></symbol></defs><use xlink:href="#icon-register_account_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-safe_center"><defs><symbol viewBox="0 0 13.372 16" id="icon-safe_center_a"><path d="M1600.052-103.178c-6.624-2.316-6.522-7.784-6.446-11.777.007-.36.016-.807.016-1.212a.683.683 0 0 1 .679-.686 7.364 7.364 0 0 0 5.5-2.091.672.672 0 0 1 .949 0 7.365 7.365 0 0 0 5.5 2.09.684.684 0 0 1 .68.686c0 .371.008.755.015 1.159v.052c.076 3.993.179 9.462-6.447 11.778a.669.669 0 0 1-.223.038.675.675 0 0 1-.223-.037Zm-5.075-12.321c0 .162-.005.327-.009.495v.075c-.074 3.912-.158 8.347 5.309 10.375 5.466-2.028 5.383-6.463 5.309-10.375v-.063q0-.258-.008-.506a8.413 8.413 0 0 1-5.3-2.026 8.413 8.413 0 0 1-5.301 2.024Zm4.063 6.639-1.51-1.523a.69.69 0 0 1 0-.97.676.676 0 0 1 .961 0l1.03 1.038 2.538-2.561a.674.674 0 0 1 .481-.2.671.671 0 0 1 .48.2.684.684 0 0 1 .2.485.682.682 0 0 1-.2.485l-3.02 3.046a.678.678 0 0 1-.481.2.673.673 0 0 1-.479-.2Z" transform="translate(-1593.59 119.14)" /></symbol></defs><use xlink:href="#icon-safe_center_a" fill="var(--theme-primary-color)" /></symbol><symbol  viewBox="64 64 896 896" fill="currentColor" aria-hidden="true" id="icon-searchIcon"><path d="M909.6 854.5 649.9 594.8C690.2 542.7 712 479 712 412c0-80.2-31.3-155.4-87.9-212.1-56.6-56.7-132-87.9-212.1-87.9s-155.5 31.3-212.1 87.9C143.2 256.5 112 331.8 112 412c0 80.1 31.3 155.5 87.9 212.1C256.5 680.8 331.8 712 412 712c67 0 130.6-21.8 182.7-62l259.7 259.6a8.2 8.2 0 0 0 11.6 0l43.6-43.5a8.2 8.2 0 0 0 0-11.6zM570.4 570.4C528 612.7 471.8 636 412 636s-116-23.3-158.4-65.6C211.3 528 188 471.8 188 412s23.3-116.1 65.6-158.4C296 211.3 352.2 188 412 188s116.1 23.2 158.4 65.6S636 352.2 636 412s-23.3 116.1-65.6 158.4z" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-search_record"><defs><symbol viewBox="0 0 35.999 36" id="icon-search_record_a"><path data-name="Union 159" d="M-5182.98-6307.534a18.078 18.078 0 0 1-5.724-3.871 18.109 18.109 0 0 1-3.873-5.724 17.7 17.7 0 0 1-1.423-6.981 17.881 17.881 0 0 1 1.405-6.978 17.957 17.957 0 0 1 3.844-5.724 17.858 17.858 0 0 1 12.749-5.3 17.861 17.861 0 0 1 12.751 5.3 17.957 17.957 0 0 1 3.844 5.724 17.882 17.882 0 0 1 1.406 6.978 17.739 17.739 0 0 1-1.423 6.981 18.108 18.108 0 0 1-3.872 5.724 18.089 18.089 0 0 1-5.724 3.871 17.711 17.711 0 0 1-6.981 1.424 17.706 17.706 0 0 1-6.979-1.424Zm-8.2-16.455a15.193 15.193 0 0 0 15.18 15.178 15.193 15.193 0 0 0 15.177-15.178 15.194 15.194 0 0 0-15.177-15.176 15.194 15.194 0 0 0-15.176 15.177Zm15.054 2.93a1.336 1.336 0 0 1-1.35-1.35v-11.667a1.337 1.337 0 0 1 1.35-1.352 1.337 1.337 0 0 1 1.353 1.352v10.2h10.072a1.368 1.368 0 0 1 1.35 1.471 1.334 1.334 0 0 1-1.35 1.35Z" transform="translate(5193.999 6342.11)" /></symbol></defs><use xlink:href="#icon-search_record_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-search_result_delete"><defs><symbol viewBox="0 0 21.351 24" id="icon-search_result_delete_a"><path data-name="Path 503" d="M1966.49 59.525c.1-.085.12-.114.141-.116 1.694-.211 1.694-.21 1.694 1.456v11.46c0 2.576-1.283 3.844-3.877 3.844-3.343 0-6.685.007-10.028 0a3.29 3.29 0 0 1-3.528-3.463c-.025-4.3-.007-8.6-.006-12.893 0-.1.019-.207.035-.376h1.8v12.95c0 1.486.47 1.954 1.952 1.955h10.027c1.277 0 1.787-.492 1.789-1.77q.011-6.128 0-12.256Z" transform="translate(-1948.928 -52.171)" /><path data-name="Path 504" d="M1962.479 44.734h3.736c.623 0 1.234.078 1.22.89-.012.767-.567.919-1.217.918q-9.5-.005-19 0c-.632 0-1.139-.163-1.137-.9s.5-.917 1.135-.914h3.791c.019-.313.033-.567.05-.821a2.086 2.086 0 0 1 2.251-2.146c2.279-.016 4.558-.007 6.837 0a2.084 2.084 0 0 1 2.331 2.291c.008.184.003.367.003.682Zm-9.559-.065h7.689c.149-1.093.123-1.127-.851-1.128h-5.959c-.988 0-.988.002-.879 1.128Z" transform="translate(-1946.084 -41.758)" /><path data-name="Path 505" d="M1964.983 67.255v-4.456c0-.552.143-1.01.74-1.162.641-.164 1.084.264 1.092 1.088.015 1.644.005 3.289.005 4.933 0 1.379.009 2.758 0 4.138-.007.786-.369 1.225-.969 1.185-.743-.05-.86-.587-.861-1.19q-.008-2.268-.007-4.536Z" transform="translate(-1957.294 -53.53)" /><path data-name="Path 506" d="M1977.18 67.343v4.453c0 .8-.333 1.236-.932 1.2-.745-.039-.857-.56-.856-1.176.007-3 0-5.99 0-8.985 0-.81.325-1.232.929-1.2.746.038.864.553.859 1.172-.007 1.514 0 3.025 0 4.536Z" transform="translate(-1963.469 -53.55)" /></symbol></defs><use xlink:href="#icon-search_result_delete_a" /></symbol><symbol  viewBox="0 0 35.969 21.998" fill="currentColor" aria-hidden="true" id="icon-select_arrow"><path d="M35.383 3.4 19.61 21.143a2 2 0 0 1-3.058.271 2.037 2.037 0 0 1-.23-.274L.552 3.4A1.992 1.992 0 0 1 3.368.583l14.6 16.422L32.568.583A1.992 1.992 0 1 1 35.385 3.4Z" fill="var(--theme-text-color-lighten)" /></symbol><symbol  viewBox="0 0 35.969 21.998" fill="currentColor" aria-hidden="true" id="icon-select_arrow_green"><path d="M35.383 3.4 19.61 21.143a2 2 0 0 1-3.058.271 2.037 2.037 0 0 1-.23-.274L.552 3.4A1.992 1.992 0 0 1 3.368.583l14.6 16.422L32.568.583A1.992 1.992 0 1 1 35.385 3.4Z" fill="#7DB39E" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-select_down"><defs><symbol viewBox="0 0 12 7" id="icon-select_down_a"><path d="M300.734 37.264A1 1 0 0 0 300 37l-9.973.066a1 1 0 0 0-.731.264.953.953 0 0 0 0 1.387l4.986 4.953c.067.066.2.132.266.2l.067.066a1.045 1.045 0 0 0 1.063-.2l4.987-5.019a1.036 1.036 0 0 0 .069-1.453Z" transform="translate(-289 -37)" /></symbol></defs><use xlink:href="#icon-select_down_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-share"><defs><symbol viewBox="0 0 40 40" id="icon-share_a"><path d="M39.084 11.043a9.472 9.472 0 0 1-.628.812q-4.419 4.614-8.851 9.219a1.176 1.176 0 0 1-1.126.451 1.1 1.1 0 0 1-.868-1.194V15.877c-.042-.031-.059-.054-.078-.055a12.329 12.329 0 0 0-9.671 3.139 12.019 12.019 0 0 0-2.493 3.316 1.08 1.08 0 0 1-1.481.576.968.968 0 0 1-.6-.867 18.273 18.273 0 0 1 .6-6.3A13.785 13.785 0 0 1 24.744 6a22.662 22.662 0 0 1 2.5-.254c.109-.011.219-.012.364-.02v-.383c0-1.3.019-2.6-.008-3.9A1.36 1.36 0 0 1 28.4 0h.537a6.223 6.223 0 0 1 .763.582q4.389 4.546 8.759 9.112a9.284 9.284 0 0 1 .627.811ZM40 33.7V19.919a1.852 1.852 0 0 0-3.7 0V33.7a2.6 2.6 0 0 1-2.6 2.6H6.3a2.6 2.6 0 0 1-2.6-2.6V12.6a2.6 2.6 0 0 1 2.6-2.589h5.469a1.852 1.852 0 0 0 0-3.7H6.3A6.3 6.3 0 0 0 0 12.6v21.1A6.3 6.3 0 0 0 6.3 40h27.4a6.3 6.3 0 0 0 6.3-6.3Z" /></symbol></defs><use xlink:href="#icon-share_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 130 130" id="icon-skin2_default_game"><defs><symbol viewBox="0 0 130 130" id="icon-skin2_default_game_a"><path data-name="\u8DEF\u5F84 19640" d="M82.082 11.842c-.078-.231-.16-.6-.259-1.011-.646-2.627-1.253-5.109-3.652-6.025L66.78.472a7.15 7.15 0 0 0-6.631.822l-.7.63a34.39 34.39 0 0 1-1.9 2H36.553a33.43 33.43 0 0 1-1.609-1.855L34.13 1.3A7.112 7.112 0 0 0 27.5.469L16.1 4.8c-2.388.908-2.987 3.363-3.625 5.966a3.318 3.318 0 0 0-.149.755.012.012 0 0 0 .008 0C8.45 19.176-10.02 57.941 7.271 69.385a6.585 6.585 0 0 0 8.017-.634L28.841 56.6a6.4 6.4 0 0 1 4.271-1.661h28.05a6.408 6.408 0 0 1 4.271 1.661l13.553 12.15a6.673 6.673 0 0 0 4.455 1.726 6.311 6.311 0 0 0 3.649-1.156c15.26-10.707 1.511-43.936-5.007-57.48m-45.2 21.206h-4.802V37.6a3.478 3.478 0 1 1-6.952.252V33.05h-4.55a3.478 3.478 0 1 1-.252-6.952h4.802v-4.55a3.478 3.478 0 1 1 6.952-.252v4.798h4.55a3.478 3.478 0 1 1 .259 6.952m24.628 6.9H61.5a5.18 5.18 0 1 1 .017 0m10.375-10.374h-.03a5.18 5.18 0 1 1 .02 0" transform="translate(18.056 29.609)" /></symbol></defs><use xlink:href="#icon-skin2_default_game_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-slide_icon"><defs><symbol viewBox="0 0 20.413 12.425" id="icon-slide_icon_a"><path d="M5666.2 158.425a1.2 1.2 0 1 1 0-2.4h8a1.2 1.2 0 1 1 0 2.4Zm12.322-.522a1.2 1.2 0 0 1 0-1.7l2.793-2.794H5666.2a1.2 1.2 0 1 1 0-2.4h15.115l-2.793-2.794a1.2 1.2 0 1 1 1.7-1.7l4.841 4.841a1.2 1.2 0 0 1 0 1.7l-4.841 4.841a1.2 1.2 0 0 1-1.7 0Zm-12.322-9.5a1.2 1.2 0 1 1 0-2.4h8a1.2 1.2 0 1 1 0 2.4Z" transform="translate(-5665 -146)" /></symbol></defs><use xlink:href="#icon-slide_icon_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-slots"><defs><symbol viewBox="0 0 100 76" id="icon-slots_a"><path data-name="Union 219" d="M4.005 45a4 4 0 0 1-4-4V4a4 4 0 0 1 4-4H86a4 4 0 0 1 4 4v37a4 4 0 0 1-4 4ZM60 7v31a2 2 0 0 0 2 2h21a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H62a2 2 0 0 0-2 2ZM32.5 7v31a2 2 0 0 0 2 2h21a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-21a2 2 0 0 0-1.995 2ZM5 7v31a2 2 0 0 0 2 2h21a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2Zm60.674 26.626c-1.013-5.238 1.87-8.651 9.47-14.446a7.026 7.026 0 0 1-3.2-.555 6.3 6.3 0 0 0-3.154-.516 4.318 4.318 0 0 0-2.781 2.223h-3.504V12.5h3.714c-.052.9.624.767 1.092.5a4.443 4.443 0 0 1 2.544-.424 33.446 33.446 0 0 1 4.028 1.058 13.338 13.338 0 0 0 4.677.583 4.684 4.684 0 0 0 3.169-1.35l2.027 2.342c-9.119 9.207-6.9 14.923-5.883 18.414Zm-27.5 0c-1.014-5.238 1.87-8.651 9.469-14.446a7.022 7.022 0 0 1-3.2-.555 6.3 6.3 0 0 0-3.155-.516 4.314 4.314 0 0 0-2.78 2.223H35V12.5h3.713c-.051.9.624.767 1.092.5a4.446 4.446 0 0 1 2.545-.424 33.474 33.474 0 0 1 4.027 1.058 13.338 13.338 0 0 0 4.677.583 4.684 4.684 0 0 0 3.169-1.35l2.027 2.342c-9.119 9.207-6.9 14.923-5.883 18.414Zm-27.5 0c-1.014-5.238 1.87-8.651 9.47-14.446a7.026 7.026 0 0 1-3.2-.555 6.3 6.3 0 0 0-3.155-.516 4.318 4.318 0 0 0-2.78 2.223H7.5V12.5h3.714c-.052.9.624.767 1.092.5a4.443 4.443 0 0 1 2.544-.424 33.49 33.49 0 0 1 4.027 1.058 13.335 13.335 0 0 0 4.677.583 4.684 4.684 0 0 0 3.169-1.35l2.026 2.342c-9.119 9.207-6.9 14.923-5.883 18.414Z" transform="translate(4.998 15)" /></symbol></defs><use xlink:href="#icon-slots_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-slots_2"><use xlink:href="#icon-slots_2_a" /><defs><symbol viewBox="0 0 100 76" id="icon-slots_2_a"><path data-name="icon_dtfl_dz_0" d="M-293.314-8565.123h.031a2.061 2.061 0 0 1 0 .22 1.917 1.917 0 0 1-.031-.22Zm-17.942.22a21.768 21.768 0 0 1 1.05-5.6 17.532 17.532 0 0 1 2.356-4.311 16.8 16.8 0 0 1 5.355-4.956c.984-.5 1.724-.765 3-1.292a22.088 22.088 0 0 0 3-1.722 16.646 16.646 0 0 0 1.927-1.512c.46-.442.751-.943.645-1.075-.221-.263-2.21 1.309-4.5 1.723a11.591 11.591 0 0 1-4.281-.22c-1.105-.276-2.692-.781-5.143-1.29a6.864 6.864 0 0 0-1.5 0 4.52 4.52 0 0 0-3 1.723 8.15 8.15 0 0 0-1.184 3.232h-3.315l2.705-14.271h4.069v2.153c1.817-2.161 2.312-3.251 6.078-2.534.884.169 1.532.262 1.565.275-.08-.016-.062 0-.035 0h.035c.088.018.522.053 1 .15a22.336 22.336 0 0 1 3.857 1.295 18.972 18.972 0 0 0 3.428 1.081 9.9 9.9 0 0 0 4.5-.221 11.72 11.72 0 0 0 2.57-1.075 11.294 11.294 0 0 1 2.46 2.048 25.317 25.317 0 0 0-1.606 2.041c-1.546 2.462-3.074 5.265-3.856 6.469a24.053 24.053 0 0 0-3.214 8.62 20.274 20.274 0 0 0-.221 4.525c.042 2.112.115 3.924.181 4.529-1.64.075-3.362.153-4.9.22Zm-39.214-.22h.031a2.094 2.094 0 0 1 0 .22 1.45 1.45 0 0 1-.03-.22Zm-17.942.22a21.761 21.761 0 0 1 1.05-5.6 17.591 17.591 0 0 1 2.353-4.311 16.838 16.838 0 0 1 5.358-4.956c.985-.5 1.724-.765 3-1.292a22.072 22.072 0 0 0 3-1.722 17.4 17.4 0 0 0 1.927-1.512c.46-.442.749-.943.643-1.075-.221-.263-2.21 1.309-4.5 1.723a11.6 11.6 0 0 1-4.283-.22c-1.105-.276-2.69-.781-5.143-1.29a6.865 6.865 0 0 0-1.5 0 4.513 4.513 0 0 0-3 1.727 8.169 8.169 0 0 0-1.189 3.229H-374l2.705-14.271h4.069v2.153c1.814-2.161 2.312-3.251 6.078-2.534.884.169 1.532.262 1.565.275-.08-.016-.062 0-.035 0h.035c.088.018.522.053 1 .15a22.353 22.353 0 0 1 3.857 1.295 18.959 18.959 0 0 0 3.426 1.081 9.9 9.9 0 0 0 4.5-.221 11.5 11.5 0 0 0 2.573-1.075 11.38 11.38 0 0 1 2.462 2.046 23.712 23.712 0 0 0-1.607 2.043c-1.547 2.462-3.074 5.265-3.854 6.469a24.054 24.054 0 0 0-3.216 8.62 20.28 20.28 0 0 0-.221 4.527c.046 2.11.115 3.922.181 4.527-1.64.075-3.362.153-4.9.22Zm48.978-3.923h.035a2.742 2.742 0 0 1 0 .322 2.184 2.184 0 0 1-.035-.333Zm-26.912.319a32.981 32.981 0 0 1 1.574-8.4c.744-2.039 2.112-8.074 4.767-11.84 2.736-3.878 4.036-5.691 6.118-6.754 1.472-.746 3.273-1.827 5.183-2.622a32.286 32.286 0 0 0 4.5-2.581 25.773 25.773 0 0 0 2.891-2.263c.689-.664 1.123-1.422.966-1.621-.318-.387-3.331 1.974-6.745 2.592a17.525 17.525 0 0 1-6.429-.324c-1.644-.412-4.035-1.169-7.711-1.937a10.2 10.2 0 0 0-2.25 0 6.807 6.807 0 0 0-4.5 2.581 12.4 12.4 0 0 0-1.781 4.848h-4.966v-19.389h6.1v3.229c2.725-3.243 7.514-6.891 13.174-5.816 1.326.253 2.3.4 2.347.417-.117-.021-.091 0-.053 0s.077.013.053 0c.135.024.785.086 1.505.234a33.317 33.317 0 0 1 5.785 1.938 28.146 28.146 0 0 0 5.142 1.616 14.9 14.9 0 0 0 6.747-.327 17.54 17.54 0 0 0 3.857-1.616 17.456 17.456 0 0 1 3.695 3.071 34.426 34.426 0 0 0-2.411 3.069c-2.316 3.69-4.608 7.893-5.782 9.7a36.141 36.141 0 0 0-4.82 12.928 100.528 100.528 0 0 0-.321 12.155c.068 3.162.17 5.882.274 6.789-2.462.115-5.043.221-7.344.319Zm61.75-22.777Zm-57.153 0Zm57.138-.015.111-.108c.044-.034-.08.1-.1.123Zm-57.153 0a1.3 1.3 0 0 1 .109-.105c.039-.037-.082.094-.093.12Zm35.408-22.154v-.006Zm-.02-.023a1.82 1.82 0 0 1 .159-.159c.064-.053-.121.144-.141.183Z" transform="translate(380 8629.994)" /></symbol></defs></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 100 76" id="icon-slots_active"><defs><symbol viewBox="0 0 100 76" id="icon-slots_active_a"><path data-name="Union 219" d="M4.005 45a4 4 0 0 1-4-4V4a4 4 0 0 1 4-4H86a4 4 0 0 1 4 4v37a4 4 0 0 1-4 4ZM60 7v31a2 2 0 0 0 2 2h21a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H62a2 2 0 0 0-2 2ZM32.5 7v31a2 2 0 0 0 2 2h21a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-21a2 2 0 0 0-1.995 2ZM5 7v31a2 2 0 0 0 2 2h21a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2Zm60.674 26.626c-1.013-5.238 1.87-8.651 9.47-14.446a7.026 7.026 0 0 1-3.2-.555 6.3 6.3 0 0 0-3.154-.516 4.318 4.318 0 0 0-2.781 2.223h-3.504V12.5h3.714c-.052.9.624.767 1.092.5a4.443 4.443 0 0 1 2.544-.424 33.446 33.446 0 0 1 4.028 1.058 13.338 13.338 0 0 0 4.677.583 4.684 4.684 0 0 0 3.169-1.35l2.027 2.342c-9.119 9.207-6.9 14.923-5.883 18.414Zm-27.5 0c-1.014-5.238 1.87-8.651 9.469-14.446a7.022 7.022 0 0 1-3.2-.555 6.3 6.3 0 0 0-3.155-.516 4.314 4.314 0 0 0-2.78 2.223H35V12.5h3.713c-.051.9.624.767 1.092.5a4.446 4.446 0 0 1 2.545-.424 33.474 33.474 0 0 1 4.027 1.058 13.338 13.338 0 0 0 4.677.583 4.684 4.684 0 0 0 3.169-1.35l2.027 2.342c-9.119 9.207-6.9 14.923-5.883 18.414Zm-27.5 0c-1.014-5.238 1.87-8.651 9.47-14.446a7.026 7.026 0 0 1-3.2-.555 6.3 6.3 0 0 0-3.155-.516 4.318 4.318 0 0 0-2.78 2.223H7.5V12.5h3.714c-.052.9.624.767 1.092.5a4.443 4.443 0 0 1 2.544-.424 33.49 33.49 0 0 1 4.027 1.058 13.335 13.335 0 0 0 4.677.583 4.684 4.684 0 0 0 3.169-1.35l2.026 2.342c-9.119 9.207-6.9 14.923-5.883 18.414Z" transform="translate(4.998 15)" /></symbol></defs><use xlink:href="#icon-slots_active_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-slots_active_green"><defs><symbol viewBox="0 0 40.5 24.477" id="icon-slots_active_green_a"><path d="M-337.492-8594.62h.014a.946.946 0 0 1 0 .1.971.971 0 0 1-.014-.1Zm-8.118.1a9.858 9.858 0 0 1 .475-2.535 7.945 7.945 0 0 1 1.066-1.95 7.6 7.6 0 0 1 2.423-2.242c.445-.226.78-.346 1.357-.585a9.914 9.914 0 0 0 1.356-.779 7.67 7.67 0 0 0 .872-.684c.208-.2.34-.427.292-.486-.1-.119-1 .592-2.037.779a5.251 5.251 0 0 1-1.937-.1c-.5-.125-1.218-.354-2.327-.584a3.165 3.165 0 0 0-.678 0 2.049 2.049 0 0 0-1.358.781 3.679 3.679 0 0 0-.536 1.461h-1.5l1.224-6.457h1.841v.974c.822-.978 1.046-1.471 2.75-1.146.4.076.693.119.708.125-.036-.007-.028 0-.016 0h.016c.04.008.236.024.454.068a10.02 10.02 0 0 1 1.745.586 8.512 8.512 0 0 0 1.551.488 4.483 4.483 0 0 0 2.036-.1 5.256 5.256 0 0 0 1.163-.486 5.106 5.106 0 0 1 1.113.926 11.166 11.166 0 0 0-.726.925c-.7 1.113-1.391 2.382-1.745 2.927a10.882 10.882 0 0 0-1.454 3.9 9.162 9.162 0 0 0-.1 2.047c.019.956.052 1.775.082 2.05l-2.215.1Zm-17.743-.1h.014a.946.946 0 0 1 0 .1.668.668 0 0 1-.014-.1Zm-8.118.1a9.858 9.858 0 0 1 .475-2.535 7.974 7.974 0 0 1 1.065-1.95 7.609 7.609 0 0 1 2.424-2.242c.446-.226.78-.346 1.357-.585a9.925 9.925 0 0 0 1.356-.779 7.756 7.756 0 0 0 .872-.684c.208-.2.339-.427.291-.486-.1-.119-1 .592-2.036.779a5.256 5.256 0 0 1-1.938-.1c-.5-.125-1.217-.354-2.327-.584a3.163 3.163 0 0 0-.678 0 2.048 2.048 0 0 0-1.356.781 3.7 3.7 0 0 0-.538 1.461H-374l1.224-6.457h1.841v.974c.821-.978 1.046-1.471 2.75-1.146.4.076.693.119.708.125-.036-.007-.028 0-.016 0h.016c.04.008.236.024.454.068a10.086 10.086 0 0 1 1.745.586 8.529 8.529 0 0 0 1.55.488 4.482 4.482 0 0 0 2.036-.1 5.249 5.249 0 0 0 1.164-.486 5.136 5.136 0 0 1 1.114.926 10.744 10.744 0 0 0-.727.925c-.7 1.113-1.391 2.382-1.744 2.927a10.885 10.885 0 0 0-1.455 3.9 9.158 9.158 0 0 0-.1 2.047c.021.956.052 1.775.082 2.05l-2.215.1Zm22.161-1.775h.016a1.256 1.256 0 0 1 0 .146.985.985 0 0 1-.016-.151Zm-12.177.145a14.913 14.913 0 0 1 .712-3.8c.337-.923.956-3.653 2.157-5.357 1.238-1.755 1.826-2.575 2.768-3.056.666-.338 1.481-.827 2.345-1.187a14.6 14.6 0 0 0 2.036-1.168 11.573 11.573 0 0 0 1.308-1.024c.312-.3.508-.643.437-.732-.144-.176-1.507.893-3.052 1.172a7.891 7.891 0 0 1-2.909-.146c-.744-.187-1.826-.529-3.489-.877a4.659 4.659 0 0 0-1.018 0 3.08 3.08 0 0 0-2.036 1.17 5.608 5.608 0 0 0-.806 2.192h-2.247v-8.772h2.762v1.461c1.233-1.468 3.4-3.118 5.961-2.632.6.114 1.039.179 1.062.188-.053-.01-.041 0-.024 0s.035.006.024 0c.061.011.355.039.681.106a14.89 14.89 0 0 1 2.618.877 12.742 12.742 0 0 0 2.326.73 6.743 6.743 0 0 0 3.053-.146 7.936 7.936 0 0 0 1.745-.732 7.9 7.9 0 0 1 1.672 1.39 15.754 15.754 0 0 0-1.091 1.389c-1.048 1.67-2.085 3.571-2.616 4.389a16.342 16.342 0 0 0-2.181 5.849 45.5 45.5 0 0 0-.145 5.5c.031 1.432.077 2.662.124 3.072-1.114.053-2.282.1-3.323.145Zm27.94-10.306Zm-25.86 0Zm25.853-.007.05-.049c.02-.016-.036.044-.043.056Zm-25.86 0a.654.654 0 0 1 .049-.049c.018-.016-.037.044-.042.056Zm16.021-10.024.001-.004Zm-.009-.01a.775.775 0 0 1 .072-.072c.029-.024-.055.064-.064.082Z" transform="translate(374 8619)" /></symbol></defs><use xlink:href="#icon-slots_active_green_a" fill="#333" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-slots_green"><defs><symbol viewBox="0 0 40.5 24.477" id="icon-slots_green_a"><path d="M-337.492-8594.62h.014a.946.946 0 0 1 0 .1.971.971 0 0 1-.014-.1Zm-8.118.1a9.858 9.858 0 0 1 .475-2.535 7.945 7.945 0 0 1 1.066-1.95 7.6 7.6 0 0 1 2.423-2.242c.445-.226.78-.346 1.357-.585a9.914 9.914 0 0 0 1.356-.779 7.67 7.67 0 0 0 .872-.684c.208-.2.34-.427.292-.486-.1-.119-1 .592-2.037.779a5.251 5.251 0 0 1-1.937-.1c-.5-.125-1.218-.354-2.327-.584a3.165 3.165 0 0 0-.678 0 2.049 2.049 0 0 0-1.358.781 3.679 3.679 0 0 0-.536 1.461h-1.5l1.224-6.457h1.841v.974c.822-.978 1.046-1.471 2.75-1.146.4.076.693.119.708.125-.036-.007-.028 0-.016 0h.016c.04.008.236.024.454.068a10.02 10.02 0 0 1 1.745.586 8.512 8.512 0 0 0 1.551.488 4.483 4.483 0 0 0 2.036-.1 5.256 5.256 0 0 0 1.163-.486 5.106 5.106 0 0 1 1.113.926 11.166 11.166 0 0 0-.726.925c-.7 1.113-1.391 2.382-1.745 2.927a10.882 10.882 0 0 0-1.454 3.9 9.162 9.162 0 0 0-.1 2.047c.019.956.052 1.775.082 2.05l-2.215.1Zm-17.743-.1h.014a.946.946 0 0 1 0 .1.668.668 0 0 1-.014-.1Zm-8.118.1a9.858 9.858 0 0 1 .475-2.535 7.974 7.974 0 0 1 1.065-1.95 7.609 7.609 0 0 1 2.424-2.242c.446-.226.78-.346 1.357-.585a9.925 9.925 0 0 0 1.356-.779 7.756 7.756 0 0 0 .872-.684c.208-.2.339-.427.291-.486-.1-.119-1 .592-2.036.779a5.256 5.256 0 0 1-1.938-.1c-.5-.125-1.217-.354-2.327-.584a3.163 3.163 0 0 0-.678 0 2.048 2.048 0 0 0-1.356.781 3.7 3.7 0 0 0-.538 1.461H-374l1.224-6.457h1.841v.974c.821-.978 1.046-1.471 2.75-1.146.4.076.693.119.708.125-.036-.007-.028 0-.016 0h.016c.04.008.236.024.454.068a10.086 10.086 0 0 1 1.745.586 8.529 8.529 0 0 0 1.55.488 4.482 4.482 0 0 0 2.036-.1 5.249 5.249 0 0 0 1.164-.486 5.136 5.136 0 0 1 1.114.926 10.744 10.744 0 0 0-.727.925c-.7 1.113-1.391 2.382-1.744 2.927a10.885 10.885 0 0 0-1.455 3.9 9.158 9.158 0 0 0-.1 2.047c.021.956.052 1.775.082 2.05l-2.215.1Zm22.161-1.775h.016a1.256 1.256 0 0 1 0 .146.985.985 0 0 1-.016-.151Zm-12.177.145a14.913 14.913 0 0 1 .712-3.8c.337-.923.956-3.653 2.157-5.357 1.238-1.755 1.826-2.575 2.768-3.056.666-.338 1.481-.827 2.345-1.187a14.6 14.6 0 0 0 2.036-1.168 11.573 11.573 0 0 0 1.308-1.024c.312-.3.508-.643.437-.732-.144-.176-1.507.893-3.052 1.172a7.891 7.891 0 0 1-2.909-.146c-.744-.187-1.826-.529-3.489-.877a4.659 4.659 0 0 0-1.018 0 3.08 3.08 0 0 0-2.036 1.17 5.608 5.608 0 0 0-.806 2.192h-2.247v-8.772h2.762v1.461c1.233-1.468 3.4-3.118 5.961-2.632.6.114 1.039.179 1.062.188-.053-.01-.041 0-.024 0s.035.006.024 0c.061.011.355.039.681.106a14.89 14.89 0 0 1 2.618.877 12.742 12.742 0 0 0 2.326.73 6.743 6.743 0 0 0 3.053-.146 7.936 7.936 0 0 0 1.745-.732 7.9 7.9 0 0 1 1.672 1.39 15.754 15.754 0 0 0-1.091 1.389c-1.048 1.67-2.085 3.571-2.616 4.389a16.342 16.342 0 0 0-2.181 5.849 45.5 45.5 0 0 0-.145 5.5c.031 1.432.077 2.662.124 3.072-1.114.053-2.282.1-3.323.145Zm27.94-10.306Zm-25.86 0Zm25.853-.007.05-.049c.02-.016-.036.044-.043.056Zm-25.86 0a.654.654 0 0 1 .049-.049c.018-.016-.037.044-.042.056Zm16.021-10.024.001-.004Zm-.009-.01a.775.775 0 0 1 .072-.072c.029-.024-.055.064-.064.082Z" transform="translate(374 8619)" /></symbol></defs><use xlink:href="#icon-slots_green_a" fill="#ADB6C4" /></symbol><symbol  viewBox="64 64 896 896" fill="currentColor" aria-hidden="true" id="icon-success"><path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm193.5 301.7-210.6 292a31.8 31.8 0 0 1-51.7 0L318.5 484.9c-3.8-5.3 0-12.7 6.5-12.7h46.9c10.2 0 19.9 4.9 25.9 13.3l71.2 98.8 157.2-218c6-8.3 15.6-13.3 25.9-13.3H699c6.5 0 10.3 7.4 6.5 12.7z" fill="#52C41A" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-tab_left"><defs><symbol viewBox="0 0 21.999 35.998" id="icon-tab_left_a"><path d="m2209.279 137.564-17.743-15.773a2.024 2.024 0 0 1-.271-.228 2.009 2.009 0 0 1 0-2.83 2.02 2.02 0 0 1 .274-.23l17.74-15.77a1.992 1.992 0 0 1 2.817 2.816l-16.422 14.6 16.422 14.6a1.992 1.992 0 0 1-2.817 2.817Z" transform="translate(-2190.681 -102.15)" /></symbol></defs><use xlink:href="#icon-tab_left_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 12.928 22.67" id="icon-tab_right"><defs><symbol viewBox="0 0 12.928 22.67" id="icon-tab_right_a"><path d="M10.806 21.6a.961.961 0 0 1-.7-.256L.259 11.181a.889.889 0 0 1 0-1.242.81.81 0 0 1 .6-.267.824.824 0 0 1 .607.267l9.34 9.6 9.326-9.6a.834.834 0 0 1 .61-.267.818.818 0 0 1 .6.267.882.882 0 0 1 0 1.242L11.5 21.348a1 1 0 0 1-.638.25Z" transform="rotate(-90 6.463 15.635)" /></symbol></defs><use xlink:href="#icon-tab_right_a" fill="#FFF" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-ticked"><defs><symbol viewBox="0 0 20 15" id="icon-ticked_a"><path d="m1234.22-597.615-6.584-5.628a1.524 1.524 0 0 1-.149-2.141 1.5 1.5 0 0 1 2.128-.15l5.438 4.648 9.417-10.834a1.5 1.5 0 0 1 2.128-.15 1.525 1.525 0 0 1 .149 2.141l-10.4 11.964a1.5 1.5 0 0 1-1.139.522 1.494 1.494 0 0 1-.988-.372Z" transform="translate(-1227.117 612.242)" /></symbol></defs><use xlink:href="#icon-ticked_a" fill="var(--theme-web_filter_gou)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 24.846 40" id="icon-to_top"><defs><symbol viewBox="0 0 12.389 19.945" id="icon-to_top_a"><path d="M37.695 23h12c.13 0 .195.13.195.26s-.065.547-.195.547h-12c-.13 0-.195-.417-.195-.547s.065-.26.195-.26Zm6 2.924a8.169 8.169 0 0 1 4.287 7.276 2.923 2.923 0 0 1 1.429 3.118 3.05 3.05 0 0 1-2.339 2.664c-.65-.065-.455-.52-.455-.52l-.195-.845s-.91 1.364-1.169 1.364h-3.248c-.26 0-1.169-1.364-1.169-1.364l-.195.845s.13.455-.455.52a3.05 3.05 0 0 1-2.339-2.664 3.188 3.188 0 0 1 1.559-3.118 8.408 8.408 0 0 1 4.288-7.276Zm-1.755 5.392a1.755 1.755 0 1 0 3.508 0 1.755 1.755 0 1 0-3.508 0Zm.455 10.72a.375.375 0 0 0 .39-.39v-1.819a.39.39 0 1 0-.78 0v1.819a.374.374 0 0 0 .395.39Zm1.364.91a.419.419 0 0 0 .39-.39v-2.664a.39.39 0 0 0-.78 0v2.664a.419.419 0 0 0 .39.389Zm1.234-1.364a.374.374 0 0 0 .39-.39v-1.3a.39.39 0 0 0-.78 0v1.3a.374.374 0 0 0 .391.389Z" transform="translate(-37.5 -23)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-to_top_a" fill="var(--theme-primary-font-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-visible"><defs><symbol viewBox="0 0 26 17.776" id="icon-visible_a"><path d="M1858.15 327.364a13.956 13.956 0 0 0-26 0l.069.007-.069.007a13.955 13.955 0 0 0 26 0l-.07-.007Zm-13.007 5.9a5.946 5.946 0 1 1 5.947-5.947 5.947 5.947 0 0 1-5.947 5.949Zm0-9.457a3.515 3.515 0 1 0 3.515 3.515 3.516 3.516 0 0 0-3.512-3.513Z" transform="translate(-1832.15 -318.484)" fill-rule="evenodd" /></symbol></defs><use xlink:href="#icon-visible_a" fill="var(--theme-primary-color)" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-wallet"><defs><symbol viewBox="0 0 54 46" id="icon-wallet_a"><path d="M42 46H0a6.007 6.007 0 0 1-6-6V6a6.007 6.007 0 0 1 6-6h42a6.007 6.007 0 0 1 6 6v9.333H35.75a7.667 7.667 0 1 0 0 15.333H48V40a6.007 6.007 0 0 1-6 6Zm6-17.888H35.75a5.111 5.111 0 0 1 0-10.222H48v10.221Zm-9.644-7.987A2.875 2.875 0 1 0 41.236 23a2.875 2.875 0 0 0-2.88-2.875Z" transform="translate(6)" /></symbol></defs><use xlink:href="#icon-wallet_a" fill="var(--theme-text-person-color)" /></symbol><symbol  viewBox="64 64 896 896" fill="currentColor" aria-hidden="true" id="icon-warning"><path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm-32 232c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v272c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V296zm32 440a48.01 48.01 0 0 1 0-96 48.01 48.01 0 0 1 0 96z" fill="#FAAD14" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-withdraw"><defs><symbol viewBox="0 0 60 60" id="icon-withdraw_a"><g transform="translate(-2198 241)" clip-path="url(#icon_wd_tx1--svgSprite:all_clip-path)"><path data-name="Subtraction 44" d="M1540.967-24.951h-44.932a6.042 6.042 0 0 1-6.035-6.033v-7.766a10.445 10.445 0 0 0 6.671-9.7 10.447 10.447 0 0 0-6.671-9.7v-7.818a6.043 6.043 0 0 1 6.036-6.032h44.935a6.04 6.04 0 0 1 6.029 6.032v7.728a10.412 10.412 0 0 0-6.917 9.788 10.421 10.421 0 0 0 6.917 9.794v7.675a6.037 6.037 0 0 1-6.03 6.031Zm-35.834-29.793a.108.108 0 0 0-.111.112v16.249a.1.1 0 0 0 .01.035v.012a.255.255 0 0 1 .011.031.126.126 0 0 0 .085.034h26.739a.118.118 0 0 0 .1-.112v-16.249a.107.107 0 0 0-.1-.112ZM1525.2-57.1a2.14 2.14 0 0 0 .354.774h4.5l-.9-3.918a.114.114 0 0 0-.1-.1.1.1 0 0 0-.027 0l-2.919.662-2.3.544-12.185 2.806h10.213l3.014-.7.352-.077Zm2.231 16.517h-17.852a1.089 1.089 0 0 0-.017-.241 1.9 1.9 0 0 0-.258-.774.266.266 0 0 0-.061-.165 2.386 2.386 0 0 0-.887-.818l-.017-.018h-.017a.435.435 0 0 0-.19-.068 1.217 1.217 0 0 0-.526-.137.871.871 0 0 0-.293-.036h-.007v-7.345a2.3 2.3 0 0 0 1.956-1.111 2.22 2.22 0 0 0 .318-1.161h17.852a2.229 2.229 0 0 0 .3 1.144 2.235 2.235 0 0 0 1.946 1.129v7.345a2.255 2.255 0 0 0-2.247 2.256Zm-8.939-9.361a3.432 3.432 0 0 0-3.427 3.428 3.436 3.436 0 0 0 3.427 3.436 3.44 3.44 0 0 0 3.436-3.436 3.436 3.436 0 0 0-3.437-3.431Z" transform="translate(709.501 -162.499)" /></g></symbol></defs><use xlink:href="#icon-withdraw_a" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-withdraw_exchange_pwd"><defs><symbol viewBox="0 0 22 14.99" id="icon-withdraw_exchange_pwd_a"><path d="M-2392.6-1224.8a1.92 1.92 0 0 1-1.921-1.921v-7.388h22v7.388a1.921 1.921 0 0 1-1.921 1.921Zm.714-6.976v.657a.711.711 0 0 0 .711.711h4.1a.711.711 0 0 0 .711-.711v-.657a.711.711 0 0 0-.711-.711h-4.1a.711.711 0 0 0-.715.707Zm-2.635-4.429v-1.664a1.92 1.92 0 0 1 1.921-1.921h18.158a1.921 1.921 0 0 1 1.921 1.921v1.664Z" transform="translate(2394.524 1239.793)" /></symbol></defs><use xlink:href="#icon-withdraw_exchange_pwd_a" fill="#E94D3C" /></symbol><symbol   fill="currentColor" aria-hidden="true" viewBox="0 0 1 1" id="icon-withdraw_login_pwd"><defs><symbol viewBox="0 0 18.013 18.998" id="icon-withdraw_login_pwd_a"><path d="m8.587 15.229 1.908-1.987a5.939 5.939 0 0 0 6.725-1.363 6.561 6.561 0 0 0 0-9.013 5.959 5.959 0 0 0-8.42-.238 5.935 5.935 0 0 0-.238.238 6.477 6.477 0 0 0-1.796 4.508 6.59 6.59 0 0 0 .485 2.492l-5.84 6.077a.573.573 0 0 0-.16.355L1 19.117a.574.574 0 0 0 .493.625l2.22.258h.061a.542.542 0 0 0 .377-.154.585.585 0 0 0 .174-.442L4.277 17.9l1.445.051a.522.522 0 0 0 .413-.168.6.6 0 0 0 .16-.428l-.051-1.5 1.449.051a.533.533 0 0 0 .41-.168Zm5.042-11.187a1.692 1.692 0 0 1 2.392-.069q.035.033.069.069a1.86 1.86 0 0 1 0 2.562 1.692 1.692 0 0 1-2.391.071l-.07-.071a1.863 1.863 0 0 1 0-2.562Z" transform="translate(-.999 -1)" /></symbol></defs><use xlink:href="#icon-withdraw_login_pwd_a" fill="#04BE02" /></symbol>', e.insertBefore(t, e.lastChild)
        };
        document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", a) : a()
    }
    let ve, we, Ae, Pe, Me, Ie, Ce, Te, Be, Re, Ee, Se;
    ve = {
        class: "skeleton-screen-main"
    }, we = {
        key: 0,
        "data-device": "mobile",
        class: "eu_an-loading-container"
    }, Ae = Ya('<header class="shadow"><div class="circle base-loading-animation"></div><div class="searchBox"></div><div class="btn base-loading-animation b-redius"></div><div class="btn base-loading-animation b-redius"></div><div class="btn base-loading-animation b-redius"></div><div class="circle base-loading-animation"></div></header><main class="main-content"><div class="centre-content"><div class="banner banner1 b-redius-max base-loading-animation"></div><div class="banner banner2"><div class="circle base-loading-animation"></div><div class="p1 base-loading-animation b-redius-min"></div></div><div class="banner banner3"><div class="left"><div class="base-loading-animation b-redius btn"></div><div class="base-loading-animation b-redius btn"></div><div class="base-loading-animation b-redius btn"></div><div class="base-loading-animation b-redius btn"></div></div><div class="right"><div class="search"></div></div></div><div class="banner banner2"><div class="circle base-loading-animation"></div><div class="p2 base-loading-animation b-redius-min"></div></div><div class="banner banner4"><div class="card b-redius-max base-loading-animation"></div><div class="card b-redius-max base-loading-animation"></div><div class="card b-redius-max base-loading-animation"></div><div class="card b-redius-max base-loading-animation"></div><div class="card b-redius-max base-loading-animation"></div><div class="card b-redius-max base-loading-animation"></div><div class="card b-redius-max base-loading-animation"></div><div class="card b-redius-max base-loading-animation"></div><div class="card b-redius-max base-loading-animation"></div></div></div></main>', 2), Pe = [Ae], Me = {
        key: 1,
        "data-device": "desktop",
        class: "eu_an-loading-container"
    }, Ie = Ya('<header class="shadow"><aside class="base-loading-animation b-redius"></aside><section><div><div class="circle1"></div><div class="block1 base-loading-animation b-redius"></div><div class="block1 base-loading-animation b-redius"></div><div class="block1 base-loading-animation b-redius"></div><div class="block2"><div class="left base-loading-animation b-redius"></div><div class="right"><div class="rb1 base-loading-animation b-redius-min"></div><div class="rb2 base-loading-animation b-redius-min"></div></div></div></div></section></header><main class="main-content"><aside class="main-aside shadow"><div class="circle-box"><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius long"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius"></div><div class="circle base-loading-animation b-redius long"></div><div class="p"><div class="circle base-loading-animation"></div><div class="p1 base-loading-animation b-redius-min"></div></div><div class="p"><div class="circle base-loading-animation"></div><div class="p1 base-loading-animation b-redius-min"></div></div></div></aside><div class="right-aside"><div class="item b-shadow b-redius"><div class="circle base-loading-animation"></div><div class="p1 base-loading-animation b-redius-min"></div><div class="p2 base-loading-animation b-redius-min"></div></div></div><div class="right-content"><div class="centre-content"><div class="banner banner1 b-redius b-shadow"><div class="img1 base-loading-animation b-redius-max"></div><div class="img2 base-loading-animation1 b-redius-max"></div></div><div class="banner banner3 b-redius b-shadow"><div class="p"><div class="circle base-loading-animation"></div><div class="p1 base-loading-animation b-redius-min"></div></div></div><div class="banner banner4 b-redius b-shadow"><div class="item base-loading-animation b-redius"></div><div class="item base-loading-animation b-redius"></div><div class="item base-loading-animation b-redius"></div><div class="item base-loading-animation b-redius"></div><div class="item base-loading-animation b-redius"></div><div class="item base-loading-animation b-redius"></div><div class="item base-loading-animation b-redius"></div><div class="item base-loading-animation b-redius"></div><div class="item base-loading-animation b-redius"></div></div><div class="banner banner2 b-redius b-shadow"><div class="top"><div class="left"><div class="item"><div class="circle base-loading-animation"></div><div class="p1 base-loading-animation b-redius-min"></div></div></div></div><div class="game-list"><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div><div class="game-item"><div class="base-loading-animation b-redius-max"></div></div></div></div></div></div></main>', 2), Ce = [Ie], Te = {
        __name: "skin1",
        setup(a) {
            return (e, t) => (A(), F("div", ve, [c(ma)() ? (A(), F("div", we, Pe)) : (A(), F("div", Me, Ce))]))
        }
    }, Be = {
        class: "skeleton-screen-main",
        "data-type": "1",
        "data-skin-type": "17",
        "data-inject-mode": "undefined"
    }, Re = Ya('<div><div data-device="desktop" class="base-loading-container"><header class="shadow"><aside class="base-loading-animation b-redius"></aside> <section><div><div class="circle1"></div> <div class="circle2"></div> <div class="block1 base-loading-animation b-redius"></div> <div class="block1 base-loading-animation b-redius"></div> <div class="block2"><div class="left base-loading-animation b-redius"></div> <div class="right"><div class="rb1 base-loading-animation b-redius-min"></div> <div class="rb2 base-loading-animation b-redius-min"></div></div></div></div></section></header> <main class="main-content"><aside class="main-aside shadow"><div class="circle-box"><div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div></div> <div class="circle-box"><div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div> <div class="circle base-loading-animation"></div></div></aside> <div class="right-aside"><div class="item b-shadow b-redius"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="item b-shadow b-redius"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="item b-shadow b-redius"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div></div> <div class="centre-content"><div class="banner banner1 b-redius-min b-shadow"><div class="img1 base-loading-animation b-redius-max"></div> <div class="img2 base-loading-animation1 b-redius-max"></div> <div class="p"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div></div> <div class="banner banner2 b-redius-min b-shadow"><div class="top"><div class="left"><div class="item"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div> <div class="item"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div> <div class="item"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div></div> <div class="right"></div></div> <div class="game-list"><div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div></div></div></div></main></div> <div data-device="mobile" class="base-loading-container"><header class="shadow"><div class="left"><div class="item"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div> <div class="item"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div></div> <div class="mid b-redius base-loading-animation"></div> <div class="right"><div class="item"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div> <div class="item"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div></div></header> <main class="main-content"><div class="bottom-menu"><div class="item b-redius"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div> <div class="item b-redius"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div> <div class="item b-redius"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div> <div class="item b-redius"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div> <div class="item b-redius"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div></div> <div class="centre-content"><div class="ban banner1 b-redius base-loading-animation"></div> <div class="ban banner2"><div class="circle base-loading-animation"></div> <div class="p1 base-loading-animation b-redius-min"></div></div> <div class="ban banner3"><div class="left"><div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="right"><div class="base-loading-animation b-redius-min"></div> <div class="base-loading-animation b-redius-min"></div> <div class="base-loading-animation b-redius-min"></div> <div class="base-loading-animation b-redius-min"></div></div></div> <div class="ban banner4"><div class="left"><div class="item b-redius base-loading-animation"><div class="circle"></div> <div class="p1 b-redius-min"></div></div> <div class="item b-redius base-loading-animation"><div class="circle"></div> <div class="p1 b-redius-min"></div></div> <div class="item b-redius base-loading-animation"><div class="circle"></div> <div class="p1 b-redius-min"></div></div> <div class="item b-redius base-loading-animation"><div class="circle"></div> <div class="p1 b-redius-min"></div></div> <div class="item b-redius base-loading-animation"><div class="circle"></div> <div class="p1 b-redius-min"></div></div> <div class="item b-redius base-loading-animation"><div class="circle"></div> <div class="p1 b-redius-min"></div></div> <div class="item b-redius base-loading-animation"><div class="circle"></div> <div class="p1 b-redius-min"></div></div> <div class="item b-redius base-loading-animation"><div class="circle"></div> <div class="p1 b-redius-min"></div></div> <div class="item b-redius base-loading-animation"><div class="circle"></div> <div class="p1 b-redius-min"></div></div></div> <div class="right"><div class="top"><div class="base-loading-animation b-redius-min"></div> <div class="base-loading-animation b-redius-min"></div> <div class="base-loading-animation b-redius-min"></div> <div class="base-loading-animation b-redius-min"></div></div> <div class="game-list"><div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div> <div class="game-item"><div class="img base-loading-animation b-redius"></div> <div class="p1 base-loading-animation b-redius-min"></div> <div class="p2 base-loading-animation b-redius-min"></div></div></div></div></div></div></main></div></div>', 1), Ee = [Re], Se = {
        __name: "skin2",
        setup(a) {
            return (e, t) => (A(), F("div", Be, Ee))
        }
    }, te = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAABYCAMAAABGS8AGAAAAulBMVEUAAAD////e5Or////e5Ore5Ore5Or////e5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Ore5Or////e5Or////g5ev5+vv7/P3i6O3l6u/9/f7u8fTr7/Ln6/D2+Pr09vjp7fHw8/by9Pft8PTd3Q4iAAAALnRSTlMAYJaAvJEhIHx2LtSKalcoGV4EooE9NREHrphQ28SDSkUM6c/KtuzicGWonZ/WMiwlOgAABORJREFUWMPdmWl3ojAUhjMUGRBxX+vaalttZyAk7Mj//1uTpcccGypg+mneTwrx4fLee+GeCP5Ltbubd91+e359fX7b6yOz2wPqMk6jFc7CNIE+E0zOYYbsj0FfhTo7vaAoha4keI7Qoju/E9treVHifqcgzbxN/x5jH3EefDIguf0YIyIcR+EZfh73Q9QxGmL7Gjp/3nUee+sPc7Cb9gyjN90NzNEBZTnkl8xR56kJ1/JCHlOO953tTLpst2Xj3GfoYn+q74IWsx/ByOtMv1s00byQr8JaTasdL+dY2xnerBnLKxg6XHfrcFsYstXesXLp0OQxJGhTvVbL+NLWrFb/aCyMAGsVC5+0iIWrL0FNOXsWdKZVcAt6/VibNegjHkt0k8y4PuqARtJwUEFm14aeBRqqg2h1xNq33JhxHdBYY0RjxuPys0dEfaDc5trw3y5Lk/CXFg4ywV1qYVqk+rDMiJz61GoAk/NTlNhsYVq/Grhbo5Te8EBqfI8kFh4UXjgTRlhLHoX0eiegIBPTDhx/yZzHjVDSe0orY3gdcE6PMSNUzKANeBVyXxxSUSv/GvImJEfe1IcQLyDxOeLAkCY0suSVvx8eHn4DUOOECBna4ns3I89KT54/frlUv0DtEz3a2Vi8JxcknedHOSzX5QCZyyXHrCeum3dEcxBr8ERa9eAKchnXfZB+Moh4soQT/gqUggVZ5rp/5FcQiVF48Xgm8bfKwIIsccsjBi/E1dACXDYkrbgEJR5LZMEt9xhYheumL5/VR1OJpK4TEEGWDkmaYlFgy5gU3x6AanI1F8yZyW0R/QjUIMtcWeuE+Nq95C4cgxrkGlwwojTrkshoAGqQa3DBOCQlxp+/B1IU8RZUkGtygRNdyuIvlPtOJldzRbcl/AX15rM8VpBrcsFW1NgrAaMeqCDX5IIdBdscHDBwJVlwq8HCCnWwbMWKJm+qboVIHlxL5aaevFNEquKFN0giGkS93EzSIOcP9vGDNqH5Ew0iaOIaI/WWFm+9bCDsPqg/hMQkgaeXd3bgzX7msdnGFPbEv6x8URaqD3qHFoUuHqFiGFB8Nb2n7OEuhgFo/8jLdHg1ovTZYNT+idf/MqYWD6XBSHVgEcOaaEP/WW3EEnM2nlwPRpmjPBTKc7bG5lqVMVYEWFhAqE3TFx9L5us/Yr6uPtEpWHd8LT+4Amrq0YDD6yKY0JCjlhpYy2nA/bKDWxWuQ4MrvgbXpreRvihwDRtSO+eS8RnbflEwIqQ1fASlTeNi825u7LKhTdaOPqJ9b3Af16QGQ9sonRMxPXdY3pU4GpWLnBubJIl+B/nkQWl7RvI/WTd24+jB25k3Hs+U7B2bbrvBqt2ONiND1KQF5xoOGPcJ3CTndHMze2zX5e4WhUtUVG2HGhpbd/asujakfDN2Xn1nMb0zP6tTHYNDxBZjrd52YsL2pvFid3thV49ho9tb6gWNw03xwel/65llxywAPxtNaie6xZ1zYYQWTq8kx0cdhdDl4Y4b7XS983DcII2Q/W52p8ZsPhzOZ8Z0MF6scEHO8puqrh/ZwNTlgmmYYeQxIRyFl7+1zjQNzbVdYH67XIFPFIjvsEB1zZWt3HhxmLiygiTEe8sACtpt1oj/T8gjpv8UFjHSzSlQlrE0R+sV+V+T6PV5pX9Y2z74D/UPhdNSn68Xk84AAAAASUVORK5CYII=";
    let De, Oe, Ze, Le, je, Ne, Ve, qe, Ma;
    De = ["onClick"], Oe = {
        class: "dialog-page-box"
    }, Ze = {
        class: "dialog-page-box-close"
    }, Le = ["onClick"], je = {
        key: 1,
        class: "dialog-page-box-header"
    }, Ne = {
        class: "dialog-page-box-content"
    }, Ve = {
        key: 3,
        class: "dialog-page-box-footer"
    }, qe = {
        key: 4,
        class: "dialog-page-box-footer"
    }, Na = {
        __name: "index",
        props: {
            title: {
                type: String,
                required: !1
            },
            value: {
                type: Boolean,
                default: !1,
                required: !0
            },
            btnText: {
                type: Array,
                required: !1
            },
            disabledBtn: {
                type: Boolean,
                default: !1,
                required: !1
            },
            btnNum: {
                type: Number,
                default: 1,
                required: !1
            },
            modalClose: {
                type: Boolean,
                default: !0,
                required: !1
            },
            showClose: {
                type: Boolean,
                default: !0,
                required: !1
            }
        },
        emits: ["input", "submit", "cancel"],
        setup(a, {
            emit: e
        }) {
            const t = a,
                n = ot();
            let o = ka({
                get() {
                    return t.value
                }
            });
            const m = () => {
                    e("input", !1)
                },
                k = () => {
                    t.modalClose && e("input", !1)
                },
                g = () => {
                    e("submit")
                },
                P = () => {
                    e("cancel")
                };
            return (w, f) => {
                const R = Qa("svg-icon");
                return c(o) ? (A(), F("div", {
                    key: 0,
                    class: "dialog-page",
                    onClick: $a(k, ["self"])
                }, [T("div", Oe, [T("div", Ze, [c(n).state.isMobile ? (A(), F("img", {
                    key: 0,
                    src: te,
                    onClick: $a(m, ["stop"])
                }, null, 8, Le)) : (A(), O(R, {
                    key: 1,
                    iconClass: "close",
                    onClick: $a(m, ["stop"])
                }, null, 8, ["onClick"]))]), w.$slots.title ? Xa(w.$slots, "title", {
                    key: 0,
                    slot: "title"
                }) : (A(), F("div", je, ba(a.title || "Tips"), 1)), T("div", Ne, [w.$slots.default ? Xa(w.$slots, "default", {
                    key: 0,
                    slot: "default"
                }) : Z("", !0)]), w.$slots.footer ? Xa(w.$slots, "footer", {
                    key: 2,
                    slot: "footer"
                }) : a.btnNum === 1 ? (A(), F("div", Ve, [T("div", {
                    class: sa(["dialog-page-box-footer-btn", {
                        disabled: a.disabledBtn
                    }]),
                    onClick: g
                }, ba(a.btnText && a.btnText[0] || w.$t("common.confirm")), 3)])) : (A(), F("div", qe, [T("div", {
                    class: sa(["dialog-page-box-footer-btn", {
                        disabled: a.disabledBtn
                    }]),
                    onClick: P
                }, ba(a.btnText && a.btnText[0] || w.$t("common.confirm")), 3), T("div", {
                    class: sa(["dialog-page-box-footer-btn blue", {
                        disabled: a.disabledBtn
                    }]),
                    onClick: g
                }, ba(a.btnText && a.btnText[1] || w.$t("common.cancel")), 3)]))])], 8, De)) : Z("", !0)
            }
        }
    }, Dt = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Na
    }, Symbol.toStringTag, {
        value: "Module"
    })), Ma = document.createElement("link"), Ma.rel = "manifest", Ma.href = location.origin + `/api/user/app/manifest.webmanifest?t=${Date.now()}`, document.querySelector("head").append(Ma), window.addEventListener("beforeinstallprompt", a => {
        console.log("beforeinstallprompt"), a.preventDefault(), window.deferredPrompt = a
    }), window.globalVBus = An;
    let He = h();
    He.mid && localStorage.setItem("mid", He.mid);
    const ga = await I.get("/user/app/layout");
    if (ga && ga.code === 0) {
        const {
            decorators: a,
            menus: e,
            sections: t,
            template: n = {
                type: 1,
                color: 1
            },
            offerTypes: o,
            downloadBar: m = [],
            webFooter: k = {},
            leftNavigations: g = {},
            logos: P = [],
            festivalStyle: w = "",
            cs: f = {},
            scatter: R = {},
            awardPools: L = [],
            techSupport: Q = ""
        } = ga.data;
        s.state.decorators = a, s.state.sections = t, s.state.downloadBar = m, s.state.offerTypes = o, s.state.webFooter = k, s.state.leftNavigations = g, s.state.layoutMode = n.type || 1, s.state.layoutColor = n.color || 2, s.state.logos = P, s.state.festivalStyle = w, s.state.customerConfig = f, s.state.scatter = R, s.state.awardPools = L, s.state.moduleList = e.filter(V => V.status === 1), s.state.techSupport = Q;
        let Y = P.find(V => V.alias === "wapLogo");
        if (Y) {
            document.title = Y.title || "";
            const V = document.createElement("link");
            V.rel = "icon", V.type = "image/svg+xml", V.href = Y.icon;
            const ea = document.querySelector("head");
            ea.appendChild(V);
            const X = document.createElement("meta");
            X.setAttribute("property", "og:image"), X.content = Y.icon, ea.appendChild(X)
        }
    } else s.state.layoutMode = 1, s.state.layoutColor = 1;
    s.state.layoutMode === 1 ? _e({
        source: location.origin + "/theme/" + da() + ".css",
        type: "css"
    }) : _e({
        source: location.origin + "/theme/" + da() + ".css",
        type: "css"
    });
    let pa, za;
    ga && ga.status !== "maintain" && (s.state.layoutMode === 1 ? pa = fa(Te).use(s) : pa = fa(Se).use(s), za = document.createElement("div"), document.body.appendChild(za), pa.mount(za)), s.state.moduleList.length && x.addRoute({
        path: "/",
        redirect: {
            path: s.state.moduleList[0].alias
        }
    }), window.addEventListener("resize", () => {
        s.state.isMobile = ma()
    });
    const Ia = fa({
        render: () => it(xn)
    }).use(s).use(x).use(ia).use(yi).use(Ha).use(xi);
    Ia.use(fi, {
        preLoad: 1,
        loading: "/img/colors/" + da() + "/preload.gif"
    }), Ia.component("Dialog", Na), await s.dispatch("getMetas", "language,country"), await In(), await s.dispatch("getMetas"), s.state.metaConfig && (s.state.currency = ja(), pa && document.body.removeChild(pa._container)), Ia.directive("throttle", {
        mounted(a, e) {
            const t = e.value,
                n = fa({
                    render: () => it(qa, {
                        iconClass: "loading",
                        class: "animate-svg"
                    })
                }).mount(document.createElement("div"));
            n.$el.style.display = "none", n.$el.style.marginRight = "0.05rem", a.insertBefore(n.$el, a.firstChild), a.addEventListener("click", async () => {
                if (!s.state.btnLoading) {
                    s.state.btnLoading = !0, n.$el.style.display = "inline-block";
                    try {
                        await t()
                    } catch {}
                    n.$el.style.display = "none", s.state.btnLoading = !1
                }
            })
        },
        unmounted(a) {
            a.removeEventListener("click", a.__vueThrottleHandler__)
        }
    }), Ia.mount("#app"), ki("browser-address-bar"), window.inAndroid = () => {
        s.state.isApp = !0, s.state.isAndroid = !0
    }, window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.inAndroid && window.webkit.messageHandlers.inAndroid.postMessage(null), await Mn(), Pn(), nn();
    async function Pn() {
        const {
            default: a
        } = await l(() =>
            import ("./fastclick.611e5c76.js").then(e => e.f), ["js/fastclick.611e5c76.js", "js/clipboard.f53621db.js"]);
        a.FastClick.attach(document.body)
    }
    async function Mn() {
        await bi.load().then(a => {
            a.get().then(e => {})
        })
    }
    async function In() {
        const {
            language: a,
            country: e
        } = s.state.metaConfig;
        let t = a;
        if (!a) return;
        let n = localStorage.getItem("language"),
            o;
        n && (o = t.find(m => m.value === n)), o ? s.state.language = o.value : (o = t.find(m => m.value === navigator.language), o || (o = t.find(m => m.value === navigator.language.split("-")[0])), o ? localStorage.setItem("language", o.value) : localStorage.setItem("language", "en"), s.state.language = localStorage.getItem("language")), localStorage.setItem("country", e && e[0].value), s.state.area = e && e[0].label.split("/")[1].replace("+", "")
    }
})();
export {
    I as $, la as A, dt as B, ae as C, La as D, mt as E, ct as F, ut as G, gt as H, x as I, pt as J, _t as K, ht as L, bt as M, kt as N, ft as O, yt as P, xt as Q, vt as R, wt as S, aa as T, At as U, Pt as V, Mt as W, It as X, Ct as Y, ja as Z, l as _, vi as __tla, Tt as __vite_legacy_guard, h as a, Na as a0, Bt as a1, Rt as a2, Et as a3, ee as a4, St as a5, Dt as a6, Ot as b, Zt as c, te as d, Lt as e, jt as f, da as g, Nt as h, ne as i, Vt as j, qt as k, Ht as l, na as m, ma as n, Ft as o, Ut as p, Kt as q, zt as r, s, N as t, Gt as u, Wt as v, Jt as w, ie as x, Qt as y, re as z
};