import {
    u as j,
    s as L,
    t as R,
    r as C,
    v as k,
    g as x,
    j as W,
    n as B,
    w as Q
} from "./@vue.16908cbf.js";
var b;
const y = typeof window < "u",
    $ = e => typeof e == "string",
    N = () => {},
    F = y && ((b = window ? .navigator) == null ? void 0 : b.userAgent) && /iP(ad|hone|od)/.test(window.navigator.userAgent);

function _(e) {
    return typeof e == "function" ? e() : j(e)
}

function M(e) {
    return e
}

function w(e) {
    return L() ? (R(e), !0) : !1
}

function z(e, n = !0) {
    x() ? W(e) : n ? e() : B(e)
}

function Z(e, n, t = {}) {
    const {
        immediate: r = !0
    } = t, a = C(!1);
    let i = null;

    function u() {
        i && (clearTimeout(i), i = null)
    }

    function l() {
        a.value = !1, u()
    }

    function f(...O) {
        u(), a.value = !0, i = setTimeout(() => {
            a.value = !1, i = null, e(...O)
        }, _(n))
    }
    return r && (a.value = !0, y && f()), w(l), {
        isPending: k(a),
        start: f,
        stop: l
    }
}

function v(e) {
    var n;
    const t = _(e);
    return (n = t ? .$el) != null ? n : t
}
const g = y ? window : void 0;

function m(...e) {
    let n, t, r, a;
    if ($(e[0]) || Array.isArray(e[0]) ? ([t, r, a] = e, n = g) : [n, t, r, a] = e, !n) return N;
    Array.isArray(t) || (t = [t]), Array.isArray(r) || (r = [r]);
    const i = [],
        u = () => {
            i.forEach(c => c()), i.length = 0
        },
        l = (c, p, o, s) => (c.addEventListener(p, o, s), () => c.removeEventListener(p, o, s)),
        f = Q(() => [v(n), _(a)], ([c, p]) => {
            u(), c && i.push(...t.flatMap(o => r.map(s => l(c, o, s, p))))
        }, {
            immediate: !0,
            flush: "post"
        }),
        O = () => {
            f(), u()
        };
    return w(O), O
}
let I = !1;

function ee(e, n, t = {}) {
    const {
        window: r = g,
        ignore: a = [],
        capture: i = !0,
        detectIframe: u = !1
    } = t;
    if (!r) return;
    F && !I && (I = !0, Array.from(r.document.body.children).forEach(o => o.addEventListener("click", N)));
    let l = !0;
    const f = o => a.some(s => {
            if (typeof s == "string") return Array.from(r.document.querySelectorAll(s)).some(d => d === o.target || o.composedPath().includes(d)); {
                const d = v(s);
                return d && (o.target === d || o.composedPath().includes(d))
            }
        }),
        c = [m(r, "click", o => {
            const s = v(e);
            if (!(!s || s === o.target || o.composedPath().includes(s))) {
                if (o.detail === 0 && (l = !f(o)), !l) {
                    l = !0;
                    return
                }
                n(o)
            }
        }, {
            passive: !0,
            capture: i
        }), m(r, "pointerdown", o => {
            const s = v(e);
            s && (l = !o.composedPath().includes(s) && !f(o))
        }, {
            passive: !0
        }), u && m(r, "blur", o => {
            var s;
            const d = v(e);
            ((s = r.document.activeElement) == null ? void 0 : s.tagName) === "IFRAME" && !d ? .contains(r.document.activeElement) && n(o)
        })].filter(Boolean);
    return () => c.forEach(o => o())
}

function U(e, n = !1) {
    const t = C(),
        r = () => t.value = !!e();
    return r(), z(r, n), t
}
const h = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
    E = "__vueuse_ssr_handlers__";
h[E] = h[E] || {};
var P = Object.getOwnPropertySymbols,
    G = Object.prototype.hasOwnProperty,
    H = Object.prototype.propertyIsEnumerable,
    q = (e, n) => {
        var t = {};
        for (var r in e) G.call(e, r) && n.indexOf(r) < 0 && (t[r] = e[r]);
        if (e != null && P)
            for (var r of P(e)) n.indexOf(r) < 0 && H.call(e, r) && (t[r] = e[r]);
        return t
    };

function te(e, n, t = {}) {
    const r = t,
        {
            window: a = g
        } = r,
        i = q(r, ["window"]);
    let u;
    const l = U(() => a && "ResizeObserver" in a),
        f = () => {
            u && (u.disconnect(), u = void 0)
        },
        O = Q(() => v(e), p => {
            f(), l.value && a && p && (u = new ResizeObserver(n), u.observe(p, i))
        }, {
            immediate: !0,
            flush: "post"
        }),
        c = () => {
            f(), O()
        };
    return w(c), {
        isSupported: l,
        stop: c
    }
}
var S;
(function(e) {
    e.UP = "UP", e.RIGHT = "RIGHT", e.DOWN = "DOWN", e.LEFT = "LEFT", e.NONE = "NONE"
})(S || (S = {}));
var D = Object.defineProperty,
    A = Object.getOwnPropertySymbols,
    K = Object.prototype.hasOwnProperty,
    V = Object.prototype.propertyIsEnumerable,
    T = (e, n, t) => n in e ? D(e, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[n] = t,
    J = (e, n) => {
        for (var t in n || (n = {})) K.call(n, t) && T(e, t, n[t]);
        if (A)
            for (var t of A(n)) V.call(n, t) && T(e, t, n[t]);
        return e
    };
const X = {
    easeInSine: [.12, 0, .39, 0],
    easeOutSine: [.61, 1, .88, 1],
    easeInOutSine: [.37, 0, .63, 1],
    easeInQuad: [.11, 0, .5, 0],
    easeOutQuad: [.5, 1, .89, 1],
    easeInOutQuad: [.45, 0, .55, 1],
    easeInCubic: [.32, 0, .67, 0],
    easeOutCubic: [.33, 1, .68, 1],
    easeInOutCubic: [.65, 0, .35, 1],
    easeInQuart: [.5, 0, .75, 0],
    easeOutQuart: [.25, 1, .5, 1],
    easeInOutQuart: [.76, 0, .24, 1],
    easeInQuint: [.64, 0, .78, 0],
    easeOutQuint: [.22, 1, .36, 1],
    easeInOutQuint: [.83, 0, .17, 1],
    easeInExpo: [.7, 0, .84, 0],
    easeOutExpo: [.16, 1, .3, 1],
    easeInOutExpo: [.87, 0, .13, 1],
    easeInCirc: [.55, 0, 1, .45],
    easeOutCirc: [0, .55, .45, 1],
    easeInOutCirc: [.85, 0, .15, 1],
    easeInBack: [.36, 0, .66, -.56],
    easeOutBack: [.34, 1.56, .64, 1],
    easeInOutBack: [.68, -.6, .32, 1.6]
};
J({
    linear: M
}, X);
export {
    m as a, v as b, F as c, Z as d, y as i, ee as o, w as t, te as u
};