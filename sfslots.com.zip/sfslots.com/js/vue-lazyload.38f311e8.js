import {
    n as m,
    d as z,
    r as b,
    f as y,
    e as S,
    j as R,
    b as C,
    U as $,
    w as H
} from "./@vue.16908cbf.js";
/*!
 * Vue-Lazyload.js v3.0.0
 * (c) 2023 Awe <hilongjw@gmail.com>
 * Released under the MIT License.
 */
function B(r, e) {
    return e = {
        exports: {}
    }, r(e, e.exports), e.exports
}
var _ = B(function(r) {
        const e = Object.prototype.toString,
            t = Object.prototype.propertyIsEnumerable,
            s = Object.getOwnPropertySymbols;
        r.exports = (o, ...n) => {
            if (!i(o)) throw new TypeError("expected the first argument to be an object");
            if (n.length === 0 || typeof Symbol != "function" || typeof s != "function") return o;
            for (let l of n) {
                let d = s(l);
                for (let a of d) t.call(l, a) && (o[a] = l[a])
            }
            return o
        };

        function i(o) {
            return typeof o == "function" || e.call(o) === "[object Object]" || Array.isArray(o)
        }
    }),
    I = Object.freeze({
        __proto__: null,
        default: _,
        __moduleExports: _
    }),
    D = I && _ || I,
    Q = B(function(r) {
        const e = Object.prototype.toString,
            t = n => n !== "__proto__" && n !== "constructor" && n !== "prototype",
            s = r.exports = (n, ...l) => {
                let d = 0;
                for (o(n) && (n = l[d++]), n || (n = {}); d < l.length; d++)
                    if (i(l[d])) {
                        for (const a of Object.keys(l[d])) t(a) && (i(n[a]) && i(l[d][a]) ? s(n[a], l[d][a]) : n[a] = l[d][a]);
                        D(n, l[d])
                    }
                return n
            };

        function i(n) {
            return typeof n == "function" || e.call(n) === "[object Object]"
        }

        function o(n) {
            return typeof n == "object" ? n === null : typeof n != "function"
        }
    });
const f = typeof window < "u" && window !== null,
    O = j();

function j() {
    return f && "IntersectionObserver" in window && "IntersectionObserverEntry" in window && "intersectionRatio" in window.IntersectionObserverEntry.prototype ? ("isIntersecting" in window.IntersectionObserverEntry.prototype || Object.defineProperty(window.IntersectionObserverEntry.prototype, "isIntersecting", {
        get: function() {
            return this.intersectionRatio > 0
        }
    }), !0) : !1
}
const p = {
    event: "event",
    observer: "observer"
};

function v(r, e) {
    if (!r.length) return;
    const t = r.indexOf(e);
    if (t > -1) return r.splice(t, 1)
}

function T(r, e) {
    if (r.tagName !== "IMG" || !r.getAttribute("data-srcset")) return "";
    let t = r.getAttribute("data-srcset").trim().split(",");
    const s = [],
        o = r.parentNode.offsetWidth * e;
    let n, l, d;
    t.forEach(h => {
        h = h.trim(), n = h.lastIndexOf(" "), n === -1 ? (l = h, d = 99999) : (l = h.substr(0, n), d = parseInt(h.substr(n + 1, h.length - n - 2), 10)), s.push([d, l])
    }), s.sort((h, c) => {
        if (h[0] < c[0]) return 1;
        if (h[0] > c[0]) return -1;
        if (h[0] === c[0]) {
            if (c[1].indexOf(".webp", c[1].length - 5) !== -1) return 1;
            if (h[1].indexOf(".webp", h[1].length - 5) !== -1) return -1
        }
        return 0
    });
    let a = "",
        u;
    for (let h = 0; h < s.length; h++) {
        u = s[h], a = u[1];
        const c = s[h + 1];
        if (c && c[0] < o) {
            a = u[1];
            break
        } else if (!c) {
            a = u[1];
            break
        }
    }
    return a
}
const U = (r = 1) => f && window.devicePixelRatio || r;

function W() {
    if (!f) return !1;
    let r = !0;

    function e(t, s) {
        const i = {
                lossy: "UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA",
                lossless: "UklGRhoAAABXRUJQVlA4TA0AAAAvAAAAEAcQERGIiP4HAA==",
                alpha: "UklGRkoAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAwAAAARBxAR/Q9ERP8DAABWUDggGAAAABQBAJ0BKgEAAQAAAP4AAA3AAP7mtQAAAA==",
                animation: "UklGRlIAAABXRUJQVlA4WAoAAAASAAAAAAAAAAAAQU5JTQYAAAD/////AABBTk1GJgAAAAAAAAAAAAAAAAAAAGQAAABWUDhMDQAAAC8AAAAQBxAREYiI/gcA"
            },
            o = new Image;
        o.onload = function() {
            const n = o.width > 0 && o.height > 0;
            s(n)
        }, o.onerror = function() {
            s(!1)
        }, o.src = "data:image/webp;base64," + i[t]
    }
    return e("lossy", t => {
        r = t
    }), e("lossless", t => {
        r = t
    }), e("alpha", t => {
        r = t
    }), e("animation", t => {
        r = t
    }), r
}

function P(r, e) {
    let t = null,
        s = 0;
    return function() {
        if (t) return;
        const i = Date.now() - s,
            o = this,
            n = arguments,
            l = function() {
                s = Date.now(), t = !1, r.apply(o, n)
            };
        i >= e ? l() : t = setTimeout(l, e)
    }
}

function V() {
    if (!f) return !1;
    let r = !1;
    try {
        const e = Object.defineProperty({}, "passive", {
            get: function() {
                r = !0
            }
        });
        window.addEventListener("test", E, e)
    } catch {}
    return r
}
const N = V(),
    M = {
        on(r, e, t, s = !1) {
            N ? r.addEventListener(e, t, {
                capture: s,
                passive: !0
            }) : r.addEventListener(e, t, s)
        },
        off(r, e, t, s = !1) {
            r.removeEventListener(e, t, s)
        }
    },
    L = (r, e, t) => {
        let s = new Image;
        if (!r || !r.src) {
            const i = new Error("image src is required");
            return t(i)
        }
        r.cors && (s.crossOrigin = r.cors), s.src = r.src, s.onload = function() {
            e({
                naturalHeight: s.naturalHeight,
                naturalWidth: s.naturalWidth,
                src: s.src
            }), s = null
        }, s.onerror = function(i) {
            t(i)
        }
    },
    w = (r, e) => typeof getComputedStyle < "u" ? getComputedStyle(r, null).getPropertyValue(e) : r.style[e],
    G = r => w(r, "overflow") + w(r, "overflowY") + w(r, "overflowX"),
    q = r => {
        if (!f) return;
        if (!(r instanceof Element)) return window;
        let e = r;
        for (; e && !(e === document.body || e === document.documentElement || !e.parentNode);) {
            if (/(scroll|auto)/.test(G(e))) return e;
            e = e.parentNode
        }
        return window
    };

function J(r) {
    return r !== null && typeof r == "object"
}

function E() {}
class F {
    constructor(e) {
        this.max = e || 100, this._caches = []
    }
    has(e) {
        return this._caches.indexOf(e) > -1
    }
    add(e) {
        this.has(e) || (this._caches.push(e), this._caches.length > this.max && this.free())
    }
    free() {
        this._caches.shift()
    }
}
class X {
    constructor(e, t, s, i, o, n, l, d, a, u) {
        this.el = e, this.src = t, this.error = s, this.loading = i, this.bindType = o, this.attempt = 0, this.cors = d, this.naturalHeight = 0, this.naturalWidth = 0, this.options = l, this.rect = {}, this.$parent = n, this.elRenderer = a, this._imageCache = u, this.performanceData = {
            init: Date.now(),
            loadStart: 0,
            loadEnd: 0
        }, this.filter(), this.initState(), this.render("loading", !1)
    }
    initState() {
        "dataset" in this.el ? this.el.dataset.src = this.src : this.el.setAttribute("data-src", this.src), this.state = {
            loading: !1,
            error: !1,
            loaded: !1,
            rendered: !1
        }
    }
    record(e) {
        this.performanceData[e] = Date.now()
    }
    update(e) {
        const t = this.src;
        this.src = e.src, this.loading = e.loading, this.error = e.error, this.filter(), t !== this.src && (this.attempt = 0, this.initState())
    }
    getRect() {
        this.rect = this.el.getBoundingClientRect()
    }
    checkInView() {
        return this.getRect(), this.rect.top < window.innerHeight * this.options.preLoad && this.rect.bottom > this.options.preLoadTop && this.rect.left < window.innerWidth * this.options.preLoad && this.rect.right > 0
    }
    filter() {
        for (const e in this.options.filter) this.options.filter[e](this, this.options)
    }
    renderLoading(e) {
        this.state.loading = !0, L({
            src: this.loading,
            cors: this.cors
        }, () => {
            this.render("loading", !1), this.state.loading = !1, e()
        }, () => {
            e(), this.state.loading = !1, this.options.silent || console.warn(`VueLazyload log: load failed with loading image(${this.loading})`)
        })
    }
    load(e = E) {
        if (this.attempt > this.options.attempt - 1 && this.state.error) {
            this.options.silent || console.log(`VueLazyload log: ${this.src} tried too more than ${this.options.attempt} times`), e();
            return
        }
        if (!(this.state.rendered && this.state.loaded)) {
            if (this._imageCache.has(this.src)) return this.state.loaded = !0, this.render("loaded", !0), this.state.rendered = !0, e();
            this.renderLoading(() => {
                this.attempt++, this.options.adapter.beforeLoad && this.options.adapter.beforeLoad(this, this.options), this.record("loadStart"), L({
                    src: this.src,
                    cors: this.cors
                }, t => {
                    this.naturalHeight = t.naturalHeight, this.naturalWidth = t.naturalWidth, this.state.loaded = !0, this.state.error = !1, this.record("loadEnd"), this.render("loaded", !1), this.state.rendered = !0, this._imageCache.add(this.src), e()
                }, t => {
                    !this.options.silent && console.error(t), this.state.error = !0, this.state.loaded = !1, this.render("error", !1)
                })
            })
        }
    }
    render(e, t) {
        this.elRenderer(this, e, t)
    }
    performance() {
        let e = "loading",
            t = 0;
        return this.state.loaded && (e = "loaded", t = (this.performanceData.loadEnd - this.performanceData.loadStart) / 1e3), this.state.error && (e = "error"), {
            src: this.src,
            state: e,
            time: t
        }
    }
    $destroy() {
        this.el = null, this.src = "", this.error = null, this.loading = "", this.bindType = null, this.attempt = 0
    }
}
const x = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
    Y = ["scroll", "wheel", "mousewheel", "resize", "animationend", "transitionend", "touchmove"],
    K = {
        rootMargin: "0px",
        threshold: 0
    };
class Z {
    constructor({
        preLoad: e,
        error: t,
        throttleWait: s,
        preLoadTop: i,
        dispatchEvent: o,
        loading: n,
        attempt: l,
        silent: d = !0,
        scale: a,
        listenEvents: u,
        filter: h,
        adapter: c,
        observer: A,
        observerOptions: g
    }) {
        this.version = '"3.0.0"', this.lazyContainerMananger = null, this.mode = p.event, this.ListenerQueue = [], this.TargetIndex = 0, this.TargetQueue = [], this.options = {
            silent: d,
            dispatchEvent: !!o,
            throttleWait: s || 200,
            preLoad: e || 1.3,
            preLoadTop: i || 0,
            error: t || x,
            loading: n || x,
            attempt: l || 3,
            scale: a || U(a),
            listenEvents: u || Y,
            supportWebp: W(),
            filter: h || {},
            adapter: c || {},
            observer: !!A,
            observerOptions: g || K
        }, this._initEvent(), this._imageCache = new F(200), this.lazyLoadHandler = P(this._lazyLoadHandler.bind(this), this.options.throttleWait), this.setMode(this.options.observer ? p.observer : p.event)
    }
    performance() {
        const e = [];
        return this.ListenerQueue.map(t => e.push(t.performance())), e
    }
    addLazyBox(e) {
        this.ListenerQueue.push(e), f && (this._addListenerTarget(window), this._observer && this._observer.observe(e.el), e.$el && e.$el.parentNode && this._addListenerTarget(e.$el.parentNode))
    }
    add(e, t, s) {
        if (this.ListenerQueue.some(d => d.el === e)) return this.update(e, t), m(this.lazyLoadHandler);
        let {
            src: i,
            loading: o,
            error: n,
            cors: l
        } = this._valueFormatter(t.value);
        m(() => {
            i = T(e, this.options.scale) || i, this._observer && this._observer.observe(e);
            const d = Object.keys(t.modifiers)[0];
            let a;
            d && (a = t.instance.$refs[d], a = a ? a.el || a : document.getElementById(d)), a || (a = q(e));
            const u = new X(e, i, n, o, t.arg, a, this.options, l, this._elRenderer.bind(this), this._imageCache);
            this.ListenerQueue.push(u), f && (this._addListenerTarget(window), this._addListenerTarget(a)), m(this.lazyLoadHandler)
        })
    }
    update(e, t, s) {
        let {
            src: i,
            loading: o,
            error: n
        } = this._valueFormatter(t.value);
        i = T(e, this.options.scale) || i;
        const l = this.ListenerQueue.find(d => d.el === e);
        l ? l.update({
            src: i,
            loading: o,
            error: n
        }) : (e.getAttribute("lazy") !== "loaded" || e.dataset.src !== i) && this.add(e, t, s), this._observer && (this._observer.unobserve(e), this._observer.observe(e)), m(this.lazyLoadHandler)
    }
    remove(e) {
        if (!e) return;
        this._observer && this._observer.unobserve(e);
        const t = this.ListenerQueue.find(s => s.el === e);
        t && (this._removeListenerTarget(t.$parent), this._removeListenerTarget(window), v(this.ListenerQueue, t), t.$destroy && t.$destroy())
    }
    removeComponent(e) {
        e && (v(this.ListenerQueue, e), this._observer && this._observer.unobserve(e.el), e.$parent && e.$el.parentNode && this._removeListenerTarget(e.$el.parentNode), this._removeListenerTarget(window))
    }
    setMode(e) {
        !O && e === p.observer && (e = p.event), this.mode = e, e === p.event ? (this._observer && (this.ListenerQueue.forEach(t => {
            this._observer.unobserve(t.el)
        }), this._observer = null), this.TargetQueue.forEach(t => {
            this._initListen(t.el, !0)
        })) : (this.TargetQueue.forEach(t => {
            this._initListen(t.el, !1)
        }), this._initIntersectionObserver())
    }
    _addListenerTarget(e) {
        if (!e) return;
        let t = this.TargetQueue.find(s => s.el === e);
        return t ? t.childrenCount++ : (t = {
            el: e,
            id: ++this.TargetIndex,
            childrenCount: 1,
            listened: !0
        }, this.mode === p.event && this._initListen(t.el, !0), this.TargetQueue.push(t)), this.TargetIndex
    }
    _removeListenerTarget(e) {
        this.TargetQueue.forEach((t, s) => {
            t.el === e && (t.childrenCount--, t.childrenCount || (this._initListen(t.el, !1), this.TargetQueue.splice(s, 1), t = null))
        })
    }
    _initListen(e, t) {
        this.options.listenEvents.forEach(s => M[t ? "on" : "off"](e, s, this.lazyLoadHandler))
    }
    _initEvent() {
        this.Event = {
            listeners: {
                loading: [],
                loaded: [],
                error: []
            }
        }, this.$on = (e, t) => {
            this.Event.listeners[e] || (this.Event.listeners[e] = []), this.Event.listeners[e].push(t)
        }, this.$once = (e, t) => {
            const s = this;

            function i() {
                s.$off(e, i), t.apply(s, arguments)
            }
            this.$on(e, i)
        }, this.$off = (e, t) => {
            if (!t) {
                if (!this.Event.listeners[e]) return;
                this.Event.listeners[e].length = 0;
                return
            }
            v(this.Event.listeners[e], t)
        }, this.$emit = (e, t, s) => {
            this.Event.listeners[e] && this.Event.listeners[e].forEach(i => i(t, s))
        }
    }
    _lazyLoadHandler() {
        const e = [];
        this.ListenerQueue.forEach((t, s) => {
            (!t.el || !t.el.parentNode || t.state.loaded) && e.push(t), t.checkInView() && (t.state.loaded || t.load())
        }), e.forEach(t => {
            v(this.ListenerQueue, t), t.$destroy && t.$destroy()
        })
    }
    _initIntersectionObserver() {
        O && (this._observer = new IntersectionObserver(this._observerHandler.bind(this), this.options.observerOptions), this.ListenerQueue.length && this.ListenerQueue.forEach(e => {
            this._observer.observe(e.el)
        }))
    }
    _observerHandler(e) {
        e.forEach(t => {
            t.isIntersecting && this.ListenerQueue.forEach(s => {
                if (s.el === t.target) {
                    if (s.state.loaded) return this._observer.unobserve(s.el);
                    s.load()
                }
            })
        })
    }
    _elRenderer(e, t, s) {
        if (!e.el) return;
        const {
            el: i,
            bindType: o
        } = e;
        let n;
        switch (t) {
            case "loading":
                n = e.loading;
                break;
            case "error":
                n = e.error;
                break;
            default:
                n = e.src;
                break
        }
        if (o ? i.style[o] = 'url("' + n + '")' : i.getAttribute("src") !== n && i.setAttribute("src", n), i.setAttribute("lazy", t), this.$emit(t, e, s), this.options.adapter[t] && this.options.adapter[t](e, this.options), this.options.dispatchEvent) {
            const l = new CustomEvent(t, {
                detail: e
            });
            i.dispatchEvent(l)
        }
    }
    _valueFormatter(e) {
        return J(e) ? (!e.src && !this.options.silent && console.error("Vue Lazyload warning: miss src with " + e), {
            src: e.src,
            loading: e.loading || this.options.loading,
            error: e.error || this.options.error,
            cors: this.options.cors
        }) : {
            src: e,
            loading: this.options.loading,
            error: this.options.error,
            cors: this.options.cors
        }
    }
}
const k = (r, e) => {
    let t = y({});
    const s = () => {
        t = r.value.getBoundingClientRect()
    };
    return {
        rect: t,
        checkInView: () => (s(), f && t.top < window.innerHeight * e && t.bottom > 0 && t.left < window.innerWidth * e && t.right > 0)
    }
};
var ee = r => z({
    props: {
        tag: {
            type: String,
            default: "div"
        }
    },
    emits: ["show"],
    setup(e, {
        emit: t,
        slots: s
    }) {
        const i = b(),
            o = y({
                loaded: !1,
                error: !1,
                attempt: 0
            }),
            n = b(!1),
            {
                rect: l,
                checkInView: d
            } = k(i, r.options.preLoad),
            a = () => {
                n.value = !0, o.loaded = !0, t("show", n.value)
            },
            u = S(() => ({
                el: i.value,
                rect: l,
                checkInView: d,
                load: a,
                state: o
            }));
        return R(() => {
            r.addLazyBox(u.value), r.lazyLoadHandler()
        }), C(() => {
            r.removeComponent(u.value)
        }), () => {
            var h;
            return $(e.tag, {
                ref: i
            }, [n.value && ((h = s.default) === null || h === void 0 ? void 0 : h.call(s))])
        }
    }
});
class te {
    constructor(e) {
        this.lazy = e, e.lazyContainerMananger = this, this._queue = []
    }
    bind(e, t, s) {
        const i = new se(e, t, s, this.lazy);
        this._queue.push(i)
    }
    update(e, t, s) {
        const i = this._queue.find(o => o.el === e);
        i && i.update(e, t)
    }
    unbind(e, t, s) {
        const i = this._queue.find(o => o.el === e);
        i && (i.clear(), v(this._queue, i))
    }
}
const re = {
    selector: "img",
    error: "",
    loading: ""
};
class se {
    constructor(e, t, s, i) {
        this.el = e, this.vnode = s, this.binding = t, this.options = {}, this.lazy = i, this._queue = [], this.update(e, t)
    }
    update(e, t) {
        this.el = e, this.options = Q({}, re, t.value), this.getImgs().forEach(i => {
            this.lazy.add(i, Q({}, this.binding, {
                value: {
                    src: i.getAttribute("data-src") || i.dataset.src,
                    error: i.getAttribute("data-error") || i.dataset.error || this.options.error,
                    loading: i.getAttribute("data-loading") || i.dataset.loading || this.options.loading
                }
            }), this.vnode)
        })
    }
    getImgs() {
        return Array.from(this.el.querySelectorAll(this.options.selector))
    }
    clear() {
        this.getImgs().forEach(t => this.lazy.remove(t)), this.vnode = null, this.binding = null, this.lazy = null
    }
}
var ie = r => z({
        setup(e, {
            slots: t
        }) {
            const s = b(),
                i = y({
                    src: "",
                    error: "",
                    loading: "",
                    attempt: r.options.attempt
                }),
                o = y({
                    loaded: !1,
                    error: !1,
                    attempt: 0
                }),
                {
                    rect: n,
                    checkInView: l
                } = k(s, r.options.preLoad),
                d = b(""),
                a = (c = E) => {
                    if (o.attempt > i.attempt - 1 && o.error) return r.options.silent || console.log(`VueLazyload log: ${i.src} tried too more than ${i.attempt} times`), c();
                    const A = i.src;
                    L({
                        src: A
                    }, ({
                        src: g
                    }) => {
                        d.value = g, o.loaded = !0
                    }, () => {
                        o.attempt++, d.value = i.error, o.error = !0
                    })
                },
                u = S(() => ({
                    el: s.value,
                    rect: n,
                    checkInView: l,
                    load: a,
                    state: o
                }));
            R(() => {
                r.addLazyBox(u.value), r.lazyLoadHandler()
            }), C(() => {
                r.removeComponent(u.value)
            });
            const h = () => {
                const {
                    src: c,
                    loading: A,
                    error: g
                } = r._valueFormatter(e.src);
                o.loaded = !1, i.src = c, i.error = g, i.loading = A, d.value = i.loading
            };
            return H(() => e.src, () => {
                h(), r.addLazyBox(u.value), r.lazyLoadHandler()
            }, {
                immediate: !0
            }), () => {
                var c;
                return $(e.tag || "img", {
                    src: d.value,
                    ref: s
                }, [(c = t.default) === null || c === void 0 ? void 0 : c.call(t)])
            }
        }
    }),
    oe = {
        install(r, e = {}) {
            const t = new Z(e),
                s = new te(t);
            if (Number(r.version.split(".")[0]) < 3) return new Error("Vue version at least 3.0");
            r.config.globalProperties.$Lazyload = t, r.provide("Lazyload", t), e.lazyComponent && r.component("lazy-component", ee(t)), e.lazyImage && r.component("lazy-image", ie(t)), r.directive("lazy", {
                beforeMount: t.add.bind(t),
                beforeUpdate: t.update.bind(t),
                updated: t.lazyLoadHandler.bind(t),
                unmounted: t.remove.bind(t)
            }), r.directive("lazy-container", {
                beforeMount: s.bind.bind(s),
                updated: s.update.bind(s),
                unmounted: s.unbind.bind(s)
            })
        }
    };
export {
    oe as i
};