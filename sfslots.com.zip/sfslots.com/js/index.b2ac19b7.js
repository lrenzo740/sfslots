import {
    d as f,
    __tla as w
} from "./index.0a674315.js";
import {
    u as y
} from "./vuex.7fead168.js";
import {
    r as L,
    w as k,
    j as x,
    o as a,
    c as e,
    P as _,
    a3 as N,
    a as p,
    W as C,
    O as v,
    u as B
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./vue-router.d17f0860.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./vue-i18n.d9454f26.js";
import "./@intlify.7347860c.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
let g, H = Promise.all([(() => {
    try {
        return w
    } catch {}
})()]).then(async () => {
    let l, m, n, c, d, u;
    l = {
        key: 0,
        class: "notice-dialog"
    }, m = {
        key: 0,
        class: "notice-dialog-box"
    }, n = {
        class: "notice-dialog-title"
    }, c = {
        class: "notice-dialog-content"
    }, d = ["innerHTML"], u = ["onClick"], g = {
        __name: "index",
        setup(M) {
            const t = y(),
                r = L(!0);
            k(() => t.state.popNoticeList, o => {
                o && o.findIndex(s => s.show) > -1 ? r.value = !0 : (r.value = !1, t.state.popStep = 2)
            }, {
                deep: !0
            });
            const h = o => {
                o.show = !1, t.state.popNoticeList.find(s => s.show) || (t.state.popStep = 2)
            };
            return x(async () => {
                await t.dispatch("getNoticeList")
            }), (o, s) => r.value ? (a(), e("div", l, [(a(!0), e(_, null, N(B(t).state.popNoticeList, i => (a(), e(_, {
                key: i.id
            }, [i.show ? (a(), e("div", m, [p("div", n, C(i.title), 1), p("div", c, [p("div", {
                class: "innerBox",
                innerHTML: i.content
            }, null, 8, d)]), p("img", {
                class: "notice-dialog-close",
                src: f,
                onClick: P => h(i)
            }, null, 8, u)])) : v("", !0)], 64))), 128))])) : v("", !0)
        }
    }
});
export {
    H as __tla, g as
    default
};