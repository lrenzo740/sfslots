import {
    _ as E,
    t as n,
    r as x,
    __tla as j
} from "./index.0a674315.js";
import {
    C as D
} from "./vant.be74fb7c.js";
import {
    u as W
} from "./vuex.7fead168.js";
import {
    b as X
} from "./vue-router.d17f0860.js";
import {
    u as z
} from "./vue-i18n.d9454f26.js";
import {
    X as c
} from "./xe-utils.0e898ace.js";
import {
    an as F,
    r as M,
    w as L,
    e as G,
    j as H,
    o as i,
    R as K,
    S as u,
    a as r,
    U as O,
    a4 as P,
    W as o,
    c as p,
    P as Q,
    a3 as Y,
    u as g
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./nprogress.1adef0ba.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@vant.359a3f91.js";
import "./@intlify.7347860c.js";
let V, Z = Promise.all([(() => {
    try {
        return j
    } catch {}
})()]).then(async () => {
    let h, _, v, A, C, k, I, R, S, y, w;
    h = {
        class: "first-recharge-box"
    }, _ = {
        class: "table-header"
    }, v = {
        class: "table-list"
    }, A = {
        class: "table-list-item"
    }, C = {
        key: 0
    }, k = {
        key: 1
    }, I = {
        key: 2
    }, R = {
        class: "footer"
    }, S = {
        class: "checkBoxes"
    }, y = {
        class: "once"
    }, w = {
        class: "never"
    }, V = {
        __name: "first_recharge_dialog",
        props: ["value", "item", "detail"],
        emits: ["update:value"],
        setup($, {
            emit: b
        }) {
            const m = $,
                J = F(() => E(() =>
                    import ("./index.0a674315.js").then(async e => (await e.__tla, e)).then(e => e.a6), ["js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css"])),
                s = W(),
                T = X();
            z();
            const d = M(!1),
                f = M(!1);
            L(d, e => {
                let t = JSON.parse(localStorage.getItem("firstChargeAllUserCheckTodayReminderMapper")) || {};
                e ? (n() ? t[s.state.accountInfo.id] = !0 : t.unLogin = !0, c.cookie("firstRechargePop", "1", {
                    expires: "1d"
                })) : (n() ? t[s.state.accountInfo.id] = !1 : t.unLogin = !1, c.cookie("firstRechargePop", null, {
                    expires: -1
                })), localStorage.setItem("firstChargeAllUserCheckTodayReminderMapper", JSON.stringify(t))
            }), L(f, e => {
                let t = JSON.parse(localStorage.getItem("firstChargeAllUserCheckNeverReminderMapper")) || {};
                e ? n() ? t[s.state.accountInfo.id] = !0 : t.unLogin = !0 : n() ? t[s.state.accountInfo.id] = !1 : t.unLogin = !1, localStorage.setItem("firstChargeAllUserCheckNeverReminderMapper", JSON.stringify(t))
            });
            const l = G({
                    get() {
                        return m.value
                    },
                    set(e) {
                        b("update:value", e)
                    }
                }),
                N = () => {
                    l.value = !1
                },
                q = () => {
                    T.push(`/recharge-activity/${m.detail.id}`)
                };
            H(() => {
                B()
            });
            const B = () => {
                let e = JSON.parse(localStorage.getItem("firstChargeAllUserCheckTodayReminderMapper")) || {},
                    t = JSON.parse(localStorage.getItem("firstChargeAllUserCheckNeverReminderMapper")) || {};
                n() ? (s.state.accountInfo.id in e && e[s.state.accountInfo.id] && c.cookie("firstRechargePop") && (l.value = !1), s.state.accountInfo.id in t && t[s.state.accountInfo.id] && (l.value = !1)) : (t.unLogin || e.unLogin && c.cookie("firstRechargePop")) && (l.value = !1)
            };
            return (e, t) => {
                const U = D;
                return i(), K(g(J), {
                    value: l.value,
                    class: "first-recharge-dialog",
                    onInput: N,
                    modalClose: !1,
                    title: e.$t("first_charge_pop.title"),
                    onCancel: N
                }, {
                    footer: u(() => [r("div", R, [r("div", S, [r("div", y, [O(U, {
                        modelValue: d.value,
                        "onUpdate:modelValue": t[0] || (t[0] = a => d.value = a),
                        shape: "square"
                    }, {
                        default: u(() => [P(o(e.$t("new_player.tips1")), 1)]),
                        _: 1
                    }, 8, ["modelValue"])]), r("div", w, [O(U, {
                        modelValue: f.value,
                        "onUpdate:modelValue": t[1] || (t[1] = a => f.value = a),
                        shape: "square"
                    }, {
                        default: u(() => [P(o(e.$t("new_player.tips2")), 1)]),
                        _: 1
                    }, 8, ["modelValue"])])]), r("div", {
                        class: "collectBtn",
                        onClick: q
                    }, [r("span", null, o(e.$t("first_charge_pop.btn")), 1)])])]),
                    default: u(() => [r("div", h, [r("div", _, [r("span", null, o(e.$t("first_charge_pop.text1")), 1), r("span", null, o(e.$t("first_charge_pop.text2")), 1)]), r("div", v, [(i(!0), p(Q, null, Y(m.detail.rules, a => (i(), p("div", A, [r("span", null, "\u2265 " + o(g(x)(a.reachAmount || 0)), 1), a.rewardAmount || a.rewardAmount === 0 ? (i(), p("span", C, o(g(x)(a.rewardAmount)), 1)) : a.rewardAmountRatio || a.rewardAmountRatio === 0 ? (i(), p("span", k, o(a.rewardAmountRatio) + " %", 1)) : (i(), p("span", I, o(a.rewardMinAmount + "~" + a.rewardMaxAmount), 1))]))), 256))])])]),
                    _: 1
                }, 8, ["value", "title"])
            }
        }
    }
});
export {
    Z as __tla, V as
    default
};