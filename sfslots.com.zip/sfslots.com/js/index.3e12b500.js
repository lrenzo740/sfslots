import {
    _ as ke,
    k as p,
    g as T,
    l as Se,
    T as Ce,
    __tla as be
} from "./index.0a674315.js";
import {
    b as we,
    c as Le
} from "./element-plus.c133b52b.js";
import {
    u as Te
} from "./vuex.7fead168.js";
import {
    u as xe
} from "./vue-i18n.d9454f26.js";
import {
    an as $e,
    r as v,
    e as b,
    w as x,
    j as Be,
    aa as Me,
    o as u,
    R as n,
    S as $,
    a as i,
    W as m,
    U as _,
    u as o,
    O as ee,
    X as B,
    Q as M,
    c as h,
    P as he,
    a3 as Ve
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./vue-router.d17f0860.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./nprogress.1adef0ba.js";
import "./clipboard.f53621db.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./dayjs.42829e09.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./@intlify.7347860c.js";
let se, Ae = Promise.all([(() => {
    try {
        return be
    } catch {}
})()]).then(async () => {
    let V, A, q, O, E, J, N, P, U, z, R, j, D, Q, W, X, F, G, H;
    V = {
        class: "musicBox"
    }, A = {
        class: "soundBox"
    }, q = {
        class: "text"
    }, O = {
        class: "playBox"
    }, E = {
        class: "playBox-process"
    }, J = {
        class: "startTime"
    }, N = {
        class: "endTime"
    }, P = {
        class: "funBox"
    }, U = {
        class: "funBox-content"
    }, z = {
        class: "funBox-right"
    }, R = {
        class: "musicList"
    }, j = {
        class: "tabs"
    }, D = {
        class: "list"
    }, Q = ["onClick"], W = {
        class: "serial"
    }, X = {
        key: 1
    }, F = {
        class: "name"
    }, G = {
        class: "size"
    }, H = {
        class: "music-item-status"
    }, se = {
        __name: "index",
        props: ["value", "item"],
        emits: ["update:value"],
        setup(te, {
            emit: ie
        }) {
            const le = te,
                ae = $e(() => ke(() =>
                    import ("./index.0a674315.js").then(async e => (await e.__tla, e)).then(e => e.a6), ["js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css"])),
                t = Te(),
                w = v(50),
                k = v(!0),
                f = v(),
                y = v(),
                I = v(),
                g = v(null),
                d = v(0),
                r = v(0),
                {
                    t: ue
                } = xe(),
                L = b(() => d.value === 0 ? t.state.musicInfo.allList : t.state.musicInfo.downloadList),
                K = b(() => t.state.musicInfo.currentMusic),
                oe = b(() => t.state.musicInfo.playStatus);
            x(oe, e => {
                e ? setTimeout(() => {
                    let s = document.querySelector("#musicAudio");
                    if (s) {
                        let a = s.duration * 1e3;
                        y.value !== p(a.toString()) && a && (y.value = p(a.toString())), g.value && clearInterval(g.value), g.value = setInterval(() => {
                            I.value = p((s.currentTime || 0) * 1e3), ne()
                        }, 1e3)
                    }
                }, 100) : g.value && clearInterval(g.value)
            }), x(K, (e, s) => {
                e.id !== s.id && setTimeout(() => {
                    let a = document.querySelector("#musicAudio");
                    if (a && !a.paused) {
                        let l = a.duration * 1e3;
                        l && (y.value = p(l.toString()))
                    }
                    d.value === 0 ? r.value = t.state.musicInfo.allList.findIndex(l => l.id === e.id) : r.value = t.state.musicInfo.downloadList.findIndex(l => l.id === e.id)
                }, 100)
            }), x(d, () => {
                r.value = L.value.findIndex(e => e.id === t.state.musicInfo.currentMusic.id)
            });
            const Y = b({
                    get() {
                        return le.value
                    },
                    set(e) {
                        ie("update:value", e)
                    }
                }),
                ce = () => {
                    t.state.musicInfo.cycleType === "cycle" ? t.state.musicInfo.cycleType = "random" : t.state.musicInfo.cycleType === "random" ? t.state.musicInfo.cycleType = "single" : t.state.musicInfo.cycleType = "cycle"
                },
                ne = () => {
                    let e = document.querySelector("#musicAudio"),
                        s = e.duration,
                        a = e.currentTime / s;
                    f.value = a * 100
                },
                me = e => {
                    let s = document.querySelector("#musicAudio");
                    s.volume = e / 100, localStorage.setItem("volume", e / 100)
                },
                de = e => {
                    let s = document.querySelector("#musicAudio");
                    globalVBus.$emit("startMusic"), setTimeout(() => {
                        let a = s.duration;
                        s.currentTime = a * (e / 100), I.value = p(s.currentTime * 1e3)
                    })
                },
                Z = () => {
                    let e = document.querySelector("#musicAudio");
                    k.value = !k.value, k.value ? e.muted = "" : e.muted = "muted"
                },
                re = () => {
                    t.state.musicInfo.playStatus ? globalVBus.$emit("pauseMusic") : globalVBus.$emit("startMusic")
                },
                ve = (e, s) => {
                    t.state.musicInfo.downloadList.find(l => l.id === e.id) || (t.state.musicInfo.downloadList.push(e), localStorage.setItem("myMusicList", JSON.stringify(t.state.musicInfo.downloadList.map(l => l.id)))), r.value = s, t.state.musicInfo.currentMusic = e, I.value = "00:00", f.value = 0;
                    let a = document.querySelector("#musicAudio");
                    a.src = e.info.url, globalVBus.$emit("startMusic")
                },
                pe = () => {
                    globalVBus.$emit("preMusic")
                },
                ye = () => {
                    globalVBus.$emit("nextMusic")
                },
                fe = e => {
                    if (t.state.musicInfo.downloadList = t.state.musicInfo.downloadList.filter(s => s.id !== e.id), localStorage.setItem("myMusicList", JSON.stringify(t.state.musicInfo.downloadList.map(s => s.id))), I.value = "00:00", f.value = 0, K.value.id === e.id) {
                        t.state.musicInfo.currentMusic = t.state.musicInfo.downloadList[0], r.value = 0;
                        let s = document.querySelector("#musicAudio");
                        s.src = t.state.musicInfo.downloadList[0].info.url, t.state.musicInfo.playStatus && globalVBus.$emit("startMusic")
                    } else r.value = L.value.findIndex(s => s.id === t.state.musicInfo.currentMusic.id)
                },
                Ie = e => {
                    let s = document.createElement("video");
                    t.state.musicInfo.downloadList.push(e), localStorage.setItem("myMusicList", JSON.stringify(t.state.musicInfo.downloadList.map(a => a.id))), s.src = e.info.url, s.load()
                },
                ge = () => {
                    Ce(ue("music.deleteTips"), "warning")
                };
            return Be(() => {
                localStorage.getItem("volume") && (w.value = localStorage.getItem("volume") * 100), setTimeout(() => {
                    let e = document.querySelector("#musicAudio");
                    e.addEventListener("loadeddata", () => {
                        let s = e.duration * 1e3;
                        y.value !== p(s.toString()) && s && (y.value = p(s.toString()))
                    })
                }, 20)
            }), (e, s) => {
                const a = we,
                    l = Me("svg-icon"),
                    _e = Le;
                return u(), n(o(ae), {
                    class: "music-list-dialog",
                    title: e.$t("music.music"),
                    value: Y.value,
                    modalClose: !1,
                    onInput: s[4] || (s[4] = c => Y.value = !1)
                }, {
                    footer: $(() => []),
                    default: $(() => [i("div", V, [i("div", A, [i("span", q, m(e.$t("music.music")), 1), _(a, {
                        modelValue: w.value,
                        "onUpdate:modelValue": s[0] || (s[0] = c => w.value = c),
                        onInput: me,
                        "show-tooltip": !1,
                        class: "sliderBox"
                    }, null, 8, ["modelValue"]), k.value ? (u(), n(l, {
                        key: 0,
                        iconClass: "music_notice",
                        class: "noticeIcon",
                        onClick: Z
                    })) : (u(), n(l, {
                        key: 1,
                        iconClass: "music_mute",
                        class: "noticeIcon",
                        onClick: Z
                    }))]), i("div", O, [i("p", null, m(o(t).state.musicInfo.currentMusic.name), 1), i("div", E, [i("div", J, m(I.value || "00:00"), 1), _(a, {
                        modelValue: f.value,
                        "onUpdate:modelValue": s[1] || (s[1] = c => f.value = c),
                        onInput: de,
                        "show-tooltip": !1,
                        class: "sliderBox"
                    }, null, 8, ["modelValue"]), i("div", N, m(y.value || "00:00"), 1)]), i("div", P, [i("div", {
                        class: "funBox-left",
                        onClick: ce
                    }, [o(t).state.musicInfo.cycleType === "cycle" ? (u(), n(l, {
                        key: 0,
                        iconClass: "music_cycle"
                    })) : o(t).state.musicInfo.cycleType === "random" ? (u(), n(l, {
                        key: 1,
                        iconClass: "music_random"
                    })) : o(t).state.musicInfo.cycleType === "single" ? (u(), n(l, {
                        key: 2,
                        iconClass: "music_single"
                    })) : ee("", !0), i("span", null, m(o(t).state.musicInfo.cycleType === "cycle" ? e.$t("music.cycle") : o(t).state.musicInfo.cycleType === "random" ? e.$t("music.shuffle") : e.$t("music.repeat")), 1)]), i("div", U, [i("div", {
                        class: "pre",
                        onClick: pe,
                        style: B(`background-image:url('/img/colors/${o(T)()}/music_btn_bg.png');`)
                    }, [_(l, {
                        iconClass: "music_pre"
                    })], 4), i("div", {
                        class: "play",
                        onClick: re,
                        style: B(`background-image:url('/img/colors/${o(T)()}/music_btn_bg.png');`)
                    }, [o(t).state.musicInfo.playStatus ? (u(), n(l, {
                        key: 0,
                        iconClass: "music_pause",
                        class: "play-pause"
                    })) : (u(), n(l, {
                        key: 1,
                        iconClass: "music_start",
                        class: "play-start"
                    }))], 4), i("div", {
                        class: "next",
                        onClick: ye,
                        style: B(`background-image:url('/img/colors/${o(T)()}/music_btn_bg.png');`)
                    }, [_(l, {
                        iconClass: "music_next"
                    })], 4)]), i("div", z, [i("span", null, m(o(t).state.musicInfo.downloadList.length), 1), i("span", null, m(e.$t("music.downloaded")), 1)])])]), i("div", R, [i("div", j, [i("div", {
                        class: M(["tab", {
                            active: d.value === 0
                        }]),
                        onClick: s[2] || (s[2] = c => d.value = 0)
                    }, [i("span", null, m(e.$t("music.system_music")), 1)], 2), i("div", {
                        class: M(["tab", {
                            active: d.value === 1
                        }]),
                        onClick: s[3] || (s[3] = c => d.value = 1)
                    }, [i("span", null, m(e.$t("music.my_music")), 1)], 2)]), i("div", D, [_(_e, {
                        height: o(t).state.isMobile ? "5.24rem" : "3.22rem",
                        always: !0,
                        tag: "ul"
                    }, {
                        default: $(() => [(u(!0), h(he, null, Ve(L.value, (c, S) => (u(), h("li", {
                            key: c.id,
                            class: M(["music-item", {
                                active: r.value === S
                            }])
                        }, [i("div", {
                            class: "music-item-info",
                            onClick: C => ve(c, S)
                        }, [i("div", W, [r.value === S ? (u(), n(l, {
                            key: 0,
                            iconClass: "music_logo"
                        })) : (u(), h("span", X, m(S + 1), 1))]), i("div", F, m(c.name), 1), i("div", G, m(o(Se)(c.info.size)), 1)], 8, Q), i("div", H, [o(t).state.musicInfo.downloadList.map(C => C.id).includes(c.id) ? (u(), n(l, {
                            key: 0,
                            iconClass: "music_ticked"
                        })) : (u(), n(l, {
                            key: 1,
                            iconClass: "music_download",
                            onClick: C => Ie(c)
                        }, null, 8, ["onClick"])), d.value === 1 && o(t).state.musicInfo.downloadList.length > 1 ? (u(), n(l, {
                            key: 2,
                            iconClass: "music_delete",
                            style: {
                                "margin-left": ".25rem"
                            },
                            onClick: C => fe(c)
                        }, null, 8, ["onClick"])) : d.value === 1 ? (u(), n(l, {
                            key: 3,
                            iconClass: "music_disabled_delete",
                            style: {
                                "margin-left": ".25rem",
                                cursor: "not-allowed"
                            },
                            class: "disabled",
                            onClick: ge
                        })) : ee("", !0)])], 2))), 128))]),
                        _: 1
                    }, 8, ["height"])])])])]),
                    _: 1
                }, 8, ["title", "value"])
            }
        }
    }
});
export {
    Ae as __tla, se as
    default
};