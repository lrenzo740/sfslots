import {
    d as C,
    __tla as k
} from "./index.0a674315.js";
import {
    _ as w
} from "./dark_close.53d49d42.js";
import {
    u as F
} from "./vue-i18n.d9454f26.js";
import {
    u as T
} from "./vuex.7fead168.js";
import {
    r as c,
    f as j,
    j as B,
    ab as O,
    o as r,
    c as i,
    a as u,
    W as d,
    L as V,
    a4 as $,
    u as A,
    O as b
} from "./@vue.16908cbf.js";
import "./axios.4a70c6fc.js";
import "./vue-router.d17f0860.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vant.be74fb7c.js";
import "./@vant.359a3f91.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@intlify.7347860c.js";
let v, D = Promise.all([(() => {
    try {
        return k
    } catch {}
})()]).then(async () => {
    let s, l, e, m;
    s = {
        key: 0,
        class: "alert-dialog"
    }, l = {
        class: "alert-dialog-box"
    }, e = {
        class: "alert-dialog-box-content"
    }, m = {
        class: "alert-dialog-box-btn"
    }, v = {
        __name: "index",
        setup(L) {
            const {
                t: f
            } = F(), p = c(""), t = j({
                btnText: "",
                confirmFun: () => {},
                showClose: !1
            }), a = c(!1), g = T(), x = (n = "", o = {
                btnText: f("common.confirm"),
                confirmFun: () => {},
                showClose: !1
            }) => {
                a.value = !0, p.value = n, Object.assign(t, o)
            }, _ = async () => {
                try {
                    a.value = !1, await t.confirmFun()
                } catch {}
            };
            return B(() => {
                globalVBus.$on("handleAlert", x)
            }), (n, o) => {
                const h = O("throttle");
                return a.value ? (r(), i("div", s, [u("div", l, [u("div", e, d(p.value), 1), V((r(), i("div", m, [$(d(t.btnText), 1)])), [
                    [h, _, "loading"]
                ]), t.showClose && A(g).state.isMobile ? (r(), i("img", {
                    key: 0,
                    src: C,
                    class: "alert-dialog-box-close",
                    onClick: o[0] || (o[0] = y => a.value = !1)
                })) : t.showClose ? (r(), i("img", {
                    key: 1,
                    src: w,
                    class: "alert-dialog-box-close",
                    onClick: o[1] || (o[1] = y => a.value = !1)
                })) : b("", !0)])])) : b("", !0)
            }
        }
    }
});
export {
    D as __tla, v as
    default
};