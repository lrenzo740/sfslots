import {
    _ as B,
    g as De,
    $ as K,
    i as We,
    t as qe,
    n as Ho,
    o as nt,
    b as Me,
    p as Ve,
    q as jo,
    r as Do,
    T as Ge,
    c as Mo,
    s as st,
    __tla as Vo
} from "./index.0a674315.js";
import {
    S as zo,
    d as Uo,
    e as Oo,
    T as Fo,
    f as No
} from "./vant.be74fb7c.js";
import {
    f as be,
    r as k,
    j as Ke,
    k as ze,
    l as Ze,
    ab as Je,
    o as s,
    c as d,
    a as t,
    u as o,
    U as D,
    S as oe,
    P as X,
    a3 as Q,
    R as f,
    L,
    O as v,
    M as we,
    Q as de,
    W as p,
    an as R,
    n as ne,
    e as Ye,
    w as me,
    aa as it,
    X as Ue,
    V as O,
    Y as Xo,
    d as Qo
} from "./@vue.16908cbf.js";
import {
    u as Oe
} from "./vuex.7fead168.js";
import {
    b as et,
    u as tt
} from "./vue-router.d17f0860.js";
import {
    S as ct,
    A as rt,
    P as ut,
    a as dt
} from "./swiper.137b1af3.js";
import {
    _ as Fe
} from "./hot_tag.71dc183d.js";
import {
    _ as Ne,
    a as Xe,
    b as mt
} from "./bookmark_star_2.d7385625.js";
import {
    _ as at
} from "./maintenance.1b212141.js";
import {
    _ as pt,
    a as gt
} from "./blank.e4277571.js";
import {
    u as vt
} from "./vue-i18n.d9454f26.js";
import {
    _ as Wo
} from "./img_vip.31840ec8.js";
import {
    C as Go
} from "./clipboard.f53621db.js";
import {
    X as Se
} from "./xe-utils.0e898ace.js";
import "./axios.4a70c6fc.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./nprogress.1adef0ba.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
import "./@vant.359a3f91.js";
import "./@intlify.7347860c.js";
let yt, Ko = Promise.all([(() => {
    try {
        return Vo
    } catch {}
})()]).then(async () => {
    const ht = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAAAAXNSR0IArs4c6QAABUBJREFUSEutln9slVcdxp/nnPe9pb8CBQEpvb12a71UHIjpgNy2RCYGdEvQZBgUBBdMZoIIVfhjsMXGQXBBUfkHURN0LoNVzQgsYJRIgLYqVAzVrre/aLmXHzLUTTIIvfd9z7O8JWUNghLhTd6/zvk+n3O+53ue7yHu8+tQhz88MKFsSplu1kyquTYa1pZ5cwFkvg8iAfEwfPNKbtg7sbCq6uad0rwf1tHu7knFxWaRA5ZQOmutfjGvovafUWz7UHdK1uyANBdgSKBHwB6yaH8qHv/XWP3/Cjsmef5Qdx2NWQPyMwCmCeqkwTfqK2b8PhJq6eqKVRRjpugvF7TM921VGLgrULjH5Lzvza95Pwv3hP1hsPtDoWeXGegLcPioCN8YAydlCG1IxZOvj111azpdyhKzQE4bfN9flM/nr8q5lwoTM3bVkflo7n/Aurq6YtdK7RInPgtivrF2onMhIGAE5tw5wTQ1VNYc/N3AwPiYzU80zL3TmJj1diTYmknXGZpvAXgK0qCDNuTjlw8v5MKAJzs7y2ITiydLHGe8MHRO5WHotgBcQJKSbm/gNoxYl6+49Ntx2fJ1DojS9xdPfGV+Itl66xz7U864nYTmkTjiGfvs3OnVWbZne3cILgUxJiAgWQKhGtC4O4tnFEZqLVB83OnGjwy5UrdWdIZ0P0jFa1/t6Ojwc5OLnxHNLgDXQa3PBQW/Ylu2Jx2LFSTDIBjRjqJcGN61SG/DxPWpxIffODnY9wlrtdzBfToWi1UGuXwn5LakErVvtGf7qyX3U0ANIPcz0Fa2ZXr/Zq2ZGd4DMJY6AgvdOVFNDZUzDkZjbX/vn4IgXAxxM6QZBI4ELlwTJmqvFlzoa5K0HUQ/nLZGaTxrjJn1/8IiYF9fX8HVWPhV0WwXdJ2w6+orq/e3nu/9lDHaJ4eYqD1sz/acNcY+ECwCHs92P+bBvAzhI5J+OLXSvnD5Qpi0jq/BoAZCy0OD/WkoXRUY7gTwWRA/ede/2TQ+X1IeKniVRJ2EAw8NNlIQCPdAWGiA3WLRRtgbCYXcB2E2iF8/FFhzc7NZ/MyKJx3dbhDjFerblxLJnZUX+x8PnfulgMlG+DnbMulOa73HHqRAjl3o+ljMec0klzqhS8SahoqaU+0Xe1fC4ccC3iGwg63newY833tk7N0a6xp3K30Hs6ExUXPo1FtdHwxythEyqyRFRp0D8VKu4tLW0svlE4YD7AC5GnInrPzn2ZpNH4E4n4IBFQL0ARQBMPdyEBHryq4FR98u8b5J4DkalkLuuoN5OWbN9sia2ob6n5AJf0ZoksBt0vButg2lnxDtLCAoJE0O5BRIXyRZcecOb3ujw9fyRcHJgpvedhGfl/APQfty5N5PxpMX27M90yFsozGr5Vy3gNX1lcnTbGlpsSVz5niFnseKINBbpRzPYbdR1ErP86ZFZzkKveUg4bnIyRsTtYcih5f4cQBvFvqlZ+rKy28cGxycELP5tYA2RVly0ouFfumuaOyu/eyPV85N1XDwOSd9CUQkNmLKt/qZO0+gKepnkqL46FfUIFoz6XKAXybRRPADEvaR2pSKJy/etZ+NnlMk1J4dmEkFqxzwNA3jnvW8IAgzIbR+QWXyQDQ3KvslK5aUBAVlsw3wFYFPkygScNjltbnxkeTZUc3/+QZpvZoutdfZ4AxWk6x30ilD15yK1/51pHdFl9mFXwe1FGQc4r8B/cbJfrcxUf3n+36DjNmlaRvsqaHHObQ2Eyt/9PRoqz+R6V7s0X5HUi2kyzDmNeXd3vqqZG+U2rGw9wCWTe0aziQyqQAAAABJRU5ErkJggg==",
        ft = "/png/img_tempPoker_01.c175fb65.png",
        kt = {
            class: "home-page"
        },
        _t = {
            class: "container"
        },
        bt = {
            key: 0,
            class: "mini-banner"
        },
        wt = {
            key: 1,
            class: "notice"
        },
        Tt = {
            src: ht
        },
        Lt = {
            class: "notice-content"
        },
        It = ["innerHTML"],
        xt = {
            class: "notice-btn"
        },
        Ct = {
            class: "gameBox"
        },
        qt = {
            class: "gameBox-table"
        },
        St = {
            key: 0,
            class: "tags"
        },
        At = ["onClick"],
        Pt = {
            key: 0,
            class: "hot-tips"
        },
        Et = {
            key: 0,
            class: "scrollBox"
        },
        Bt = {
            key: 0,
            class: "gameBox-container"
        },
        Rt = {
            key: 1,
            class: "manufacturer-container"
        },
        $t = ["onClick"],
        Ht = ["src"],
        jt = ["src"],
        Dt = {
            key: 1,
            src: ft,
            class: "manufacturer-item-img"
        },
        Mt = {
            __name: "default",
            setup(Be) {
                const M = R(() => B(() =>
                        import ("./index.b235957e.js").then(async b => (await b.__tla, b)), ["js/index.b235957e.js", "js/@vue.16908cbf.js", "js/maintenance.1b212141.js", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/index.0767a7c7.css"])),
                    se = Oe(),
                    pe = et();
                let ge = be([]);
                const ve = k();
                let ie = k("title");
                k(""), k(0), k(0), k(!1);
                const ye = k(null),
                    te = k(null),
                    A = k(!1),
                    n = k([]),
                    q = k(0),
                    I = k(),
                    F = k(null),
                    U = k(!1),
                    g = k(!1),
                    y = k(0),
                    $ = k(15),
                    Z = k(0),
                    V = k([]),
                    W = k([]),
                    ae = k(null),
                    J = b => ({
                        loading: new URL("/img/colors/" + De() + "/search.png",
                            import.meta.url).href,
                        src: b.image
                    }),
                    Te = () => {
                        K.get("/user/site/banners", {
                            type: 1
                        }).then(b => {
                            if (b.code === 0) {
                                let {
                                    list: C,
                                    time: N
                                } = b.data;
                                C.length && (ge.push(...C), ve.value = N)
                            }
                        })
                    },
                    _ = () => {
                        K.get("/game/game/types").then(b => {
                            b.code === 0 && (n.value = b.data.filter(C => !!C.status), I.value = n.value[0])
                        })
                    },
                    Ae = (b, C) => {
                        q.value !== C && (I.value = b, y.value = 0, he(C), q.value = C, V.value = [], W.value = [], g.value = !1, U.value = !0, globalVBus.$emit("globalLoading", !0), ce())
                    },
                    ce = async () => {
                        y.value++, I.value.typeName === "\u70ED\u95E8" ? ($.value = 4, await Le()) : ($.value = 4, await z())
                    },
                    he = b => {
                        ne(() => {
                            let C = document.querySelector(".tags");
                            if (!C) return;
                            let N = C.clientWidth - document.querySelectorAll(".tag")[0].clientWidth,
                                H = C.scrollLeft,
                                le = F.value[b].offsetLeft - N / 2 > 0 ? F.value[b].offsetLeft - N / 2 : 0;
                            if (le > H) {
                                let Y = setInterval(() => {
                                    le > H ? (H = H + 5, C.scrollLeft = H) : clearInterval(Y)
                                })
                            } else {
                                let Y = setInterval(() => {
                                    le < H ? (H = H - 5, C.scrollLeft = H) : clearInterval(Y)
                                })
                            }
                        })
                    },
                    Pe = b => {
                        b.redirectUrl && (b.redirectUrl.indexOf("http") > -1 ? window.open(b.redirectUrl, "new") : pe.push(b.redirectUrl))
                    },
                    P = b => {
                        pe.push({
                            path: "/manufacturer",
                            query: {
                                id: b.id || 2,
                                name: b.name
                            }
                        })
                    },
                    z = async () => {
                        let b = {
                            type: n.value[q.value].type,
                            _page: y.value,
                            _size: $.value
                        };
                        await K.get("/game/game/vendors", b).then(C => {
                            if (globalVBus.$emit("globalLoading", !1), C.code === 0) {
                                const {
                                    list: N,
                                    total: H
                                } = C.data;
                                if (I.value.type !== b.type) return;
                                W.value.push(...N), U.value = !1, Z.value = H, g.value = W.value.length >= Z.value
                            }
                        })
                    },
                    Le = async () => {
                        let b = {
                            tag: 1,
                            _page: y.value,
                            _size: $.value
                        };
                        await K.get("/game/game/list", b).then(C => {
                            if (globalVBus.$emit("globalLoading", !1), C.code === 0) {
                                let {
                                    list: N,
                                    total: H
                                } = C.data;
                                V.value.push(...N), Z.value = H, U.value = !1, g.value = V.value.length >= Z.value
                            }
                        })
                    };
                return Ke(() => {
                    Te(), _()
                }), ze(() => {
                    n.value.length && (globalVBus.$emit("globalLoading", !0), V.value = [], W.value = [], y.value = 0, U.value = !0, ce())
                }), Ze(() => {
                    ye.value && clearInterval(ye.value), te.value && clearInterval(te.value), A.value = !1
                }), (b, C) => {
                    const N = zo,
                        H = Uo,
                        le = Oo,
                        Y = Je("lazy");
                    return s(), d("div", kt, [t("div", _t, [o(se).state.sections.banner ? (s(), d("div", bt, [D(H, {
                        class: "my-swipe",
                        autoplay: ve.value * 1e3,
                        "indicator-color": "white",
                        "stop-propagation": !1
                    }, {
                        default: oe(() => [(s(!0), d(X, null, Q(o(ge), E => (s(), f(N, {
                            key: E,
                            onClick: ee => Pe(E)
                        }, {
                            default: oe(() => [L(t("img", null, null, 512), [
                                [Y, J(E)]
                            ])]),
                            _: 2
                        }, 1032, ["onClick"]))), 128))]),
                        _: 1
                    }, 8, ["autoplay"])])) : v("", !0), o(se).state.sections.broadcast ? (s(), d("div", wt, [L(t("img", Tt, null, 512), [
                        [we, o(ie)]
                    ]), t("div", Lt, [t("div", {
                        class: "notice-scrollBox",
                        innerHTML: o(ie)
                    }, null, 8, It)]), L(t("div", xt, "More", 512), [
                        [we, o(ie)]
                    ])])) : v("", !0), t("div", Ct, [t("div", qt, [n.value.length ? (s(), d("div", St, [(s(!0), d(X, null, Q(n.value, (E, ee) => (s(), d("span", {
                        key: ee,
                        class: de(["tag", {
                            active: q.value === ee
                        }]),
                        onClick: Ie => Ae(E, ee),
                        ref_for: !0,
                        ref_key: "tag",
                        ref: F
                    }, [L(t("img", null, null, 512), [
                        [Y, E.imgUrl]
                    ]), t("span", null, p(E.typeName || ""), 1), ee === 0 && E.typeName === "\u70ED\u95E8" ? (s(), d("div", Pt, "HOT")) : v("", !0)], 10, At))), 128))])) : v("", !0)]), n.value.length ? (s(), d("div", Et, [I.value.typeName === "\u70ED\u95E8" ? (s(), d("div", Bt, [D(le, {
                        loading: U.value,
                        "onUpdate:loading": C[0] || (C[0] = E => U.value = E),
                        finished: g.value,
                        "loading-text": "",
                        ref_key: "scrollList",
                        ref: ae,
                        offset: "100",
                        onLoad: ce
                    }, {
                        default: oe(() => [D(o(M), {
                            gameList: V.value,
                            showType: "home"
                        }, null, 8, ["gameList"])]),
                        _: 1
                    }, 8, ["loading", "finished"])])) : (s(), d("div", Rt, [D(le, {
                        loading: U.value,
                        "onUpdate:loading": C[1] || (C[1] = E => U.value = E),
                        finished: g.value,
                        "loading-text": "",
                        ref_key: "scrollList",
                        ref: ae,
                        offset: "100",
                        onLoad: ce
                    }, {
                        default: oe(() => [(s(!0), d(X, null, Q(W.value, (E, ee) => (s(), d("div", {
                            class: "manufacturer-item",
                            key: ee,
                            onClick: Ie => P(E)
                        }, [t("img", {
                            src: E.image,
                            class: "manufacturer-item-logo"
                        }, null, 8, Ht), E.sloganImage ? (s(), d("img", {
                            key: 0,
                            src: E.sloganImage,
                            alt: "",
                            class: "manufacturer-item-img"
                        }, null, 8, jt)) : (s(), d("img", Dt))], 8, $t))), 128))]),
                        _: 1
                    }, 8, ["loading", "finished"])]))])) : v("", !0)])])])
                }
            }
        },
        Vt = {
            class: "dark-home-page"
        },
        zt = {
            class: "container"
        },
        Ut = {
            class: "home-page-scroll"
        },
        Ot = {
            key: 2,
            class: "mini-banner"
        },
        Ft = {
            class: "gameTabs"
        },
        Nt = ["onClick"],
        Xt = ["src"],
        Qt = {
            class: "textBox"
        },
        Wt = {
            key: 2,
            class: "festival"
        },
        Gt = t("div", {
            class: "festival-img"
        }, null, -1),
        Kt = [Gt],
        Zt = {
            class: "searchBox"
        },
        Jt = ["src"],
        Yt = {
            class: "tab-content"
        },
        ea = {
            key: 0,
            class: "recentTab"
        },
        ta = {
            class: "item-title"
        },
        aa = {
            class: "item-title-left"
        },
        la = ["src"],
        oa = {
            key: 0,
            class: "item-list"
        },
        na = ["onClick"],
        sa = {
            key: 1,
            src: Fe,
            class: "hotTag"
        },
        ia = ["src", "onClick"],
        ca = ["onClick"],
        ra = ["onClick"],
        ua = {
            key: 5,
            class: "maintain"
        },
        da = t("img", {
            src: at,
            alt: ""
        }, null, -1),
        ma = {
            class: "names"
        },
        pa = {
            class: "gameName"
        },
        ga = {
            key: 1,
            class: "blankImg"
        },
        va = {
            key: 0,
            src: pt,
            alt: ""
        },
        ya = {
            key: 1,
            src: gt,
            alt: ""
        },
        ha = {
            key: 1,
            class: "recentTab"
        },
        fa = {
            class: "item-title"
        },
        ka = {
            class: "item-title-left"
        },
        _a = ["src"],
        ba = {
            key: 0,
            class: "item-list"
        },
        wa = ["onClick"],
        Ta = {
            key: 1,
            src: Fe,
            class: "hotTag"
        },
        La = ["src", "onClick"],
        Ia = ["onClick"],
        xa = ["onClick"],
        Ca = {
            key: 5,
            class: "maintain"
        },
        qa = t("img", {
            src: at,
            alt: ""
        }, null, -1),
        Sa = {
            class: "names"
        },
        Aa = {
            class: "gameName"
        },
        Pa = {
            key: 1,
            class: "blankImg"
        },
        Ea = {
            key: 0,
            src: pt,
            alt: ""
        },
        Ba = {
            key: 1,
            src: gt,
            alt: ""
        },
        Ra = ["id"],
        $a = {
            class: "item-title"
        },
        Ha = {
            class: "item-title-left"
        },
        ja = ["src"],
        Da = ["onClick"],
        Ma = {
            class: "item-list"
        },
        Va = ["onClick"],
        za = {
            key: 1,
            src: Fe,
            class: "hotTag"
        },
        Ua = ["src"],
        Oa = ["src", "onClick"],
        Fa = ["onClick"],
        Na = ["onClick"],
        Xa = {
            key: 6,
            class: "maintain"
        },
        Qa = t("img", {
            src: at,
            alt: ""
        }, null, -1),
        Wa = {
            class: "names"
        },
        Ga = {
            key: 0,
            class: "gameName"
        },
        Ka = ["onClick"],
        Za = {
            class: "item-tips-text"
        },
        Ja = {
            class: "item-tips-btn"
        },
        Ya = {
            class: "floatBox"
        },
        el = {
            class: "imgBox"
        },
        tl = {
            __name: "dark",
            setup(Be) {
                const M = R(() => B(() =>
                        import ("./notice.1965d519.js").then(async i => (await i.__tla, i)), ["js/notice.1965d519.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "js/swiper.137b1af3.js", "css/swiper.c73a1d56.css", "css/notice.e7929a49.css"])),
                    se = R(() => B(() =>
                        import ("./footer.dafc9156.js").then(async i => (await i.__tla, i)), ["js/footer.dafc9156.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/vue-router.d17f0860.js", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/footer.913dc7b5.css"])),
                    pe = R(() => B(() =>
                        import ("./fixed_banner.b45e1be5.js").then(async i => (await i.__tla, i)), ["js/fixed_banner.b45e1be5.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/fixed_banner.74a0ec54.css"])),
                    ge = R(() => B(() =>
                        import ("./index.8240e21f.js").then(async i => (await i.__tla, i)), ["js/index.8240e21f.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/index.fbaed231.css"])),
                    ve = R(() => B(() =>
                        import ("./index.1dbd0564.js").then(async i => (await i.__tla, i)), ["js/index.1dbd0564.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css"])),
                    ie = R(() => B(() =>
                        import ("./banner.4b5938a5.js").then(async i => (await i.__tla, i)), ["js/banner.4b5938a5.js", "js/@vue.16908cbf.js", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/banner.9785577e.css"])),
                    ye = R(() => B(() =>
                        import ("./fixed_ad.bf9c68db.js").then(async i => (await i.__tla, i)), ["js/fixed_ad.bf9c68db.js", "js/@vue.16908cbf.js", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/fixed_ad.763aabfb.css"])),
                    te = R(() => B(() =>
                        import ("./fixed_customer.60dcf12b.js"), ["js/fixed_customer.60dcf12b.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "css/fixed_customer.88fd6170.css"])),
                    A = R(() => B(() =>
                        import ("./jackpot.beb1f51d.js").then(async i => (await i.__tla, i)), ["js/jackpot.beb1f51d.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/jackpot.4d99e285.css"]));
                vt();
                const n = Oe(),
                    q = et(),
                    I = tt();
                let F = be([]);
                const U = k(),
                    g = k(),
                    y = be([]),
                    $ = k(!1),
                    Z = k(!1),
                    V = k(!1),
                    W = k(!0),
                    ae = k(9),
                    J = k(!1),
                    Te = k(""),
                    _ = k(!1);
                let Ae = Ye(() => !n.state.isApp && W.value && !!n.state.sections.downloadBar && !We());
                me(() => n.state.activeTab, i => {
                    if (n.state.tableList.length) {
                        let m = n.state.tableList[i].type;
                        q.replace(`/index?gameType=${m}`)
                    }
                }), me(_, () => {
                    I.query.gameType && z()
                }), me(y, i => {
                    ne(() => {
                        Y()
                    })
                }, {
                    deep: !0
                });
                const ce = i => ({
                        loading: new URL("/img/colors/" + De() + "/default_large.png",
                            import.meta.url).href,
                        src: i.image
                    }),
                    he = i => ({
                        loading: Te,
                        src: i
                    }),
                    Pe = () => new URL("/img/colors/" + De() + "/search.png",
                        import.meta.url).href,
                    P = i => {
                        i.showLength = i.total, setTimeout(() => {
                            fe()
                        })
                    },
                    z = () => {
                        if (!I.query.gameType) return;
                        const i = I.query.gameType || 0;
                        let m = n.state.tableList.findIndex(T => T.type == i),
                            h = n.state.tableList.find(T => T.type == i);
                        h && setTimeout(() => {
                            n.state.isMobile ? Ie(m, h) : Ee(m, h)
                        })
                    },
                    Le = () => {
                        let i;
                        n.state.isMobile ? i = document.querySelector("#app .home-page-scroll") : i = document.querySelector("#app .scroll-wrapper");
                        let m = i.scrollTop;
                        m -= 100, m = Math.max(m, 0), i.scrollTo(0, m), m > 0 && requestAnimationFrame(Le)
                    },
                    b = (i, m) => {
                        K.post("game/game/collect", {
                            id: i.id,
                            gameType: i.type,
                            type: i.collect ? 0 : 1
                        }).then(h => {
                            if (h.code === 0) {
                                i.bookmark_star_2 = mt + new Date().getTime(), i.collect = !i.collect, i.collect && (i.clickCollect = !0);
                                let T = y.find(a => a.type === 99);
                                y.find(a => a.type === 0).vendors.forEach(a => {
                                    a.id === i.id && (a.collect = i.collect)
                                });
                                let x = T.vendors.findIndex(a => a.id === i.id);
                                x > -1 ? T.vendors.splice(x, 1) : T.vendors.unshift(i)
                            }
                        })
                    },
                    C = (i, m) => {
                        i.maintain !== 1 && q.push({
                            path: "/sub-game",
                            query: {
                                typeId: i.type || m,
                                vendor: i.vendor
                            }
                        })
                    },
                    N = () => {
                        K.get("/user/site/banners", {
                            type: 1
                        }).then(i => {
                            if (i.code === 0) {
                                let {
                                    list: m,
                                    time: h
                                } = i.data;
                                m.length && (F.push(...m), U.value = h)
                            }
                        })
                    },
                    H = () => {
                        let i = document.querySelector(".dark-home-page .van-tabs__nav"),
                            m = i.scrollLeft;
                        m -= 20, m = Math.max(m, 0), i.scrollTo(m, 0), m > 0 && requestAnimationFrame(H)
                    },
                    le = () => {
                        let i = document.querySelector(".dark-home-page .van-tabs__nav"),
                            m = i.scrollLeft,
                            h = document.querySelectorAll(".dark-home-page .van-tab"),
                            T = h[0].clientWidth * h.length;
                        m += 20, i.scrollTo(m, 0), m < T - i.clientWidth && requestAnimationFrame(le)
                    },
                    Y = () => {
                        let i = document.querySelectorAll(".dark-home-page .van-tab");
                        if (!i.length) return;
                        let m = i[0].clientWidth * i.length,
                            h = document.querySelector(".dark-home-page .van-tabs__nav"),
                            T = h.clientWidth,
                            x = h.scrollLeft,
                            a = 20;
                        x + T + a < m ? Z.value = !0 : Z.value = !1, x > a ? $.value = !0 : $.value = !1
                    },
                    E = async i => {
                        let m = [],
                            h = 0,
                            T = {
                                tag: i,
                                _page: 1,
                                _size: 1e3
                            };
                        return await K.get("/game/game/list", T).then(x => {
                            if (x.code === 0) {
                                let {
                                    list: a,
                                    total: e
                                } = x.data;
                                m.push(...a), h = e
                            }
                        }), {
                            gameList: m,
                            totalCount: h
                        }
                    },
                    ee = (i, m) => {
                        n.state.activeTab !== i && (q.replace("/index?gameType=" + m.type), Re(i, m))
                    },
                    Ie = async (i, m) => {
                        const h = parseFloat(getComputedStyle(document.documentElement).fontSize);
                        let T = document.querySelector("#app .home-page-scroll"),
                            x = document.querySelector(".dark-home-page .mini-banner"),
                            a = document.querySelector(".dark-home-page .notice"),
                            e = document.querySelector(".dark-home-page .jackpot-box-2"),
                            u = document.querySelector(".dark-home-page .jackpot-box-3"),
                            r = x.clientHeight + a.clientHeight + .4 * h;
                        e && (r = r + e.clientHeight), u && (r = r + u.clientHeight), ne(async () => {
                            n.state.activeTab = i, m.type === 98 || m.type === 99 ? (g.value = m, T.scrollTo(0, r), m.vendors = [], m.type === 98 ? qe() && (m.vendors = (await E(2)).gameList, m.vendors.forEach(l => l.loading = !0), setTimeout(() => {
                                fe()
                            })) : qe() && (m.vendors = (await E(3)).gameList, m.vendors.forEach(l => l.loading = !0), setTimeout(() => {
                                fe()
                            }))) : (g.value = "", setTimeout(() => {
                                let l = document.querySelectorAll(".dark-home-page .home-page-scroll .item"),
                                    c = 0;
                                for (var w = 0; w < i; w++) c += l[w].clientHeight;
                                let S = r + c + 5;
                                T.scrollTo(0, S)
                            }))
                        })
                    },
                    Ee = async (i, m) => {
                        if (I.name !== "index") return;
                        let h = document.querySelector("#app .scroll-wrapper");
                        if (n.state.activeTab === i) return;
                        let T = document.querySelector(".download-app"),
                            x = document.querySelector(".dark-home-page .home-pc-banner") || {
                                clientHeight: 0
                            },
                            a = document.querySelector(".dark-home-page .notice"),
                            e = document.querySelector(".van-tabs"),
                            u = document.querySelector(".dark-home-page .jackpot-box-2"),
                            r = document.querySelector(".dark-home-page .jackpot-box-3"),
                            l = x.clientHeight + a.clientHeight + 45 + "px";
                        T && (l = l + T.clientHeight), u && (l = l + u.clientHeight), r && (l = l + r.clientHeight), ne(async () => {
                            m.type === 98 || m.type === 99 ? (g.value = m, h.scrollTo(0, l), m.vendors = [], n.state.activeTab = i, m.type === 98 ? qe() && (m.vendors = (await E(2)).gameList) : qe() && (m.vendors = (await E(3)).gameList)) : (g.value = "", n.state.activeTab = i, ne(() => {
                                let c = document.querySelectorAll(".dark-home-page .home-page-scroll .item"),
                                    w = 0;
                                for (var S = 0; S < i; S++) w += c[S].clientHeight;
                                let j = i === 0 ? l + w : l + w + e.clientHeight;
                                h.scrollTo(0, j)
                            }))
                        })
                    },
                    re = () => {
                        let i = .4;
                        ne(() => {
                            const m = parseFloat(getComputedStyle(document.documentElement).fontSize);
                            let h = document.querySelector("#app .home-page-scroll"),
                                T = h.scrollTop,
                                x = document.querySelector(".dark-home-page .gameTabs"),
                                a = document.querySelector(".download-app"),
                                e = document.querySelector(".dark-headerMenu"),
                                u = document.querySelector(".dark-home-page .mini-banner"),
                                r = document.querySelector(".dark-home-page .notice"),
                                l = document.querySelector(".dark-home-page .jackpot-box-2"),
                                c = document.querySelector(".dark-home-page .jackpot-box-3"),
                                w = u.getBoundingClientRect().height + r.getBoundingClientRect().height + m * i,
                                S = a ? a.getBoundingClientRect().height + e.getBoundingClientRect().height : e.getBoundingClientRect().height;
                            l && (w = w + l.clientHeight), c && (w = w + c.clientHeight);
                            let j = document.querySelector(".dark-home-page .preIcon"),
                                ue = document.querySelector(".dark-home-page .nextIcon");
                            T >= w ? (x.classList.add("fixed"), j.classList.add("fixed"), ue.classList.add("fixed"), x.style.top = S + "px", h.style.paddingTop = x.clientHeight + m * .2 + "px", V.value = !0) : (x.classList.remove("fixed"), j.classList.remove("fixed"), ue.classList.remove("fixed"), x.style.top = 0, h.style.paddingTop = ".2rem", V.value = !1);
                            let _e = document.querySelectorAll(".dark-home-page .home-page-scroll .item"),
                                G = [],
                                He = 0;
                            if (g.value || J.value) return x.style.opacity = "1";
                            Array.from(_e).forEach($o => {
                                He += $o.clientHeight, G.push(He)
                            });
                            let je = !0;
                            for (var Ce = G.length - 1; Ce >= 0; Ce--) {
                                if (!je) return;
                                T + 3 >= G[Ce] + w - 10 ? (Ce < G.length - 1 && (n.state.activeTab = Ce + 1), Ce + 1 > G.length - 1 ? x.style.opacity = "0" : x.style.opacity = "1", je = !1) : x.style.opacity = "1"
                            }
                            T < G[0] + w && (n.state.activeTab = 0)
                        })
                    },
                    xe = () => {
                        I.name === "index" && ne(() => {
                            let i = document.querySelector("#app .scroll-wrapper").scrollTop,
                                m = document.querySelector(".dark-home-page .home-pc-banner") || {
                                    clientHeight: 0
                                },
                                h = document.querySelector(".dark-home-page .notice") || {
                                    clientHeight: 0
                                },
                                T = document.querySelector(".dark-home-page .download-app"),
                                x = document.querySelector(".dark-home-page .jackpot-box-2"),
                                a = document.querySelector(".dark-home-page .jackpot-box-3"),
                                e = document.querySelector(".dark-home-page .van-tabs"),
                                u = T ? T.clientHeight + m.clientHeight + h.clientHeight + e.clientHeight + 35 : m.clientHeight + h.clientHeight + e.clientHeight + 35;
                            x && (u = u + x.clientHeight), a && (u = u + a.clientHeight), i >= u ? V.value = !0 : V.value = !1;
                            let r = document.querySelectorAll(".dark-home-page .home-page-scroll .item"),
                                l = [],
                                c = 0;
                            if (g.value || J.value) return;
                            Array.from(r).forEach(j => {
                                c += j.clientHeight, l.push(c)
                            });
                            let w = !0;
                            for (var S = l.length - 1; S >= 0; S--) {
                                if (!w) return;
                                i + 3 >= l[S] + u && (n.state.activeTab = S + 1, w = !1)
                            }
                            i < l[0] + u && (n.state.activeTab = 0)
                        })
                    },
                    Qe = () => {
                        W.value = !1, globalVBus.$emit("closeDownloadBar"), n.state.isMobile ? re() : xe()
                    },
                    Re = (i, m) => {
                        J.value = !0, setTimeout(() => {
                            J.value = !1
                        }, 500), n.state.isMobile ? Ie(i, m) : Ee(i, m)
                    };
                Ke(async () => {
                    N(), await ke(), Y();
                    let i = document.querySelector(".dark-home-page .van-tabs__nav");
                    i && i.addEventListener("scroll", Y), globalVBus.$on("refreshGameTypeVendorList", ke), globalVBus.$on("changeActiveTab", Re), ae.value = n.state.isMobile ? 9 : 12, window.addEventListener("resize", $e)
                }), ze(() => {
                    n.dispatch("getAppConfig"), n.state.isMobile ? document.querySelector("#app .home-page-scroll").addEventListener("scroll", re) : document.querySelector("#app .scroll-wrapper").addEventListener("scroll", xe), setTimeout(() => {
                        z()
                    }, 200)
                }), Ze(() => {});
                const fe = () => {
                        let i = document.querySelectorAll(".gameBox .innerBox"),
                            m = document.querySelectorAll(".vendorBox .innerBox"),
                            h = y.find(a => a.type === 0).vendors,
                            T = y.filter(a => a.type !== 0 && a.type !== 98 && a.type !== 99 && a.vendors.length),
                            x = [];
                        T.forEach(a => {
                            x.push(...a.vendors)
                        }), Array.from(i).forEach((a, e) => {
                            let u = a.getAttribute("data-src");
                            var r = document.createElement("img");
                            r.src = u, r.style.display = "none", document.body.appendChild(r), r.onload = function() {
                                a.style.backgroundImage = "url(" + u + ") no-repeat", document.body.removeChild(r), g.value ? g.value.vendors.forEach(l => {
                                    (l.image === u || l.sloganImage === u || l.hotImage === u) && (l.loading = !1)
                                }) : h.forEach(l => {
                                    (l.image === u || l.sloganImage === u || l.hotImage === u) && (l.loading = !1)
                                })
                            }
                        }), Array.from(m).forEach((a, e) => {
                            let u = a.getAttribute("data-src");
                            var r = document.createElement("img");
                            r.src = u, r.style.display = "none", document.body.appendChild(r), r.onload = function() {
                                a.style.backgroundImage = "url(" + u + ") no-repeat", document.body.removeChild(r), x.find(l => {
                                    (l.image === u || l.sloganImage === u) && (l.loading = !1)
                                })
                            }
                        })
                    },
                    $e = () => {
                        if (I.name !== "index") return;
                        if (n.state.isMobile) {
                            ae.value = 9;
                            let m = document.querySelector("#app .home-page-scroll");
                            document.querySelector("#app .scroll-wrapper").removeEventListener("scroll", xe), m.addEventListener("scroll", re)
                        } else {
                            ae.value = 12;
                            let m = document.querySelector("#app .scroll-wrapper");
                            document.querySelector("#app .home-page-scroll").removeEventListener("scroll", re), m.addEventListener("scroll", xe);
                            let h = document.querySelector(".home-page-scroll .van-tabs");
                            h.style.paddingTop = 0
                        }
                        let i = n.state.tableList.find(m => m.type === 0);
                        i && (i.showLength = Math.min(ae.value, i.total))
                    },
                    ke = async () => {
                        y.length = 0, await K.get("/game/game/typedVendors").then(async i => {
                            if (i.code === 0) {
                                y.push(...i.data.filter(u => !!u.vendors.length || u.type === 0 || u.type === 98 || u.type === 99)), y.forEach(async (u, r) => {
                                    u.type === 0 && I.query.gameType !== 98 && I.query.gameType !== 99 ? (u.vendors = (await E(1)).gameList, _.value = !0, u.total = u.vendors.length, u.showLength = Math.min(ae.value, u.total), u.vendors.forEach(l => {
                                        l.loading = !0
                                    }), setTimeout(() => {
                                        fe()
                                    })) : (u.total = u.vendors.length, u.showLength = Math.min(6, u.total), u.vendors.forEach(l => {
                                        l.loading = !0
                                    }))
                                });
                                let m = y.find(u => u.type === 0),
                                    h = y.findIndex(u => u.type === 0);
                                h !== -1 && y.splice(h, 1);
                                let T = y.find(u => u.type === 98),
                                    x = y.findIndex(u => u.type === 98);
                                x !== -1 && y.splice(x, 1);
                                let a = y.find(u => u.type === 99),
                                    e = y.findIndex(u => u.type === 99);
                                e !== -1 && y.splice(e, 1), m && y.unshift(m), T && y.push(T), a && y.push(a), n.state.tableList = y
                            }
                        })
                    };
                return (i, m) => {
                    const h = it("svg-icon"),
                        T = Fo,
                        x = No,
                        a = Je("lazy");
                    return s(), d("div", Vt, [t("div", zt, [o(Ae) ? (s(), f(o(ge), {
                        key: 0,
                        onClose: Qe,
                        ref: "downloadAppRef"
                    }, null, 512)) : v("", !0), L(D(o(ve), {
                        ref: "headerMenu"
                    }, null, 512), [
                        [we, o(Ho)()]
                    ]), t("div", Ut, [o(n).state.awardPools.find(e => e.position === 2) ? (s(), f(o(A), {
                        key: 0,
                        itemInfo: o(n).state.awardPools.find(e => e.position === 2)
                    }, null, 8, ["itemInfo"])) : v("", !0), o(n).state.sections.banner && o(F).length && !o(n).state.isMobile ? (s(), f(o(ie), {
                        key: 1,
                        bannerList: o(F),
                        autoplayTime: U.value
                    }, null, 8, ["bannerList", "autoplayTime"])) : v("", !0), o(n).state.sections.banner && o(n).state.isMobile ? (s(), d("div", Ot, [o(F).length ? (s(), f(o(dt), {
                        key: 0,
                        preventClicksPropagation: "",
                        loop: !0,
                        autoplay: {
                            delay: U.value * 1e3,
                            disableOnInteraction: !1
                        },
                        modules: [o(rt), o(ut)],
                        pagination: {
                            clickable: !0
                        },
                        class: "mySwiper my-swipe"
                    }, {
                        default: oe(() => [(s(!0), d(X, null, Q(o(F), e => (s(), f(o(ct), {
                            key: e,
                            onClick: u => o(nt)(e)
                        }, {
                            default: oe(() => [L(t("img", null, null, 512), [
                                [a, ce(e)]
                            ])]),
                            _: 2
                        }, 1032, ["onClick"]))), 128))]),
                        _: 1
                    }, 8, ["autoplay", "modules"])) : v("", !0)])) : v("", !0), o(n).state.awardPools.find(e => e.position === 3) ? (s(), f(o(A), {
                        key: 3,
                        itemInfo: o(n).state.awardPools.find(e => e.position === 3)
                    }, null, 8, ["itemInfo"])) : v("", !0), o(n).state.sections.broadcast ? (s(), f(o(M), {
                        key: 4
                    })) : v("", !0), t("div", Ft, [o(n).state.sections.game ? (s(), f(x, {
                        key: 0,
                        active: o(n).state.activeTab,
                        "onUpdate:active": m[0] || (m[0] = e => o(n).state.activeTab = e),
                        "before-change": () => !1
                    }, {
                        default: oe(() => [L(t("div", {
                            class: "preIcon",
                            ref: "preIconRef",
                            onClick: H
                        }, [D(h, {
                            iconClass: "tab_left"
                        })], 512), [
                            [we, $.value]
                        ]), L(t("div", {
                            class: "nextIcon",
                            ref: "nextIconRef",
                            onClick: le
                        }, [D(h, {
                            iconClass: "tab_right"
                        })], 512), [
                            [we, Z.value]
                        ]), (s(!0), d(X, null, Q(y, (e, u) => (s(), f(T, {
                            key: u
                        }, {
                            title: oe(() => [t("div", {
                                class: "tab-item",
                                onClick: r => ee(u, e)
                            }, [o(n).state.activeTab === u ? (s(), d("img", {
                                key: 0,
                                src: e.icon
                            }, null, 8, Xt)) : o(Me)(e.type) ? (s(), f(h, {
                                key: 1,
                                iconClass: o(Me)(e.type).icon
                            }, null, 8, ["iconClass"])) : v("", !0), t("span", Qt, [t("span", null, p(e.name || ""), 1)]), o(n).state.activeTab === u && o(n).state.festivalStyle && o(n).state.isMobile ? (s(), d("div", Wt, Kt)) : v("", !0)], 8, Nt)]),
                            _: 2
                        }, 1024))), 128))]),
                        _: 1
                    }, 8, ["active"])) : v("", !0), t("div", Zt, [t("img", {
                        src: Pe(),
                        class: "searchIcon",
                        onClick: m[1] || (m[1] = e => o(q).push("/game-search"))
                    }, null, 8, Jt)])]), t("div", Yt, [g.value && g.value.type == 98 ? (s(), d("div", ea, [t("a", ta, [t("div", aa, [t("img", {
                        src: g.value.icon
                    }, null, 8, la), t("span", null, p(g.value.name), 1)])]), g.value.vendors.length && o(n).state.accountInfo.id ? (s(), d("div", oa, [(s(!0), d(X, null, Q(g.value.vendors, (e, u) => (s(), d("div", {
                        key: u,
                        class: "gameBox box",
                        onClick: r => o(Ve)(e)
                    }, [L((s(), d("div", {
                        class: de(["innerBox", `innerBox${e.id}`]),
                        style: Ue(`background:url(${e.image}) no-repeat;background-size:100% 100%;`)
                    }, [e.loading ? (s(), f(h, {
                        key: 0,
                        iconClass: "default_game"
                    })) : v("", !0), e.hot === 1 ? (s(), d("img", sa)) : v("", !0), e.collect && e.clickCollect ? (s(), d("img", {
                        key: 2,
                        src: e.bookmark_star_2,
                        class: "collectIcon collected",
                        style: {
                            transform: "scale(1.7)"
                        },
                        onClick: O(r => b(e), ["stop"])
                    }, null, 8, ia)) : e.collect && !e.clickCollect ? (s(), d("img", {
                        key: 3,
                        src: Ne,
                        class: "collectIcon",
                        onClick: O(r => b(e), ["stop"])
                    }, null, 8, ca)) : (s(), d("img", {
                        key: 4,
                        src: Xe,
                        class: "collectIcon",
                        onClick: O(r => b(e), ["stop"])
                    }, null, 8, ra)), e.maintain === 1 ? (s(), d("div", ua, [da, t("p", null, p(i.$t("home.maintainText")), 1)])) : v("", !0), t("div", ma, [t("span", pa, p(e.name), 1)])], 6)), [
                        [a, he(e.image), "background-image"]
                    ])], 8, na))), 128))])) : (s(), d("div", ga, [o(n).state.skinBg === 0 ? (s(), d("img", va)) : (s(), d("img", ya)), t("span", null, p(i.$t("home.noData")), 1)]))])) : g.value && g.value.type == 99 ? (s(), d("div", ha, [t("a", fa, [t("div", ka, [t("img", {
                        src: g.value.icon
                    }, null, 8, _a), t("span", null, p(g.value.name), 1)])]), g.value.vendors.length && o(n).state.accountInfo.id ? (s(), d("div", ba, [(s(!0), d(X, null, Q(g.value.vendors, (e, u) => (s(), d("div", {
                        key: u,
                        class: "gameBox box",
                        onClick: r => o(Ve)(e)
                    }, [L((s(), d("div", {
                        class: de(["innerBox", `innerBox${e.id}`]),
                        style: Ue(`background:url(${e.image}) no-repeat;background-size:100% 100%;`)
                    }, [e.loading ? (s(), f(h, {
                        key: 0,
                        iconClass: "default_game"
                    })) : v("", !0), e.hot === 1 ? (s(), d("img", Ta)) : v("", !0), e.collect && e.clickCollect ? (s(), d("img", {
                        key: 2,
                        src: e.bookmark_star_2,
                        class: "collectIcon collected",
                        style: {
                            transform: "scale(1.7)"
                        },
                        onClick: O(r => b(e), ["stop"])
                    }, null, 8, La)) : e.collect && !e.clickCollect ? (s(), d("img", {
                        key: 3,
                        src: Ne,
                        class: "collectIcon",
                        onClick: O(r => b(e), ["stop"])
                    }, null, 8, Ia)) : (s(), d("img", {
                        key: 4,
                        src: Xe,
                        class: "collectIcon",
                        onClick: O(r => b(e), ["stop"])
                    }, null, 8, xa)), e.maintain === 1 ? (s(), d("div", Ca, [qa, t("p", null, p(i.$t("home.maintainText")), 1)])) : v("", !0), t("div", Sa, [t("span", Aa, p(e.name), 1)])], 6)), [
                        [a, he(e.image), "background-image"]
                    ])], 8, wa))), 128))])) : (s(), d("div", Pa, [o(n).state.skinBg === 0 ? (s(), d("img", Ea)) : (s(), d("img", Ba)), t("span", null, p(i.$t("home.noData")), 1)]))])) : v("", !0), (s(!0), d(X, null, Q(y, (e, u) => (s(), d(X, {
                        key: u
                    }, [!g.value && e.type !== 98 && e.type !== 99 ? (s(), d("div", {
                        key: 0,
                        class: "item",
                        id: `item${u+1}`
                    }, [t("a", $a, [t("div", Ha, [t("img", {
                        src: e.icon
                    }, null, 8, ja), t("span", null, p(e.name), 1)]), e.total > 6 && e.type !== 0 ? (s(), d("div", {
                        key: 0,
                        class: "item-title-right",
                        onClick: r => o(q).push({
                            path: "/sub-game",
                            query: {
                                typeId: e.type
                            }
                        })
                    }, p(i.$t("home.all")), 9, Da)) : v("", !0)]), e.type === 0 && o(n).state.awardPools.find(r => r.position === 1) ? (s(), f(o(A), {
                        key: 0,
                        itemInfo: o(n).state.awardPools.find(r => r.position === 1)
                    }, null, 8, ["itemInfo"])) : e.type === 2 && o(n).state.awardPools.find(r => r.position === 5) ? (s(), f(o(A), {
                        key: 1,
                        itemInfo: o(n).state.awardPools.find(r => r.position === 5)
                    }, null, 8, ["itemInfo"])) : e.type === 4 && o(n).state.awardPools.find(r => r.position === 7) ? (s(), f(o(A), {
                        key: 2,
                        itemInfo: o(n).state.awardPools.find(r => r.position === 7)
                    }, null, 8, ["itemInfo"])) : e.type === 3 && o(n).state.awardPools.find(r => r.position === 6) ? (s(), f(o(A), {
                        key: 3,
                        itemInfo: o(n).state.awardPools.find(r => r.position === 6)
                    }, null, 8, ["itemInfo"])) : e.type === 1 && o(n).state.awardPools.find(r => r.position === 4) ? (s(), f(o(A), {
                        key: 4,
                        itemInfo: o(n).state.awardPools.find(r => r.position === 4)
                    }, null, 8, ["itemInfo"])) : e.type === 5 && o(n).state.awardPools.find(r => r.position === 8) ? (s(), f(o(A), {
                        key: 5,
                        itemInfo: o(n).state.awardPools.find(r => r.position === 8)
                    }, null, 8, ["itemInfo"])) : v("", !0), t("div", Ma, [(s(!0), d(X, null, Q(e.showLength, (r, l) => (s(), d("div", {
                        key: l,
                        class: de(e.type === 0 ? "gameBox box" : "vendorBox box")
                    }, [L((s(), d("div", {
                        class: de(["innerBox", `innerBox${e.vendors[l].id}`]),
                        style: Ue(`background:url(${e.type===0&&e.vendors[l].hotType===1?e.vendors[l].image:e.type===0?e.vendors[l].hotImage:e.vendors[l].sloganImage}) no-repeat;background-size:100% 100%;`),
                        onClick: c => e.type === 0 && e.vendors[l].hotType === 1 ? o(Ve)(e.vendors[l]) : C(e.vendors[l], e.type)
                    }, [e.vendors[l].loading ? (s(), f(h, {
                        key: 0,
                        iconClass: "default_game"
                    })) : v("", !0), e.vendors[l].hot === 1 && e.vendors[l].hotType === 1 ? (s(), d("img", za)) : v("", !0), e.type === 0 && e.vendors[l].maskImage && e.vendors[l].hotType === 1 ? (s(), d("img", {
                        key: 2,
                        src: e.vendors[l].maskImage,
                        alt: "",
                        class: "maskImage"
                    }, null, 8, Ua)) : v("", !0), e.vendors[l].collect && e.vendors[l].hotType === 1 && e.vendors[l].clickCollect ? (s(), d("img", {
                        key: 3,
                        src: e.vendors[l].bookmark_star_2,
                        class: "collectIcon collected",
                        style: {
                            transform: "scale(1.7)"
                        },
                        onClick: O(c => b(e.vendors[l]), ["stop"])
                    }, null, 8, Oa)) : e.vendors[l].collect && e.vendors[l].hotType === 1 && !e.vendors[l].clickCollect ? (s(), d("img", {
                        key: 4,
                        src: Ne,
                        class: "collectIcon",
                        onClick: O(c => b(e.vendors[l]), ["stop"])
                    }, null, 8, Fa)) : e.vendors[l].hotType === 1 ? (s(), d("img", {
                        key: 5,
                        src: Xe,
                        class: "collectIcon",
                        onClick: O(c => b(e.vendors[l]), ["stop"])
                    }, null, 8, Na)) : v("", !0), e.vendors[l].maintain == 1 ? (s(), d("div", Xa, [Qa, t("p", null, p(i.$t("home.maintainText")), 1)])) : v("", !0), t("div", Wa, [e.type === 0 && e.vendors[l].hotType === 1 ? (s(), d("span", Ga, p(e.vendors[l].name), 1)) : v("", !0)])], 14, Va)), [
                        [a, he(e.type === 0 && e.vendors[l].hotType === 1 ? e.vendors[l].image : e.type === 0 ? e.vendors[l].hotImage : e.vendors[l].sloganImage), "background-image"]
                    ])], 2))), 128))]), e.total > e.showLength ? (s(), d("div", {
                        key: 6,
                        class: "item-tips",
                        onClick: r => P(e)
                    }, [t("div", Za, p(i.$t("home.moreTipsText1")) + " " + p(e.showLength) + " " + p(i.$t("home.moreTipsText2")) + " " + p(e.total) + " " + p(i.$t("home.moreTipsText3")), 1), t("div", Ja, [t("span", null, p(i.$t("home.loadMore")), 1), D(h, {
                        iconClass: "expand"
                    })])], 8, Ka)) : v("", !0)], 8, Ra)) : v("", !0)], 64))), 128))]), o(n).state.isMobile ? (s(), f(o(se), {
                        key: 5
                    })) : v("", !0), t("div", Ya, [o(n).state.customerConfig.ocs ? (s(), f(o(te), {
                        key: 0
                    })) : v("", !0), D(o(ye)), D(o(pe)), V.value ? (s(), d("div", {
                        key: 1,
                        class: "toTop",
                        onClick: Le
                    }, [t("div", el, [D(h, {
                        iconClass: "to_top"
                    })]), t("span", null, p(i.$t("home.top")), 1)])) : v("", !0)])])])])
                }
            }
        },
        al = "/png/blank_green.c77f04e0.png",
        ll = {
            class: "green-home-page"
        },
        ol = {
            class: "container"
        },
        nl = {
            class: "mainBox"
        },
        sl = {
            class: "home-page-scroll"
        },
        il = {
            key: 2,
            class: "mini-banner"
        },
        cl = {
            key: 5,
            class: "navWrap"
        },
        rl = {
            class: "navWrap-left"
        },
        ul = {
            key: 0,
            class: "userDetail"
        },
        dl = {
            class: "userDetail-top"
        },
        ml = {
            class: "vip"
        },
        pl = t("img", {
            src: Wo,
            alt: ""
        }, null, -1),
        gl = ["data-text"],
        vl = {
            class: "userName"
        },
        yl = {
            class: "copyIcon"
        },
        hl = {
            class: "userDetail-btm"
        },
        fl = {
            class: "countryBox"
        },
        kl = ["src"],
        _l = {
            key: 1,
            class: "loginBtn childFontSize"
        },
        bl = ["onClick"],
        wl = ["onClick"],
        Tl = {
            class: "navWrap-right"
        },
        Ll = {
            alt: ""
        },
        Il = {
            alt: ""
        },
        xl = t("span", null, "VIP", -1),
        Cl = {
            alt: ""
        },
        ql = {
            alt: ""
        },
        Sl = {
            class: "mixedBox-inner"
        },
        Al = {
            alt: ""
        },
        Pl = {
            alt: ""
        },
        El = {
            class: "gameContent"
        },
        Bl = {
            class: "gameContent-box"
        },
        Rl = {
            class: "vendor-tabs"
        },
        $l = {
            class: "vendor-tabs-scrollBox"
        },
        Hl = ["onClick"],
        jl = ["src"],
        Dl = ["src"],
        Ml = ["src"],
        Vl = {
            class: "gameName"
        },
        zl = {
            key: 4,
            class: "festival"
        },
        Ul = t("div", {
            class: "festival-leftImg"
        }, null, -1),
        Ol = t("div", {
            class: "festival-rightImg"
        }, null, -1),
        Fl = [Ul, Ol],
        Nl = {
            class: "gameBox"
        },
        Xl = {
            class: "gameBox-scrollBox"
        },
        Ql = {
            class: "scroll-content"
        },
        Wl = {
            class: "common-tab-menu"
        },
        Gl = t("div", {
            class: "underLine"
        }, null, -1),
        Kl = {
            class: "list"
        },
        Zl = {
            class: "game-list"
        },
        Jl = {
            key: 1,
            class: "game-list-innerBox"
        },
        Yl = {
            class: "marginBox"
        },
        eo = {
            class: "gameItem"
        },
        to = ["onClick"],
        ao = {
            class: "imgBox"
        },
        lo = {
            key: 0,
            src: Fe,
            class: "hotTag"
        },
        oo = ["onLoad"],
        no = ["src", "onClick"],
        so = ["onClick"],
        io = ["onClick"],
        co = {
            key: 5,
            class: "maintain"
        },
        ro = t("div", {
            class: "maintainIcon"
        }, null, -1),
        uo = [ro],
        mo = {
            class: "name"
        },
        po = {
            class: "game-list-tips-text"
        },
        go = {
            class: "game-list-tips-btn"
        },
        vo = {
            key: 3,
            class: "noGameList"
        },
        yo = t("img", {
            src: al,
            alt: ""
        }, null, -1),
        ho = {
            class: "vendor-list"
        },
        fo = {
            class: "vendor-list-title"
        },
        ko = {
            class: "vendor-logos"
        },
        _o = ["src"],
        bo = ["onClick"],
        wo = {
            class: "list-items"
        },
        To = {
            class: "list-items-innerBox"
        },
        Lo = ["onClick"],
        Io = {
            key: 0,
            class: "maintain"
        },
        xo = t("div", {
            class: "maintainIcon"
        }, null, -1),
        Co = [xo],
        qo = {
            class: "vendor-list-item-name"
        },
        So = ["onClick"],
        Ao = {
            class: "game-list-tips-text"
        },
        Po = {
            class: "game-list-tips-btn"
        },
        Eo = {
            class: "floatBox"
        },
        Bo = {
            class: "imgBox"
        },
        Ro = {
            __name: "green",
            setup(Be) {
                const M = R(() => B(() =>
                        import ("./index.1dbd0564.js").then(async a => (await a.__tla, a)), ["js/index.1dbd0564.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css"])),
                    se = R(() => B(() =>
                        import ("./banner.4b5938a5.js").then(async a => (await a.__tla, a)), ["js/banner.4b5938a5.js", "js/@vue.16908cbf.js", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/banner.9785577e.css"])),
                    pe = R(() => B(() =>
                        import ("./notice.1965d519.js").then(async a => (await a.__tla, a)), ["js/notice.1965d519.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "js/swiper.137b1af3.js", "css/swiper.c73a1d56.css", "css/notice.e7929a49.css"])),
                    ge = R(() => B(() =>
                        import ("./footer_green.d602fbd7.js").then(async a => (await a.__tla, a)), ["js/footer_green.d602fbd7.js", "js/vuex.7fead168.js", "js/@vue.16908cbf.js", "js/vue-router.d17f0860.js", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/footer_green.f8b8ea93.css"])),
                    ve = R(() => B(() =>
                        import ("./fixed_ad.bf9c68db.js").then(async a => (await a.__tla, a)), ["js/fixed_ad.bf9c68db.js", "js/@vue.16908cbf.js", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/fixed_ad.763aabfb.css"])),
                    ie = R(() => B(() =>
                        import ("./fixed_customer.60dcf12b.js"), ["js/fixed_customer.60dcf12b.js", "js/@vue.16908cbf.js", "js/vuex.7fead168.js", "css/fixed_customer.88fd6170.css"])),
                    ye = R(() => B(() =>
                        import ("./fixed_banner.b45e1be5.js").then(async a => (await a.__tla, a)), ["js/fixed_banner.b45e1be5.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/fixed_banner.74a0ec54.css"])),
                    te = R(() => B(() =>
                        import ("./index.8240e21f.js").then(async a => (await a.__tla, a)), ["js/index.8240e21f.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/index.fbaed231.css"])),
                    A = R(() => B(() =>
                        import ("./jackpot.beb1f51d.js").then(async a => (await a.__tla, a)), ["js/jackpot.beb1f51d.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/jackpot.4d99e285.css"])),
                    n = Oe(),
                    q = et(),
                    I = tt();
                let F = be([]);
                const U = k(),
                    g = k(null),
                    y = be([]),
                    $ = k(9),
                    Z = k(),
                    V = k("hot"),
                    W = k(!1),
                    ae = k(0),
                    J = k(!1),
                    Te = k(!0),
                    _ = be({
                        showLength: 9,
                        list: []
                    }),
                    {
                        t: Ae
                    } = vt(),
                    ce = k(),
                    he = k(!1);
                let Pe = Ye(() => !n.state.isApp && Te.value && !!n.state.sections.downloadBar && !We());
                me(() => n.state.activeTab, a => {
                    if (n.state.tableList.length) {
                        let e = n.state.tableList[a].type;
                        q.replace(`/index?gameType=${e}`)
                    }
                }), me(he, () => {
                    N()
                }), me(V, async a => {
                    _.list = [];
                    let e = [];
                    a === "hot" ? e = await ke(1) : a === "recent" ? e = await ke(2) : e = await ke(3), _.list = e.gameList, _.showLength = Math.min($.value, e.totalCount)
                });
                const P = a => new URL("/img/colors/" + De() + "/" + a + ".png",
                        import.meta.url).href,
                    z = a => {
                        if (!a) return Ge(Ae("side_bar.closed"));
                        J.value = !1, n.state.showSideBar = !1, a == "/recharge" ? n.state.showRechargeDialog = !0 : q.push(a)
                    },
                    Le = () => {
                        if (!qe()) return n.state.showLoginDialog = !0;
                        n.state.showRechargeDialog = !0
                    },
                    b = () => {
                        Mo()
                    },
                    C = () => {
                        ae.value += 360;
                        let a = document.querySelector(".green-home-page .refreshIcon");
                        a.style.transform = `rotateZ(${ae.value}deg)`, n.dispatch("refreshBalance", !0)
                    },
                    N = () => {
                        const a = I.query.gameType || 0;
                        let e = n.state.tableList.filter(r => r.type !== 98 && r.type !== 99).findIndex(r => r.type == a),
                            u = n.state.tableList.filter(r => r.type !== 98 && r.type !== 99).find(r => r.type == a);
                        setTimeout(() => {
                            n.state.isMobile && (Z.value = u, m(e), setTimeout(() => {
                                Z.value = ""
                            }, 100))
                        })
                    },
                    H = a => a.hotType === 0 ? {
                        loading: ce.value,
                        src: a.hotImage
                    } : {
                        loading: ce.value,
                        src: a.image
                    },
                    le = () => {
                        Te.value = !1, globalVBus.$emit("closeDownloadBar"), n.state.isMobile ? i() : checkContainerScrollPC()
                    },
                    Y = () => {
                        g.value && g.value.destroy(), g.value = new Go(".copyUserName"), g.value.on("success", () => {
                            Ge("Success", "success"), g.value.destroy()
                        }), g.value.on("error", () => {
                            Ge("Failed", "error"), g.value.destroy()
                        })
                    },
                    E = a => {
                        K.post("game/game/collect", {
                            id: a.id,
                            gameType: a.type,
                            type: a.collect ? 0 : 1
                        }).then(e => {
                            e.code === 0 && (a.bookmark_star_2 = mt + new Date().getTime(), a.collect = !a.collect, a.collect && (a.clickCollect = !0))
                        })
                    },
                    ee = () => {
                        let a;
                        n.state.isMobile && (a = document.querySelector("#app .green-home-page .mainBox"));
                        let e = a.scrollTop;
                        e -= 100, e = Math.max(e, 0), a.scrollTo(0, e), e > 0 && requestAnimationFrame(ee)
                    },
                    Ie = (a, e) => {
                        n.state.activeTab !== a && (a === 0 && (V.value = "hot"), n.state.activeTab = a, q.replace("/index?gameType=" + e.type), Ee(a))
                    },
                    Ee = (a, e) => {
                        n.state.isMobile && m(a)
                    },
                    re = async a => {
                        V.value !== a && (V.value = a, ne(() => {
                            h()
                        }))
                    },
                    xe = () => {
                        K.get("/user/site/banners", {
                            type: 1
                        }).then(a => {
                            if (a.code === 0) {
                                let {
                                    list: e,
                                    time: u
                                } = a.data;
                                e.length && (F.push(...e), U.value = u)
                            }
                        })
                    },
                    Qe = () => {
                        n.state.showLoginDialog = !0, n.state.loginType = "login"
                    },
                    Re = () => {
                        n.state.showLoginDialog = !0, n.state.loginType = "register"
                    },
                    fe = async () => {
                        y.length = 0, await K.get("/game/game/typedVendors").then(async a => {
                            if (a.code === 0) {
                                y.push(...a.data.filter(c => !!c.vendors.length || c.type === 0 || c.type === 98 || c.type === 99)), y.forEach(async (c, w) => {
                                    c.type === 0 ? (c.vendors = (await ke(1)).gameList, he.value = !0, c.total = c.vendors.length, c.showLength = Math.min($.value, c.total), c.noIcon = c.noIcon.replace("/default", "/green"), c.icon = c.icon.replace("/default", "/green"), _.showLength = Math.min($.value, c.total), _.list = c.vendors) : (c.total = c.vendors.length, c.showLength = Math.min(6, c.total), c.noIcon = c.noIcon.replace("/default", "/green"), c.icon = c.icon.replace("/default", "/green"), c.vendors.forEach(S => {
                                        const j = new Image;
                                        j.src = S.sloganImage, j.complete ? c.loading = !1 : c.loading = !0
                                    }))
                                });
                                let e = y.find(c => c.type === 0),
                                    u = y.findIndex(c => c.type === 0);
                                y.splice(u, 1);
                                let r = y.findIndex(c => c.type === 98);
                                y.splice(r, 1);
                                let l = y.findIndex(c => c.type === 99);
                                y.splice(l, 1), y.unshift(e), n.state.tableList = y
                            }
                        })
                    },
                    $e = (a, e) => {
                        a.maintain !== 1 && q.push({
                            path: "/sub-game",
                            query: {
                                typeId: e,
                                vendor: a.vendor
                            }
                        })
                    },
                    ke = async a => {
                        let e = [],
                            u = 0,
                            r = {
                                tag: a,
                                _page: 1,
                                _size: 1e3
                            };
                        return await K.get("/game/game/list", r).then(l => {
                            if (l.code === 0) {
                                let {
                                    list: w,
                                    total: S
                                } = l.data;
                                e.push(...w), e.forEach(ue => {
                                    ue.loading = !1
                                });
                                let j = document.querySelectorAll(".game-list .imgBox .img");
                                if (j.length)
                                    for (var c = 0; c < j.length; c++) j[c].complete && (e[c].loading = !1);
                                u = S
                            }
                        }), {
                            gameList: e,
                            totalCount: u
                        }
                    },
                    i = () => {
                        parseFloat(getComputedStyle(document.documentElement).fontSize), ne(() => {
                            let a = document.querySelector("#app .green-home-page .mainBox"),
                                e = document.querySelector(".green-home-page .common-tab-menu"),
                                u = document.querySelector(".green-home-page .gameContent-box"),
                                r = document.querySelector(".green-home-page .game-list"),
                                l = e.clientHeight + r.clientHeight + u.offsetTop,
                                c = a.scrollTop,
                                w = document.querySelectorAll("#app .green-home-page .list .vendor-list"),
                                S = [],
                                j = l;
                            if (Z.value) return;
                            let ue = Array.from(w);
                            c > u.offsetTop ? W.value = !0 : W.value = !1, ue.forEach((He, je) => {
                                je !== ue.length - 1 && (j += He.clientHeight, S.push(j))
                            }), S.unshift(l);
                            let _e = !0;
                            for (var G = S.length - 1; G >= 0; G--) {
                                if (!_e) return;
                                c >= S[G] && (n.state.activeTab = G + 1, _e = !1)
                            }
                            c < l && (n.state.activeTab = 0)
                        })
                    },
                    m = async (a, e) => {
                        parseFloat(getComputedStyle(document.documentElement).fontSize);
                        let u = document.querySelector(".green-home-page .common-tab-menu"),
                            r = document.querySelector(".green-home-page .gameContent-box"),
                            l = document.querySelector(".green-home-page .game-list");
                        u.clientHeight + l.clientHeight;
                        let c = document.querySelector(".green-home-page .mainBox"),
                            w = c.scrollTop;
                        document.querySelector(".green-home-page .mini-banner"), document.querySelector(".green-home-page .notice"), document.querySelector(".green-home-page .navWrap");
                        let S = r.offsetTop;
                        ne(async () => {
                            n.state.activeTab = a, ne(() => {
                                if (a === 0) w > S && c.scrollTo(0, S);
                                else {
                                    let ue = document.querySelectorAll(".green-home-page .list .vendor-list");
                                    document.querySelectorAll(".green-home-page .tabItem");
                                    let _e = 0;
                                    for (var j = 0; j < a - 1; j++) _e += ue[j].clientHeight;
                                    let G = S + l.clientHeight + u.clientHeight + _e + 1;
                                    c.scrollTo(0, G), W.value = !0
                                }
                                setTimeout(() => {
                                    T()
                                }, 100)
                            })
                        })
                    },
                    h = () => {
                        let a = document.querySelectorAll(".menuItem"),
                            e = Array.from(a).find(l => l.classList[1] === "active").querySelector("div"),
                            u = e.offsetLeft,
                            r = document.querySelector(".underLine");
                        r.style.transform = `translateX(${u}px)`, r.style.width = e.clientWidth + "px"
                    },
                    T = () => {
                        const a = parseFloat(getComputedStyle(document.documentElement).fontSize);
                        let e = document.querySelector(".green-home-page .gameContent-box"),
                            u = document.querySelector(".green-home-page .mainBox"),
                            r = document.querySelector(".green-home-page .vendor-tabs-scrollBox"),
                            l = document.querySelector(".green-home-page .vendor-tabs"),
                            c = document.querySelector(".green-home-page .download-app"),
                            w = document.querySelector(".green-home-page .green-headerMenu");
                        if (!w) return;
                        let S = c ? c.clientHeight + w.clientHeight : w.clientHeight;
                        u.scrollTop > e.offsetTop + e.clientHeight - l.offsetLeft - r.clientHeight ? r.style.cssText = "position:absolute;bottom:.3rem;z-index:98;width:1.5rem;" : u.scrollTop > e.offsetTop - l.offsetLeft ? r.style.cssText = `position:fixed;left:${.2*a}px;top:${S+l.offsetLeft}px;` : u.scrollTop < e.offsetTop - l.offsetLeft && (r.style.cssText = "position:relative;")
                    };
                Ke(async () => {
                    xe(), await fe(), setTimeout(() => {
                        I.query.gameType && N(), h()
                    }, 200), $.value = n.state.isMobile ? 9 : 18, document.querySelector(".green-home-page .mainBox").addEventListener("scroll", T), globalVBus.$on("changeActiveTab", Ee), globalVBus.$on("changeTag", re), globalVBus.$on("refreshGameTypeVendorList", fe)
                }), ze(() => {
                    n.dispatch("getAppConfig"), n.state.isMobile && document.querySelector("#app .green-home-page .mainBox").addEventListener("scroll", i), setTimeout(() => {
                        N(), h()
                    }), window.addEventListener("click", () => {
                        J.value = !1
                    })
                }), Ze(() => {
                    document.querySelector("#app .green-home-page .mainBox").removeEventListener("scroll", i)
                });
                const x = a => {
                    a.loading = !1
                };
                return (a, e) => {
                    const u = it("svg-icon"),
                        r = Je("lazy");
                    return s(), d("div", ll, [t("div", ol, [o(Pe) ? (s(), f(o(te), {
                        key: 0,
                        onClose: le
                    })) : v("", !0), L(D(o(M), {
                        ref: "headerMenu"
                    }, null, 512), [
                        [we, o(n).state.isMobile]
                    ]), t("div", nl, [t("div", sl, [o(n).state.awardPools.find(l => l.position === 2) ? (s(), f(o(A), {
                        key: 0,
                        itemInfo: o(n).state.awardPools.find(l => l.position === 2)
                    }, null, 8, ["itemInfo"])) : v("", !0), o(n).state.sections.banner && o(F).length && !o(n).state.isMobile ? (s(), f(o(se), {
                        key: 1,
                        bannerList: o(F),
                        autoplayTime: U.value
                    }, null, 8, ["bannerList", "autoplayTime"])) : v("", !0), o(n).state.sections.banner && o(n).state.isMobile ? (s(), d("div", il, [o(F).length ? (s(), f(o(dt), {
                        key: 0,
                        preventClicksPropagation: "",
                        loop: !0,
                        autoplay: {
                            delay: U.value * 1e3,
                            disableOnInteraction: !1
                        },
                        modules: [o(rt), o(ut)],
                        pagination: {
                            clickable: !0
                        },
                        class: "mySwiper my-swipe"
                    }, {
                        default: oe(() => [(s(!0), d(X, null, Q(o(F), l => (s(), f(o(ct), {
                            key: l,
                            onClick: c => o(nt)(l)
                        }, {
                            default: oe(() => [L(t("img", null, null, 512), [
                                [r, l.image]
                            ])]),
                            _: 2
                        }, 1032, ["onClick"]))), 128))]),
                        _: 1
                    }, 8, ["autoplay", "modules"])) : v("", !0)])) : v("", !0), o(n).state.awardPools.find(l => l.position === 3) ? (s(), f(o(A), {
                        key: 3,
                        itemInfo: o(n).state.awardPools.find(l => l.position === 3)
                    }, null, 8, ["itemInfo"])) : v("", !0), o(n).state.sections.broadcast ? (s(), f(o(pe), {
                        key: 4
                    })) : v("", !0), o(n).state.isMobile ? (s(), d("div", cl, [t("div", rl, [o(n).state.accountInfo.username ? (s(), d("div", ul, [t("div", dl, [t("div", ml, [pl, t("span", {
                        "data-text": o(n).state.accountInfo.level
                    }, p(o(n).state.accountInfo.level), 9, gl)]), t("div", vl, p(o(n).state.accountInfo.username), 1), t("div", yl, [D(u, {
                        iconClass: "copy",
                        "data-clipboard-text": o(n).state.accountInfo.username,
                        onClick: Y,
                        class: "copyUserName"
                    }, null, 8, ["data-clipboard-text"])])]), t("div", hl, [t("div", fl, [t("img", {
                        src: o(jo)(),
                        class: "countryIcon"
                    }, null, 8, kl)]), t("span", {
                        class: "balance",
                        onClick: e[0] || (e[0] = l => o(q).push("/wallet"))
                    }, [t("span", null, p(o(Do)(o(n).state.balance.coinActiveAmount || 0)), 1)]), D(u, {
                        iconClass: "refresh",
                        class: "refreshIcon",
                        onClick: O(C, ["stop"])
                    }, null, 8, ["onClick"])])])) : (s(), d("div", _l, [t("span", {
                        class: "btn",
                        onClick: O(Qe, ["stop"])
                    }, p(a.$t("header_menu.login")), 9, bl), t("span", null, p(a.$t("header_menu.or")), 1), t("span", {
                        class: "btn",
                        onClick: O(Re, ["stop"])
                    }, p(a.$t("header_menu.register")), 9, wl)]))]), t("div", Tl, [t("div", {
                        class: "menu-item",
                        onClick: e[1] || (e[1] = l => o(q).push("/promotion/fees"))
                    }, [L(t("img", Ll, null, 512), [
                        [r, P("nav_incomeBox")]
                    ]), t("span", null, p(a.$t("side_bar.fees")), 1)]), t("div", {
                        class: "menu-item",
                        onClick: e[2] || (e[2] = l => o(q).push("/promotion/vip"))
                    }, [L(t("img", Il, null, 512), [
                        [r, P("nav_vip")]
                    ]), xl]), t("div", {
                        class: "menu-item",
                        onClick: e[3] || (e[3] = l => o(q).push("/agent"))
                    }, [L(t("img", Cl, null, 512), [
                        [r, P("nav_inviteShare")]
                    ]), t("span", null, p(a.$t("side_bar.agency")), 1)]), t("div", {
                        class: "menu-item",
                        onClick: e[4] || (e[4] = O(l => J.value = !J.value, ["stop"]))
                    }, [L(t("img", ql, null, 512), [
                        [r, P("nav_mixed")]
                    ]), t("span", null, p(a.$t("promotion_event.more")), 1)])]), L(t("div", {
                        class: "mixedBox",
                        onClick: e[20] || (e[20] = O(() => {}, ["stop"]))
                    }, [t("div", Sl, [t("ul", null, [t("li", {
                        onClick: e[5] || (e[5] = l => z("/message-center?type=customer-service"))
                    }, [L(t("img", Al, null, 512), [
                        [r, P("nav_support")]
                    ]), t("span", null, p(a.$t("side_bar.customer_service")), 1)]), t("li", {
                        onClick: e[6] || (e[6] = l => z("/exchange"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_withdraw")]
                    ]), t("span", null, p(a.$t("side_bar.exchange")), 1)]), t("li", {
                        onClick: Le
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_recharge")]
                    ]), t("span", null, p(a.$t("recharge.recharge")), 1)]), t("li", {
                        onClick: e[7] || (e[7] = l => z("/promotion/event"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_event")]
                    ]), t("span", null, p(a.$t("footer.funcList.event")), 1)]), t("li", {
                        onClick: e[8] || (e[8] = l => z("/promotion/task"))
                    }, [L(t("img", Pl, null, 512), [
                        [r, P("nav_mission")]
                    ]), t("span", null, p(a.$t("footer.funcList.task")), 1)]), t("li", {
                        onClick: e[9] || (e[9] = l => z("/promotion/rebate"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_rebate")]
                    ]), t("span", null, p(a.$t("footer.funcList.rebate")), 1)]), t("li", {
                        onClick: e[10] || (e[10] = l => z("/message-center?type=advise"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_advise")]
                    ]), t("span", null, p(a.$t("footer.supportList.advise")), 1)]), t("li", {
                        onClick: e[11] || (e[11] = l => o(q).push("/security-center"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_help")]
                    ]), t("span", null, p(a.$t("mine.security_center")), 1)]), o(n).state.leftNavigations.download && !o(We)() ? (s(), d("li", {
                        key: 0,
                        onClick: b
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_download")]
                    ]), t("span", null, p(a.$t("side_bar.download")), 1)])) : v("", !0), t("li", {
                        onClick: e[12] || (e[12] = l => z("/mine-info"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_perfil")]
                    ]), t("span", null, p(a.$t("mine.tab_account")), 1)]), t("li", {
                        onClick: e[13] || (e[13] = l => z("/account?tabId=1"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_statement")]
                    ]), t("span", null, p(a.$t("account.account_detail")), 1)]), t("li", {
                        onClick: e[14] || (e[14] = l => z("/account?tabId=2"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_betRecords")]
                    ]), t("span", null, p(a.$t("account.bet_record")), 1)]), t("li", {
                        onClick: e[15] || (e[15] = l => z("/account?tabId=3"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_reports")]
                    ]), t("span", null, p(a.$t("account.personal_report")), 1)]), t("li", {
                        onClick: e[16] || (e[16] = l => z("/promotion/claim"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_pending")]
                    ]), t("span", null, p(a.$t("side_bar.reward")), 1)]), t("li", {
                        onClick: e[17] || (e[17] = l => z("/exchange?index=3"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_account_manage")]
                    ]), t("span", null, p(a.$t("side_bar.account_manage")), 1)]), t("li", {
                        onClick: e[18] || (e[18] = l => z("/exchange?index=1"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_withdraw_record")]
                    ]), t("span", null, p(a.$t("exchange.exchange_record")), 1)]), t("li", {
                        onClick: e[19] || (e[19] = l => z("/promotion/records"))
                    }, [L(t("img", null, null, 512), [
                        [r, P("nav_mixRecord")]
                    ]), t("span", null, p(a.$t("side_bar.history")), 1)])])])], 512), [
                        [we, J.value]
                    ])])) : v("", !0), t("div", El, [t("div", Bl, [t("div", Rl, [t("div", $l, [(s(!0), d(X, null, Q(o(n).state.tableList.filter(l => l.type !== 98 && l.type !== 99), (l, c) => (s(), d("div", {
                        class: de(["tabItem", [{
                            active: o(n).state.activeTab == c
                        }, {
                            isMobile: !o(n).state.isDesktop && o(n).state.deviceOs !== "ios" && o(n).state.deviceOs !== "android"
                        }]]),
                        onClick: w => Ie(c, l)
                    }, [o(n).state.activeTab === c ? (s(), d("img", {
                        key: 0,
                        src: P("tab_bg_active"),
                        class: "tabItem-bg"
                    }, null, 8, jl)) : (s(), d("img", {
                        key: 1,
                        src: P("tab_bg"),
                        class: "tabItem-bg"
                    }, null, 8, Dl)), o(n).state.activeTab === c ? (s(), d("img", {
                        key: 2,
                        src: l.icon,
                        class: "gameLogo"
                    }, null, 8, Ml)) : o(Me)(l.type) ? (s(), f(u, {
                        key: 3,
                        iconClass: o(Me)(l.type).icon,
                        class: "gameLogo"
                    }, null, 8, ["iconClass"])) : v("", !0), t("div", Vl, [t("span", null, p(l.name), 1)]), o(n).state.festivalStyle && o(n).state.activeTab === c ? (s(), d("div", zl, Fl)) : v("", !0)], 10, Hl))), 256))])]), t("div", Nl, [t("div", Xl, [t("div", Ql, [t("div", Wl, [t("div", {
                        class: de(["menuItem", {
                            active: V.value === "hot"
                        }]),
                        onClick: e[21] || (e[21] = l => re("hot"))
                    }, [t("div", null, [t("span", null, p(a.$t("footer.gameList.hot")), 1)])], 2), t("div", {
                        class: de(["menuItem", {
                            active: V.value === "recent"
                        }]),
                        onClick: e[22] || (e[22] = l => re("recent"))
                    }, [t("div", null, [t("span", null, p(a.$t("footer.gameList.recent")), 1)])], 2), t("div", {
                        class: de(["menuItem", {
                            active: V.value === "collect"
                        }]),
                        onClick: e[23] || (e[23] = l => re("collect"))
                    }, [t("div", null, [t("span", null, p(a.$t("footer.gameList.collect")), 1)])], 2), Gl]), t("div", Kl, [t("div", Zl, [o(n).state.awardPools.find(l => l.position === 1) ? (s(), f(o(A), {
                        key: 0,
                        itemInfo: o(n).state.awardPools.find(l => l.position === 1),
                        style: {
                            "--jackpot-card-count-box-height": ".52rem",
                            "--jackpot-card-count-box-scale": ".42",
                            "--jackpot-card-width": "5.2rem",
                            "--jackpot-card-height": "1.24rem",
                            "--jackpot-card-margin": "0 0 .2rem",
                            "--jackpot-font-size": ".33rem"
                        }
                    }, null, 8, ["itemInfo"])) : v("", !0), _.list.length ? (s(), d("div", Jl, [t("div", Yl, [(s(!0), d(X, null, Q(_.showLength, (l, c) => (s(), d("div", eo, [t("div", {
                        class: "gameItem-inner",
                        onClick: O(w => _.list[c].hotType === 0 && _.list[c].hot === 1 ? $e(_.list[c], _.list[c].type) : o(Ve)(_.list[c]), ["stop"])
                    }, [t("div", ao, [_.list[c].hot === 1 && _.list[c].hotType === 1 ? (s(), d("img", lo)) : v("", !0), L(t("img", {
                        onLoad: w => x(_.list[c]),
                        class: "img"
                    }, null, 40, oo), [
                        [r, H(_.list[c])]
                    ]), _.list[c].loading ? (s(), f(u, {
                        key: 1,
                        iconClass: "skin2_default_game"
                    })) : v("", !0), _.list[c].collect && _.list[c].hotType === 1 && _.list[c].clickCollect ? (s(), d("img", {
                        key: 2,
                        src: _.list[c].bookmark_star_2,
                        class: "collectIcon",
                        style: {
                            transform: "scale(1.7)"
                        },
                        onClick: O(w => E(_.list[c]), ["stop"])
                    }, null, 8, no)) : _.list[c].collect && _.list[c].hotType === 1 && !_.list[c].clickCollect ? (s(), d("img", {
                        key: 3,
                        src: Ne,
                        class: "collectIcon",
                        onClick: O(w => E(_.list[c]), ["stop"])
                    }, null, 8, so)) : _.list[c].hotType === 1 ? (s(), d("img", {
                        key: 4,
                        src: Xe,
                        class: "collectIcon",
                        onClick: O(w => E(_.list[c]), ["stop"])
                    }, null, 8, io)) : v("", !0), _.list[c].maintain == 1 ? (s(), d("div", co, uo)) : v("", !0)]), t("div", mo, [t("span", null, p(_.list[c].name), 1)])], 8, to)]))), 256))])])) : v("", !0), _.list.length > _.showLength ? (s(), d("div", {
                        key: 2,
                        class: "game-list-tips",
                        onClick: e[24] || (e[24] = l => _.showLength = _.list.length)
                    }, [t("div", po, p(a.$t("home.moreTipsText1")) + " " + p(_.showLength) + " " + p(a.$t("home.moreTipsText2")) + " " + p(_.list.length) + " " + p(a.$t("home.moreTipsText3")), 1), t("div", go, [t("span", null, p(a.$t("home.loadMore")), 1), D(u, {
                        iconClass: "expand"
                    })])])) : v("", !0), _.list.length ? v("", !0) : (s(), d("div", vo, [yo, t("span", null, p(a.$t("common.no_data")), 1)]))]), (s(!0), d(X, null, Q(o(n).state.tableList.filter(l => l.type !== 0 && l.type !== 98 && l.type !== 99), l => (s(), d("div", ho, [t("div", fo, [t("div", ko, [t("img", {
                        src: l.icon,
                        alt: ""
                    }, null, 8, _o), t("span", null, p(l.name), 1)]), l.type !== 0 ? (s(), d("div", {
                        key: 0,
                        class: "vendor-all",
                        onClick: c => o(q).push({
                            path: "/sub-game",
                            query: {
                                typeId: l.type
                            }
                        })
                    }, p(a.$t("home.all")), 9, bo)) : v("", !0)]), l.type === 1 && o(n).state.awardPools.find(c => c.position === 4) ? (s(), f(o(A), {
                        key: 0,
                        itemInfo: o(n).state.awardPools.find(c => c.position === 4),
                        style: {
                            "--jackpot-card-count-box-height": ".52rem",
                            "--jackpot-card-count-box-scale": ".42",
                            "--jackpot-card-width": "5.2rem",
                            "--jackpot-card-height": "1.24rem",
                            "--jackpot-card-margin": "0",
                            "--jackpot-font-size": ".33rem"
                        }
                    }, null, 8, ["itemInfo"])) : l.type === 2 && o(n).state.awardPools.find(c => c.position === 5) ? (s(), f(o(A), {
                        key: 1,
                        itemInfo: o(n).state.awardPools.find(c => c.position === 5),
                        style: {
                            "--jackpot-card-count-box-height": ".52rem",
                            "--jackpot-card-count-box-scale": ".42",
                            "--jackpot-card-width": "5.2rem",
                            "--jackpot-card-height": "1.24rem",
                            "--jackpot-card-margin": "0",
                            "--jackpot-font-size": ".33rem"
                        }
                    }, null, 8, ["itemInfo"])) : l.type === 3 && o(n).state.awardPools.find(c => c.position === 6) ? (s(), f(o(A), {
                        key: 2,
                        itemInfo: o(n).state.awardPools.find(c => c.position === 6),
                        style: {
                            "--jackpot-card-count-box-height": ".52rem",
                            "--jackpot-card-count-box-scale": ".42",
                            "--jackpot-card-width": "5.2rem",
                            "--jackpot-card-height": "1.24rem",
                            "--jackpot-card-margin": "0",
                            "--jackpot-font-size": ".33rem"
                        }
                    }, null, 8, ["itemInfo"])) : l.type === 4 && o(n).state.awardPools.find(c => c.position === 7) ? (s(), f(o(A), {
                        key: 3,
                        itemInfo: o(n).state.awardPools.find(c => c.position === 7),
                        style: {
                            "--jackpot-card-count-box-height": ".52rem",
                            "--jackpot-card-count-box-scale": ".42",
                            "--jackpot-card-width": "5.2rem",
                            "--jackpot-card-height": "1.24rem",
                            "--jackpot-card-margin": "0",
                            "--jackpot-font-size": ".33rem"
                        }
                    }, null, 8, ["itemInfo"])) : l.type === 5 && o(n).state.awardPools.find(c => c.position === 8) ? (s(), f(o(A), {
                        key: 4,
                        itemInfo: o(n).state.awardPools.find(c => c.position === 8),
                        style: {
                            "--jackpot-card-count-box-height": ".52rem",
                            "--jackpot-card-count-box-scale": ".42",
                            "--jackpot-card-width": "5.2rem",
                            "--jackpot-card-height": "1.24rem",
                            "--jackpot-card-margin": "0",
                            "--jackpot-font-size": ".33rem"
                        }
                    }, null, 8, ["itemInfo"])) : v("", !0), t("div", wo, [t("div", To, [(s(!0), d(X, null, Q(l.showLength, (c, w) => (s(), d("div", {
                        class: "vendor-list-item",
                        style: Ue(`background:url(${l.vendors[w].sloganImage}) no-repeat;background-size:100% 100%;`),
                        onClick: S => $e(l.vendors[w], l.type)
                    }, [l.vendors[w].maintain == 1 ? (s(), d("div", Io, Co)) : v("", !0), t("span", qo, p(l.vendors[w].name) + " " + p(l.name), 1)], 12, Lo))), 256))])]), l.vendors.length > l.showLength ? (s(), d("div", {
                        key: 5,
                        class: "vendor-list-tips",
                        onClick: c => l.showLength = l.vendors.length
                    }, [t("div", Ao, p(a.$t("home.moreTipsText1")) + " " + p(l.showLength) + " " + p(a.$t("home.moreTipsText2")) + " " + p(l.vendors.length) + " " + p(a.$t("home.moreTipsText3")), 1), t("div", Po, [t("span", null, p(a.$t("home.loadMore")), 1), D(u, {
                        iconClass: "expand"
                    })])], 8, So)) : v("", !0)]))), 256))])])])])])]), o(n).state.isMobile ? (s(), f(o(ge), {
                        key: 6
                    })) : v("", !0)]), t("div", Eo, [o(n).state.customerConfig.ocs ? (s(), f(o(ie), {
                        key: 0
                    })) : v("", !0), D(o(ve)), D(o(ye)), D(Xo, {
                        name: "fade"
                    }, {
                        default: oe(() => [W.value ? (s(), d("div", {
                            key: 0,
                            class: "toTop",
                            onClick: ee
                        }, [t("div", Bo, [D(u, {
                            iconClass: "to_top"
                        })]), t("span", null, p(a.$t("home.top")), 1)])) : v("", !0)]),
                        _: 1
                    })])])])])
                }
            }
        };
    let lt, ot;
    lt = {
        class: "home-page-box"
    }, ot = Qo({
        beforeRouteEnter(Be, M, se) {
            st.state.popStep === 4 && (st.state.popStep = 3), se()
        }
    }), yt = Object.assign(ot, {
        __name: "index",
        setup(Be) {
            const M = Oe(),
                se = R(() => B(() =>
                    import ("./new_player_task.a07a6fab.js").then(async g => (await g.__tla, g)), ["js/new_player_task.a07a6fab.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/new_player_task.4831f099.css"])),
                pe = R(() => B(() =>
                    import ("./first_recharge_dialog.7cb3235b.js").then(async g => (await g.__tla, g)), ["js/first_recharge_dialog.7cb3235b.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/first_recharge_dialog.6ea8aa77.css"])),
                ge = R(() => B(() =>
                    import ("./index.4516f0ad.js").then(async g => (await g.__tla, g)), ["js/index.4516f0ad.js", "js/vant.be74fb7c.js", "js/@vue.16908cbf.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/index.0a674315.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/index.19fcd299.css"])),
                ve = R(() => B(() =>
                    import ("./index.b2ac19b7.js").then(async g => (await g.__tla, g)), ["js/index.b2ac19b7.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/index.1344f1b2.css"])),
                ie = R(() => B(() =>
                    import ("./promote_registration_dialog.6f462fa0.js").then(async g => (await g.__tla, g)), ["js/promote_registration_dialog.6f462fa0.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/promote_registration_dialog.2494a9e8.css"])),
                ye = R(() => B(() =>
                    import ("./break_through_dialog.ee5c2557.js").then(async g => (await g.__tla, g)), ["js/break_through_dialog.ee5c2557.js", "js/index.0a674315.js", "js/@vue.16908cbf.js", "js/axios.4a70c6fc.js", "js/vuex.7fead168.js", "js/vue-router.d17f0860.js", "js/element-plus.c133b52b.js", "js/dayjs.42829e09.js", "js/clipboard.f53621db.js", "js/@element-plus.c1fd9846.js", "js/@vueuse.da2de41b.js", "js/lodash-es.0b530f8e.js", "js/@ctrl.f8748455.js", "js/@popperjs.c45de710.js", "css/element-plus.7a1426c0.css", "js/vant.be74fb7c.js", "js/@vant.359a3f91.js", "css/vant.8a4693cc.css", "js/vue-i18n.d9454f26.js", "js/@intlify.7347860c.js", "js/nprogress.1adef0ba.js", "js/xe-utils.0e898ace.js", "js/crypto-js.bfe2481f.js", "js/decimal.js.d133ee8e.js", "js/@fingerprintjs.bfff8371.js", "js/tslib.521c7ea7.js", "js/vh-check.e6149712.js", "js/vue-lazyload.38f311e8.js", "js/@lucky-canvas.861f1f96.js", "js/vue-demi.71ba0ef2.js", "js/vue-dragscroll.ace105ad.js", "css/index.3888bc3e.css", "css/break_through_dialog.4780aae4.css"]));
            tt();
            const te = k(!0),
                A = k(!0),
                n = k(!1),
                q = k(!1),
                I = be([]);
            me(A, () => {
                A.value || (n.value = !0)
            }), me(n, (g, y) => {
                !g && y && (q.value = !0)
            }), me(q, (g, y) => {
                g && !y && (te.value = !0)
            });
            const F = Ye(() => {
                    let g = !0;
                    return M.state.accountInfo.id ? (I.length && I[0].loginPop.afterLoginPop === 0 && (g = !1), I.length && I[0].loginPop.afterLoginPop === 2 && Se.cookie("sysFirstRechargePopLogin") && (g = !1)) : (I.length && I[0].loginPop.beforeLoginPop === 0 && (g = !1), I.length && I[0].loginPop.beforeLoginPop === 2 && Se.cookie("sysFirstRechargePop") && (g = !1)), g ? A.value = !0 : M.state.popStep = 4, g
                }),
                U = () => {
                    I.length = 0, K.get("/user/promotion/firstChargePop").then(g => {
                        g && g.status === "OK" && (I.push(...g.data), I.length && I[0] ? qe() ? I[0].loginPop.afterLoginPop === 2 ? setTimeout(() => {
                            Se.cookie("sysFirstRechargePopLogin", "1", {
                                expires: "1d"
                            })
                        }, 1e3) : Se.cookie("sysFirstRechargePopLogin", null, {
                            expires: -1
                        }) : I[0].loginPop.beforeLoginPop === 2 ? setTimeout(() => {
                            Se.cookie("sysFirstRechargePop", "1", {
                                expires: "1d"
                            })
                        }, 1e3) : Se.cookie("sysFirstRechargePop", null, {
                            expires: -1
                        }) : A.value = !1)
                    })
                };
            return ze(async () => {
                q.value = !1, U()
            }), (g, y) => (s(), d("div", lt, [o(M).state.layoutMode === 1 ? (s(), f(tl, {
                key: 0
            })) : o(M).state.layoutMode === 2 ? (s(), f(Ro, {
                key: 1
            })) : (s(), f(Mt, {
                key: 2
            })), o(M).state.popStep >= 4 && te.value ? (s(), f(o(se), {
                key: 3,
                value: te.value,
                "onUpdate:value": y[0] || (y[0] = $ => te.value = $)
            }, null, 8, ["value"])) : v("", !0), o(M).state.popStep >= 3 && F.value && I[0] && I[0].rules.length && A.value ? (s(), f(o(pe), {
                key: 4,
                value: A.value,
                "onUpdate:value": y[1] || (y[1] = $ => A.value = $),
                detail: I[0]
            }, null, 8, ["value", "detail"])) : v("", !0), o(M).state.popStep === 2 && o(M).state.sections.popup ? (s(), f(o(ge), {
                key: 5,
                onClose: y[2] || (y[2] = $ => o(M).state.popStep = 3)
            })) : v("", !0), o(M).state.popStep === 1 ? (s(), f(o(ve), {
                key: 6
            })) : v("", !0), o(M).state.popStep >= 3 && n.value ? (s(), f(o(ie), {
                key: 7,
                value: n.value,
                "onUpdate:value": y[3] || (y[3] = $ => n.value = $)
            }, null, 8, ["value"])) : v("", !0), o(M).state.popStep >= 3 && q.value ? (s(), f(o(ye), {
                key: 8,
                value: q.value,
                "onUpdate:value": y[4] || (y[4] = $ => q.value = $)
            }, null, 8, ["value"])) : v("", !0)]))
        }
    })
});
export {
    Ko as __tla, yt as
    default
};