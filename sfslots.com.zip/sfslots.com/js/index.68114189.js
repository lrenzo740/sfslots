import {
    o as a,
    c as l,
    a as t,
    W as o,
    X as r
} from "./@vue.16908cbf.js";
const i = {
        class: "tool-tips-box"
    },
    c = t("p", {
        class: "tool-tips-tail"
    }, null, -1),
    u = {
        __name: "index",
        props: {
            text: {
                default: "",
                required: !0
            },
            right: {
                default: "",
                required: !1
            },
            left: {
                default: "",
                required: !1
            },
            top: {
                default: "",
                required: !1
            }
        },
        setup(s) {
            const e = s;
            return (n, p) => (a(), l("div", {
                class: "custom-badge",
                style: r({
                    right: e.right ? e.right : "",
                    top: e.top ? e.top : "",
                    left: e.left ? e.left : ""
                })
            }, [t("p", i, o(e.text), 1), c], 4))
        }
    };
export {
    u as
    default
};