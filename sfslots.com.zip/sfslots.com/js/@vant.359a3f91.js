import {
    i as x,
    g as O,
    b as N,
    e as R,
    r as w,
    f as k,
    j as A,
    n as S,
    k as P,
    l as _,
    m as V,
    w as M,
    u as T,
    p as D,
    q as I
} from "./@vue.16908cbf.js";
var m = typeof window < "u";

function C(e) {
    return m ? requestAnimationFrame(e) : -1
}

function G(e) {
    m && cancelAnimationFrame(e)
}

function Q(e) {
    C(() => C(e))
}
var W = e => e === window,
    L = (e, t) => ({
        top: 0,
        left: 0,
        right: e,
        bottom: t,
        width: e,
        height: t
    }),
    Z = e => {
        const t = T(e);
        if (W(t)) {
            const i = t.innerWidth,
                r = t.innerHeight;
            return L(i, r)
        }
        return t ? .getBoundingClientRect ? t.getBoundingClientRect() : L(0, 0)
    };

function $(e) {
    const t = x(e, null);
    if (t) {
        const i = O(),
            {
                link: r,
                unlink: a,
                internalChildren: s
            } = t;
        r(i), N(() => a(i));
        const l = R(() => s.indexOf(i));
        return {
            parent: t,
            index: l
        }
    }
    return {
        parent: null,
        index: w(-1)
    }
}

function B(e) {
    const t = [],
        i = r => {
            Array.isArray(r) && r.forEach(a => {
                var s;
                I(a) && (t.push(a), (s = a.component) != null && s.subTree && (t.push(a.component.subTree), i(a.component.subTree.children)), a.children && i(a.children))
            })
        };
    return i(e), t
}
var b = (e, t) => {
    const i = e.indexOf(t);
    return i === -1 ? e.findIndex(r => t.key !== void 0 && t.key !== null && r.type === t.type && r.key === t.key) : i
};

function X(e, t, i) {
    const r = B(e.subTree.children);
    i.sort((s, l) => b(r, s.vnode) - b(r, l.vnode));
    const a = i.map(s => s.proxy);
    t.sort((s, l) => {
        const d = a.indexOf(s),
            c = a.indexOf(l);
        return d - c
    })
}

function ee(e) {
    const t = k([]),
        i = k([]),
        r = O();
    return {
        children: t,
        linkChildren: s => {
            D(e, Object.assign({
                link: c => {
                    c.proxy && (i.push(c), t.push(c.proxy), X(r, t, i))
                },
                unlink: c => {
                    const f = i.indexOf(c);
                    t.splice(f, 1), i.splice(f, 1)
                },
                children: t,
                internalChildren: i
            }, s))
        }
    }
}

function j(e) {
    let t;
    A(() => {
        e(), S(() => {
            t = !0
        })
    }), P(() => {
        t && e()
    })
}

function F(e, t, i = {}) {
    if (!m) return;
    const {
        target: r = window,
        passive: a = !1,
        capture: s = !1
    } = i;
    let l = !1,
        d;
    const c = n => {
            if (l) return;
            const u = T(n);
            u && !d && (u.addEventListener(e, t, {
                capture: s,
                passive: a
            }), d = !0)
        },
        f = n => {
            if (l) return;
            const u = T(n);
            u && d && (u.removeEventListener(e, t, s), d = !1)
        };
    N(() => f(r)), _(() => f(r)), j(() => c(r));
    let o;
    return V(r) && (o = M(r, (n, u) => {
        f(u), c(n)
    })), () => {
        o ? .(), f(r), l = !0
    }
}

function te(e, t, i = {}) {
    if (!m) return;
    const {
        eventName: r = "click"
    } = i;
    F(r, s => {
        (Array.isArray(e) ? e : [e]).every(c => {
            const f = T(c);
            return f && !f.contains(s.target)
        }) && t(s)
    }, {
        target: document
    })
}
var g, E;

function ne() {
    if (!g && (g = w(0), E = w(0), m)) {
        const e = () => {
            g.value = window.innerWidth, E.value = window.innerHeight
        };
        e(), window.addEventListener("resize", e, {
            passive: !0
        }), window.addEventListener("orientationchange", e, {
            passive: !0
        })
    }
    return {
        width: g,
        height: E
    }
}
var H = /scroll|auto|overlay/i,
    Y = m ? window : void 0;

function q(e) {
    return e.tagName !== "HTML" && e.tagName !== "BODY" && e.nodeType === 1
}

function z(e, t = Y) {
    let i = e;
    for (; i && i !== t && q(i);) {
        const {
            overflowY: r
        } = window.getComputedStyle(i);
        if (H.test(r)) return i;
        i = i.parentNode
    }
    return t
}

function ie(e, t = Y) {
    const i = w();
    return A(() => {
        e.value && (i.value = z(e.value, t))
    }), i
}
var y;

function re() {
    if (!y && (y = w("visible"), m)) {
        const e = () => {
            y.value = document.hidden ? "hidden" : "visible"
        };
        e(), window.addEventListener("visibilitychange", e)
    }
    return y
}
var U = Symbol("van-field");

function oe(e) {
    const t = x(U, null);
    t && !t.customValue.value && (t.customValue.value = e, M(e, () => {
        t.resetValidation(), t.validateWithTrigger("onChange")
    }))
}(function() {
    if (typeof window > "u") return;
    var e, t = "ontouchstart" in window;
    document.createTouch || (document.createTouch = function(o, n, u, h, p, v, K) {
        return new i(n, u, {
            pageX: h,
            pageY: p,
            screenX: v,
            screenY: K,
            clientX: h - window.pageXOffset,
            clientY: p - window.pageYOffset
        }, 0, 0)
    }), document.createTouchList || (document.createTouchList = function() {
        for (var o = r(), n = 0; n < arguments.length; n++) o[n] = arguments[n];
        return o.length = arguments.length, o
    }), Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector), Element.prototype.closest || (Element.prototype.closest = function(o) {
        var n = this;
        do {
            if (n.matches(o)) return n;
            n = n.parentElement || n.parentNode
        } while (n !== null && n.nodeType === 1);
        return null
    });
    var i = function(n, u, h, p, v) {
        p = p || 0, v = v || 0, this.identifier = u, this.target = n, this.clientX = h.clientX + p, this.clientY = h.clientY + v, this.screenX = h.screenX + p, this.screenY = h.screenY + v, this.pageX = h.pageX + p, this.pageY = h.pageY + v
    };

    function r() {
        var o = [];
        return o.item = function(n) {
            return this[n] || null
        }, o.identifiedTouch = function(n) {
            return this[n + 1] || null
        }, o
    }
    var a = !1;

    function s(o) {
        return function(n) {
            n.type === "mousedown" && (a = !0), n.type === "mouseup" && (a = !1), !(n.type === "mousemove" && !a) && ((n.type === "mousedown" || !e || e && !e.dispatchEvent) && (e = n.target), e.closest("[data-no-touch-simulate]") == null && l(o, n), n.type === "mouseup" && (e = null))
        }
    }

    function l(o, n) {
        var u = document.createEvent("Event");
        u.initEvent(o, !0, !0), u.altKey = n.altKey, u.ctrlKey = n.ctrlKey, u.metaKey = n.metaKey, u.shiftKey = n.shiftKey, u.touches = c(n), u.targetTouches = c(n), u.changedTouches = d(n), e.dispatchEvent(u)
    }

    function d(o) {
        var n = r();
        return n.push(new i(e, 1, o, 0, 0)), n
    }

    function c(o) {
        return o.type === "mouseup" ? r() : d(o)
    }

    function f() {
        window.addEventListener("mousedown", s("touchstart"), !0), window.addEventListener("mousemove", s("touchmove"), !0), window.addEventListener("mouseup", s("touchend"), !0)
    }
    f.multiTouchOffset = 75, t || new f
})();
export {
    U as C, Z as a, F as b, $ as c, G as d, ie as e, ee as f, z as g, re as h, Q as i, oe as j, te as k, j as o, C as r, ne as u
};