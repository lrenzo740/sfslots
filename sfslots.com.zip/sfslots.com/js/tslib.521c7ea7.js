var y = function() {
    return y = Object.assign || function(l) {
        for (var e, r = 1, a = arguments.length; r < a; r++) {
            e = arguments[r];
            for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (l[n] = e[n])
        }
        return l
    }, y.apply(this, arguments)
};

function h(u, l, e, r) {
    function a(n) {
        return n instanceof e ? n : new e(function(i) {
            i(n)
        })
    }
    return new(e || (e = Promise))(function(n, i) {
        function f(c) {
            try {
                t(r.next(c))
            } catch (o) {
                i(o)
            }
        }

        function s(c) {
            try {
                t(r.throw(c))
            } catch (o) {
                i(o)
            }
        }

        function t(c) {
            c.done ? n(c.value) : a(c.value).then(f, s)
        }
        t((r = r.apply(u, l || [])).next())
    })
}

function b(u, l) {
    var e = {
            label: 0,
            sent: function() {
                if (n[0] & 1) throw n[1];
                return n[1]
            },
            trys: [],
            ops: []
        },
        r, a, n, i;
    return i = {
        next: f(0),
        throw: f(1),
        return: f(2)
    }, typeof Symbol == "function" && (i[Symbol.iterator] = function() {
        return this
    }), i;

    function f(t) {
        return function(c) {
            return s([t, c])
        }
    }

    function s(t) {
        if (r) throw new TypeError("Generator is already executing.");
        for (; i && (i = 0, t[0] && (e = 0)), e;) try {
            if (r = 1, a && (n = t[0] & 2 ? a.return : t[0] ? a.throw || ((n = a.return) && n.call(a), 0) : a.next) && !(n = n.call(a, t[1])).done) return n;
            switch (a = 0, n && (t = [t[0] & 2, n.value]), t[0]) {
                case 0:
                case 1:
                    n = t;
                    break;
                case 4:
                    return e.label++, {
                        value: t[1],
                        done: !1
                    };
                case 5:
                    e.label++, a = t[1], t = [0];
                    continue;
                case 7:
                    t = e.ops.pop(), e.trys.pop();
                    continue;
                default:
                    if (n = e.trys, !(n = n.length > 0 && n[n.length - 1]) && (t[0] === 6 || t[0] === 2)) {
                        e = 0;
                        continue
                    }
                    if (t[0] === 3 && (!n || t[1] > n[0] && t[1] < n[3])) {
                        e.label = t[1];
                        break
                    }
                    if (t[0] === 6 && e.label < n[1]) {
                        e.label = n[1], n = t;
                        break
                    }
                    if (n && e.label < n[2]) {
                        e.label = n[2], e.ops.push(t);
                        break
                    }
                    n[2] && e.ops.pop(), e.trys.pop();
                    continue
            }
            t = l.call(u, e)
        } catch (c) {
            t = [6, c], a = 0
        } finally {
            r = n = 0
        }
        if (t[0] & 5) throw t[1];
        return {
            value: t[0] ? t[1] : void 0,
            done: !0
        }
    }
}

function w(u, l, e) {
    if (e || arguments.length === 2)
        for (var r = 0, a = l.length, n; r < a; r++)(n || !(r in l)) && (n || (n = Array.prototype.slice.call(l, 0, r)), n[r] = l[r]);
    return u.concat(n || Array.prototype.slice.call(l))
}
export {
    h as _, y as a, b, w as c
};