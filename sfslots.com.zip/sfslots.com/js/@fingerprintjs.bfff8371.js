import {
    _ as Z,
    a as ge,
    b as W,
    c as oe
} from "./tslib.521c7ea7.js";
var ce = "3.4.1";

function Y(e, n) {
    return new Promise(function(t) {
        return setTimeout(t, e, n)
    })
}

function be(e, n) {
    n === void 0 && (n = 1 / 0);
    var t = window.requestIdleCallback;
    return t ? new Promise(function(a) {
        return t.call(window, function() {
            return a()
        }, {
            timeout: n
        })
    }) : Y(Math.min(e, n))
}

function ue(e) {
    return !!e && typeof e.then == "function"
}

function U(e, n) {
    try {
        var t = e();
        ue(t) ? t.then(function(a) {
            return n(!0, a)
        }, function(a) {
            return n(!1, a)
        }) : n(!0, t)
    } catch (a) {
        n(!1, a)
    }
}

function K(e, n, t) {
    return t === void 0 && (t = 16), Z(this, void 0, void 0, function() {
        var a, i, o;
        return W(this, function(r) {
            switch (r.label) {
                case 0:
                    a = Date.now(), i = 0, r.label = 1;
                case 1:
                    return i < e.length ? (n(e[i], i), o = Date.now(), o >= a + t ? (a = o, [4, Y(0)]) : [3, 3]) : [3, 4];
                case 2:
                    r.sent(), r.label = 3;
                case 3:
                    return ++i, [3, 1];
                case 4:
                    return [2]
            }
        })
    })
}

function J(e) {
    e.then(void 0, function() {})
}

function R(e, n) {
    e = [e[0] >>> 16, e[0] & 65535, e[1] >>> 16, e[1] & 65535], n = [n[0] >>> 16, n[0] & 65535, n[1] >>> 16, n[1] & 65535];
    var t = [0, 0, 0, 0];
    return t[3] += e[3] + n[3], t[2] += t[3] >>> 16, t[3] &= 65535, t[2] += e[2] + n[2], t[1] += t[2] >>> 16, t[2] &= 65535, t[1] += e[1] + n[1], t[0] += t[1] >>> 16, t[1] &= 65535, t[0] += e[0] + n[0], t[0] &= 65535, [t[0] << 16 | t[1], t[2] << 16 | t[3]]
}

function V(e, n) {
    e = [e[0] >>> 16, e[0] & 65535, e[1] >>> 16, e[1] & 65535], n = [n[0] >>> 16, n[0] & 65535, n[1] >>> 16, n[1] & 65535];
    var t = [0, 0, 0, 0];
    return t[3] += e[3] * n[3], t[2] += t[3] >>> 16, t[3] &= 65535, t[2] += e[2] * n[3], t[1] += t[2] >>> 16, t[2] &= 65535, t[2] += e[3] * n[2], t[1] += t[2] >>> 16, t[2] &= 65535, t[1] += e[1] * n[3], t[0] += t[1] >>> 16, t[1] &= 65535, t[1] += e[2] * n[2], t[0] += t[1] >>> 16, t[1] &= 65535, t[1] += e[3] * n[1], t[0] += t[1] >>> 16, t[1] &= 65535, t[0] += e[0] * n[3] + e[1] * n[2] + e[2] * n[1] + e[3] * n[0], t[0] &= 65535, [t[0] << 16 | t[1], t[2] << 16 | t[3]]
}

function X(e, n) {
    return n %= 64, n === 32 ? [e[1], e[0]] : n < 32 ? [e[0] << n | e[1] >>> 32 - n, e[1] << n | e[0] >>> 32 - n] : (n -= 32, [e[1] << n | e[0] >>> 32 - n, e[0] << n | e[1] >>> 32 - n])
}

function S(e, n) {
    return n %= 64, n === 0 ? e : n < 32 ? [e[0] << n | e[1] >>> 32 - n, e[1] << n] : [e[1] << n - 32, 0]
}

function w(e, n) {
    return [e[0] ^ n[0], e[1] ^ n[1]]
}

function q(e) {
    return e = w(e, [0, e[0] >>> 1]), e = V(e, [4283543511, 3981806797]), e = w(e, [0, e[0] >>> 1]), e = V(e, [3301882366, 444984403]), e = w(e, [0, e[0] >>> 1]), e
}

function ye(e, n) {
    e = e || "", n = n || 0;
    var t = e.length % 16,
        a = e.length - t,
        i = [0, n],
        o = [0, n],
        r = [0, 0],
        c = [0, 0],
        s = [2277735313, 289559509],
        l = [1291169091, 658871167],
        u;
    for (u = 0; u < a; u = u + 16) r = [e.charCodeAt(u + 4) & 255 | (e.charCodeAt(u + 5) & 255) << 8 | (e.charCodeAt(u + 6) & 255) << 16 | (e.charCodeAt(u + 7) & 255) << 24, e.charCodeAt(u) & 255 | (e.charCodeAt(u + 1) & 255) << 8 | (e.charCodeAt(u + 2) & 255) << 16 | (e.charCodeAt(u + 3) & 255) << 24], c = [e.charCodeAt(u + 12) & 255 | (e.charCodeAt(u + 13) & 255) << 8 | (e.charCodeAt(u + 14) & 255) << 16 | (e.charCodeAt(u + 15) & 255) << 24, e.charCodeAt(u + 8) & 255 | (e.charCodeAt(u + 9) & 255) << 8 | (e.charCodeAt(u + 10) & 255) << 16 | (e.charCodeAt(u + 11) & 255) << 24], r = V(r, s), r = X(r, 31), r = V(r, l), i = w(i, r), i = X(i, 27), i = R(i, o), i = R(V(i, [0, 5]), [0, 1390208809]), c = V(c, l), c = X(c, 33), c = V(c, s), o = w(o, c), o = X(o, 31), o = R(o, i), o = R(V(o, [0, 5]), [0, 944331445]);
    switch (r = [0, 0], c = [0, 0], t) {
        case 15:
            c = w(c, S([0, e.charCodeAt(u + 14)], 48));
        case 14:
            c = w(c, S([0, e.charCodeAt(u + 13)], 40));
        case 13:
            c = w(c, S([0, e.charCodeAt(u + 12)], 32));
        case 12:
            c = w(c, S([0, e.charCodeAt(u + 11)], 24));
        case 11:
            c = w(c, S([0, e.charCodeAt(u + 10)], 16));
        case 10:
            c = w(c, S([0, e.charCodeAt(u + 9)], 8));
        case 9:
            c = w(c, [0, e.charCodeAt(u + 8)]), c = V(c, l), c = X(c, 33), c = V(c, s), o = w(o, c);
        case 8:
            r = w(r, S([0, e.charCodeAt(u + 7)], 56));
        case 7:
            r = w(r, S([0, e.charCodeAt(u + 6)], 48));
        case 6:
            r = w(r, S([0, e.charCodeAt(u + 5)], 40));
        case 5:
            r = w(r, S([0, e.charCodeAt(u + 4)], 32));
        case 4:
            r = w(r, S([0, e.charCodeAt(u + 3)], 24));
        case 3:
            r = w(r, S([0, e.charCodeAt(u + 2)], 16));
        case 2:
            r = w(r, S([0, e.charCodeAt(u + 1)], 8));
        case 1:
            r = w(r, [0, e.charCodeAt(u)]), r = V(r, s), r = X(r, 31), r = V(r, l), i = w(i, r)
    }
    return i = w(i, [0, e.length]), o = w(o, [0, e.length]), i = R(i, o), o = R(o, i), i = q(i), o = q(o), i = R(i, o), o = R(o, i), ("00000000" + (i[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (i[1] >>> 0).toString(16)).slice(-8) + ("00000000" + (o[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (o[1] >>> 0).toString(16)).slice(-8)
}

function we(e) {
    var n;
    return ge({
        name: e.name,
        message: e.message,
        stack: (n = e.stack) === null || n === void 0 ? void 0 : n.split(`
`)
    }, e)
}

function Le(e, n) {
    for (var t = 0, a = e.length; t < a; ++t)
        if (e[t] === n) return !0;
    return !1
}

function Se(e, n) {
    return !Le(e, n)
}

function E(e) {
    return parseInt(e)
}

function C(e) {
    return parseFloat(e)
}

function k(e, n) {
    return typeof e == "number" && isNaN(e) ? n : e
}

function x(e) {
    return e.reduce(function(n, t) {
        return n + (t ? 1 : 0)
    }, 0)
}

function se(e, n) {
    if (n === void 0 && (n = 1), Math.abs(n) >= 1) return Math.round(e / n) * n;
    var t = 1 / n;
    return Math.round(e * t) / t
}

function Ve(e) {
    for (var n, t, a = "Unexpected syntax '".concat(e, "'"), i = /^\s*([a-z-]*)(.*)$/i.exec(e), o = i[1] || void 0, r = {}, c = /([.:#][\w-]+|\[.+?\])/gi, s = function(d, p) {
            r[d] = r[d] || [], r[d].push(p)
        };;) {
        var l = c.exec(i[2]);
        if (!l) break;
        var u = l[0];
        switch (u[0]) {
            case ".":
                s("class", u.slice(1));
                break;
            case "#":
                s("id", u.slice(1));
                break;
            case "[":
                {
                    var f = /^\[([\w-]+)([~|^$*]?=("(.*?)"|([\w-]+)))?(\s+[is])?\]$/.exec(u);
                    if (f) s(f[1], (t = (n = f[4]) !== null && n !== void 0 ? n : f[5]) !== null && t !== void 0 ? t : "");
                    else throw new Error(a);
                    break
                }
            default:
                throw new Error(a)
        }
    }
    return [o, r]
}

function _(e) {
    return e && typeof e == "object" && "message" in e ? e : {
        message: e
    }
}

function Ce(e) {
    return typeof e != "function"
}

function xe(e, n) {
    var t = new Promise(function(a) {
        var i = Date.now();
        U(e.bind(null, n), function() {
            for (var o = [], r = 0; r < arguments.length; r++) o[r] = arguments[r];
            var c = Date.now() - i;
            if (!o[0]) return a(function() {
                return {
                    error: _(o[1]),
                    duration: c
                }
            });
            var s = o[1];
            if (Ce(s)) return a(function() {
                return {
                    value: s,
                    duration: c
                }
            });
            a(function() {
                return new Promise(function(l) {
                    var u = Date.now();
                    U(s, function() {
                        for (var f = [], d = 0; d < arguments.length; d++) f[d] = arguments[d];
                        var p = c + Date.now() - u;
                        if (!f[0]) return l({
                            error: _(f[1]),
                            duration: p
                        });
                        l({
                            value: f[1],
                            duration: p
                        })
                    })
                })
            })
        })
    });
    return J(t),
        function() {
            return t.then(function(i) {
                return i()
            })
        }
}

function Fe(e, n, t) {
    var a = Object.keys(e).filter(function(o) {
            return Se(t, o)
        }),
        i = Array(a.length);
    return K(a, function(o, r) {
            i[r] = xe(e[o], n)
        }),
        function() {
            return Z(this, void 0, void 0, function() {
                var r, c, s, l, u, f, d;
                return W(this, function(p) {
                    switch (p.label) {
                        case 0:
                            for (r = {}, c = 0, s = a; c < s.length; c++) l = s[c], r[l] = void 0;
                            u = Array(a.length), f = function() {
                                var v;
                                return W(this, function(g) {
                                    switch (g.label) {
                                        case 0:
                                            return v = !0, [4, K(a, function(y, h) {
                                                if (!u[h])
                                                    if (i[h]) {
                                                        var F = i[h]().then(function(G) {
                                                            return r[y] = G
                                                        });
                                                        J(F), u[h] = F
                                                    } else v = !1
                                            })];
                                        case 1:
                                            return g.sent(), v ? [2, "break"] : [4, Y(1)];
                                        case 2:
                                            return g.sent(), [2]
                                    }
                                })
                            }, p.label = 1;
                        case 1:
                            return [5, f()];
                        case 2:
                            if (d = p.sent(), d === "break") return [3, 4];
                            p.label = 3;
                        case 3:
                            return [3, 1];
                        case 4:
                            return [4, Promise.all(u)];
                        case 5:
                            return p.sent(), [2, r]
                    }
                })
            })
        }
}

function le() {
    var e = window,
        n = navigator;
    return x(["MSCSSMatrix" in e, "msSetImmediate" in e, "msIndexedDB" in e, "msMaxTouchPoints" in n, "msPointerEnabled" in n]) >= 4
}

function We() {
    var e = window,
        n = navigator;
    return x(["msWriteProfilerMark" in e, "MSStream" in e, "msLaunchUri" in n, "msSaveBlob" in n]) >= 3 && !le()
}

function O() {
    var e = window,
        n = navigator;
    return x(["webkitPersistentStorage" in n, "webkitTemporaryStorage" in n, n.vendor.indexOf("Google") === 0, "webkitResolveLocalFileSystemURL" in e, "BatteryManager" in e, "webkitMediaStream" in e, "webkitSpeechGrammar" in e]) >= 5
}

function I() {
    var e = window,
        n = navigator;
    return x(["ApplePayError" in e, "CSSPrimitiveValue" in e, "Counter" in e, n.vendor.indexOf("Apple") === 0, "getStorageUpdates" in n, "WebKitMediaKeys" in e]) >= 4
}

function Q() {
    var e = window;
    return x(["safari" in e, !("DeviceMotionEvent" in e), !("ongestureend" in e), !("standalone" in navigator)]) >= 3
}

function ke() {
    var e, n, t = window;
    return x(["buildID" in navigator, "MozAppearance" in ((n = (e = document.documentElement) === null || e === void 0 ? void 0 : e.style) !== null && n !== void 0 ? n : {}), "onmozfullscreenchange" in t, "mozInnerScreenX" in t, "CSSMozDocumentRule" in t, "CanvasCaptureMediaStream" in t]) >= 4
}

function Ze() {
    var e = window;
    return x([!("MediaSettingsRange" in e), "RTCEncodedAudioFrame" in e, "" + e.Intl == "[object Intl]", "" + e.Reflect == "[object Reflect]"]) >= 3
}

function Re() {
    var e = window;
    return x(["DOMRectList" in e, "RTCPeerConnectionIceEvent" in e, "SVGGeometryElement" in e, "ontransitioncancel" in e]) >= 3
}

function Xe() {
    if (navigator.platform === "iPad") return !0;
    var e = screen,
        n = e.width / e.height;
    return x(["MediaSource" in window, !!Element.prototype.webkitRequestFullscreen, n > .65 && n < 1.53]) >= 2
}

function Me() {
    var e = document;
    return e.fullscreenElement || e.msFullscreenElement || e.mozFullScreenElement || e.webkitFullscreenElement || null
}

function Ae() {
    var e = document;
    return (e.exitFullscreen || e.msExitFullscreen || e.mozCancelFullScreen || e.webkitExitFullscreen).call(e)
}

function fe() {
    var e = O(),
        n = ke();
    if (!e && !n) return !1;
    var t = window;
    return x(["onorientationchange" in t, "orientation" in t, e && !("SharedWorker" in t), n && /android/i.test(navigator.appVersion)]) >= 2
}

function Ye() {
    var e = window,
        n = e.OfflineAudioContext || e.webkitOfflineAudioContext;
    if (!n) return -2;
    if (Ge()) return -1;
    var t = 4500,
        a = 5e3,
        i = new n(1, a, 44100),
        o = i.createOscillator();
    o.type = "triangle", o.frequency.value = 1e4;
    var r = i.createDynamicsCompressor();
    r.threshold.value = -50, r.knee.value = 40, r.ratio.value = 12, r.attack.value = 0, r.release.value = .25, o.connect(r), r.connect(i.destination), o.start(0);
    var c = Ie(i),
        s = c[0],
        l = c[1],
        u = s.then(function(f) {
            return je(f.getChannelData(0).subarray(t))
        }, function(f) {
            if (f.name === "timeout" || f.name === "suspended") return -3;
            throw f
        });
    return J(u),
        function() {
            return l(), u
        }
}

function Ge() {
    return I() && !Q() && !Re()
}

function Ie(e) {
    var n = 3,
        t = 500,
        a = 500,
        i = 5e3,
        o = function() {},
        r = new Promise(function(c, s) {
            var l = !1,
                u = 0,
                f = 0;
            e.oncomplete = function(v) {
                return c(v.renderedBuffer)
            };
            var d = function() {
                    setTimeout(function() {
                        return s($("timeout"))
                    }, Math.min(a, f + i - Date.now()))
                },
                p = function() {
                    try {
                        var v = e.startRendering();
                        switch (ue(v) && J(v), e.state) {
                            case "running":
                                f = Date.now(), l && d();
                                break;
                            case "suspended":
                                document.hidden || u++, l && u >= n ? s($("suspended")) : setTimeout(p, t);
                                break
                        }
                    } catch (g) {
                        s(g)
                    }
                };
            p(), o = function() {
                l || (l = !0, f > 0 && d())
            }
        });
    return [r, o]
}

function je(e) {
    for (var n = 0, t = 0; t < e.length; ++t) n += Math.abs(e[t]);
    return n
}

function $(e) {
    var n = new Error(e);
    return n.name = e, n
}

function de(e, n, t) {
    var a, i, o;
    return t === void 0 && (t = 50), Z(this, void 0, void 0, function() {
        var r, c;
        return W(this, function(s) {
            switch (s.label) {
                case 0:
                    r = document, s.label = 1;
                case 1:
                    return r.body ? [3, 3] : [4, Y(t)];
                case 2:
                    return s.sent(), [3, 1];
                case 3:
                    c = r.createElement("iframe"), s.label = 4;
                case 4:
                    return s.trys.push([4, , 10, 11]), [4, new Promise(function(l, u) {
                        var f = !1,
                            d = function() {
                                f = !0, l()
                            },
                            p = function(y) {
                                f = !0, u(y)
                            };
                        c.onload = d, c.onerror = p;
                        var v = c.style;
                        v.setProperty("display", "block", "important"), v.position = "absolute", v.top = "0", v.left = "0", v.visibility = "hidden", n && "srcdoc" in c ? c.srcdoc = n : c.src = "about:blank", r.body.appendChild(c);
                        var g = function() {
                            var y, h;
                            f || (((h = (y = c.contentWindow) === null || y === void 0 ? void 0 : y.document) === null || h === void 0 ? void 0 : h.readyState) === "complete" ? d() : setTimeout(g, 10))
                        };
                        g()
                    })];
                case 5:
                    s.sent(), s.label = 6;
                case 6:
                    return !((i = (a = c.contentWindow) === null || a === void 0 ? void 0 : a.document) === null || i === void 0) && i.body ? [3, 8] : [4, Y(t)];
                case 7:
                    return s.sent(), [3, 6];
                case 8:
                    return [4, e(c, c.contentWindow)];
                case 9:
                    return [2, s.sent()];
                case 10:
                    return (o = c.parentNode) === null || o === void 0 || o.removeChild(c), [7];
                case 11:
                    return [2]
            }
        })
    })
}

function Pe(e) {
    for (var n = Ve(e), t = n[0], a = n[1], i = document.createElement(t ? ? "div"), o = 0, r = Object.keys(a); o < r.length; o++) {
        var c = r[o],
            s = a[c].join(" ");
        c === "style" ? Je(i.style, s) : i.setAttribute(c, s)
    }
    return i
}

function Je(e, n) {
    for (var t = 0, a = n.split(";"); t < a.length; t++) {
        var i = a[t],
            o = /^\s*([\w-]+)\s*:\s*(.+?)(\s*!([\w-]+))?\s*$/.exec(i);
        if (o) {
            var r = o[1],
                c = o[2],
                s = o[4];
            e.setProperty(r, c, s || "")
        }
    }
}
var Ne = "mmMwWLliI0O&1",
    He = "48px",
    M = ["monospace", "sans-serif", "serif"],
    ee = ["sans-serif-thin", "ARNO PRO", "Agency FB", "Arabic Typesetting", "Arial Unicode MS", "AvantGarde Bk BT", "BankGothic Md BT", "Batang", "Bitstream Vera Sans Mono", "Calibri", "Century", "Century Gothic", "Clarendon", "EUROSTILE", "Franklin Gothic", "Futura Bk BT", "Futura Md BT", "GOTHAM", "Gill Sans", "HELV", "Haettenschweiler", "Helvetica Neue", "Humanst521 BT", "Leelawadee", "Letter Gothic", "Levenim MT", "Lucida Bright", "Lucida Sans", "Menlo", "MS Mincho", "MS Outlook", "MS Reference Specialty", "MS UI Gothic", "MT Extra", "MYRIAD PRO", "Marlett", "Meiryo UI", "Microsoft Uighur", "Minion Pro", "Monotype Corsiva", "PMingLiU", "Pristina", "SCRIPTINA", "Segoe UI Light", "Serifa", "SimHei", "Small Fonts", "Staccato222 BT", "TRAJAN PRO", "Univers CE 55 Medium", "Vrinda", "ZWAdobeF"];

function Te() {
    return de(function(e, n) {
        var t = n.document,
            a = t.body;
        a.style.fontSize = He;
        var i = t.createElement("div"),
            o = {},
            r = {},
            c = function(g) {
                var y = t.createElement("span"),
                    h = y.style;
                return h.position = "absolute", h.top = "0", h.left = "0", h.fontFamily = g, y.textContent = Ne, i.appendChild(y), y
            },
            s = function(g, y) {
                return c("'".concat(g, "',").concat(y))
            },
            l = function() {
                return M.map(c)
            },
            u = function() {
                for (var g = {}, y = function(j) {
                        g[j] = M.map(function(N) {
                            return s(j, N)
                        })
                    }, h = 0, F = ee; h < F.length; h++) {
                    var G = F[h];
                    y(G)
                }
                return g
            },
            f = function(g) {
                return M.some(function(y, h) {
                    return g[h].offsetWidth !== o[y] || g[h].offsetHeight !== r[y]
                })
            },
            d = l(),
            p = u();
        a.appendChild(i);
        for (var v = 0; v < M.length; v++) o[M[v]] = d[v].offsetWidth, r[M[v]] = d[v].offsetHeight;
        return ee.filter(function(g) {
            return f(p[g])
        })
    })
}

function ze() {
    var e = navigator.plugins;
    if (e) {
        for (var n = [], t = 0; t < e.length; ++t) {
            var a = e[t];
            if (a) {
                for (var i = [], o = 0; o < a.length; ++o) {
                    var r = a[o];
                    i.push({
                        type: r.type,
                        suffixes: r.suffixes
                    })
                }
                n.push({
                    name: a.name,
                    description: a.description,
                    mimeTypes: i
                })
            }
        }
        return n
    }
}

function De() {
    var e = !1,
        n, t, a = Be(),
        i = a[0],
        o = a[1];
    if (!Ee(i, o)) n = t = "";
    else {
        e = Oe(o), Qe(i, o);
        var r = H(i),
            c = H(i);
        r !== c ? n = t = "unstable" : (t = r, Ue(i, o), n = H(i))
    }
    return {
        winding: e,
        geometry: n,
        text: t
    }
}

function Be() {
    var e = document.createElement("canvas");
    return e.width = 1, e.height = 1, [e, e.getContext("2d")]
}

function Ee(e, n) {
    return !!(n && e.toDataURL)
}

function Oe(e) {
    return e.rect(0, 0, 10, 10), e.rect(2, 2, 6, 6), !e.isPointInPath(5, 5, "evenodd")
}

function Qe(e, n) {
    e.width = 240, e.height = 60, n.textBaseline = "alphabetic", n.fillStyle = "#f60", n.fillRect(100, 1, 62, 20), n.fillStyle = "#069", n.font = '11pt "Times New Roman"';
    var t = "Cwm fjordbank gly ".concat(String.fromCharCode(55357, 56835));
    n.fillText(t, 2, 15), n.fillStyle = "rgba(102, 204, 0, 0.2)", n.font = "18pt Arial", n.fillText(t, 4, 45)
}

function Ue(e, n) {
    e.width = 122, e.height = 110, n.globalCompositeOperation = "multiply";
    for (var t = 0, a = [
            ["#f2f", 40, 40],
            ["#2ff", 80, 40],
            ["#ff2", 60, 80]
        ]; t < a.length; t++) {
        var i = a[t],
            o = i[0],
            r = i[1],
            c = i[2];
        n.fillStyle = o, n.beginPath(), n.arc(r, c, 40, 0, Math.PI * 2, !0), n.closePath(), n.fill()
    }
    n.fillStyle = "#f9c", n.arc(60, 60, 60, 0, Math.PI * 2, !0), n.arc(60, 60, 20, 0, Math.PI * 2, !0), n.fill("evenodd")
}

function H(e) {
    return e.toDataURL()
}

function Ke() {
    var e = navigator,
        n = 0,
        t;
    e.maxTouchPoints !== void 0 ? n = E(e.maxTouchPoints) : e.msMaxTouchPoints !== void 0 && (n = e.msMaxTouchPoints);
    try {
        document.createEvent("TouchEvent"), t = !0
    } catch {
        t = !1
    }
    var a = "ontouchstart" in window;
    return {
        maxTouchPoints: n,
        touchEvent: t,
        touchStart: a
    }
}

function qe() {
    return navigator.oscpu
}

function _e() {
    var e = navigator,
        n = [],
        t = e.language || e.userLanguage || e.browserLanguage || e.systemLanguage;
    if (t !== void 0 && n.push([t]), Array.isArray(e.languages)) O() && Ze() || n.push(e.languages);
    else if (typeof e.languages == "string") {
        var a = e.languages;
        a && n.push(a.split(","))
    }
    return n
}

function $e() {
    return window.screen.colorDepth
}

function en() {
    return k(C(navigator.deviceMemory), void 0)
}

function nn() {
    var e = screen,
        n = function(a) {
            return k(E(a), null)
        },
        t = [n(e.width), n(e.height)];
    return t.sort().reverse(), t
}
var tn = 2500,
    rn = 10,
    P, T;

function an() {
    if (T === void 0) {
        var e = function() {
            var n = D();
            B(n) ? T = setTimeout(e, tn) : (P = n, T = void 0)
        };
        e()
    }
}

function on() {
    var e = this;
    return an(),
        function() {
            return Z(e, void 0, void 0, function() {
                var n;
                return W(this, function(t) {
                    switch (t.label) {
                        case 0:
                            return n = D(), B(n) ? P ? [2, oe([], P, !0)] : Me() ? [4, Ae()] : [3, 2] : [3, 2];
                        case 1:
                            t.sent(), n = D(), t.label = 2;
                        case 2:
                            return B(n) || (P = n), [2, n]
                    }
                })
            })
        }
}

function cn() {
    var e = this,
        n = on();
    return function() {
        return Z(e, void 0, void 0, function() {
            var t, a;
            return W(this, function(i) {
                switch (i.label) {
                    case 0:
                        return [4, n()];
                    case 1:
                        return t = i.sent(), a = function(o) {
                            return o === null ? null : se(o, rn)
                        }, [2, [a(t[0]), a(t[1]), a(t[2]), a(t[3])]]
                }
            })
        })
    }
}

function D() {
    var e = screen;
    return [k(C(e.availTop), null), k(C(e.width) - C(e.availWidth) - k(C(e.availLeft), 0), null), k(C(e.height) - C(e.availHeight) - k(C(e.availTop), 0), null), k(C(e.availLeft), null)]
}

function B(e) {
    for (var n = 0; n < 4; ++n)
        if (e[n]) return !1;
    return !0
}

function un() {
    return k(E(navigator.hardwareConcurrency), void 0)
}

function sn() {
    var e, n = (e = window.Intl) === null || e === void 0 ? void 0 : e.DateTimeFormat;
    if (n) {
        var t = new n().resolvedOptions().timeZone;
        if (t) return t
    }
    var a = -ln();
    return "UTC".concat(a >= 0 ? "+" : "").concat(Math.abs(a))
}

function ln() {
    var e = new Date().getFullYear();
    return Math.max(C(new Date(e, 0, 1).getTimezoneOffset()), C(new Date(e, 6, 1).getTimezoneOffset()))
}

function fn() {
    try {
        return !!window.sessionStorage
    } catch {
        return !0
    }
}

function dn() {
    try {
        return !!window.localStorage
    } catch {
        return !0
    }
}

function mn() {
    if (!(le() || We())) try {
        return !!window.indexedDB
    } catch {
        return !0
    }
}

function vn() {
    return !!window.openDatabase
}

function hn() {
    return navigator.cpuClass
}

function pn() {
    var e = navigator.platform;
    return e === "MacIntel" && I() && !Q() ? Xe() ? "iPad" : "iPhone" : e
}

function gn() {
    return navigator.vendor || ""
}

function bn() {
    for (var e = [], n = 0, t = ["chrome", "safari", "__crWeb", "__gCrWeb", "yandex", "__yb", "__ybro", "__firefox__", "__edgeTrackingPreventionStatistics", "webkit", "oprt", "samsungAr", "ucweb", "UCShellJava", "puffinDevice"]; n < t.length; n++) {
        var a = t[n],
            i = window[a];
        i && typeof i == "object" && e.push(a)
    }
    return e.sort()
}

function yn() {
    var e = document;
    try {
        e.cookie = "cookietest=1; SameSite=Strict;";
        var n = e.cookie.indexOf("cookietest=") !== -1;
        return e.cookie = "cookietest=1; SameSite=Strict; expires=Thu, 01-Jan-1970 00:00:01 GMT", n
    } catch {
        return !1
    }
}

function wn() {
    var e = atob;
    return {
        abpIndo: ["#Iklan-Melayang", "#Kolom-Iklan-728", "#SidebarIklan-wrapper", e("YVt0aXRsZT0iN25hZ2EgcG9rZXIiIGld"), '[title="ALIENBOLA" i]'],
        abpvn: ["#quangcaomb", e("Lmlvc0Fkc2lvc0Fkcy1sYXlvdXQ="), ".quangcao", e("W2hyZWZePSJodHRwczovL3I4OC52bi8iXQ=="), e("W2hyZWZePSJodHRwczovL3piZXQudm4vIl0=")],
        adBlockFinland: [".mainostila", e("LnNwb25zb3JpdA=="), ".ylamainos", e("YVtocmVmKj0iL2NsaWNrdGhyZ2guYXNwPyJd"), e("YVtocmVmXj0iaHR0cHM6Ly9hcHAucmVhZHBlYWsuY29tL2FkcyJd")],
        adBlockPersian: ["#navbar_notice_50", ".kadr", 'TABLE[width="140px"]', "#divAgahi", e("I2FkMl9pbmxpbmU=")],
        adBlockWarningRemoval: ["#adblock-honeypot", ".adblocker-root", ".wp_adblock_detect", e("LmhlYWRlci1ibG9ja2VkLWFk"), e("I2FkX2Jsb2NrZXI=")],
        adGuardAnnoyances: ['amp-embed[type="zen"]', ".hs-sosyal", "#cookieconsentdiv", 'div[class^="app_gdpr"]', ".as-oil"],
        adGuardBase: [".BetterJsPopOverlay", e("I2FkXzMwMFgyNTA="), e("I2Jhbm5lcmZsb2F0MjI="), e("I2FkLWJhbm5lcg=="), e("I2NhbXBhaWduLWJhbm5lcg==")],
        adGuardChinese: [e("LlppX2FkX2FfSA=="), e("YVtocmVmKj0iL29kMDA1LmNvbSJd"), e("YVtocmVmKj0iLmh0aGJldDM0LmNvbSJd"), ".qq_nr_lad", "#widget-quan"],
        adGuardFrench: [e("I2Jsb2NrLXZpZXdzLWFkcy1zaWRlYmFyLWJsb2NrLWJsb2Nr"), "#pavePub", e("LmFkLWRlc2t0b3AtcmVjdGFuZ2xl"), ".mobile_adhesion", ".widgetadv"],
        adGuardGerman: [e("LmJhbm5lcml0ZW13ZXJidW5nX2hlYWRfMQ=="), e("LmJveHN0YXJ0d2VyYnVuZw=="), e("LndlcmJ1bmcz"), e("YVtocmVmXj0iaHR0cDovL3d3dy5laXMuZGUvaW5kZXgucGh0bWw/cmVmaWQ9Il0="), e("YVtocmVmXj0iaHR0cHM6Ly93d3cudGlwaWNvLmNvbS8/YWZmaWxpYXRlSWQ9Il0=")],
        adGuardJapanese: ["#kauli_yad_1", e("YVtocmVmXj0iaHR0cDovL2FkMi50cmFmZmljZ2F0ZS5uZXQvIl0="), e("Ll9wb3BJbl9pbmZpbml0ZV9hZA=="), e("LmFkZ29vZ2xl"), e("LmFkX3JlZ3VsYXIz")],
        adGuardMobile: [e("YW1wLWF1dG8tYWRz"), e("LmFtcF9hZA=="), 'amp-embed[type="24smi"]', "#mgid_iframe1", e("I2FkX2ludmlld19hcmVh")],
        adGuardRussian: [e("YVtocmVmXj0iaHR0cHM6Ly9hZC5sZXRtZWFkcy5jb20vIl0="), e("LnJlY2xhbWE="), 'div[id^="smi2adblock"]', e("ZGl2W2lkXj0iQWRGb3hfYmFubmVyXyJd"), e("I2FkX3NxdWFyZQ==")],
        adGuardSocial: [e("YVtocmVmXj0iLy93d3cuc3R1bWJsZXVwb24uY29tL3N1Ym1pdD91cmw9Il0="), e("YVtocmVmXj0iLy90ZWxlZ3JhbS5tZS9zaGFyZS91cmw/Il0="), ".etsy-tweet", "#inlineShare", ".popup-social"],
        adGuardSpanishPortuguese: ["#barraPublicidade", "#Publicidade", "#publiEspecial", "#queTooltip", e("W2hyZWZePSJodHRwOi8vYWRzLmdsaXNwYS5jb20vIl0=")],
        adGuardTrackingProtection: ["#qoo-counter", e("YVtocmVmXj0iaHR0cDovL2NsaWNrLmhvdGxvZy5ydS8iXQ=="), e("YVtocmVmXj0iaHR0cDovL2hpdGNvdW50ZXIucnUvdG9wL3N0YXQucGhwIl0="), e("YVtocmVmXj0iaHR0cDovL3RvcC5tYWlsLnJ1L2p1bXAiXQ=="), "#top100counter"],
        adGuardTurkish: ["#backkapat", e("I3Jla2xhbWk="), e("YVtocmVmXj0iaHR0cDovL2Fkc2Vydi5vbnRlay5jb20udHIvIl0="), e("YVtocmVmXj0iaHR0cDovL2l6bGVuemkuY29tL2NhbXBhaWduLyJd"), e("YVtocmVmXj0iaHR0cDovL3d3dy5pbnN0YWxsYWRzLm5ldC8iXQ==")],
        bulgarian: [e("dGQjZnJlZW5ldF90YWJsZV9hZHM="), "#ea_intext_div", ".lapni-pop-over", "#xenium_hot_offers", e("I25ld0Fk")],
        easyList: [e("I0FEX0NPTlRST0xfMjg="), e("LnNlY29uZC1wb3N0LWFkcy13cmFwcGVy"), ".universalboxADVBOX03", e("LmFkdmVydGlzZW1lbnQtNzI4eDkw"), e("LnNxdWFyZV9hZHM=")],
        easyListChina: [e("YVtocmVmKj0iLndlbnNpeHVldGFuZy5jb20vIl0="), e("LmFwcGd1aWRlLXdyYXBbb25jbGljayo9ImJjZWJvcy5jb20iXQ=="), e("LmZyb250cGFnZUFkdk0="), "#taotaole", "#aafoot.top_box"],
        easyListCookie: ["#AdaCompliance.app-notice", ".text-center.rgpd", ".panel--cookie", ".js-cookies-andromeda", ".elxtr-consent"],
        easyListCzechSlovak: ["#onlajny-stickers", e("I3Jla2xhbW5pLWJveA=="), e("LnJla2xhbWEtbWVnYWJvYXJk"), ".sklik", e("W2lkXj0ic2tsaWtSZWtsYW1hIl0=")],
        easyListDutch: [e("I2FkdmVydGVudGll"), e("I3ZpcEFkbWFya3RCYW5uZXJCbG9jaw=="), ".adstekst", e("YVtocmVmXj0iaHR0cHM6Ly94bHR1YmUubmwvY2xpY2svIl0="), "#semilo-lrectangle"],
        easyListGermany: [e("I0FkX1dpbjJkYXk="), e("I3dlcmJ1bmdzYm94MzAw"), e("YVtocmVmXj0iaHR0cDovL3d3dy5yb3RsaWNodGthcnRlaS5jb20vP3NjPSJd"), e("I3dlcmJ1bmdfd2lkZXNreXNjcmFwZXJfc2NyZWVu"), e("YVtocmVmXj0iaHR0cDovL2xhbmRpbmcucGFya3BsYXR6a2FydGVpLmNvbS8/YWc9Il0=")],
        easyListItaly: [e("LmJveF9hZHZfYW5udW5jaQ=="), ".sb-box-pubbliredazionale", e("YVtocmVmXj0iaHR0cDovL2FmZmlsaWF6aW9uaWFkcy5zbmFpLml0LyJd"), e("YVtocmVmXj0iaHR0cHM6Ly9hZHNlcnZlci5odG1sLml0LyJd"), e("YVtocmVmXj0iaHR0cHM6Ly9hZmZpbGlhemlvbmlhZHMuc25haS5pdC8iXQ==")],
        easyListLithuania: [e("LnJla2xhbW9zX3RhcnBhcw=="), e("LnJla2xhbW9zX251b3JvZG9z"), e("aW1nW2FsdD0iUmVrbGFtaW5pcyBza3lkZWxpcyJd"), e("aW1nW2FsdD0iRGVkaWt1b3RpLmx0IHNlcnZlcmlhaSJd"), e("aW1nW2FsdD0iSG9zdGluZ2FzIFNlcnZlcmlhaS5sdCJd")],
        estonian: [e("QVtocmVmKj0iaHR0cDovL3BheTRyZXN1bHRzMjQuZXUiXQ==")],
        fanboyAnnoyances: ["#feedback-tab", "#taboola-below-article", ".feedburnerFeedBlock", ".widget-feedburner-counter", '[title="Subscribe to our blog"]'],
        fanboyAntiFacebook: [".util-bar-module-firefly-visible"],
        fanboyEnhancedTrackers: [".open.pushModal", "#issuem-leaky-paywall-articles-zero-remaining-nag", "#sovrn_container", 'div[class$="-hide"][zoompage-fontsize][style="display: block;"]', ".BlockNag__Card"],
        fanboySocial: [".td-tags-and-social-wrapper-box", ".twitterContainer", ".youtube-social", 'a[title^="Like us on Facebook"]', 'img[alt^="Share on Digg"]'],
        frellwitSwedish: [e("YVtocmVmKj0iY2FzaW5vcHJvLnNlIl1bdGFyZ2V0PSJfYmxhbmsiXQ=="), e("YVtocmVmKj0iZG9rdG9yLXNlLm9uZWxpbmsubWUiXQ=="), "article.category-samarbete", e("ZGl2LmhvbGlkQWRz"), "ul.adsmodern"],
        greekAdBlock: [e("QVtocmVmKj0iYWRtYW4ub3RlbmV0LmdyL2NsaWNrPyJd"), e("QVtocmVmKj0iaHR0cDovL2F4aWFiYW5uZXJzLmV4b2R1cy5nci8iXQ=="), e("QVtocmVmKj0iaHR0cDovL2ludGVyYWN0aXZlLmZvcnRobmV0LmdyL2NsaWNrPyJd"), "DIV.agores300", "TABLE.advright"],
        hungarian: ["#cemp_doboz", ".optimonk-iframe-container", e("LmFkX19tYWlu"), e("W2NsYXNzKj0iR29vZ2xlQWRzIl0="), "#hirdetesek_box"],
        iDontCareAboutCookies: ['.alert-info[data-block-track*="CookieNotice"]', ".ModuleTemplateCookieIndicator", ".o--cookies--container", ".cookie-msg-info-container", "#cookies-policy-sticky"],
        icelandicAbp: [e("QVtocmVmXj0iL2ZyYW1ld29yay9yZXNvdXJjZXMvZm9ybXMvYWRzLmFzcHgiXQ==")],
        latvian: [e("YVtocmVmPSJodHRwOi8vd3d3LnNhbGlkemluaS5sdi8iXVtzdHlsZT0iZGlzcGxheTogYmxvY2s7IHdpZHRoOiAxMjBweDsgaGVpZ2h0OiA0MHB4OyBvdmVyZmxvdzogaGlkZGVuOyBwb3NpdGlvbjogcmVsYXRpdmU7Il0="), e("YVtocmVmPSJodHRwOi8vd3d3LnNhbGlkemluaS5sdi8iXVtzdHlsZT0iZGlzcGxheTogYmxvY2s7IHdpZHRoOiA4OHB4OyBoZWlnaHQ6IDMxcHg7IG92ZXJmbG93OiBoaWRkZW47IHBvc2l0aW9uOiByZWxhdGl2ZTsiXQ==")],
        listKr: [e("YVtocmVmKj0iLy9hZC5wbGFuYnBsdXMuY28ua3IvIl0="), e("I2xpdmVyZUFkV3JhcHBlcg=="), e("YVtocmVmKj0iLy9hZHYuaW1hZHJlcC5jby5rci8iXQ=="), e("aW5zLmZhc3R2aWV3LWFk"), ".revenue_unit_item.dable"],
        listeAr: [e("LmdlbWluaUxCMUFk"), ".right-and-left-sponsers", e("YVtocmVmKj0iLmFmbGFtLmluZm8iXQ=="), e("YVtocmVmKj0iYm9vcmFxLm9yZyJd"), e("YVtocmVmKj0iZHViaXp6bGUuY29tL2FyLz91dG1fc291cmNlPSJd")],
        listeFr: [e("YVtocmVmXj0iaHR0cDovL3Byb21vLnZhZG9yLmNvbS8iXQ=="), e("I2FkY29udGFpbmVyX3JlY2hlcmNoZQ=="), e("YVtocmVmKj0id2Vib3JhbWEuZnIvZmNnaS1iaW4vIl0="), ".site-pub-interstitiel", 'div[id^="crt-"][data-criteo-id]'],
        officialPolish: ["#ceneo-placeholder-ceneo-12", e("W2hyZWZePSJodHRwczovL2FmZi5zZW5kaHViLnBsLyJd"), e("YVtocmVmXj0iaHR0cDovL2Fkdm1hbmFnZXIudGVjaGZ1bi5wbC9yZWRpcmVjdC8iXQ=="), e("YVtocmVmXj0iaHR0cDovL3d3dy50cml6ZXIucGwvP3V0bV9zb3VyY2UiXQ=="), e("ZGl2I3NrYXBpZWNfYWQ=")],
        ro: [e("YVtocmVmXj0iLy9hZmZ0cmsuYWx0ZXgucm8vQ291bnRlci9DbGljayJd"), 'a[href^="/magazin/"]', e("YVtocmVmXj0iaHR0cHM6Ly9ibGFja2ZyaWRheXNhbGVzLnJvL3Ryay9zaG9wLyJd"), e("YVtocmVmXj0iaHR0cHM6Ly9ldmVudC4ycGVyZm9ybWFudC5jb20vZXZlbnRzL2NsaWNrIl0="), e("YVtocmVmXj0iaHR0cHM6Ly9sLnByb2ZpdHNoYXJlLnJvLyJd")],
        ruAd: [e("YVtocmVmKj0iLy9mZWJyYXJlLnJ1LyJd"), e("YVtocmVmKj0iLy91dGltZy5ydS8iXQ=="), e("YVtocmVmKj0iOi8vY2hpa2lkaWtpLnJ1Il0="), "#pgeldiz", ".yandex-rtb-block"],
        thaiAds: ["a[href*=macau-uta-popup]", e("I2Fkcy1nb29nbGUtbWlkZGxlX3JlY3RhbmdsZS1ncm91cA=="), e("LmFkczMwMHM="), ".bumq", ".img-kosana"],
        webAnnoyancesUltralist: ["#mod-social-share-2", "#social-tools", e("LmN0cGwtZnVsbGJhbm5lcg=="), ".zergnet-recommend", ".yt.btn-link.btn-md.btn"]
    }
}

function Ln(e) {
    var n = e === void 0 ? {} : e,
        t = n.debug;
    return Z(this, void 0, void 0, function() {
        var a, i, o, r, c, s;
        return W(this, function(l) {
            switch (l.label) {
                case 0:
                    return Sn() ? (a = wn(), i = Object.keys(a), o = (s = []).concat.apply(s, i.map(function(u) {
                        return a[u]
                    })), [4, Vn(o)]) : [2, void 0];
                case 1:
                    return r = l.sent(), t && Cn(a, r), c = i.filter(function(u) {
                        var f = a[u],
                            d = x(f.map(function(p) {
                                return r[p]
                            }));
                        return d > f.length * .6
                    }), c.sort(), [2, c]
            }
        })
    })
}

function Sn() {
    return I() || fe()
}

function Vn(e) {
    var n;
    return Z(this, void 0, void 0, function() {
        var t, a, i, o, s, r, c, s;
        return W(this, function(l) {
            switch (l.label) {
                case 0:
                    for (t = document, a = t.createElement("div"), i = new Array(e.length), o = {}, ne(a), s = 0; s < e.length; ++s) r = Pe(e[s]), c = t.createElement("div"), ne(c), c.appendChild(r), a.appendChild(c), i[s] = r;
                    l.label = 1;
                case 1:
                    return t.body ? [3, 3] : [4, Y(50)];
                case 2:
                    return l.sent(), [3, 1];
                case 3:
                    t.body.appendChild(a);
                    try {
                        for (s = 0; s < e.length; ++s) i[s].offsetParent || (o[e[s]] = !0)
                    } finally {
                        (n = a.parentNode) === null || n === void 0 || n.removeChild(a)
                    }
                    return [2, o]
            }
        })
    })
}

function ne(e) {
    e.style.setProperty("display", "block", "important")
}

function Cn(e, n) {
    for (var t = "DOM blockers debug:\n```", a = 0, i = Object.keys(e); a < i.length; a++) {
        var o = i[a];
        t += `
`.concat(o, ":");
        for (var r = 0, c = e[o]; r < c.length; r++) {
            var s = c[r];
            t += `
  `.concat(n[s] ? "🚫" : "➡️", " ").concat(s)
        }
    }
    console.log("".concat(t, "\n```"))
}

function xn() {
    for (var e = 0, n = ["rec2020", "p3", "srgb"]; e < n.length; e++) {
        var t = n[e];
        if (matchMedia("(color-gamut: ".concat(t, ")")).matches) return t
    }
}

function Fn() {
    if (te("inverted")) return !0;
    if (te("none")) return !1
}

function te(e) {
    return matchMedia("(inverted-colors: ".concat(e, ")")).matches
}

function Wn() {
    if (re("active")) return !0;
    if (re("none")) return !1
}

function re(e) {
    return matchMedia("(forced-colors: ".concat(e, ")")).matches
}
var kn = 100;

function Zn() {
    if (matchMedia("(min-monochrome: 0)").matches) {
        for (var e = 0; e <= kn; ++e)
            if (matchMedia("(max-monochrome: ".concat(e, ")")).matches) return e;
        throw new Error("Too high value")
    }
}

function Rn() {
    if (A("no-preference")) return 0;
    if (A("high") || A("more")) return 1;
    if (A("low") || A("less")) return -1;
    if (A("forced")) return 10
}

function A(e) {
    return matchMedia("(prefers-contrast: ".concat(e, ")")).matches
}

function Xn() {
    if (ae("reduce")) return !0;
    if (ae("no-preference")) return !1
}

function ae(e) {
    return matchMedia("(prefers-reduced-motion: ".concat(e, ")")).matches
}

function Mn() {
    if (ie("high")) return !0;
    if (ie("standard")) return !1
}

function ie(e) {
    return matchMedia("(dynamic-range: ".concat(e, ")")).matches
}
var m = Math,
    L = function() {
        return 0
    };

function An() {
    var e = m.acos || L,
        n = m.acosh || L,
        t = m.asin || L,
        a = m.asinh || L,
        i = m.atanh || L,
        o = m.atan || L,
        r = m.sin || L,
        c = m.sinh || L,
        s = m.cos || L,
        l = m.cosh || L,
        u = m.tan || L,
        f = m.tanh || L,
        d = m.exp || L,
        p = m.expm1 || L,
        v = m.log1p || L,
        g = function(b) {
            return m.pow(m.PI, b)
        },
        y = function(b) {
            return m.log(b + m.sqrt(b * b - 1))
        },
        h = function(b) {
            return m.log(b + m.sqrt(b * b + 1))
        },
        F = function(b) {
            return m.log((1 + b) / (1 - b)) / 2
        },
        G = function(b) {
            return m.exp(b) - 1 / m.exp(b) / 2
        },
        j = function(b) {
            return (m.exp(b) + 1 / m.exp(b)) / 2
        },
        N = function(b) {
            return m.exp(b) - 1
        },
        he = function(b) {
            return (m.exp(2 * b) - 1) / (m.exp(2 * b) + 1)
        },
        pe = function(b) {
            return m.log(1 + b)
        };
    return {
        acos: e(.12312423423423424),
        acosh: n(1e308),
        acoshPf: y(1e154),
        asin: t(.12312423423423424),
        asinh: a(1),
        asinhPf: h(1),
        atanh: i(.5),
        atanhPf: F(.5),
        atan: o(.5),
        sin: r(-1e300),
        sinh: c(1),
        sinhPf: G(1),
        cos: s(10.000000000123),
        cosh: l(1),
        coshPf: j(1),
        tan: u(-1e300),
        tanh: f(1),
        tanhPf: he(1),
        exp: d(1),
        expm1: p(1),
        expm1Pf: N(1),
        log1p: v(10),
        log1pPf: pe(10),
        powPI: g(-100)
    }
}
var Yn = "mmMwWLliI0fiflO&1",
    z = {
        default: [],
        apple: [{
            font: "-apple-system-body"
        }],
        serif: [{
            fontFamily: "serif"
        }],
        sans: [{
            fontFamily: "sans-serif"
        }],
        mono: [{
            fontFamily: "monospace"
        }],
        min: [{
            fontSize: "1px"
        }],
        system: [{
            fontFamily: "system-ui"
        }]
    };

function Gn() {
    return In(function(e, n) {
        for (var t = {}, a = {}, i = 0, o = Object.keys(z); i < o.length; i++) {
            var r = o[i],
                c = z[r],
                s = c[0],
                l = s === void 0 ? {} : s,
                u = c[1],
                f = u === void 0 ? Yn : u,
                d = e.createElement("span");
            d.textContent = f, d.style.whiteSpace = "nowrap";
            for (var p = 0, v = Object.keys(l); p < v.length; p++) {
                var g = v[p],
                    y = l[g];
                y !== void 0 && (d.style[g] = y)
            }
            t[r] = d, n.appendChild(e.createElement("br")), n.appendChild(d)
        }
        for (var h = 0, F = Object.keys(z); h < F.length; h++) {
            var r = F[h];
            a[r] = t[r].getBoundingClientRect().width
        }
        return a
    })
}

function In(e, n) {
    return n === void 0 && (n = 4e3), de(function(t, a) {
        var i = a.document,
            o = i.body,
            r = o.style;
        r.width = "".concat(n, "px"), r.webkitTextSizeAdjust = r.textSizeAdjust = "none", O() ? o.style.zoom = "".concat(1 / a.devicePixelRatio) : I() && (o.style.zoom = "reset");
        var c = i.createElement("div");
        return c.textContent = oe([], Array(n / 20 << 0), !0).map(function() {
            return "word"
        }).join(" "), o.appendChild(c), e(i, o)
    }, '<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">')
}

function jn() {
    var e, n = document.createElement("canvas"),
        t = (e = n.getContext("webgl")) !== null && e !== void 0 ? e : n.getContext("experimental-webgl");
    if (t && "getExtension" in t) {
        var a = t.getExtension("WEBGL_debug_renderer_info");
        if (a) return {
            vendor: (t.getParameter(a.UNMASKED_VENDOR_WEBGL) || "").toString(),
            renderer: (t.getParameter(a.UNMASKED_RENDERER_WEBGL) || "").toString()
        }
    }
}

function Pn() {
    return navigator.pdfViewerEnabled
}

function Jn() {
    var e = new Float32Array(1),
        n = new Uint8Array(e.buffer);
    return e[0] = 1 / 0, e[0] = e[0] - e[0], n[3]
}
var Nn = {
    fonts: Te,
    domBlockers: Ln,
    fontPreferences: Gn,
    audio: Ye,
    screenFrame: cn,
    osCpu: qe,
    languages: _e,
    colorDepth: $e,
    deviceMemory: en,
    screenResolution: nn,
    hardwareConcurrency: un,
    timezone: sn,
    sessionStorage: fn,
    localStorage: dn,
    indexedDB: mn,
    openDatabase: vn,
    cpuClass: hn,
    platform: pn,
    plugins: ze,
    canvas: De,
    touchSupport: Ke,
    vendor: gn,
    vendorFlavors: bn,
    cookiesEnabled: yn,
    colorGamut: xn,
    invertedColors: Fn,
    forcedColors: Wn,
    monochrome: Zn,
    contrast: Rn,
    reducedMotion: Xn,
    hdr: Mn,
    math: An,
    videoCard: jn,
    pdfViewerEnabled: Pn,
    architecture: Jn
};

function Hn(e) {
    return Fe(Nn, e, [])
}
var Tn = "$ if upgrade to Pro: https://fpjs.dev/pro";

function zn(e) {
    var n = Dn(e),
        t = Bn(n);
    return {
        score: n,
        comment: Tn.replace(/\$/g, "".concat(t))
    }
}

function Dn(e) {
    if (fe()) return .4;
    if (I()) return Q() ? .5 : .3;
    var n = e.platform.value || "";
    return /^Win/.test(n) ? .6 : /^Mac/.test(n) ? .5 : .7
}

function Bn(e) {
    return se(.99 + .01 * e, 1e-4)
}

function En(e) {
    for (var n = "", t = 0, a = Object.keys(e).sort(); t < a.length; t++) {
        var i = a[t],
            o = e[i],
            r = o.error ? "error" : JSON.stringify(o.value);
        n += "".concat(n ? "|" : "").concat(i.replace(/([:|\\])/g, "\\$1"), ":").concat(r)
    }
    return n
}

function me(e) {
    return JSON.stringify(e, function(n, t) {
        return t instanceof Error ? we(t) : t
    }, 2)
}

function ve(e) {
    return ye(En(e))
}

function On(e) {
    var n, t = zn(e);
    return {
        get visitorId() {
            return n === void 0 && (n = ve(this.components)), n
        },
        set visitorId(a) {
            n = a
        },
        confidence: t,
        components: e,
        version: ce
    }
}

function Qn(e) {
    return e === void 0 && (e = 50), be(e, e * 2)
}

function Un(e, n) {
    var t = Date.now();
    return {
        get: function(a) {
            return Z(this, void 0, void 0, function() {
                var i, o, r;
                return W(this, function(c) {
                    switch (c.label) {
                        case 0:
                            return i = Date.now(), [4, e()];
                        case 1:
                            return o = c.sent(), r = On(o), (n || a ? .debug) && console.log("Copy the text below to get the debug data:\n\n```\nversion: ".concat(r.version, `
userAgent: `).concat(navigator.userAgent, `
timeBetweenLoadAndGet: `).concat(i - t, `
visitorId: `).concat(r.visitorId, `
components: `).concat(me(o), "\n```")), [2, r]
                    }
                })
            })
        }
    }
}

function Kn() {
    if (!(window.__fpjs_d_m || Math.random() >= .001)) try {
        var e = new XMLHttpRequest;
        e.open("get", "https://m1.openfpcdn.io/fingerprintjs/v".concat(ce, "/npm-monitoring"), !0), e.send()
    } catch (n) {
        console.error(n)
    }
}

function qn(e) {
    var n = e === void 0 ? {} : e,
        t = n.delayFallback,
        a = n.debug,
        i = n.monitoring,
        o = i === void 0 ? !0 : i;
    return Z(this, void 0, void 0, function() {
        var r;
        return W(this, function(c) {
            switch (c.label) {
                case 0:
                    return o && Kn(), [4, Qn(t)];
                case 1:
                    return c.sent(), r = Hn({
                        debug: a
                    }), [2, Un(r, a)]
            }
        })
    })
}
var $n = {
    load: qn,
    hashComponents: ve,
    componentsToDebugString: me
};
export {
    $n as i
};