import {
    i as zt
} from "./vue-demi.71ba0ef2.js";
import {
    d as lt,
    h as _t
} from "./@vue.16908cbf.js";
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var W = function() {
    return W = Object.assign || function(o) {
        for (var n, t = 1, i = arguments.length; t < i; t++)
            for (var e in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, e) && (o[e] = n[e]);
        return o
    }, W.apply(this, arguments)
};
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var ct = function(o, n) {
    return ct = Object.setPrototypeOf || {
        __proto__: []
    }
    instanceof Array && function(t, i) {
        t.__proto__ = i
    } || function(t, i) {
        for (var e in i) Object.prototype.hasOwnProperty.call(i, e) && (t[e] = i[e])
    }, ct(o, n)
};

function ut(o, n) {
    if (typeof n != "function" && n !== null) throw new TypeError("Class extends value " + String(n) + " is not a constructor or null");

    function t() {
        this.constructor = o
    }
    ct(o, n), o.prototype = n === null ? Object.create(n) : (t.prototype = n.prototype, new t)
}
var R = function() {
    return R = Object.assign || function(o) {
        for (var n, t = 1, i = arguments.length; t < i; t++)
            for (var e in n = arguments[t]) Object.prototype.hasOwnProperty.call(n, e) && (o[e] = n[e]);
        return o
    }, R.apply(this, arguments)
};

function D(o, n, t, i) {
    return new(t || (t = Promise))(function(e, r) {
        function c(a) {
            try {
                f(i.next(a))
            } catch (h) {
                r(h)
            }
        }

        function s(a) {
            try {
                f(i.throw(a))
            } catch (h) {
                r(h)
            }
        }

        function f(a) {
            var h;
            a.done ? e(a.value) : (h = a.value, h instanceof t ? h : new t(function(l) {
                l(h)
            })).then(c, s)
        }
        f((i = i.apply(o, n || [])).next())
    })
}

function H(o, n) {
    var t, i, e, r, c = {
        label: 0,
        sent: function() {
            if (1 & e[0]) throw e[1];
            return e[1]
        },
        trys: [],
        ops: []
    };
    return r = {
        next: s(0),
        throw: s(1),
        return: s(2)
    }, typeof Symbol == "function" && (r[Symbol.iterator] = function() {
        return this
    }), r;

    function s(f) {
        return function(a) {
            return function(h) {
                if (t) throw new TypeError("Generator is already executing.");
                for (; c;) try {
                    if (t = 1, i && (e = 2 & h[0] ? i.return : h[0] ? i.throw || ((e = i.return) && e.call(i), 0) : i.next) && !(e = e.call(i, h[1])).done) return e;
                    switch (i = 0, e && (h = [2 & h[0], e.value]), h[0]) {
                        case 0:
                        case 1:
                            e = h;
                            break;
                        case 4:
                            return c.label++, {
                                value: h[1],
                                done: !1
                            };
                        case 5:
                            c.label++, i = h[1], h = [0];
                            continue;
                        case 7:
                            h = c.ops.pop(), c.trys.pop();
                            continue;
                        default:
                            if (!((e = (e = c.trys).length > 0 && e[e.length - 1]) || h[0] !== 6 && h[0] !== 2)) {
                                c = 0;
                                continue
                            }
                            if (h[0] === 3 && (!e || h[1] > e[0] && h[1] < e[3])) {
                                c.label = h[1];
                                break
                            }
                            if (h[0] === 6 && c.label < e[1]) {
                                c.label = e[1], e = h;
                                break
                            }
                            if (e && c.label < e[2]) {
                                c.label = e[2], c.ops.push(h);
                                break
                            }
                            e[2] && c.ops.pop(), c.trys.pop();
                            continue
                    }
                    h = n.call(o, c)
                } catch (l) {
                    h = [6, l], i = 0
                } finally {
                    t = e = 0
                }
                if (5 & h[0]) throw h[1];
                return {
                    value: h[0] ? h[1] : void 0,
                    done: !0
                }
            }([f, a])
        }
    }
}

function q(o, n) {
    for (var t = 0, i = n.length, e = o.length; t < i; t++, e++) o[e] = n[t];
    return o
}
Array.prototype.includes || Object.defineProperty(Array.prototype, "includes", {
    value: function(o, n) {
        if (this == null) throw new TypeError('"this" is null or not defined');
        var t = Object(this),
            i = t.length >>> 0;
        if (i === 0) return !1;
        for (var e, r, c = 0 | n, s = Math.max(c >= 0 ? c : i - Math.abs(c), 0); s < i;) {
            if ((e = t[s]) === (r = o) || typeof e == "number" && typeof r == "number" && isNaN(e) && isNaN(r)) return !0;
            s++
        }
        return !1
    }
}), String.prototype.includes || (String.prototype.includes = function(o, n) {
    return typeof n != "number" && (n = 0), !(n + o.length > this.length) && this.indexOf(o, n) !== -1
}), Array.prototype.find || Object.defineProperty(Array.prototype, "find", {
    value: function(o) {
        if (this == null) throw new TypeError('"this" is null or not defined');
        var n = Object(this),
            t = n.length >>> 0;
        if (typeof o != "function") throw new TypeError("predicate must be a function");
        for (var i = arguments[1], e = 0; e < t;) {
            var r = n[e];
            if (o.call(i, r, e, n)) return r;
            e++
        }
    }
});
var K = function(o) {
        for (var n = [], t = 1; t < arguments.length; t++) n[t - 1] = arguments[t];
        return n.some(function(i) {
            return Object.prototype.toString.call(o).slice(8, -1).toLowerCase() === i
        })
    },
    U = function(o, n) {
        return Object.prototype.hasOwnProperty.call(o, n)
    },
    ft = function(o) {
        return [].filter.call(o, function(n) {
            return n !== `
`
        }).join("")
    },
    M = function(o) {
        if (typeof o != "string" || (o = o.toLocaleLowerCase().trim()) === "transparent") return !1;
        var n;
        return !(/^rgba/.test(o) && ((n = /([^\s,]+)\)$/.exec(o)) === null ? 0 : typeof n == "object" ? NaN : typeof n == "number" ? n : typeof n == "string" ? n[n.length - 1] === "%" ? Number(n.slice(0, -1)) / 100 : Number(n) : NaN) === 0)
    },
    xt = function(o, n) {
        var t, i = ((t = o.padding) === null || t === void 0 ? void 0 : t.split(" ").map(function(h) {
                return n(h)
            })) || [0],
            e = 0,
            r = 0,
            c = 0,
            s = 0;
        switch (i.length) {
            case 1:
                e = r = c = s = i[0];
                break;
            case 2:
                e = r = i[0], c = s = i[1];
                break;
            case 3:
                e = i[0], c = s = i[1], r = i[2];
                break;
            default:
                e = i[0], r = i[1], c = i[2], s = i[3]
        }
        var f = {
            paddingTop: e,
            paddingBottom: r,
            paddingLeft: c,
            paddingRight: s
        };
        for (var a in f) f[a] = U(o, a) && K(o[a], "string", "number") ? n(o[a]) : f[a];
        return [e, r, c, s]
    },
    It = function(o) {
        var n = [],
            t = o.map(function(e) {
                return Number(e)
            }).reduce(function(e, r) {
                if (r > 0) {
                    var c = e + r;
                    return n.push(c), c
                }
                return n.push(NaN), e
            }, 0),
            i = Math.random() * t;
        return n.findIndex(function(e) {
            return i <= e
        })
    },
    dt = function(o, n, t, i) {
        i === void 0 && (i = 1 / 0), i <= 0 && (i = 1 / 0);
        for (var e = "", r = [], c = o.measureText("...").width, s = 0; s < n.length; s++) {
            e += n[s];
            var f = o.measureText(e).width,
                a = t(r);
            if (i === r.length + 1 && (f += c), a < 0) return r;
            if (f > a && (r.push(e.slice(0, -1)), e = n[s]), i === r.length) return r[r.length - 1] += "...", r
        }
        return e && r.push(e), r.length || r.push(n), r
    },
    B = function() {
        function o() {
            this.subs = []
        }
        return o.prototype.addSub = function(n) {
            this.subs.includes(n) || this.subs.push(n)
        }, o.prototype.notify = function() {
            this.subs.forEach(function(n) {
                n.update()
            })
        }, o
    }(),
    Pt = "__proto__" in {};

function St(o, n, t, i) {
    Object.defineProperty(o, n, {
        value: t,
        enumerable: !!i,
        writable: !0,
        configurable: !0
    })
}
var $t = Array.prototype,
    nt = Object.create($t);
["push", "pop", "shift", "unshift", "sort", "splice", "reverse"].forEach(function(o) {
    nt[o] = function() {
        for (var n = [], t = 0; t < arguments.length; t++) n[t] = arguments[t];
        var i = $t[o].apply(this, n),
            e = this.__luckyOb__;
        return ["push", "unshift", "splice"].includes(o) && e.walk(this), e.dep.notify(), i
    }
});
var Ft = function() {
    function o(n) {
        this.dep = new B, St(n, "__luckyOb__", this), Array.isArray(n) && (Pt ? n.__proto__ = nt : Object.getOwnPropertyNames(nt).forEach(function(t) {
            St(n, t, nt[t])
        })), this.walk(n)
    }
    return o.prototype.walk = function(n) {
        Object.keys(n).forEach(function(t) {
            At(n, t, n[t])
        })
    }, o
}();

function Ct(o) {
    if (o && typeof o == "object") return "__luckyOb__" in o ? o.__luckyOb__ : new Ft(o)
}

function At(o, n, t) {
    var i = new B,
        e = Object.getOwnPropertyDescriptor(o, n);
    if (!e || e.configurable !== !1) {
        var r = e && e.get,
            c = e && e.set;
        r && !c || arguments.length !== 2 || (t = o[n]);
        var s = Ct(t);
        Object.defineProperty(o, n, {
            get: function() {
                var f = r ? r.call(o) : t;
                return B.target && (i.addSub(B.target), s && s.dep.addSub(B.target)), f
            },
            set: function(f) {
                f !== t && (t = f, r && !c || (c ? c.call(o, f) : t = f, s = Ct(f), i.notify()))
            }
        })
    }
}
var Rt = 0,
    Dt = function() {
        function o(n, t, i, e) {
            e === void 0 && (e = {}), this.id = Rt++, this.$lucky = n, this.expr = t, this.deep = !!e.deep, this.getter = typeof t == "function" ? t : function(r) {
                r += ".";
                for (var c = [], s = "", f = 0; f < r.length; f++) {
                    var a = r[f];
                    if (/\[|\./.test(a)) c.push(s), s = "";
                    else {
                        if (/\W/.test(a)) continue;
                        s += a
                    }
                }
                return function(h) {
                    return c.reduce(function(l, u) {
                        return l[u]
                    }, h)
                }
            }(t), this.cb = i, this.value = this.get()
        }
        return o.prototype.get = function() {
            B.target = this;
            var n = this.getter.call(this.$lucky, this.$lucky);
            return this.deep && function(t) {
                var i = function(e) {
                    K(e, "array", "object") && Object.keys(e).forEach(function(r) {
                        var c = e[r];
                        i(c)
                    })
                };
                i(t)
            }(n), B.target = null, n
        }, o.prototype.update = function() {
            var n = this.get(),
                t = this.value;
            this.value = n, this.cb.call(this.$lucky, n, t)
        }, o
    }(),
    pt = function() {
        function o(n, t) {
            var i = this;
            this.version = "1.7.21", this.htmlFontSize = 16, this.rAF = function() {}, this.boxWidth = 0, this.boxHeight = 0, typeof n == "string" ? n = {
                el: n
            } : n.nodeType === 1 && (n = {
                el: "",
                divElement: n
            }), n = n, this.config = n, this.data = t, n.flag || (n.flag = "WEB"), n.el && (n.divElement = document.querySelector(n.el)), n.divElement && (n.canvasElement = document.createElement("canvas"), n.divElement.appendChild(n.canvasElement)), n.canvasElement && (n.ctx = n.canvasElement.getContext("2d"), n.canvasElement.setAttribute("package", "lucky-canvas@1.7.21"), n.canvasElement.addEventListener("click", function(e) {
                return i.handleClick(e)
            })), this.ctx = n.ctx, this.initWindowFunction(), this.config.ctx || console.error("无法获取到 CanvasContext2D"), window && typeof window.addEventListener == "function" && window.addEventListener("resize", function(e, r) {
                r === void 0 && (r = 300);
                var c = null;
                return function() {
                    for (var s = this, f = [], a = 0; a < arguments.length; a++) f[a] = arguments[a];
                    c || (c = setTimeout(function() {
                        e.apply(s, f), clearTimeout(c), c = null
                    }, r))
                }
            }(function() {
                return i.resize()
            }, 300)), window && typeof window.MutationObserver == "function" && new window.MutationObserver(function() {
                i.resize()
            }).observe(document.documentElement, {
                attributes: !0
            })
        }
        return o.prototype.resize = function() {
            var n, t;
            (t = (n = this.config).beforeResize) === null || t === void 0 || t.call(n), this.setHTMLFontSize(), this.setDpr(), this.resetWidthAndHeight(), this.zoomCanvas()
        }, o.prototype.initLucky = function() {
            if (this.resize(), !this.boxWidth || !this.boxHeight) return console.error("无法获取到宽度或高度")
        }, o.prototype.handleClick = function(n) {}, o.prototype.setHTMLFontSize = function() {
            window && (this.htmlFontSize = +window.getComputedStyle(document.documentElement).fontSize.slice(0, -2))
        }, o.prototype.clearCanvas = function() {
            var n = [this.boxWidth, this.boxHeight],
                t = n[0],
                i = n[1];
            this.ctx.clearRect(-t, -i, 2 * t, 2 * i)
        }, o.prototype.setDpr = function() {
            var n = this.config;
            n.dpr || (window ? window.dpr = n.dpr = window.devicePixelRatio || 1 : n.dpr || console.error(n, "未传入 dpr 可能会导致绘制异常"))
        }, o.prototype.resetWidthAndHeight = function() {
            var n = this.config,
                t = this.data,
                i = 0,
                e = 0;
            n.divElement && (i = n.divElement.offsetWidth, e = n.divElement.offsetHeight), this.boxWidth = this.getLength(t.width || n.width) || i, this.boxHeight = this.getLength(t.height || n.height) || e, n.divElement && (n.divElement.style.overflow = "hidden", n.divElement.style.width = this.boxWidth + "px", n.divElement.style.height = this.boxHeight + "px")
        }, o.prototype.zoomCanvas = function() {
            var n = this.config,
                t = this.ctx,
                i = n.canvasElement,
                e = n.dpr,
                r = [this.boxWidth * e, this.boxHeight * e],
                c = r[0],
                s = r[1];
            i && (i.width = c, i.height = s, i.style.width = c + "px", i.style.height = s + "px", i.style["transform-origin"] = "left top", i.style.transform = "scale(" + 1 / e + ")", t.scale(e, e))
        }, o.prototype.initWindowFunction = function() {
            var n = this.config;
            if (window) return this.rAF = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || function(i) {
                window.setTimeout(i, 1e3 / 60)
            }, n.setTimeout = window.setTimeout, n.setInterval = window.setInterval, n.clearTimeout = window.clearTimeout, void(n.clearInterval = window.clearInterval);
            if (n.rAF) this.rAF = n.rAF;
            else if (n.setTimeout) {
                var t = n.setTimeout;
                this.rAF = function(i) {
                    return t(i, 16.7)
                }
            } else this.rAF = function(i) {
                return setTimeout(i, 16.7)
            }
        }, o.prototype.loadImg = function(n, t, i) {
            var e = this;
            return i === void 0 && (i = "$resolve"), new Promise(function(r, c) {
                if (n || c("=> '" + t.src + "' 不能为空或不合法"), e.config.flag !== "WEB") return t[i] = r, void(t.$reject = c);
                var s = new Image;
                s.onload = function() {
                    return r(s)
                }, s.onerror = function() {
                    return c("=> '" + t.src + "' 图片加载失败")
                }, s.src = n
            })
        }, o.prototype.drawImage = function(n, t) {
            for (var i, e = [], r = 2; r < arguments.length; r++) e[r - 2] = arguments[r];
            var c = this.config,
                s = c.flag,
                f = c.dpr;
            if (["WEB", "MP-WX"].includes(s)) i = t;
            else {
                if (!["UNI-H5", "UNI-MP", "TARO-H5", "TARO-MP"].includes(s)) return console.error("意料之外的 flag, 该平台尚未兼容!");
                i = t.path
            }
            if (!i.canvas) return e.length === 8 && (e = e.map(function(l, u) {
                return u < 4 ? l * f : l
            })), n.drawImage.apply(n, q([i], e));
            var a = i.canvas.getContext("2d");
            e = e.map(function(l) {
                return l * f
            });
            var h = a.getImageData.apply(a, e.slice(0, 4));
            n.putImageData.apply(n, q([h], e.slice(4, 6)))
        }, o.prototype.computedWidthAndHeight = function(n, t, i, e) {
            if (!t.width && !t.height) return [n.width, n.height];
            if (t.width && !t.height) {
                var r = this.getLength(t.width, i);
                return [r, n.height * (r / n.width)]
            }
            if (!t.width && t.height) {
                var c = this.getLength(t.height, e);
                return [n.width * (c / n.height), c]
            }
            return [this.getLength(t.width, i), this.getLength(t.height, e)]
        }, o.prototype.changeUnits = function(n, t) {
            var i = this;
            t === void 0 && (t = 1);
            var e = this.config;
            return Number(n.replace(/^([-]*[0-9.]*)([a-z%]*)$/, function(r, c, s) {
                var f = {
                    "%": function(h) {
                        return h * (t / 100)
                    },
                    px: function(h) {
                        return 1 * h
                    },
                    rem: function(h) {
                        return h * i.htmlFontSize
                    },
                    vw: function(h) {
                        return h / 100 * window.innerWidth
                    }
                }[s];
                if (f) return f(c);
                var a = e.handleCssUnit || e.unitFunc;
                return a ? a(c, s) : c
            }))
        }, o.prototype.getLength = function(n, t) {
            return K(n, "number") ? n : K(n, "string") ? this.changeUnits(n, t) : 0
        }, o.prototype.getOffsetX = function(n, t) {
            return t === void 0 && (t = 0), (t - n) / 2
        }, o.prototype.getOffscreenCanvas = function(n, t) {
            if (!U(this, "_offscreenCanvas") && (window && window.document && this.config.flag === "WEB" ? this._offscreenCanvas = document.createElement("canvas") : this._offscreenCanvas = this.config.offscreenCanvas, !this._offscreenCanvas)) return console.error("离屏 Canvas 无法渲染!");
            var i = this.config.dpr,
                e = this._offscreenCanvas;
            e.width = (n || 300) * i, e.height = (t || 150) * i;
            var r = e.getContext("2d");
            return r.clearRect(0, 0, n, t), r.scale(i, i), r.dpr = i, {
                _offscreenCanvas: e,
                _ctx: r
            }
        }, o.prototype.$set = function(n, t, i) {
            n && typeof n == "object" && At(n, t, i)
        }, o.prototype.$computed = function(n, t, i) {
            var e = this;
            Object.defineProperty(n, t, {
                get: function() {
                    return i.call(e)
                }
            })
        }, o.prototype.$watch = function(n, t, i) {
            i === void 0 && (i = {}), typeof t == "object" && (t = (i = t).handler);
            var e = new Dt(this, n, t, i);
            return i.immediate && t.call(this, e.value),
                function() {}
        }, o.version = "1.7.21", o
    }(),
    j = function(o) {
        return Math.PI / 180 * o
    },
    rt = function(o) {
        for (var n = [], t = 1; t < arguments.length; t++) n[t - 1] = arguments[t];
        var i = n[0],
            e = n[1],
            r = n[2],
            c = n[3],
            s = n[4],
            f = Math.min(r, c),
            a = Math.PI;
        s > f / 2 && (s = f / 2), o.beginPath(), o.moveTo(i + s, e), o.lineTo(i + s, e), o.lineTo(i + r - s, e), o.arc(i + r - s, e + s, s, -a / 2, 0), o.lineTo(i + r, e + c - s), o.arc(i + r - s, e + c - s, s, 0, a / 2), o.lineTo(i + s, e + c), o.arc(i + s, e + c - s, s, a / 2, a), o.lineTo(i, e + s), o.arc(i + s, e + s, s, a, -a / 2), o.closePath()
    },
    gt = function(o, n, t, i) {
        return o >= i && (o = i), t * (o /= i) * o + n
    },
    Y = function(o, n, t, i) {
        return o >= i && (o = i), -t * (o /= i) * (o - 2) + n
    },
    Ht = function(o) {
        function n(t, i) {
            var e, r = o.call(this, t, {
                width: i.width,
                height: i.height
            }) || this;
            return r.blocks = [], r.prizes = [], r.buttons = [], r.defaultConfig = {}, r.defaultStyle = {}, r._defaultConfig = {}, r._defaultStyle = {}, r.Radius = 0, r.prizeRadius = 0, r.prizeDeg = 0, r.prizeAng = 0, r.rotateDeg = 0, r.maxBtnRadius = 0, r.startTime = 0, r.endTime = 0, r.stopDeg = 0, r.endDeg = 0, r.FPS = 16.6, r.step = 0, r.ImageCache = new Map, r.initData(i), r.initWatch(), r.initComputed(), (e = t.beforeCreate) === null || e === void 0 || e.call(r), r.init(), r
        }
        return ut(n, o), n.prototype.resize = function() {
            var t, i;
            o.prototype.resize.call(this), this.Radius = Math.min(this.boxWidth, this.boxHeight) / 2, this.ctx.translate(this.Radius, this.Radius), this.draw(), (i = (t = this.config).afterResize) === null || i === void 0 || i.call(t)
        }, n.prototype.initLucky = function() {
            this.Radius = 0, this.prizeRadius = 0, this.prizeDeg = 0, this.prizeAng = 0, this.rotateDeg = 0, this.maxBtnRadius = 0, this.startTime = 0, this.endTime = 0, this.stopDeg = 0, this.endDeg = 0, this.FPS = 16.6, this.prizeFlag = -1, this.step = 0, o.prototype.initLucky.call(this)
        }, n.prototype.initData = function(t) {
            this.$set(this, "width", t.width || "300px"), this.$set(this, "height", t.height || "300px"), this.$set(this, "blocks", t.blocks || []), this.$set(this, "prizes", t.prizes || []), this.$set(this, "buttons", t.buttons || []), this.$set(this, "defaultConfig", t.defaultConfig || {}), this.$set(this, "defaultStyle", t.defaultStyle || {}), this.$set(this, "startCallback", t.start), this.$set(this, "endCallback", t.end)
        }, n.prototype.initComputed = function() {
            var t = this;
            this.$computed(this, "_defaultConfig", function() {
                return R({
                    gutter: "0px",
                    offsetDegree: 0,
                    speed: 20,
                    speedFunction: "quad",
                    accelerationTime: 2500,
                    decelerationTime: 2500,
                    stopRange: 0
                }, t.defaultConfig)
            }), this.$computed(this, "_defaultStyle", function() {
                return R({
                    fontSize: "18px",
                    fontColor: "#000",
                    fontStyle: "sans-serif",
                    fontWeight: "400",
                    background: "rgba(0,0,0,0)",
                    wordWrap: !0,
                    lengthLimit: "90%"
                }, t.defaultStyle)
            })
        }, n.prototype.initWatch = function() {
            var t = this;
            this.$watch("width", function(i) {
                t.data.width = i, t.resize()
            }), this.$watch("height", function(i) {
                t.data.height = i, t.resize()
            }), this.$watch("blocks", function(i) {
                t.initImageCache()
            }, {
                deep: !0
            }), this.$watch("prizes", function(i) {
                t.initImageCache()
            }, {
                deep: !0
            }), this.$watch("buttons", function(i) {
                t.initImageCache()
            }, {
                deep: !0
            }), this.$watch("defaultConfig", function() {
                return t.draw()
            }, {
                deep: !0
            }), this.$watch("defaultStyle", function() {
                return t.draw()
            }, {
                deep: !0
            }), this.$watch("startCallback", function() {
                return t.init()
            }), this.$watch("endCallback", function() {
                return t.init()
            })
        }, n.prototype.init = function() {
            var t, i;
            return D(this, void 0, void 0, function() {
                var e;
                return H(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return this.initLucky(), e = this.config, (t = e.beforeInit) === null || t === void 0 || t.call(this), this.draw(), this.draw(), [4, this.initImageCache()];
                        case 1:
                            return r.sent(), (i = e.afterInit) === null || i === void 0 || i.call(this), [2]
                    }
                })
            })
        }, n.prototype.initImageCache = function() {
            var t = this;
            return new Promise(function(i) {
                var e = {
                    blocks: t.blocks.map(function(r) {
                        return r.imgs
                    }),
                    prizes: t.prizes.map(function(r) {
                        return r.imgs
                    }),
                    buttons: t.buttons.map(function(r) {
                        return r.imgs
                    })
                };
                Object.keys(e).forEach(function(r) {
                    var c = e[r],
                        s = [];
                    c && c.forEach(function(f, a) {
                        f && f.forEach(function(h, l) {
                            s.push(t.loadAndCacheImg(r, a, l))
                        })
                    }), Promise.all(s).then(function() {
                        t.draw(), i()
                    })
                })
            })
        }, n.prototype.handleClick = function(t) {
            var i, e = this.ctx;
            e.beginPath(), e.arc(0, 0, this.maxBtnRadius, 0, 2 * Math.PI, !1), e.isPointInPath(t.offsetX, t.offsetY) && this.step === 0 && ((i = this.startCallback) === null || i === void 0 || i.call(this, t))
        }, n.prototype.loadAndCacheImg = function(t, i, e) {
            return D(this, void 0, void 0, function() {
                var r = this;
                return H(this, function(c) {
                    return [2, new Promise(function(s, f) {
                        var a = r[t][i];
                        if (a && a.imgs) {
                            var h = a.imgs[e];
                            h && r.loadImg(h.src, h).then(function(l) {
                                return D(r, void 0, void 0, function() {
                                    return H(this, function(u) {
                                        switch (u.label) {
                                            case 0:
                                                return typeof h.formatter != "function" ? [3, 2] : [4, Promise.resolve(h.formatter.call(this, l))];
                                            case 1:
                                                l = u.sent(), u.label = 2;
                                            case 2:
                                                return this.ImageCache.set(h.src, l), s(), [2]
                                        }
                                    })
                                })
                            }).catch(function(l) {
                                console.error(t + "[" + i + "].imgs[" + e + "] " + l), f()
                            })
                        }
                    })]
                })
            })
        }, n.prototype.drawBlock = function(t, i, e) {
            var r = this,
                c = this.ctx;
            M(i.background) && (c.beginPath(), c.fillStyle = i.background, c.arc(0, 0, t, 0, 2 * Math.PI, !1), c.fill()), i.imgs && i.imgs.forEach(function(s, f) {
                var a = r.ImageCache.get(s.src);
                if (a) {
                    var h = r.computedWidthAndHeight(a, s, 2 * t, 2 * t),
                        l = h[0],
                        u = h[1],
                        v = [r.getOffsetX(l) + r.getLength(s.left, 2 * t), r.getLength(s.top, 2 * t) - t],
                        g = v[0],
                        d = v[1];
                    c.save(), s.rotate && c.rotate(j(r.rotateDeg)), r.drawImage(c, a, g, d, l, u), c.restore()
                }
            })
        }, n.prototype.draw = function() {
            var t, i, e = this,
                r = this,
                c = r.config,
                s = r.ctx,
                f = r._defaultConfig,
                a = r._defaultStyle;
            (t = c.beforeDraw) === null || t === void 0 || t.call(this, s), s.clearRect(-this.Radius, -this.Radius, 2 * this.Radius, 2 * this.Radius), this.prizeRadius = this.blocks.reduce(function(g, d, p) {
                return e.drawBlock(g, d, p), g - e.getLength(d.padding && d.padding.split(" ")[0])
            }, this.Radius), this.prizeDeg = 360 / this.prizes.length, this.prizeAng = j(this.prizeDeg);
            var h = this.prizeRadius * Math.sin(this.prizeAng / 2) * 2,
                l = j(this.rotateDeg - 90 + this.prizeDeg / 2 + f.offsetDegree),
                u = function(g, d) {
                    return e.getOffsetX(s.measureText(d).width) + e.getLength(g.left, h)
                },
                v = function(g, d, p) {
                    var m = g.lineHeight || a.lineHeight || g.fontSize || a.fontSize;
                    return e.getLength(g.top, d) + (p + 1) * e.getLength(m)
                };
            s.save(), this.prizes.forEach(function(g, d) {
                var p = l + d * e.prizeAng,
                    m = e.prizeRadius - e.maxBtnRadius,
                    S = g.background || a.background;
                M(S) && (s.fillStyle = S, function(w, y, C, z, x, A) {
                    w.beginPath();
                    var I, $, O = j(90 / Math.PI / C * A),
                        L = z + O,
                        T = x - O;
                    w.arc(0, 0, C, L, T, !1), w.lineTo.apply(w, (I = (z + x) / 2, $ = A / 2 / Math.abs(Math.sin((z - x) / 2)), [+(Math.cos(I) * $).toFixed(8), +(Math.sin(I) * $).toFixed(8)])), w.closePath()
                }(s, e.maxBtnRadius, e.prizeRadius, p - e.prizeAng / 2, p + e.prizeAng / 2, e.getLength(f.gutter)), s.fill());
                var b = Math.cos(p) * e.prizeRadius,
                    k = Math.sin(p) * e.prizeRadius;
                s.translate(b, k), s.rotate(p + j(90)), g.imgs && g.imgs.forEach(function(w, y) {
                    var C = e.ImageCache.get(w.src);
                    if (C) {
                        var z = e.computedWidthAndHeight(C, w, e.prizeAng * e.prizeRadius, m),
                            x = z[0],
                            A = z[1],
                            I = [e.getOffsetX(x) + e.getLength(w.left, h), e.getLength(w.top, m)],
                            $ = I[0],
                            O = I[1];
                        e.drawImage(s, C, $, O, x, A)
                    }
                }), g.fonts && g.fonts.forEach(function(w) {
                    var y = w.fontColor || a.fontColor,
                        C = w.fontWeight || a.fontWeight,
                        z = e.getLength(w.fontSize || a.fontSize),
                        x = w.fontStyle || a.fontStyle,
                        A = U(w, "wordWrap") ? w.wordWrap : a.wordWrap,
                        I = w.lengthLimit || a.lengthLimit,
                        $ = w.lineClamp || a.lineClamp;
                    s.fillStyle = y, s.font = C + " " + (z >> 0) + "px " + x;
                    var O = String(w.text);
                    (A ? dt(s, ft(O), function(L) {
                        var T = (e.prizeRadius - v(w, m, L.length)) * Math.tan(e.prizeAng / 2) * 2 - e.getLength(f.gutter);
                        return e.getLength(I, T)
                    }, $) : O.split(`
`)).filter(function(L) {
                        return !!L
                    }).forEach(function(L, T) {
                        s.fillText(L, u(w, L), v(w, m, T))
                    })
                }), s.rotate(j(360) - p - j(90)), s.translate(-b, -k)
            }), s.restore(), this.buttons.forEach(function(g, d) {
                var p = e.getLength(g.radius, e.prizeRadius);
                e.maxBtnRadius = Math.max(e.maxBtnRadius, p), M(g.background) && (s.beginPath(), s.fillStyle = g.background, s.arc(0, 0, p, 0, 2 * Math.PI, !1), s.fill()), g.pointer && M(g.background) && (s.beginPath(), s.fillStyle = g.background, s.moveTo(-p, 0), s.lineTo(p, 0), s.lineTo(0, 2 * -p), s.closePath(), s.fill()), g.imgs && g.imgs.forEach(function(m, S) {
                    var b = e.ImageCache.get(m.src);
                    if (b) {
                        var k = e.computedWidthAndHeight(b, m, 2 * p, 2 * p),
                            w = k[0],
                            y = k[1],
                            C = [e.getOffsetX(w) + e.getLength(m.left, p), e.getLength(m.top, p)],
                            z = C[0],
                            x = C[1];
                        e.drawImage(s, b, z, x, w, y)
                    }
                }), g.fonts && g.fonts.forEach(function(m) {
                    var S = m.fontColor || a.fontColor,
                        b = m.fontWeight || a.fontWeight,
                        k = e.getLength(m.fontSize || a.fontSize),
                        w = m.fontStyle || a.fontStyle;
                    s.fillStyle = S, s.font = b + " " + (k >> 0) + "px " + w, String(m.text).split(`
`).forEach(function(y, C) {
                        s.fillText(y, u(m, y), v(m, p, C))
                    })
                })
            }), (i = c.afterDraw) === null || i === void 0 || i.call(this, s)
        }, n.prototype.carveOnGunwaleOfAMovingBoat = function() {
            var t = this,
                i = t._defaultConfig,
                e = t.prizeFlag,
                r = t.prizeDeg,
                c = t.rotateDeg;
            this.endTime = Date.now();
            for (var s = this.stopDeg = c, f = i.speed, a = (Math.random() * r - r / 2) * this.getLength(i.stopRange), h = 0, l = 0, u = 0; ++h;) {
                var v = 360 * h - e * r - c - i.offsetDegree + a - r / 2,
                    g = Y(this.FPS, s, v, i.decelerationTime) - s;
                if (g > f) {
                    this.endDeg = f - l > g - f ? v : u;
                    break
                }
                u = v, l = g
            }
        }, n.prototype.play = function() {
            var t, i;
            this.step === 0 && (this.startTime = Date.now(), this.prizeFlag = void 0, this.step = 1, (i = (t = this.config).afterStart) === null || i === void 0 || i.call(t), this.run())
        }, n.prototype.stop = function(t) {
            if (this.step !== 0 && this.step !== 3) {
                if (!t && t !== 0) {
                    var i = this.prizes.map(function(e) {
                        return e.range
                    });
                    t = It(i)
                }
                t < 0 ? (this.step = 0, this.prizeFlag = -1) : (this.step = 2, this.prizeFlag = t % this.prizes.length)
            }
        }, n.prototype.run = function(t) {
            var i;
            t === void 0 && (t = 0);
            var e = this,
                r = e.rAF,
                c = e.step,
                s = e.prizeFlag,
                f = e._defaultConfig,
                a = f.accelerationTime,
                h = f.decelerationTime,
                l = f.speed;
            if (c !== 0) {
                if (s !== -1) {
                    c !== 3 || this.endDeg || this.carveOnGunwaleOfAMovingBoat();
                    var u = Date.now() - this.startTime,
                        v = Date.now() - this.endTime,
                        g = this.rotateDeg;
                    if (c === 1 || u < a) {
                        this.FPS = u / t;
                        var d = gt(u, 0, l, a);
                        d === l && (this.step = 2), g += d % 360
                    } else c === 2 ? (g += l % 360, s !== void 0 && s >= 0 && (this.step = 3, this.stopDeg = 0, this.endDeg = 0)) : c === 3 ? (g = Y(v, this.stopDeg, this.endDeg, h), v >= h && (this.step = 0)) : this.stop(-1);
                    this.rotateDeg = g, this.draw(), r(this.run.bind(this, t + 1))
                }
            } else(i = this.endCallback) === null || i === void 0 || i.call(this, this.prizes.find(function(p, m) {
                return m === s
            }) || {})
        }, n.prototype.conversionAxis = function(t, i) {
            var e = this.config;
            return [t / e.dpr - this.Radius, i / e.dpr - this.Radius]
        }, n
    }(pt),
    Mt = function(o) {
        function n(t, i) {
            var e, r = o.call(this, t, {
                width: i.width,
                height: i.height
            }) || this;
            return r.rows = 3, r.cols = 3, r.blocks = [], r.prizes = [], r.buttons = [], r.defaultConfig = {}, r.defaultStyle = {}, r.activeStyle = {}, r._defaultConfig = {}, r._defaultStyle = {}, r._activeStyle = {}, r.cellWidth = 0, r.cellHeight = 0, r.startTime = 0, r.endTime = 0, r.currIndex = 0, r.stopIndex = 0, r.endIndex = 0, r.demo = !1, r.timer = 0, r.FPS = 16.6, r.step = 0, r.prizeFlag = -1, r.cells = [], r.ImageCache = new Map, r.initData(i), r.initWatch(), r.initComputed(), (e = t.beforeCreate) === null || e === void 0 || e.call(r), r.init(), r
        }
        return ut(n, o), n.prototype.resize = function() {
            var t, i;
            o.prototype.resize.call(this), this.draw(), (i = (t = this.config).afterResize) === null || i === void 0 || i.call(t)
        }, n.prototype.initLucky = function() {
            this.cellWidth = 0, this.cellHeight = 0, this.startTime = 0, this.endTime = 0, this.currIndex = 0, this.stopIndex = 0, this.endIndex = 0, this.demo = !1, this.timer = 0, this.FPS = 16.6, this.prizeFlag = -1, this.step = 0, o.prototype.initLucky.call(this)
        }, n.prototype.initData = function(t) {
            this.$set(this, "width", t.width || "300px"), this.$set(this, "height", t.height || "300px"), this.$set(this, "rows", Number(t.rows) || 3), this.$set(this, "cols", Number(t.cols) || 3), this.$set(this, "blocks", t.blocks || []), this.$set(this, "prizes", t.prizes || []), this.$set(this, "buttons", t.buttons || []), this.$set(this, "button", t.button), this.$set(this, "defaultConfig", t.defaultConfig || {}), this.$set(this, "defaultStyle", t.defaultStyle || {}), this.$set(this, "activeStyle", t.activeStyle || {}), this.$set(this, "startCallback", t.start), this.$set(this, "endCallback", t.end)
        }, n.prototype.initComputed = function() {
            var t = this;
            this.$computed(this, "_defaultConfig", function() {
                var i = R({
                    gutter: 5,
                    speed: 20,
                    accelerationTime: 2500,
                    decelerationTime: 2500
                }, t.defaultConfig);
                return i.gutter = t.getLength(i.gutter), i.speed = i.speed / 40, i
            }), this.$computed(this, "_defaultStyle", function() {
                return R({
                    borderRadius: 20,
                    fontColor: "#000",
                    fontSize: "18px",
                    fontStyle: "sans-serif",
                    fontWeight: "400",
                    background: "rgba(0,0,0,0)",
                    shadow: "",
                    wordWrap: !0,
                    lengthLimit: "90%"
                }, t.defaultStyle)
            }), this.$computed(this, "_activeStyle", function() {
                return R({
                    background: "#ffce98",
                    shadow: ""
                }, t.activeStyle)
            })
        }, n.prototype.initWatch = function() {
            var t = this;
            this.$watch("width", function(i) {
                t.data.width = i, t.resize()
            }), this.$watch("height", function(i) {
                t.data.height = i, t.resize()
            }), this.$watch("blocks", function(i) {
                t.initImageCache()
            }, {
                deep: !0
            }), this.$watch("prizes", function(i) {
                t.initImageCache()
            }, {
                deep: !0
            }), this.$watch("buttons", function(i) {
                t.initImageCache()
            }, {
                deep: !0
            }), this.$watch("rows", function() {
                return t.init()
            }), this.$watch("cols", function() {
                return t.init()
            }), this.$watch("defaultConfig", function() {
                return t.draw()
            }, {
                deep: !0
            }), this.$watch("defaultStyle", function() {
                return t.draw()
            }, {
                deep: !0
            }), this.$watch("activeStyle", function() {
                return t.draw()
            }, {
                deep: !0
            }), this.$watch("startCallback", function() {
                return t.init()
            }), this.$watch("endCallback", function() {
                return t.init()
            })
        }, n.prototype.init = function() {
            var t, i;
            return D(this, void 0, void 0, function() {
                var e;
                return H(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return this.initLucky(), e = this.config, (t = e.beforeInit) === null || t === void 0 || t.call(this), this.draw(), [4, this.initImageCache()];
                        case 1:
                            return r.sent(), (i = e.afterInit) === null || i === void 0 || i.call(this), [2]
                    }
                })
            })
        }, n.prototype.initImageCache = function() {
            var t = this;
            return new Promise(function(i) {
                var e = t.buttons.map(function(c) {
                    return c.imgs
                });
                t.button && e.push(t.button.imgs);
                var r = {
                    blocks: t.blocks.map(function(c) {
                        return c.imgs
                    }),
                    prizes: t.prizes.map(function(c) {
                        return c.imgs
                    }),
                    buttons: e
                };
                Object.keys(r).forEach(function(c) {
                    var s = r[c],
                        f = [];
                    s && s.forEach(function(a, h) {
                        a && a.forEach(function(l, u) {
                            f.push(t.loadAndCacheImg(c, h, u))
                        })
                    }), Promise.all(f).then(function() {
                        t.draw(), i()
                    })
                })
            })
        }, n.prototype.handleClick = function(t) {
            var i = this,
                e = this.ctx;
            q(q([], this.buttons), [this.button]).forEach(function(r) {
                var c;
                if (r) {
                    var s = i.getGeometricProperty([r.x, r.y, r.col || 1, r.row || 1]),
                        f = s[0],
                        a = s[1],
                        h = s[2],
                        l = s[3];
                    e.beginPath(), e.rect(f, a, h, l), e.isPointInPath(t.offsetX, t.offsetY) && i.step === 0 && (typeof r.callback == "function" && r.callback.call(i, r), (c = i.startCallback) === null || c === void 0 || c.call(i, t, r))
                }
            })
        }, n.prototype.loadAndCacheImg = function(t, i, e) {
            return D(this, void 0, void 0, function() {
                var r = this;
                return H(this, function(c) {
                    return [2, new Promise(function(s, f) {
                        var a = r[t][i];
                        if (t === "buttons" && !r.buttons.length && r.button && (a = r.button), a && a.imgs) {
                            var h = a.imgs[e];
                            if (h) {
                                var l = [r.loadImg(h.src, h), h.activeSrc && r.loadImg(h.activeSrc, h, "$activeResolve")];
                                Promise.all(l).then(function(u) {
                                    var v = u[0],
                                        g = u[1];
                                    return D(r, void 0, void 0, function() {
                                        var d;
                                        return H(this, function(p) {
                                            switch (p.label) {
                                                case 0:
                                                    return typeof(d = h.formatter) != "function" ? [3, 3] : [4, Promise.resolve(d.call(this, v))];
                                                case 1:
                                                    return v = p.sent(), g ? [4, Promise.resolve(d.call(this, g))] : [3, 3];
                                                case 2:
                                                    g = p.sent(), p.label = 3;
                                                case 3:
                                                    return this.ImageCache.set(h.src, v), g && this.ImageCache.set(h.activeSrc, g), s(), [2]
                                            }
                                        })
                                    })
                                }).catch(function(u) {
                                    console.error(t + "[" + i + "].imgs[" + e + "] " + u), f()
                                })
                            }
                        }
                    })]
                })
            })
        }, n.prototype.draw = function() {
            var t, i, e = this,
                r = this,
                c = r.config,
                s = r.ctx,
                f = r._defaultConfig,
                a = r._defaultStyle,
                h = r._activeStyle;
            (t = c.beforeDraw) === null || t === void 0 || t.call(this, s), s.clearRect(0, 0, this.boxWidth, this.boxHeight), this.cells = q(q([], this.prizes), this.buttons), this.button && this.cells.push(this.button), this.cells.forEach(function(l) {
                l.col = l.col || 1, l.row = l.row || 1
            }), this.prizeArea = this.blocks.reduce(function(l, u, v) {
                var g = l.x,
                    d = l.y,
                    p = l.w,
                    m = l.h,
                    S = xt(u, e.getLength.bind(e)),
                    b = S[0],
                    k = S[1],
                    w = S[2],
                    y = S[3],
                    C = u.borderRadius ? e.getLength(u.borderRadius) : 0,
                    z = u.background;
                return M(z) && (s.fillStyle = e.handleBackground(g, d, p, m, z), rt(s, g, d, p, m, C), s.fill()), u.imgs && u.imgs.forEach(function(x, A) {
                    var I = e.ImageCache.get(x.src);
                    if (I) {
                        var $ = e.computedWidthAndHeight(I, x, p, m),
                            O = $[0],
                            L = $[1],
                            T = [e.getOffsetX(O, p) + e.getLength(x.left, p), e.getLength(x.top, m)],
                            F = T[0],
                            N = T[1];
                        e.drawImage(s, I, g + F, d + N, O, L)
                    }
                }), {
                    x: g + w,
                    y: d + b,
                    w: p - w - y,
                    h: m - b - k
                }
            }, {
                x: 0,
                y: 0,
                w: this.boxWidth,
                h: this.boxHeight
            }), this.cellWidth = (this.prizeArea.w - f.gutter * (this.cols - 1)) / this.cols, this.cellHeight = (this.prizeArea.h - f.gutter * (this.rows - 1)) / this.rows, this.cells.forEach(function(l, u) {
                var v = e.getGeometricProperty([l.x, l.y, l.col, l.row]),
                    g = v[0],
                    d = v[1],
                    p = v[2],
                    m = v[3],
                    S = !1;
                (e.prizeFlag === void 0 || e.prizeFlag > -1) && (S = u === e.currIndex % e.prizes.length >> 0);
                var b = S ? h.background : l.background || a.background;
                if (M(b)) {
                    var k = (S ? h.shadow : l.shadow || a.shadow).replace(/px/g, "").split(",")[0].split(" ").map(function(y, C) {
                        return C < 3 ? Number(y) : y
                    });
                    k.length === 4 && (s.shadowColor = k[3], s.shadowOffsetX = k[0] * c.dpr, s.shadowOffsetY = k[1] * c.dpr, s.shadowBlur = k[2], k[0] > 0 ? p -= k[0] : (p += k[0], g -= k[0]), k[1] > 0 ? m -= k[1] : (m += k[1], d -= k[1])), s.fillStyle = e.handleBackground(g, d, p, m, b);
                    var w = e.getLength(l.borderRadius ? l.borderRadius : a.borderRadius);
                    rt(s, g, d, p, m, w), s.fill(), s.shadowColor = "rgba(0, 0, 0, 0)", s.shadowOffsetX = 0, s.shadowOffsetY = 0, s.shadowBlur = 0
                }
                u >= e.prizes.length && (u -= e.prizes.length), l.imgs && l.imgs.forEach(function(y, C) {
                    var z = e.ImageCache.get(y.src),
                        x = e.ImageCache.get(y.activeSrc);
                    if (z) {
                        var A = S && x || z;
                        if (A) {
                            var I = e.computedWidthAndHeight(A, y, p, m),
                                $ = I[0],
                                O = I[1],
                                L = [g + e.getOffsetX($, p) + e.getLength(y.left, p), d + e.getLength(y.top, m)],
                                T = L[0],
                                F = L[1];
                            e.drawImage(s, A, T, F, $, O)
                        }
                    }
                }), l.fonts && l.fonts.forEach(function(y) {
                    var C = S && h.fontStyle ? h.fontStyle : y.fontStyle || a.fontStyle,
                        z = S && h.fontWeight ? h.fontWeight : y.fontWeight || a.fontWeight,
                        x = S && h.fontSize ? e.getLength(h.fontSize) : e.getLength(y.fontSize || a.fontSize),
                        A = S && h.lineHeight ? h.lineHeight : y.lineHeight || a.lineHeight || y.fontSize || a.fontSize,
                        I = U(y, "wordWrap") ? y.wordWrap : a.wordWrap,
                        $ = y.lengthLimit || a.lengthLimit,
                        O = y.lineClamp || a.lineClamp;
                    s.font = z + " " + (x >> 0) + "px " + C, s.fillStyle = S && h.fontColor ? h.fontColor : y.fontColor || a.fontColor;
                    var L = [],
                        T = String(y.text);
                    if (I) {
                        var F = e.getLength($, p);
                        L = dt(s, ft(T), function() {
                            return F
                        }, O)
                    } else L = T.split(`
`);
                    L.forEach(function(N, ot) {
                        s.fillText(N, g + e.getOffsetX(s.measureText(N).width, p) + e.getLength(y.left, p), d + e.getLength(y.top, m) + (ot + 1) * e.getLength(A))
                    })
                })
            }), (i = c.afterDraw) === null || i === void 0 || i.call(this, s)
        }, n.prototype.handleBackground = function(t, i, e, r, c) {
            var s = this.ctx;
            return c.includes("linear-gradient") && (c = function(f, a, h, l, u, v) {
                var g = /linear-gradient\((.+)\)/.exec(v)[1].split(",").map(function(b) {
                        return b.trim()
                    }),
                    d = g.shift(),
                    p = [0, 0, 0, 0];
                if (d.includes("deg")) {
                    var m = function(b) {
                        return Math.tan(b / 180 * Math.PI)
                    };
                    (d = d.slice(0, -3) % 360) >= 0 && d < 45 ? p = [a, h + u, a + l, h + u - l * m(d - 0)] : d >= 45 && d < 90 ? p = [a, h + u, a + l - u * m(d - 45), h] : d >= 90 && d < 135 ? p = [a + l, h + u, a + l - u * m(d - 90), h] : d >= 135 && d < 180 ? p = [a + l, h + u, a, h + l * m(d - 135)] : d >= 180 && d < 225 ? p = [a + l, h, a, h + l * m(d - 180)] : d >= 225 && d < 270 ? p = [a + l, h, a + u * m(d - 225), h + u] : d >= 270 && d < 315 ? p = [a, h, a + u * m(d - 270), h + u] : d >= 315 && d < 360 && (p = [a, h, a + l, h + u - l * m(d - 315)])
                } else d.includes("top") ? p = [a, h + u, a, h] : d.includes("bottom") ? p = [a, h, a, h + u] : d.includes("left") ? p = [a + l, h, a, h] : d.includes("right") && (p = [a, h, a + l, h]);
                var S = f.createLinearGradient.apply(f, p.map(function(b) {
                    return b >> 0
                }));
                return g.reduce(function(b, k, w) {
                    var y = k.split(" ");
                    return y.length === 1 ? b.addColorStop(w, y[0]) : y.length === 2 && b.addColorStop.apply(b, y), b
                }, S)
            }(s, t, i, e, r, c)), c
        }, n.prototype.carveOnGunwaleOfAMovingBoat = function() {
            var t = this,
                i = t._defaultConfig,
                e = t.prizeFlag,
                r = t.currIndex;
            this.endTime = Date.now();
            for (var c = this.stopIndex = r, s = i.speed, f = 0, a = 0, h = 0; ++f;) {
                var l = this.prizes.length * f + e - c,
                    u = Y(this.FPS, c, l, i.decelerationTime) - c;
                if (u > s) {
                    this.endIndex = s - a > u - s ? l : h;
                    break
                }
                h = l, a = u
            }
        }, n.prototype.play = function() {
            var t, i;
            this.step === 0 && (this.startTime = Date.now(), this.prizeFlag = void 0, this.step = 1, (i = (t = this.config).afterStart) === null || i === void 0 || i.call(t), this.run())
        }, n.prototype.stop = function(t) {
            if (this.step !== 0 && this.step !== 3) {
                if (!t && t !== 0) {
                    var i = this.prizes.map(function(e) {
                        return e.range
                    });
                    t = It(i)
                }
                t < 0 ? (this.step = 0, this.prizeFlag = -1) : (this.step = 2, this.prizeFlag = t % this.prizes.length)
            }
        }, n.prototype.run = function(t) {
            var i;
            t === void 0 && (t = 0);
            var e = this,
                r = e.rAF,
                c = e.step,
                s = e.prizes,
                f = e.prizeFlag,
                a = e._defaultConfig,
                h = a.accelerationTime,
                l = a.decelerationTime,
                u = a.speed;
            if (c !== 0) {
                if (f !== -1) {
                    c !== 3 || this.endIndex || this.carveOnGunwaleOfAMovingBoat();
                    var v = Date.now() - this.startTime,
                        g = Date.now() - this.endTime,
                        d = this.currIndex;
                    if (c === 1 || v < h) {
                        this.FPS = v / t;
                        var p = gt(v, .1, u - .1, h);
                        p === u && (this.step = 2), d += p % s.length
                    } else c === 2 ? (d += u % s.length, f !== void 0 && f >= 0 && (this.step = 3, this.stopIndex = 0, this.endIndex = 0)) : c === 3 ? (d = Y(g, this.stopIndex, this.endIndex, l), g >= l && (this.step = 0)) : this.stop(-1);
                    this.currIndex = d, this.draw(), r(this.run.bind(this, t + 1))
                }
            } else(i = this.endCallback) === null || i === void 0 || i.call(this, this.prizes.find(function(m, S) {
                return S === f
            }) || {})
        }, n.prototype.getGeometricProperty = function(t) {
            var i = t[0],
                e = t[1],
                r = t[2],
                c = r === void 0 ? 1 : r,
                s = t[3],
                f = s === void 0 ? 1 : s,
                a = this.cellWidth,
                h = this.cellHeight,
                l = this._defaultConfig.gutter,
                u = [this.prizeArea.x + (a + l) * i, this.prizeArea.y + (h + l) * e];
            return c && f && u.push(a * c + l * (c - 1), h * f + l * (f - 1)), u
        }, n.prototype.conversionAxis = function(t, i) {
            var e = this.config;
            return [t / e.dpr, i / e.dpr]
        }, n
    }(pt),
    jt = function(o) {
        function n(t, i) {
            var e, r = o.call(this, t, {
                width: i.width,
                height: i.height
            }) || this;
            return r.blocks = [], r.prizes = [], r.slots = [], r.defaultConfig = {}, r._defaultConfig = {}, r.defaultStyle = {}, r._defaultStyle = {}, r.endCallback = function() {}, r.cellWidth = 0, r.cellHeight = 0, r.cellAndSpacing = 0, r.widthAndSpacing = 0, r.heightAndSpacing = 0, r.FPS = 16.6, r.scroll = [], r.stopScroll = [], r.endScroll = [], r.startTime = 0, r.endTime = 0, r.step = 0, r.prizeFlag = void 0, r.ImageCache = new Map, r.initData(i), r.initWatch(), r.initComputed(), (e = t.beforeCreate) === null || e === void 0 || e.call(r), r.init(), r
        }
        return ut(n, o), n.prototype.resize = function() {
            var t, i;
            o.prototype.resize.call(this), this.draw(), (i = (t = this.config).afterResize) === null || i === void 0 || i.call(t)
        }, n.prototype.initLucky = function() {
            this.cellWidth = 0, this.cellHeight = 0, this.cellAndSpacing = 0, this.widthAndSpacing = 0, this.heightAndSpacing = 0, this.FPS = 16.6, this.scroll = [], this.stopScroll = [], this.endScroll = [], this.startTime = 0, this.endTime = 0, this.prizeFlag = void 0, this.step = 0, o.prototype.initLucky.call(this)
        }, n.prototype.initData = function(t) {
            this.$set(this, "width", t.width || "300px"), this.$set(this, "height", t.height || "300px"), this.$set(this, "blocks", t.blocks || []), this.$set(this, "prizes", t.prizes || []), this.$set(this, "slots", t.slots || []), this.$set(this, "defaultConfig", t.defaultConfig || {}), this.$set(this, "defaultStyle", t.defaultStyle || {}), this.$set(this, "endCallback", t.end)
        }, n.prototype.initComputed = function() {
            var t = this;
            this.$computed(this, "_defaultConfig", function() {
                var i = R({
                    mode: "vertical",
                    rowSpacing: 0,
                    colSpacing: 5,
                    speed: 20,
                    direction: 1,
                    accelerationTime: 2500,
                    decelerationTime: 2500
                }, t.defaultConfig);
                return i.rowSpacing = t.getLength(i.rowSpacing), i.colSpacing = t.getLength(i.colSpacing), i
            }), this.$computed(this, "_defaultStyle", function() {
                return R({
                    borderRadius: 0,
                    fontColor: "#000",
                    fontSize: "18px",
                    fontStyle: "sans-serif",
                    fontWeight: "400",
                    background: "rgba(0,0,0,0)",
                    wordWrap: !0,
                    lengthLimit: "90%"
                }, t.defaultStyle)
            })
        }, n.prototype.initWatch = function() {
            var t = this;
            this.$watch("width", function(i) {
                t.data.width = i, t.resize()
            }), this.$watch("height", function(i) {
                t.data.height = i, t.resize()
            }), this.$watch("blocks", function(i) {
                t.initImageCache()
            }, {
                deep: !0
            }), this.$watch("prizes", function(i) {
                t.initImageCache()
            }, {
                deep: !0
            }), this.$watch("slots", function(i) {
                t.drawOffscreenCanvas(), t.draw()
            }, {
                deep: !0
            }), this.$watch("defaultConfig", function() {
                return t.draw()
            }, {
                deep: !0
            }), this.$watch("defaultStyle", function() {
                return t.draw()
            }, {
                deep: !0
            }), this.$watch("endCallback", function() {
                return t.init()
            })
        }, n.prototype.init = function() {
            var t, i;
            return D(this, void 0, void 0, function() {
                var e;
                return H(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return this.initLucky(), e = this.config, (t = e.beforeInit) === null || t === void 0 || t.call(this), this.drawOffscreenCanvas(), this.draw(), [4, this.initImageCache()];
                        case 1:
                            return r.sent(), (i = e.afterInit) === null || i === void 0 || i.call(this), [2]
                    }
                })
            })
        }, n.prototype.initImageCache = function() {
            var t = this;
            return new Promise(function(i) {
                var e = {
                    blocks: t.blocks.map(function(r) {
                        return r.imgs
                    }),
                    prizes: t.prizes.map(function(r) {
                        return r.imgs
                    })
                };
                Object.keys(e).forEach(function(r) {
                    var c = e[r],
                        s = [];
                    c && c.forEach(function(f, a) {
                        f && f.forEach(function(h, l) {
                            s.push(t.loadAndCacheImg(r, a, l))
                        })
                    }), Promise.all(s).then(function() {
                        t.drawOffscreenCanvas(), t.draw(), i()
                    })
                })
            })
        }, n.prototype.loadAndCacheImg = function(t, i, e) {
            return D(this, void 0, void 0, function() {
                var r = this;
                return H(this, function(c) {
                    return [2, new Promise(function(s, f) {
                        var a = r[t][i];
                        if (a && a.imgs) {
                            var h = a.imgs[e];
                            h && r.loadImg(h.src, h).then(function(l) {
                                return D(r, void 0, void 0, function() {
                                    return H(this, function(u) {
                                        switch (u.label) {
                                            case 0:
                                                return typeof h.formatter != "function" ? [3, 2] : [4, Promise.resolve(h.formatter.call(this, l))];
                                            case 1:
                                                l = u.sent(), u.label = 2;
                                            case 2:
                                                return this.ImageCache.set(h.src, l), s(), [2]
                                        }
                                    })
                                })
                            }).catch(function(l) {
                                console.error(t + "[" + i + "].imgs[" + e + "] " + l), f()
                            })
                        }
                    })]
                })
            })
        }, n.prototype.drawOffscreenCanvas = function() {
            var t = this,
                i = this._defaultConfig,
                e = this._defaultStyle,
                r = this.drawBlocks(),
                c = r.w,
                s = r.h,
                f = this.prizes.length,
                a = this.displacementWidthOrHeight(),
                h = a.cellWidth,
                l = a.cellHeight,
                u = a.widthAndSpacing,
                v = a.heightAndSpacing,
                g = new Array(f).fill(void 0).map(function(k, w) {
                    return w
                }),
                d = 0,
                p = 0;
            this.slots.forEach(function(k, w) {
                t.scroll[w] === void 0 && (t.scroll[w] = 0), k.order = k.order || g;
                var y = k.order.length;
                d = Math.max(d, c + u * y), p = Math.max(p, s + v * y)
            });
            var m = this.getOffscreenCanvas(d, p),
                S = m._offscreenCanvas,
                b = m._ctx;
            this._offscreenCanvas = S, this.slots.forEach(function(k, w) {
                var y = h * w,
                    C = l * w,
                    z = 0,
                    x = function(P, X) {
                        for (var Q = {}, Z = [], _ = 0; _ < P.length; _++) Q[_] = P[_];
                        for (_ = 0; _ < X.length; _++) {
                            var G = Q[X[_]];
                            G && (Z[_] = G)
                        }
                        return Z
                    }(t.prizes, k.order);
                if (x.length) {
                    x.forEach(function(P, X) {
                        if (P) {
                            k.order[X];
                            var Q = u * X + i.colSpacing / 2,
                                Z = v * X + i.rowSpacing / 2,
                                _ = t.displacement([y, Z, v], [Q, C, u]),
                                G = _[0],
                                st = _[1],
                                Ot = _[2];
                            z += Ot;
                            var mt = P.background || e.background;
                            if (M(mt)) {
                                var Tt = t.getLength(U(P, "borderRadius") ? P.borderRadius : e.borderRadius);
                                rt(b, G, st, h, h, Tt), b.fillStyle = mt, b.fill()
                            }
                            P.imgs && P.imgs.forEach(function(E, wt) {
                                var V = t.ImageCache.get(E.src);
                                if (V) {
                                    var tt = t.computedWidthAndHeight(V, E, h, l),
                                        et = tt[0],
                                        at = tt[1],
                                        it = [G + t.getOffsetX(et, h) + t.getLength(E.left, h), st + t.getLength(E.top, l)],
                                        ht = it[0],
                                        J = it[1];
                                    t.drawImage(b, V, ht, J, et, at)
                                }
                            }), P.fonts && P.fonts.forEach(function(E) {
                                var wt = E.fontStyle || e.fontStyle,
                                    V = E.fontWeight || e.fontWeight,
                                    tt = t.getLength(E.fontSize || e.fontSize),
                                    et = E.lineHeight || e.lineHeight || E.fontSize || e.fontSize,
                                    at = U(E, "wordWrap") ? E.wordWrap : e.wordWrap,
                                    it = E.lengthLimit || e.lengthLimit,
                                    ht = E.lineClamp || e.lineClamp;
                                b.font = V + " " + (tt >> 0) + "px " + wt, b.fillStyle = E.fontColor || e.fontColor;
                                var J = [],
                                    bt = String(E.text);
                                if (at) {
                                    var Et = t.getLength(it, h);
                                    J = dt(b, ft(bt), function() {
                                        return Et
                                    }, ht)
                                } else J = bt.split(`
`);
                                J.forEach(function(kt, Wt) {
                                    b.fillText(kt, G + t.getOffsetX(b.measureText(kt).width, h) + t.getLength(E.left, h), st + t.getLength(E.top, l) + (Wt + 1) * t.getLength(et))
                                })
                            })
                        }
                    });
                    for (var A = t.displacement([y, 0, h, z], [0, C, z, l]), I = A[0], $ = A[1], O = A[2], L = A[3], T = z; T < p + z;) {
                        var F = t.displacement([I, T], [T, $]),
                            N = F[0],
                            ot = F[1];
                        t.drawImage(b, S, I, $, O, L, N, ot, O, L), T += z
                    }
                }
            })
        }, n.prototype.drawBlocks = function() {
            var t = this,
                i = this;
            i.config;
            var e = i.ctx;
            i._defaultConfig;
            var r = i._defaultStyle;
            return this.prizeArea = this.blocks.reduce(function(c, s, f) {
                var a = c.x,
                    h = c.y,
                    l = c.w,
                    u = c.h,
                    v = xt(s, t.getLength.bind(t)),
                    g = v[0],
                    d = v[1],
                    p = v[2],
                    m = v[3],
                    S = s.borderRadius ? t.getLength(s.borderRadius) : 0,
                    b = s.background || r.background;
                return M(b) && (rt(e, a, h, l, u, S), e.fillStyle = b, e.fill()), s.imgs && s.imgs.forEach(function(k, w) {
                    var y = t.ImageCache.get(k.src);
                    if (y) {
                        var C = t.computedWidthAndHeight(y, k, l, u),
                            z = C[0],
                            x = C[1],
                            A = [t.getOffsetX(z, l) + t.getLength(k.left, l), t.getLength(k.top, u)],
                            I = A[0],
                            $ = A[1];
                        t.drawImage(e, y, a + I, h + $, z, x)
                    }
                }), {
                    x: a + p,
                    y: h + g,
                    w: l - p - m,
                    h: u - g - d
                }
            }, {
                x: 0,
                y: 0,
                w: this.boxWidth,
                h: this.boxHeight
            })
        }, n.prototype.draw = function() {
            var t, i = this,
                e = this,
                r = e.config,
                c = e.ctx;
            e._defaultConfig, e._defaultStyle, (t = r.beforeDraw) === null || t === void 0 || t.call(this, c), c.clearRect(0, 0, this.boxWidth, this.boxHeight);
            var s = this.drawBlocks(),
                f = s.x,
                a = s.y,
                h = s.w,
                l = s.h;
            if (this._offscreenCanvas) {
                var u = this,
                    v = u.cellWidth,
                    g = u.cellHeight,
                    d = u.cellAndSpacing,
                    p = u.widthAndSpacing,
                    m = u.heightAndSpacing;
                this.slots.forEach(function(S, b) {
                    var k = d * S.order.length,
                        w = i.displacement(-(l - m) / 2, -(h - p) / 2),
                        y = i.scroll[b] + w;
                    y < 0 && (y = y % k + k), y > k && (y %= k);
                    var C = i.displacement([v * b, y, v, l], [y, g * b, h, g]),
                        z = C[0],
                        x = C[1],
                        A = C[2],
                        I = C[3],
                        $ = i.displacement([f + p * b, a, v, l], [f, a + m * b, h, g]),
                        O = $[0],
                        L = $[1],
                        T = $[2],
                        F = $[3];
                    i.drawImage(c, i._offscreenCanvas, z, x, A, I, O, L, T, F)
                })
            }
        }, n.prototype.carveOnGunwaleOfAMovingBoat = function() {
            var t = this,
                i = this,
                e = i._defaultConfig,
                r = i.prizeFlag,
                c = i.cellAndSpacing;
            this.endTime = Date.now(), this.slots.forEach(function(s, f) {
                var a = s.order;
                if (a.length)
                    for (var h = s.speed || e.speed, l = s.direction || e.direction, u = a.findIndex(function(S) {
                            return S === r[f]
                        }), v = c * a.length, g = t.stopScroll[f] = t.scroll[f], d = 0; ++d;) {
                        var p = c * u + v * d * l - g,
                            m = Y(t.FPS, g, p, e.decelerationTime) - g;
                        if (Math.abs(m) > h) {
                            t.endScroll[f] = p;
                            break
                        }
                    }
            })
        }, n.prototype.play = function() {
            var t, i;
            this.step === 0 && (this.startTime = Date.now(), this.prizeFlag = void 0, this.step = 1, (i = (t = this.config).afterStart) === null || i === void 0 || i.call(t), this.run())
        }, n.prototype.stop = function(t) {
            var i;
            if (this.step !== 0 && this.step !== 3) {
                if (typeof t == "number") this.prizeFlag = new Array(this.slots.length).fill(t);
                else {
                    if (!K(t, "array")) return this.stop(-1), console.error("stop() 无法识别的参数类型 " + typeof t);
                    if (t.length !== this.slots.length) return this.stop(-1), console.error("stop([" + t + "]) 参数长度的不正确");
                    this.prizeFlag = t
                }!((i = this.prizeFlag) === null || i === void 0) && i.includes(-1) ? (this.prizeFlag = [], this.step = 0) : this.step = 2
            }
        }, n.prototype.run = function(t) {
            var i, e, r = this;
            t === void 0 && (t = 0);
            var c = this,
                s = c.rAF,
                f = c.step,
                a = c.prizeFlag,
                h = c._defaultConfig,
                l = c.cellAndSpacing,
                u = c.slots,
                v = h.accelerationTime,
                g = h.decelerationTime;
            if (this.step !== 0 || a ? .length !== u.length) {
                if (a === void 0 || a.length) {
                    this.step !== 3 || this.endScroll.length || this.carveOnGunwaleOfAMovingBoat();
                    var d = Date.now() - this.startTime,
                        p = Date.now() - this.endTime;
                    u.forEach(function(w, y) {
                        var C = w.order;
                        if (C && C.length) {
                            var z = l * C.length,
                                x = Math.abs(w.speed || h.speed),
                                A = w.direction || h.direction,
                                I = 0,
                                $ = r.scroll[y];
                            if (f === 1 || d < v) {
                                r.FPS = d / t;
                                var O = gt(d, 0, x, v);
                                O === x && (r.step = 2), I = ($ + O * A) % z
                            } else if (f === 2) I = ($ + x * A) % z, a ? .length === u.length && (r.step = 3, r.stopScroll = [], r.endScroll = []);
                            else if (f === 3 && p) {
                                var L = r.stopScroll[y],
                                    T = r.endScroll[y];
                                I = Y(p, L, T, g), p >= g && (r.step = 0)
                            }
                            r.scroll[y] = I
                        }
                    }), this.draw(), s(this.run.bind(this, t + 1))
                }
            } else {
                for (var m = a[0], S = 0; S < u.length; S++) {
                    var b = u[S],
                        k = a[S];
                    if (!(!((i = b.order) === null || i === void 0) && i.includes(k)) || m !== k) {
                        m = -1;
                        break
                    }
                }(e = this.endCallback) === null || e === void 0 || e.call(this, this.prizes.find(function(w, y) {
                    return y === m
                }) || void 0)
            }
        }, n.prototype.displacement = function(t, i) {
            return this._defaultConfig.mode === "horizontal" ? i : t
        }, n.prototype.displacementWidthOrHeight = function() {
            var t = this._defaultConfig.mode,
                i = this.slots.length,
                e = this._defaultConfig,
                r = e.colSpacing,
                c = e.rowSpacing,
                s = this.prizeArea || this.drawBlocks();
            s.x, s.y;
            var f, a, h = s.w,
                l = s.h,
                u = 0,
                v = 0;
            return t === "horizontal" ? (v = this.cellHeight = (l - c * (i - 1)) / i, u = this.cellWidth = v) : (u = this.cellWidth = (h - r * (i - 1)) / i, v = this.cellHeight = u), f = this.widthAndSpacing = this.cellWidth + r, a = this.heightAndSpacing = this.cellHeight + c, this.cellAndSpacing = t === "horizontal" ? f : a, {
                cellWidth: u,
                cellHeight: v,
                widthAndSpacing: f,
                heightAndSpacing: a
            }
        }, n
    }(pt),
    vt = function(o, n, t) {
        n === void 0 && (n = {}), zt;
        var i = n.props,
            e = n.domProps,
            r = n.on,
            c = function(a, h) {
                var l = {};
                for (var u in a) Object.prototype.hasOwnProperty.call(a, u) && h.indexOf(u) < 0 && (l[u] = a[u]);
                if (a != null && typeof Object.getOwnPropertySymbols == "function") {
                    var v = 0;
                    for (u = Object.getOwnPropertySymbols(a); v < u.length; v++) h.indexOf(u[v]) < 0 && Object.prototype.propertyIsEnumerable.call(a, u[v]) && (l[u[v]] = a[u[v]])
                }
                return l
            }(n, ["props", "domProps", "on"]),
            s = function(a) {
                return a ? Object.entries(a).reduce(function(h, l) {
                    var u, v = l[0],
                        g = l[1];
                    return v = "on" + (v = v.charAt(0).toUpperCase() + v.slice(1)), W(W({}, h), ((u = {})[v] = g, u))
                }, {}) : null
            }(r),
            f = W(W(W(W({}, c), i), e), s);
        return _t(o, f, t)
    },
    yt = "@lucky-canvas/vue",
    Bt = lt({
        name: "LuckyWheel",
        props: {
            width: {
                type: [String, Number]
            },
            height: {
                type: [String, Number]
            },
            blocks: {
                type: Array,
                default: function() {
                    return []
                }
            },
            prizes: {
                type: Array,
                default: function() {
                    return []
                }
            },
            buttons: {
                type: Array,
                default: function() {
                    return []
                }
            },
            defaultStyle: {
                type: Object,
                default: function() {
                    return {}
                }
            },
            defaultConfig: {
                type: Object,
                default: function() {
                    return {}
                }
            }
        },
        emits: ["start", "end", "success", "error", "finally"],
        watch: {
            blocks: function(o, n) {
                this.lucky && (this.lucky.blocks = o)
            },
            prizes: function(o, n) {
                this.lucky && (this.lucky.prizes = o)
            },
            buttons: function(o, n) {
                this.lucky && (this.lucky.buttons = o)
            }
        },
        data: function() {
            return {
                lucky: null
            }
        },
        mounted: function() {
            this.$refs.myLucky && this.$refs.myLucky.setAttribute("package", yt + "@0.1.11");
            try {
                this.initLucky(), this.$emit("success")
            } catch (o) {
                this.$emit("error", o)
            } finally {
                this.$emit("finally")
            }
        },
        methods: {
            initLucky: function() {
                var o = this;
                this.lucky = new Ht({
                    flag: "WEB",
                    width: String(this.width),
                    height: String(this.height),
                    divElement: this.$refs.myLucky,
                    rAF: window.requestAnimationFrame,
                    setTimeout: window.setTimeout,
                    setInterval: window.setInterval,
                    clearTimeout: window.clearTimeout,
                    clearInterval: window.clearInterval
                }, W(W({}, this.$props), {
                    start: function(n) {
                        o.$emit("start", n)
                    },
                    end: function(n) {
                        o.$emit("end", n)
                    }
                }))
            },
            init: function() {
                this.lucky && this.lucky.init()
            },
            play: function() {
                var o;
                (o = this.lucky) === null || o === void 0 || o.play()
            },
            stop: function(o) {
                var n;
                (n = this.lucky) === null || n === void 0 || n.stop(o)
            }
        },
        render: function() {
            return vt("div", {
                ref: "myLucky"
            })
        }
    }),
    Nt = lt({
        name: "LuckyGrid",
        props: {
            width: {
                type: [String, Number]
            },
            height: {
                type: [String, Number]
            },
            cols: {
                type: [String, Number],
                default: 3
            },
            rows: {
                type: [String, Number],
                default: 3
            },
            blocks: {
                type: Array,
                default: function() {
                    return []
                }
            },
            prizes: {
                type: Array,
                default: function() {
                    return []
                }
            },
            buttons: {
                type: Array,
                default: function() {
                    return []
                }
            },
            button: {
                type: Object
            },
            defaultStyle: {
                type: Object,
                default: function() {
                    return {}
                }
            },
            activeStyle: {
                type: Object,
                default: function() {
                    return {}
                }
            },
            defaultConfig: {
                type: Object,
                default: function() {
                    return {}
                }
            }
        },
        emits: ["start", "end", "success", "error", "finally"],
        watch: {
            cols: function(o, n) {
                this.lucky && (this.lucky.cols = o)
            },
            rows: function(o, n) {
                this.lucky && (this.lucky.rows = o)
            },
            blocks: function(o, n) {
                this.lucky && (this.lucky.blocks = o)
            },
            prizes: function(o, n) {
                this.lucky && (this.lucky.prizes = o)
            },
            buttons: function(o, n) {
                this.lucky && (this.lucky.buttons = o)
            },
            button: function(o, n) {
                this.lucky && (this.lucky.button = o)
            }
        },
        data: function() {
            return {
                lucky: null
            }
        },
        mounted: function() {
            this.$refs.myLucky && this.$refs.myLucky.setAttribute("package", yt + "@0.1.11");
            try {
                this.initLucky(), this.$emit("success")
            } catch (o) {
                this.$emit("error", o)
            } finally {
                this.$emit("finally")
            }
        },
        methods: {
            initLucky: function() {
                var o = this;
                this.lucky = new Mt({
                    flag: "WEB",
                    width: String(this.width),
                    height: String(this.height),
                    divElement: this.$refs.myLucky,
                    rAF: window.requestAnimationFrame,
                    setTimeout: window.setTimeout,
                    setInterval: window.setInterval,
                    clearTimeout: window.clearTimeout,
                    clearInterval: window.clearInterval
                }, W(W({}, this.$props), {
                    start: function(n, t) {
                        o.$emit("start", n, t)
                    },
                    end: function(n) {
                        o.$emit("end", n)
                    }
                }))
            },
            init: function() {
                this.lucky && this.lucky.init()
            },
            play: function() {
                var o;
                (o = this.lucky) === null || o === void 0 || o.play()
            },
            stop: function(o) {
                var n;
                (n = this.lucky) === null || n === void 0 || n.stop(o)
            }
        },
        render: function() {
            return vt("div", {
                ref: "myLucky"
            })
        }
    }),
    Xt = lt({
        name: "SlotMachine",
        props: {
            width: {
                type: [String, Number]
            },
            height: {
                type: [String, Number]
            },
            blocks: {
                type: Array,
                default: function() {
                    return []
                }
            },
            prizes: {
                type: Array,
                default: function() {
                    return []
                }
            },
            slots: {
                type: Array,
                default: function() {
                    return []
                }
            },
            defaultStyle: {
                type: Object,
                default: function() {
                    return {}
                }
            },
            defaultConfig: {
                type: Object,
                default: function() {
                    return {}
                }
            }
        },
        watch: {
            blocks: function(o, n) {
                this.lucky && (this.lucky.blocks = o)
            },
            slots: function(o, n) {
                this.lucky && (this.lucky.slots = o)
            },
            prizes: function(o, n) {
                this.lucky && (this.lucky.prizes = o)
            }
        },
        data: function() {
            return {
                lucky: null
            }
        },
        mounted: function() {
            this.$refs.myLucky && this.$refs.myLucky.setAttribute("package", yt + "@0.1.11");
            try {
                this.initLucky(), this.$emit("success")
            } catch (o) {
                this.$emit("error", o)
            } finally {
                this.$emit("finally")
            }
        },
        methods: {
            initLucky: function() {
                var o = this;
                this.lucky = new jt({
                    flag: "WEB",
                    width: String(this.width),
                    height: String(this.height),
                    divElement: this.$refs.myLucky,
                    rAF: window.requestAnimationFrame,
                    setTimeout: window.setTimeout,
                    setInterval: window.setInterval,
                    clearTimeout: window.clearTimeout,
                    clearInterval: window.clearInterval
                }, W(W({}, this.$props), {
                    start: function(n) {
                        o.$emit("start", n)
                    },
                    end: function(n) {
                        o.$emit("end", n)
                    }
                }))
            },
            init: function() {
                this.lucky && this.lucky.init()
            },
            play: function() {
                var o;
                (o = this.lucky) === null || o === void 0 || o.play()
            },
            stop: function(o) {
                var n;
                (n = this.lucky) === null || n === void 0 || n.stop(o)
            }
        },
        render: function() {
            return vt("div", {
                ref: "myLucky"
            })
        }
    }),
    Lt = function(o) {
        o.component("LuckyWheel", Bt), o.component("LuckyGrid", Nt), o.component("SlotMachine", Xt)
    };
typeof window < "u" && window.Vue && zt && Lt(window.Vue);
var Ut = {
    install: Lt
};
export {
    Ut as j
};