import {
    S as w,
    d as L
} from "./vant.be74fb7c.js";
import {
    f as R,
    r as S,
    j as U,
    aa as j,
    ab as z,
    o as r,
    c as f,
    U as g,
    S as _,
    P as I,
    a3 as O,
    R as P,
    u as V,
    a as o,
    L as $,
    V as B,
    O as D
} from "./@vue.16908cbf.js";
import {
    $ as E,
    o as F,
    g as M,
    __tla as N
} from "./index.0a674315.js";
import "./@vant.359a3f91.js";
import "./axios.4a70c6fc.js";
import "./vuex.7fead168.js";
import "./vue-router.d17f0860.js";
import "./element-plus.c133b52b.js";
import "./dayjs.42829e09.js";
import "./clipboard.f53621db.js";
import "./@element-plus.c1fd9846.js";
import "./@vueuse.da2de41b.js";
import "./lodash-es.0b530f8e.js";
import "./@ctrl.f8748455.js";
import "./@popperjs.c45de710.js";
import "./vue-i18n.d9454f26.js";
import "./@intlify.7347860c.js";
import "./nprogress.1adef0ba.js";
import "./xe-utils.0e898ace.js";
import "./crypto-js.bfe2481f.js";
import "./decimal.js.d133ee8e.js";
import "./@fingerprintjs.bfff8371.js";
import "./tslib.521c7ea7.js";
import "./vh-check.e6149712.js";
import "./vue-lazyload.38f311e8.js";
import "./@lucky-canvas.861f1f96.js";
import "./vue-demi.71ba0ef2.js";
import "./vue-dragscroll.ace105ad.js";
let h, q = Promise.all([(() => {
    try {
        return N
    } catch {}
})()]).then(async () => {
    let e, l, p, m, n;
    e = {
        key: 0,
        class: "fixed-banner"
    }, l = {
        class: "fixed-banner-box"
    }, p = {
        class: "img"
    }, m = ["onClick"], n = {
        class: "close"
    }, h = {
        __name: "fixed_banner",
        setup(A) {
            const t = R([]),
                c = S(0),
                y = a => ({
                    loading: new URL("/img/colors/" + M() + "/default_large.png",
                        import.meta.url).href,
                    src: a.image
                });
            U(() => {
                E.get("/user/site/banners", {
                    type: 4
                }).then(a => {
                    if (a.code === 0) {
                        let {
                            list: s,
                            time: i
                        } = a.data;
                        s.length && (t.push(...s), c.value = i)
                    }
                })
            });
            const v = a => {
                t.splice(a, 1)
            };
            return (a, s) => {
                const i = j("svg-icon"),
                    b = w,
                    k = L,
                    x = z("lazy");
                return t.length ? (r(), f("div", e, [g(k, {
                    class: "fixed-swipe",
                    autoplay: c.value * 1e3,
                    "show-indicators": !1,
                    "stop-propagation": !1
                }, {
                    default: _(() => [(r(!0), f(I, null, O(t, (u, d) => (r(), P(b, {
                        key: d,
                        onClick: C => V(F)(u)
                    }, {
                        default: _(() => [o("div", l, [$(o("img", p, null, 512), [
                            [x, y(u)]
                        ]), o("div", {
                            class: "closeIcon",
                            onClick: B(C => v(d), ["stop"])
                        }, [o("div", n, [g(i, {
                            iconClass: "close"
                        })])], 8, m)])]),
                        _: 2
                    }, 1032, ["onClick"]))), 128))]),
                    _: 1
                }, 8, ["autoplay"])])) : D("", !0)
            }
        }
    }
});
export {
    q as __tla, h as
    default
};