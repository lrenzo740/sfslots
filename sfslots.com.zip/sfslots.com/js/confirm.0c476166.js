import {
    u as T
} from "./vuex.7fead168.js";
import {
    u as p
} from "./vue-i18n.d9454f26.js";
import {
    f as B,
    j as b,
    a7 as C,
    ab as y,
    u as o,
    o as f,
    c as _,
    a as n,
    W as c,
    L as h,
    Q as D,
    a4 as g,
    O as j
} from "./@vue.16908cbf.js";
import "./@intlify.7347860c.js";

function k() {
    const d = T(),
        {
            t
        } = p(),
        e = B({
            visible: !1,
            title: "Tips",
            message: "",
            cancelButtonText: t("common.cancel"),
            confirmButtonText: t("common.confirm"),
            resolve: "",
            reject: "",
            isCancel: !1
        }),
        a = async () => {
            e.isCancel = !0, await e.reject(), e.isCancel = !1, e.visible = !1
        },
        i = async () => {
            await e.resolve(), e.visible = !1
        },
        l = (r = "", m = "Tips", s = {
            confirmText: t("common.confirm"),
            cancelText: t("common.cancel")
        }, u = () => {}, v = () => {}) => {
            e.visible = !0, e.title = m, e.message = r, e.cancelButtonText = s.cancelText, e.confirmButtonText = s.confirmText, e.resolve = u, e.reject = v
        };
    return b(() => {
        globalVBus.$on("handleConfirm", l)
    }), { ...C(e),
        store: d,
        cancel: a,
        handleConfirm: i
    }
}
const w = {
        key: 0,
        class: "confirm-dialog"
    },
    V = {
        class: "confirm-dialog-box"
    },
    N = {
        class: "confirm-dialog-box__header"
    },
    S = {
        class: "confirm-dialog-box__content"
    },
    z = {
        class: "confirm-dialog-box__footer"
    },
    E = {
        class: "confirmBtn"
    },
    O = {
        __name: "confirm",
        setup(d) {
            const {
                visible: t,
                title: e,
                message: a,
                cancelButtonText: i,
                confirmButtonText: l,
                isCancel: r,
                cancel: m,
                handleConfirm: s
            } = k();
            return (u, v) => {
                const x = y("throttle");
                return o(t) ? (f(), _("div", w, [n("div", V, [n("div", N, c(o(e)), 1), n("div", S, c(o(a)), 1), n("div", z, [h((f(), _("div", {
                    class: D(["cancelBtn", {
                        hover: o(r)
                    }])
                }, [g(c(o(i)), 1)], 2)), [
                    [x, o(m), "loading"]
                ]), h((f(), _("div", E, [g(c(o(l)), 1)])), [
                    [x, o(s), "loading"]
                ])])])])) : j("", !0)
            }
        }
    };
export {
    O as
    default
};