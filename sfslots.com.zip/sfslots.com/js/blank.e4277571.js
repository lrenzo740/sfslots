const n = "/png/skin0_blank.596af76e.png",
    p = "/png/blank.949e62d0.png";
export {
    n as _, p as a
};